.class public final synthetic Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda21;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Linv/exe/systemui/qs/controller/InvQsPanelController;


# direct methods
.method public synthetic constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda21;->f$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 2

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda21;->f$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-virtual {p0, p1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->showNativeMediaOutputDialog(Landroid/view/View;)V

    return-void
.end method
