.class public Linv/exe/systemui/qs/controller/InvQsPanelController$1$1;
.super Ljava/lang/Object;
.source "QsPanelController.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Linv/exe/systemui/qs/controller/InvQsPanelController$1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field public final synthetic this$1:Linv/exe/systemui/qs/controller/InvQsPanelController$1;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController$1;)V
    .registers 2

    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$1$1;->this$1:Linv/exe/systemui/qs/controller/InvQsPanelController$1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$1$1;->this$1:Linv/exe/systemui/qs/controller/InvQsPanelController$1;

    iget-object v0, v0, Linv/exe/systemui/qs/controller/InvQsPanelController$1;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$14(Linv/exe/systemui/qs/controller/InvQsPanelController;)Z

    move-result v1

    if-nez v1, :cond_d

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$11(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    :cond_d
    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$12(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    invoke-virtual {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->updateResources()V

    return-void
.end method
