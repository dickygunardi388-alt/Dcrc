.class public final synthetic Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda12;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "b849e8a9f6cceff267251a73644faacc801ad726cc8f22a9c323c56a203f5446"
.end annotation


# instance fields
.field public final synthetic f$0:Linv/exe/systemui/qs/controller/InvQsPanelController;


# direct methods
.method public synthetic constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda12;->f$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 2

    .line 0
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda12;->f$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-virtual {p0, p1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->lambda$6$inv-exe-systemui-qs-QsPanelController(Landroid/view/View;)V

    return-void
.end method
