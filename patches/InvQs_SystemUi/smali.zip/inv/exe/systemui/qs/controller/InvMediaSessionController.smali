.class public final Linv/exe/systemui/qs/controller/InvMediaSessionController;
.super Ljava/lang/Object;
.source "MediaSessionController.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Linv/exe/systemui/qs/controller/InvMediaSessionController$Callback;
    }
.end annotation


# static fields
.field public static final ROUTE_BLUETOOTH:I = 0x2

.field public static final ROUTE_HEADSET:I = 0x1

.field public static final ROUTE_REMOTE:I = 0x3

.field public static final ROUTE_SPEAKER:I


# instance fields
.field private final artworkExecutor:Ljava/util/concurrent/ExecutorService;

.field private final audioDeviceCallback:Landroid/media/AudioDeviceCallback;

.field private final audioManager:Landroid/media/AudioManager;

.field private callback:Linv/exe/systemui/qs/controller/InvMediaSessionController$Callback;

.field private final context:Landroid/content/Context;

.field private final controllerCallback:Landroid/media/session/MediaController$Callback;

.field private current:Landroid/media/session/MediaController;

.field private listenerRegistered:Z

.field private loadingArtworkUri:Ljava/lang/String;

.field private final mainHandler:Landroid/os/Handler;

.field private final manager:Landroid/media/session/MediaSessionManager;

.field private resolvedArtwork:Landroid/graphics/Bitmap;

.field private resolvedArtworkUri:Ljava/lang/String;

.field private final sessionsListener:Landroid/media/session/MediaSessionManager$OnActiveSessionsChangedListener;

.field private shuffleCompatMode:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 4

    .line 95
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 50
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->mainHandler:Landroid/os/Handler;

    .line 51
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->artworkExecutor:Ljava/util/concurrent/ExecutorService;

    .line 63
    new-instance v0, Linv/exe/systemui/qs/controller/InvMediaSessionController$1;

    invoke-direct {v0, p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController$1;-><init>(Linv/exe/systemui/qs/controller/InvMediaSessionController;)V

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->controllerCallback:Landroid/media/session/MediaController$Callback;

    .line 79
    new-instance v0, Linv/exe/systemui/qs/controller/InvMediaSessionController$2;

    invoke-direct {v0, p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController$2;-><init>(Linv/exe/systemui/qs/controller/InvMediaSessionController;)V

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->sessionsListener:Landroid/media/session/MediaSessionManager$OnActiveSessionsChangedListener;

    .line 85
    new-instance v0, Linv/exe/systemui/qs/controller/InvMediaSessionController$3;

    invoke-direct {v0, p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController$3;-><init>(Linv/exe/systemui/qs/controller/InvMediaSessionController;)V

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->audioDeviceCallback:Landroid/media/AudioDeviceCallback;

    .line 96
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->context:Landroid/content/Context;

    .line 97
    const-string v0, "media_session"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/session/MediaSessionManager;

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->manager:Landroid/media/session/MediaSessionManager;

    .line 98
    const-string v0, "audio"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/media/AudioManager;

    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->audioManager:Landroid/media/AudioManager;

    return-void
.end method

.method public static synthetic access$0(Linv/exe/systemui/qs/controller/InvMediaSessionController;)V
    .registers 1

    .line 639
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->clearArtworkCache()V

    return-void
.end method

.method public static synthetic access$1(Linv/exe/systemui/qs/controller/InvMediaSessionController;)V
    .registers 1

    .line 227
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->notifyChanged()V

    return-void
.end method

.method public static synthetic access$2(Linv/exe/systemui/qs/controller/InvMediaSessionController;Ljava/util/List;)V
    .registers 2

    .line 167
    invoke-direct {p0, p1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->selectBest(Ljava/util/List;)V

    return-void
.end method

.method public static synthetic access$3(Linv/exe/systemui/qs/controller/InvMediaSessionController;Ljava/lang/String;)Landroid/graphics/Bitmap;
    .registers 2

    .line 604
    invoke-direct {p0, p1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->decodeBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic access$4(Linv/exe/systemui/qs/controller/InvMediaSessionController;)Landroid/os/Handler;
    .registers 1

    .line 50
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->mainHandler:Landroid/os/Handler;

    return-object p0
.end method

.method public static synthetic access$5(Linv/exe/systemui/qs/controller/InvMediaSessionController;)Landroid/media/session/MediaController;
    .registers 1

    .line 57
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    return-object p0
.end method

.method public static synthetic access$6(Linv/exe/systemui/qs/controller/InvMediaSessionController;Ljava/lang/String;)V
    .registers 2

    .line 60
    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->loadingArtworkUri:Ljava/lang/String;

    return-void
.end method

.method public static synthetic access$7(Linv/exe/systemui/qs/controller/InvMediaSessionController;Ljava/lang/String;)V
    .registers 2

    .line 59
    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->resolvedArtworkUri:Ljava/lang/String;

    return-void
.end method

.method public static synthetic access$8(Linv/exe/systemui/qs/controller/InvMediaSessionController;Landroid/graphics/Bitmap;)V
    .registers 2

    .line 61
    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->resolvedArtwork:Landroid/graphics/Bitmap;

    return-void
.end method

.method private clearArtworkCache()V
    .registers 2

    const/4 v0, 0x0

    .line 640
    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->resolvedArtworkUri:Ljava/lang/String;

    .line 641
    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->loadingArtworkUri:Ljava/lang/String;

    .line 642
    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->resolvedArtwork:Landroid/graphics/Bitmap;

    return-void
.end method

.method private decodeBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;
    .registers 6

    const/4 v0, 0x0

    .line 607
    :try_start_1
    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    .line 608
    invoke-virtual {v1}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_31

    .line 610
    const-string v3, "http"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_1b

    const-string v3, "https"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_31

    .line 611
    :cond_1b
    new-instance p0, Ljava/net/URL;

    invoke-direct {p0, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p0

    const/16 p1, 0xdac

    .line 612
    invoke-virtual {p0, p1}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    .line 613
    invoke-virtual {p0, p1}, Ljava/net/URLConnection;->setReadTimeout(I)V

    .line 614
    invoke-virtual {p0}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object p0

    goto :goto_3b

    .line 616
    :cond_31
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->context:Landroid/content/Context;

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    invoke-virtual {p0, v1}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object p0
    :try_end_3b
    .catchall {:try_start_1 .. :try_end_3b} :catchall_49

    .line 618
    :goto_3b
    :try_start_3b
    invoke-static {p0}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object p1

    .line 619
    invoke-static {p1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->scaleArtwork(Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;

    move-result-object p1
    :try_end_43
    .catchall {:try_start_3b .. :try_end_43} :catchall_4a

    if-eqz p0, :cond_48

    .line 624
    :try_start_45
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_48
    .catchall {:try_start_45 .. :try_end_48} :catchall_48

    :catchall_48
    :cond_48
    return-object p1

    :catchall_49
    move-object p0, v0

    :catchall_4a
    if-eqz p0, :cond_4f

    :try_start_4c
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_4f
    .catchall {:try_start_4c .. :try_end_4f} :catchall_4f

    :catchall_4f
    :cond_4f
    return-object v0
.end method

.method private ensureAudioDeviceCallback()V
    .registers 3

    .line 135
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->audioManager:Landroid/media/AudioManager;

    if-nez v0, :cond_5

    goto :goto_c

    .line 136
    :cond_5
    :try_start_5
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->audioDeviceCallback:Landroid/media/AudioDeviceCallback;

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->mainHandler:Landroid/os/Handler;

    invoke-virtual {v0, v1, p0}, Landroid/media/AudioManager;->registerAudioDeviceCallback(Landroid/media/AudioDeviceCallback;Landroid/os/Handler;)V
    :try_end_c
    .catchall {:try_start_5 .. :try_end_c} :catchall_c

    :catchall_c
    :goto_c
    return-void
.end method

.method private ensureSessionsListener()V
    .registers 5

    .line 152
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->manager:Landroid/media/session/MediaSessionManager;

    if-eqz v0, :cond_18

    iget-boolean v1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->listenerRegistered:Z

    if-eqz v1, :cond_9

    goto :goto_18

    .line 154
    :cond_9
    :try_start_9
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->sessionsListener:Landroid/media/session/MediaSessionManager$OnActiveSessionsChangedListener;

    iget-object v2, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->mainHandler:Landroid/os/Handler;

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v3, v2}, Landroid/media/session/MediaSessionManager;->addOnActiveSessionsChangedListener(Landroid/media/session/MediaSessionManager$OnActiveSessionsChangedListener;Landroid/content/ComponentName;Landroid/os/Handler;)V

    const/4 v0, 0x1

    .line 155
    iput-boolean v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->listenerRegistered:Z
    :try_end_14
    .catchall {:try_start_9 .. :try_end_14} :catchall_15

    return-void

    :catchall_15
    const/4 v0, 0x0

    .line 157
    iput-boolean v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->listenerRegistered:Z

    :cond_18
    :goto_18
    return-void
.end method

.method private static varargs firstBitmap(Landroid/media/MediaMetadata;[Ljava/lang/String;)Landroid/graphics/Bitmap;
    .registers 6

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 572
    :cond_4
    array-length v1, p1

    const/4 v2, 0x0

    :goto_6
    if-lt v2, v1, :cond_9

    return-object v0

    :cond_9
    aget-object v3, p1, v2

    .line 574
    :try_start_b
    invoke-virtual {p0, v3}, Landroid/media/MediaMetadata;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v3
    :try_end_f
    .catchall {:try_start_b .. :try_end_f} :catchall_12

    if-eqz v3, :cond_12

    return-object v3

    :catchall_12
    :cond_12
    add-int/lit8 v2, v2, 0x1

    goto :goto_6
.end method

.method private static varargs firstString(Landroid/media/MediaMetadata;[Ljava/lang/String;)Ljava/lang/String;
    .registers 8

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 557
    :cond_4
    array-length v1, p1

    const/4 v2, 0x0

    :goto_6
    if-lt v2, v1, :cond_9

    return-object v0

    :cond_9
    aget-object v3, p1, v2

    .line 559
    :try_start_b
    invoke-virtual {p0, v3}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 560
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5
    :try_end_13
    .catchall {:try_start_b .. :try_end_13} :catchall_16

    if-nez v5, :cond_16

    return-object v4

    .line 563
    :catchall_16
    :cond_16
    :try_start_16
    invoke-virtual {p0, v3}, Landroid/media/MediaMetadata;->getText(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v3

    .line 564
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_25

    invoke-interface {v3}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_24
    .catchall {:try_start_16 .. :try_end_24} :catchall_25

    return-object p0

    :catchall_25
    :cond_25
    add-int/lit8 v2, v2, 0x1

    goto :goto_6
.end method

.method private static varargs firstText(Landroid/media/MediaMetadata;[Ljava/lang/String;)Ljava/lang/CharSequence;
    .registers 8

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 542
    :cond_4
    array-length v1, p1

    const/4 v2, 0x0

    :goto_6
    if-lt v2, v1, :cond_9

    return-object v0

    :cond_9
    aget-object v3, p1, v2

    .line 544
    :try_start_b
    invoke-virtual {p0, v3}, Landroid/media/MediaMetadata;->getText(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v4

    .line 545
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5
    :try_end_13
    .catchall {:try_start_b .. :try_end_13} :catchall_16

    if-nez v5, :cond_16

    return-object v4

    .line 548
    :catchall_16
    :cond_16
    :try_start_16
    invoke-virtual {p0, v3}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 549
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4
    :try_end_1e
    .catchall {:try_start_16 .. :try_end_1e} :catchall_21

    if-nez v4, :cond_21

    return-object v3

    :catchall_21
    :cond_21
    add-int/lit8 v2, v2, 0x1

    goto :goto_6
.end method

.method private static isBluetooth(I)Z
    .registers 2

    const/16 v0, 0x8

    if-eq p0, v0, :cond_15

    const/4 v0, 0x7

    if-eq p0, v0, :cond_15

    const/16 v0, 0x1a

    if-eq p0, v0, :cond_15

    const/16 v0, 0x1b

    if-eq p0, v0, :cond_15

    const/16 v0, 0x1e

    if-eq p0, v0, :cond_15

    const/4 p0, 0x0

    return p0

    :cond_15
    const/4 p0, 0x1

    return p0
.end method

.method private static isHeadset(I)Z
    .registers 2

    const/4 v0, 0x3

    if-eq p0, v0, :cond_10

    const/4 v0, 0x4

    if-eq p0, v0, :cond_10

    const/16 v0, 0x16

    if-eq p0, v0, :cond_10

    const/16 v0, 0x17

    if-eq p0, v0, :cond_10

    const/4 p0, 0x0

    return p0

    :cond_10
    const/4 p0, 0x1

    return p0
.end method

.method private static isRemote(I)Z
    .registers 2

    const/16 v0, 0x9

    if-eq p0, v0, :cond_1a

    const/16 v0, 0xa

    if-eq p0, v0, :cond_1a

    const/16 v0, 0xb

    if-eq p0, v0, :cond_1a

    const/16 v0, 0xd

    if-eq p0, v0, :cond_1a

    const/16 v0, 0x19

    if-eq p0, v0, :cond_1a

    const/16 v0, 0x1d

    if-eq p0, v0, :cond_1a

    const/4 p0, 0x0

    return p0

    :cond_1a
    const/4 p0, 0x1

    return p0
.end method

.method private loadArtwork(Ljava/lang/String;)V
    .registers 5

    .line 582
    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->loadingArtworkUri:Ljava/lang/String;

    const/4 v0, 0x0

    .line 584
    :try_start_3
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    if-nez v1, :cond_8

    goto :goto_c

    :cond_8
    invoke-virtual {v1}, Landroid/media/session/MediaController;->getSessionToken()Landroid/media/session/MediaSession$Token;

    move-result-object v0
    :try_end_c
    .catchall {:try_start_3 .. :try_end_c} :catchall_17

    .line 586
    :goto_c
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->artworkExecutor:Ljava/util/concurrent/ExecutorService;

    new-instance v2, Linv/exe/systemui/qs/controller/InvMediaSessionController$5;

    invoke-direct {v2, p0, p1, v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController$5;-><init>(Linv/exe/systemui/qs/controller/InvMediaSessionController;Ljava/lang/String;Landroid/media/session/MediaSession$Token;)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/ExecutorService;->execute(Ljava/lang/Runnable;)V

    return-void

    .line 585
    :catchall_17
    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->loadingArtworkUri:Ljava/lang/String;

    return-void
.end method

.method private metadata()Landroid/media/MediaMetadata;
    .registers 2

    .line 527
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    const/4 v0, 0x0

    if-nez p0, :cond_6

    return-object v0

    .line 529
    :cond_6
    :try_start_6
    invoke-virtual {p0}, Landroid/media/session/MediaController;->getMetadata()Landroid/media/MediaMetadata;

    move-result-object p0
    :try_end_a
    .catchall {:try_start_6 .. :try_end_a} :catchall_b

    return-object p0

    :catchall_b
    return-object v0
.end method

.method private notifyChanged()V
    .registers 2

    .line 228
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->callback:Linv/exe/systemui/qs/controller/InvMediaSessionController$Callback;

    if-eqz v0, :cond_7

    .line 229
    invoke-interface {v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController$Callback;->onMediaChanged()V

    .line 230
    :cond_7
    return-void
.end method

.method private playbackState()Landroid/media/session/PlaybackState;
    .registers 2

    .line 534
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    const/4 v0, 0x0

    if-nez p0, :cond_6

    return-object v0

    .line 536
    :cond_6
    :try_start_6
    invoke-virtual {p0}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object p0
    :try_end_a
    .catchall {:try_start_6 .. :try_end_a} :catchall_b

    return-object p0

    :catchall_b
    return-object v0
.end method

.method private querySessions()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroid/media/session/MediaController;",
            ">;"
        }
    .end annotation

    .line 162
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->manager:Landroid/media/session/MediaSessionManager;

    if-nez p0, :cond_7

    sget-object p0, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    return-object p0

    :cond_7
    const/4 v0, 0x0

    .line 163
    :try_start_8
    invoke-virtual {p0, v0}, Landroid/media/session/MediaSessionManager;->getActiveSessions(Landroid/content/ComponentName;)Ljava/util/List;

    move-result-object p0
    :try_end_c
    .catchall {:try_start_8 .. :try_end_c} :catchall_d

    return-object p0

    .line 164
    :catchall_d
    sget-object p0, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    return-object p0
.end method

.method private static routeFromDevices([Landroid/media/AudioDeviceInfo;)I
    .registers 6

    const/4 v0, 0x0

    if-eqz p0, :cond_37

    .line 345
    array-length v1, p0

    if-nez v1, :cond_7

    goto :goto_37

    .line 347
    :cond_7
    array-length v1, p0

    move v2, v0

    :goto_9
    if-lt v0, v1, :cond_c

    return v2

    :cond_c
    aget-object v3, p0, v0

    if-eqz v3, :cond_34

    .line 348
    invoke-virtual {v3}, Landroid/media/AudioDeviceInfo;->isSink()Z

    move-result v4

    if-nez v4, :cond_17

    goto :goto_34

    .line 349
    :cond_17
    invoke-virtual {v3}, Landroid/media/AudioDeviceInfo;->getType()I

    move-result v3

    .line 350
    invoke-static {v3}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->isBluetooth(I)Z

    move-result v4

    if-eqz v4, :cond_23

    const/4 p0, 0x2

    return p0

    .line 351
    :cond_23
    invoke-static {v3}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->isHeadset(I)Z

    move-result v4

    if-eqz v4, :cond_2b

    const/4 v2, 0x1

    goto :goto_34

    :cond_2b
    if-nez v2, :cond_34

    .line 352
    invoke-static {v3}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->isRemote(I)Z

    move-result v3

    if-eqz v3, :cond_34

    const/4 v2, 0x3

    :cond_34
    :goto_34
    add-int/lit8 v0, v0, 0x1

    goto :goto_9

    :cond_37
    :goto_37
    return v0
.end method

.method private static sameSession(Landroid/media/session/MediaController;Landroid/media/session/MediaController;)Z
    .registers 3

    if-ne p0, p1, :cond_4

    const/4 p0, 0x1

    return p0

    :cond_4
    const/4 v0, 0x0

    if-eqz p0, :cond_17

    if-nez p1, :cond_a

    goto :goto_17

    .line 223
    :cond_a
    :try_start_a
    invoke-virtual {p0}, Landroid/media/session/MediaController;->getSessionToken()Landroid/media/session/MediaSession$Token;

    move-result-object p0

    invoke-virtual {p1}, Landroid/media/session/MediaController;->getSessionToken()Landroid/media/session/MediaSession$Token;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/media/session/MediaSession$Token;->equals(Ljava/lang/Object;)Z

    move-result p0
    :try_end_16
    .catchall {:try_start_a .. :try_end_16} :catchall_17

    return p0

    :catchall_17
    :cond_17
    :goto_17
    return v0
.end method

.method private static scaleArtwork(Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    .registers 5

    if-nez p0, :cond_4

    const/4 p0, 0x0

    return-object p0

    .line 631
    :cond_4
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/16 v1, 0x300

    if-gt v0, v1, :cond_15

    return-object p0

    :cond_15
    const/high16 v1, 0x44400000  # 768.0f

    int-to-float v0, v0

    div-float/2addr v1, v0

    .line 635
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v0

    int-to-float v0, v0

    mul-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    const/4 v2, 0x1

    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 636
    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v3

    int-to-float v3, v3

    mul-float/2addr v3, v1

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v1

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 634
    invoke-static {p0, v0, v1, v2}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object p0

    return-object p0
.end method

.method private static score(Landroid/media/session/MediaController;)I
    .registers 3

    const/4 v0, 0x0

    .line 186
    :try_start_1
    invoke-virtual {p0}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v1
    :try_end_5
    .catchall {:try_start_1 .. :try_end_5} :catchall_6

    goto :goto_7

    :catchall_6
    move-object v1, v0

    .line 187
    :goto_7
    :try_start_7
    invoke-virtual {p0}, Landroid/media/session/MediaController;->getMetadata()Landroid/media/MediaMetadata;

    move-result-object v0
    :try_end_b
    .catchall {:try_start_7 .. :try_end_b} :catchall_b

    :catchall_b
    if-nez v1, :cond_f

    const/4 p0, 0x0

    goto :goto_13

    .line 189
    :cond_f
    invoke-virtual {v1}, Landroid/media/session/PlaybackState;->getState()I

    move-result p0

    :goto_13
    packed-switch p0, :pswitch_data_2c

    :pswitch_16  #0x7
    const/16 p0, 0x64

    goto :goto_27

    :pswitch_19  #0x6, 0x8
    const/16 p0, 0x384

    goto :goto_27

    :pswitch_1c  #0x4, 0x5
    const/16 p0, 0x352

    goto :goto_27

    :pswitch_1f  #0x3
    const/16 p0, 0x3e8

    goto :goto_27

    :pswitch_22  #0x2
    const/16 p0, 0x2bc

    goto :goto_27

    :pswitch_25  #0x1
    const/16 p0, 0x12c

    :goto_27
    if-eqz v0, :cond_2b

    add-int/lit8 p0, p0, 0x32

    :cond_2b
    return p0

    :pswitch_data_2c
    .packed-switch 0x1
        :pswitch_25  #00000001
        :pswitch_22  #00000002
        :pswitch_1f  #00000003
        :pswitch_1c  #00000004
        :pswitch_1c  #00000005
        :pswitch_19  #00000006
        :pswitch_16  #00000007
        :pswitch_19  #00000008
    .end packed-switch
.end method

.method private selectBest(Ljava/util/List;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/media/session/MediaController;",
            ">;)V"
        }
    .end annotation

    const/4 v0, 0x0

    if-eqz p1, :cond_21

    .line 171
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/high16 v1, -0x80000000

    :cond_9
    :goto_9
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-nez v2, :cond_10

    goto :goto_21

    :cond_10
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/media/session/MediaController;

    .line 172
    invoke-static {v2}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->score(Landroid/media/session/MediaController;)I

    move-result v3

    if-eqz v0, :cond_1e

    if-le v3, v1, :cond_9

    :cond_1e
    move-object v0, v2

    move v1, v3

    goto :goto_9

    .line 179
    :cond_21
    :goto_21
    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->setCurrent(Landroid/media/session/MediaController;)V

    .line 180
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->notifyChanged()V

    return-void
.end method

.method private setCurrent(Landroid/media/session/MediaController;)V
    .registers 4

    .line 205
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    invoke-static {v0, p1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->sameSession(Landroid/media/session/MediaController;Landroid/media/session/MediaController;)Z

    move-result v0

    if-eqz v0, :cond_9

    goto :goto_25

    .line 208
    :cond_9
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    if-eqz v0, :cond_12

    .line 209
    :try_start_d
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->controllerCallback:Landroid/media/session/MediaController$Callback;

    invoke-virtual {v0, v1}, Landroid/media/session/MediaController;->unregisterCallback(Landroid/media/session/MediaController$Callback;)V
    :try_end_12
    .catchall {:try_start_d .. :try_end_12} :catchall_12

    .line 212
    :catchall_12
    :cond_12
    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    const/4 v0, 0x0

    iput v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->shuffleCompatMode:I

    .line 213
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->clearArtworkCache()V

    .line 214
    iget-object p1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    if-eqz p1, :cond_25

    .line 215
    :try_start_1e
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->controllerCallback:Landroid/media/session/MediaController$Callback;

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->mainHandler:Landroid/os/Handler;

    invoke-virtual {p1, v0, p0}, Landroid/media/session/MediaController;->registerCallback(Landroid/media/session/MediaController$Callback;Landroid/os/Handler;)V
    :try_end_25
    .catchall {:try_start_1e .. :try_end_25} :catchall_25

    :catchall_25
    :cond_25
    :goto_25
    return-void
.end method

.method private shuffleCustomAction()Ljava/lang/String;
    .registers 6

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->playbackState()Landroid/media/session/PlaybackState;

    move-result-object v0

    if-eqz v0, :cond_47

    invoke-virtual {v0}, Landroid/media/session/PlaybackState;->getCustomActions()Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_47

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_10
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_47

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/media/session/PlaybackState$CustomAction;

    invoke-virtual {v1}, Landroid/media/session/PlaybackState$CustomAction;->getAction()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_2e

    invoke-virtual {v2}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v3

    const-string v4, "shuffle"

    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_46

    :cond_2e
    invoke-virtual {v1}, Landroid/media/session/PlaybackState$CustomAction;->getName()Ljava/lang/CharSequence;

    move-result-object v1

    if-eqz v1, :cond_10

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const-string v3, "shuffle"

    invoke-virtual {v1, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_10

    if-eqz v2, :cond_10

    :cond_46
    return-object v2

    :cond_47
    const/4 v0, 0x0

    return-object v0
.end method

.method private supports(J)Z
    .registers 7

    .line 455
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->playbackState()Landroid/media/session/PlaybackState;

    move-result-object v0

    if-nez v0, :cond_b

    .line 456
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->hasSession()Z

    move-result p0

    return p0

    .line 457
    :cond_b
    invoke-virtual {v0}, Landroid/media/session/PlaybackState;->getActions()J

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmp-long p0, v0, v2

    if-eqz p0, :cond_1d

    and-long p0, v0, p1

    cmp-long p0, p0, v2

    if-nez p0, :cond_1d

    const/4 p0, 0x0

    return p0

    :cond_1d
    const/4 p0, 0x1

    return p0
.end method


# virtual methods
.method public canNext()Z
    .registers 3

    const-wide/16 v0, 0x20

    .line 438
    invoke-direct {p0, v0, v1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->supports(J)Z

    move-result p0

    return p0
.end method

.method public canPlayPause()Z
    .registers 9

    .line 446
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->playbackState()Landroid/media/session/PlaybackState;

    move-result-object v0

    if-nez v0, :cond_b

    .line 447
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->hasSession()Z

    move-result p0

    return p0

    .line 448
    :cond_b
    invoke-virtual {v0}, Landroid/media/session/PlaybackState;->getActions()J

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    const/4 v5, 0x1

    if-eqz v4, :cond_31

    const-wide/16 v6, 0x200

    and-long/2addr v6, v0

    cmp-long v4, v6, v2

    if-eqz v4, :cond_1e

    goto :goto_31

    .line 450
    :cond_1e
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->isPlaying()Z

    move-result p0

    if-eqz p0, :cond_27

    const-wide/16 v6, 0x2

    goto :goto_29

    :cond_27
    const-wide/16 v6, 0x4

    :goto_29
    and-long/2addr v0, v6

    cmp-long p0, v0, v2

    if-eqz p0, :cond_2f

    return v5

    :cond_2f
    const/4 p0, 0x0

    return p0

    :cond_31
    :goto_31
    return v5
.end method

.method public canPrevious()Z
    .registers 3

    const-wide/16 v0, 0x10

    .line 434
    invoke-direct {p0, v0, v1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->supports(J)Z

    move-result p0

    return p0
.end method

.method public canSeek()Z
    .registers 9

    .line 414
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->playbackState()Landroid/media/session/PlaybackState;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return v1

    .line 416
    :cond_8
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->getDurationMillis()J

    move-result-wide v2

    const-wide/16 v4, 0x0

    cmp-long p0, v2, v4

    if-gtz p0, :cond_13

    return v1

    .line 419
    :cond_13
    :try_start_13
    invoke-virtual {v0}, Landroid/media/session/PlaybackState;->getActions()J

    move-result-wide v2
    :try_end_17
    .catchall {:try_start_13 .. :try_end_17} :catchall_20

    const-wide/16 v6, 0x100

    and-long/2addr v2, v6

    cmp-long p0, v2, v4

    if-eqz p0, :cond_20

    const/4 p0, 0x1

    return p0

    :catchall_20
    :cond_20
    return v1
.end method

.method public canShuffle()Z
    .registers 3

    const-wide/32 v0, 0x200000

    invoke-direct {p0, v0, v1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->supports(J)Z

    move-result v0

    if-nez v0, :cond_18

    const-wide/32 v0, 0x80000

    invoke-direct {p0, v0, v1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->supports(J)Z

    move-result v0

    if-nez v0, :cond_18

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->shuffleCustomAction()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_1a

    :cond_18
    const/4 v0, 0x1

    return v0

    :cond_1a
    const/4 v0, 0x0

    return v0
.end method

.method public getAlbum()Ljava/lang/CharSequence;
    .registers 3

    .line 273
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->metadata()Landroid/media/MediaMetadata;

    move-result-object p0

    .line 275
    const-string v0, "android.media.metadata.ALBUM"

    .line 276
    const-string v1, "android.media.metadata.DISPLAY_DESCRIPTION"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    .line 274
    invoke-static {p0, v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->firstText(Landroid/media/MediaMetadata;[Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public getAppIcon()Landroid/graphics/drawable/Drawable;
    .registers 3

    .line 234
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return-object v1

    .line 235
    :cond_6
    :try_start_6
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->context:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    invoke-virtual {p0}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/content/pm/PackageManager;->getApplicationIcon(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object p0
    :try_end_16
    .catchall {:try_start_6 .. :try_end_16} :catchall_17

    return-object p0

    :catchall_17
    return-object v1
.end method

.method public getArtist()Ljava/lang/CharSequence;
    .registers 5

    .line 264
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->metadata()Landroid/media/MediaMetadata;

    move-result-object p0

    .line 268
    const-string v0, "android.media.metadata.ALBUM_ARTIST"

    .line 269
    const-string v1, "android.media.metadata.AUTHOR"

    const-string v2, "android.media.metadata.DISPLAY_SUBTITLE"

    const-string v3, "android.media.metadata.ARTIST"

    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    .line 265
    invoke-static {p0, v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->firstText(Landroid/media/MediaMetadata;[Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public getArtwork()Landroid/graphics/Bitmap;
    .registers 7

    .line 288
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->metadata()Landroid/media/MediaMetadata;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_8

    return-object v1

    .line 293
    :cond_8
    const-string v2, "android.media.metadata.ART"

    .line 294
    const-string v3, "android.media.metadata.ALBUM_ART"

    const-string v4, "android.media.metadata.DISPLAY_ICON"

    filled-new-array {v4, v2, v3}, [Ljava/lang/String;

    move-result-object v2

    .line 291
    invoke-static {v0, v2}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->firstBitmap(Landroid/media/MediaMetadata;[Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    if-eqz v2, :cond_19

    return-object v2

    .line 298
    :cond_19
    :try_start_19
    invoke-virtual {v0}, Landroid/media/MediaMetadata;->getDescription()Landroid/media/MediaDescription;

    move-result-object v2
    :try_end_1d
    .catchall {:try_start_19 .. :try_end_1d} :catchall_1e

    goto :goto_1f

    :catchall_1e
    move-object v2, v1

    :goto_1f
    if-eqz v2, :cond_28

    .line 302
    :try_start_21
    invoke-virtual {v2}, Landroid/media/MediaDescription;->getIconBitmap()Landroid/graphics/Bitmap;

    move-result-object v3
    :try_end_25
    .catchall {:try_start_21 .. :try_end_25} :catchall_28

    if-eqz v3, :cond_28

    return-object v3

    .line 309
    :catchall_28
    :cond_28
    const-string v3, "android.media.metadata.ART_URI"

    .line 310
    const-string v4, "android.media.metadata.ALBUM_ART_URI"

    const-string v5, "android.media.metadata.DISPLAY_ICON_URI"

    filled-new-array {v5, v3, v4}, [Ljava/lang/String;

    move-result-object v3

    .line 307
    invoke-static {v0, v3}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->firstString(Landroid/media/MediaMetadata;[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 311
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_48

    if-eqz v2, :cond_48

    .line 313
    :try_start_3e
    invoke-virtual {v2}, Landroid/media/MediaDescription;->getIconUri()Landroid/net/Uri;

    move-result-object v2

    if-eqz v2, :cond_48

    .line 314
    invoke-virtual {v2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_48
    .catchall {:try_start_3e .. :try_end_48} :catchall_48

    .line 317
    :catchall_48
    :cond_48
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_4f

    return-object v1

    .line 318
    :cond_4f
    iget-object v2, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->resolvedArtworkUri:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_5a

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->resolvedArtwork:Landroid/graphics/Bitmap;

    return-object p0

    .line 319
    :cond_5a
    iget-object v2, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->loadingArtworkUri:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_65

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->loadArtwork(Ljava/lang/String;)V

    :cond_65
    return-object v1
.end method

.method public getDurationMillis()J
    .registers 5

    .line 385
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->metadata()Landroid/media/MediaMetadata;

    move-result-object p0

    const-wide/16 v0, 0x0

    if-nez p0, :cond_9

    return-wide v0

    .line 387
    :cond_9
    :try_start_9
    const-string v2, "android.media.metadata.DURATION"

    invoke-virtual {p0, v2}, Landroid/media/MediaMetadata;->getLong(Ljava/lang/String;)J

    move-result-wide v2

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v0
    :try_end_13
    .catchall {:try_start_9 .. :try_end_13} :catchall_13

    :catchall_13
    return-wide v0
.end method

.method public getOutputRoute()I
    .registers 4

    .line 324
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->audioManager:Landroid/media/AudioManager;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return v1

    :cond_6
    const/4 v2, 0x2

    .line 333
    :try_start_7
    invoke-virtual {v0, v2}, Landroid/media/AudioManager;->getDevices(I)[Landroid/media/AudioDeviceInfo;

    move-result-object v0

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->routeFromDevices([Landroid/media/AudioDeviceInfo;)I

    move-result v0
    :try_end_f
    .catchall {:try_start_7 .. :try_end_f} :catchall_12

    if-eqz v0, :cond_12

    return v0

    .line 337
    :catchall_12
    :cond_12
    :try_start_12
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->audioManager:Landroid/media/AudioManager;

    invoke-virtual {v0}, Landroid/media/AudioManager;->isBluetoothA2dpOn()Z

    move-result v0

    if-nez v0, :cond_22

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->audioManager:Landroid/media/AudioManager;

    invoke-virtual {v0}, Landroid/media/AudioManager;->isBluetoothScoOn()Z

    move-result v0
    :try_end_20
    .catchall {:try_start_12 .. :try_end_20} :catchall_23

    if-eqz v0, :cond_23

    :cond_22
    return v2

    .line 339
    :catchall_23
    :cond_23
    :try_start_23
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->audioManager:Landroid/media/AudioManager;

    invoke-virtual {p0}, Landroid/media/AudioManager;->isWiredHeadsetOn()Z

    move-result p0
    :try_end_29
    .catchall {:try_start_23 .. :try_end_29} :catchall_2d

    if-eqz p0, :cond_2d

    const/4 p0, 0x1

    return p0

    :catchall_2d
    :cond_2d
    return v1
.end method

.method public getPackageName()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    if-eqz v0, :cond_9

    invoke-virtual {v0}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_9
    const/4 v0, 0x0

    return-object v0
.end method

.method public getPositionMillis()J
    .registers 10

    .line 392
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->playbackState()Landroid/media/session/PlaybackState;

    move-result-object v0

    const-wide/16 v1, 0x0

    if-nez v0, :cond_9

    return-wide v1

    .line 395
    :cond_9
    :try_start_9
    invoke-virtual {v0}, Landroid/media/session/PlaybackState;->getPosition()J

    move-result-wide v3
    :try_end_d
    .catchall {:try_start_9 .. :try_end_d} :catchall_45

    cmp-long v5, v3, v1

    if-gez v5, :cond_12

    move-wide v3, v1

    .line 398
    :cond_12
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->isPlaying()Z

    move-result v5

    if-eqz v5, :cond_34

    .line 400
    :try_start_18
    invoke-virtual {v0}, Landroid/media/session/PlaybackState;->getLastPositionUpdateTime()J

    move-result-wide v5

    cmp-long v7, v5, v1

    if-lez v7, :cond_34

    .line 402
    invoke-virtual {v0}, Landroid/media/session/PlaybackState;->getPlaybackSpeed()F

    move-result v0

    const/4 v7, 0x0

    cmpg-float v7, v0, v7

    if-gtz v7, :cond_2b

    const/high16 v0, 0x3f800000  # 1.0f

    .line 404
    :cond_2b
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v7
    :try_end_2f
    .catchall {:try_start_18 .. :try_end_2f} :catchall_34

    sub-long/2addr v7, v5

    long-to-float v5, v7

    mul-float/2addr v5, v0

    float-to-long v5, v5

    add-long/2addr v3, v5

    .line 408
    :catchall_34
    :cond_34
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->getDurationMillis()J

    move-result-wide v5

    cmp-long p0, v5, v1

    if-lez p0, :cond_40

    .line 409
    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v3

    .line 410
    :cond_40
    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v0

    return-wide v0

    :catchall_45
    return-wide v1
.end method

.method public getSessionActivityPendingIntent()Landroid/app/PendingIntent;
    .registers 2

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    if-eqz v0, :cond_a

    :try_start_4
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getSessionActivity()Landroid/app/PendingIntent;

    move-result-object v0
    :try_end_8
    .catchall {:try_start_4 .. :try_end_8} :catchall_9

    return-object v0

    :catchall_9
    move-exception v0

    :cond_a
    const/4 v0, 0x0

    return-object v0
.end method

.method public getSubtitle()Ljava/lang/CharSequence;
    .registers 3

    .line 280
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->getArtist()Ljava/lang/CharSequence;

    move-result-object v0

    .line 281
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->getAlbum()Ljava/lang/CharSequence;

    move-result-object p0

    .line 282
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_f

    return-object p0

    .line 283
    :cond_f
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_31

    invoke-static {v0, p0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1c

    goto :goto_31

    .line 284
    :cond_1c
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, " • "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_31
    :goto_31
    return-object v0
.end method

.method public getTitle()Ljava/lang/CharSequence;
    .registers 3

    .line 257
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->metadata()Landroid/media/MediaMetadata;

    move-result-object p0

    .line 259
    const-string v0, "android.media.metadata.DISPLAY_TITLE"

    .line 260
    const-string v1, "android.media.metadata.TITLE"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    .line 258
    invoke-static {p0, v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->firstText(Landroid/media/MediaMetadata;[Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public hasAccess()Z
    .registers 1

    const/4 p0, 0x1

    return p0
.end method

.method public hasSession()Z
    .registers 1

    .line 239
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    if-eqz p0, :cond_6

    const/4 p0, 0x1

    return p0

    :cond_6
    const/4 p0, 0x0

    return p0
.end method

.method public isPlaying()Z
    .registers 3

    .line 242
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->playbackState()Landroid/media/session/PlaybackState;

    move-result-object p0

    const/4 v0, 0x0

    if-nez p0, :cond_8

    return v0

    .line 244
    :cond_8
    invoke-virtual {p0}, Landroid/media/session/PlaybackState;->getState()I

    move-result p0

    const/4 v1, 0x3

    if-eq p0, v1, :cond_1d

    const/4 v1, 0x4

    if-eq p0, v1, :cond_1d

    const/4 v1, 0x5

    if-eq p0, v1, :cond_1d

    const/4 v1, 0x6

    if-eq p0, v1, :cond_1d

    const/16 v1, 0x8

    if-eq p0, v1, :cond_1d

    return v0

    :cond_1d
    const/4 p0, 0x1

    return p0
.end method

.method public isShuffleEnabled()Z
    .registers 2

    iget v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->shuffleCompatMode:I

    if-eqz v0, :cond_6

    const/4 v0, 0x1

    return v0

    :cond_6
    const/4 v0, 0x0

    return v0
.end method

.method public next()V
    .registers 1

    .line 469
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    if-nez p0, :cond_5

    goto :goto_c

    .line 471
    :cond_5
    :try_start_5
    invoke-virtual {p0}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object p0

    invoke-virtual {p0}, Landroid/media/session/MediaController$TransportControls;->skipToNext()V
    :try_end_c
    .catchall {:try_start_5 .. :try_end_c} :catchall_c

    :catchall_c
    :goto_c
    return-void
.end method

.method public openApp()V
    .registers 3

    .line 515
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    if-nez v0, :cond_5

    goto :goto_24

    .line 518
    :cond_5
    :try_start_5
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->context:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    .line 519
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    if-nez v0, :cond_16

    goto :goto_24

    :cond_16
    const v1, 0x34000000

    .line 521
    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 522
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->context:Landroid/content/Context;

    invoke-static {p0}, Linv/exe/systemui/qs/helper/InvActivityLaunchHelper;->collapsePanels(Landroid/content/Context;)V

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_24
    .catchall {:try_start_5 .. :try_end_24} :catchall_24

    :catchall_24
    :goto_24
    return-void
.end method

.method public previous()V
    .registers 1

    .line 462
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    if-nez p0, :cond_5

    goto :goto_c

    .line 464
    :cond_5
    :try_start_5
    invoke-virtual {p0}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object p0

    invoke-virtual {p0}, Landroid/media/session/MediaController$TransportControls;->skipToPrevious()V
    :try_end_c
    .catchall {:try_start_5 .. :try_end_c} :catchall_c

    :catchall_c
    :goto_c
    return-void
.end method

.method public refresh()V
    .registers 3

    .line 141
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    if-eq v0, v1, :cond_15

    .line 142
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->mainHandler:Landroid/os/Handler;

    new-instance v1, Linv/exe/systemui/qs/controller/InvMediaSessionController$4;

    invoke-direct {v1, p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController$4;-><init>(Linv/exe/systemui/qs/controller/InvMediaSessionController;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    .line 147
    :cond_15
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->ensureSessionsListener()V

    .line 148
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->querySessions()Ljava/util/List;

    move-result-object v0

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->selectBest(Ljava/util/List;)V

    return-void
.end method

.method public requestAccess()V
    .registers 1

    .line 131
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->refresh()V

    return-void
.end method

.method public seekTo(J)V
    .registers 8

    .line 425
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    if-nez v0, :cond_5

    goto :goto_22

    .line 427
    :cond_5
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->getDurationMillis()J

    move-result-wide v1

    const-wide/16 v3, 0x0

    cmp-long p0, v1, v3

    if-lez p0, :cond_17

    .line 428
    invoke-static {v3, v4, p1, p2}, Ljava/lang/Math;->max(JJ)J

    move-result-wide p0

    invoke-static {p0, p1, v1, v2}, Ljava/lang/Math;->min(JJ)J

    move-result-wide p1

    .line 429
    :cond_17
    :try_start_17
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object p0

    invoke-static {v3, v4, p1, p2}, Ljava/lang/Math;->max(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2}, Landroid/media/session/MediaController$TransportControls;->seekTo(J)V
    :try_end_22
    .catchall {:try_start_17 .. :try_end_22} :catchall_22

    :catchall_22
    :goto_22
    return-void
.end method

.method public start(Linv/exe/systemui/qs/controller/InvMediaSessionController$Callback;)V
    .registers 2

    .line 102
    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->callback:Linv/exe/systemui/qs/controller/InvMediaSessionController$Callback;

    .line 103
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->ensureAudioDeviceCallback()V

    .line 104
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->ensureSessionsListener()V

    .line 105
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->refresh()V

    return-void
.end method

.method public stop()V
    .registers 3

    .line 109
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->manager:Landroid/media/session/MediaSessionManager;

    if-eqz v0, :cond_d

    iget-boolean v1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->listenerRegistered:Z

    if-eqz v1, :cond_d

    .line 110
    :try_start_8
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->sessionsListener:Landroid/media/session/MediaSessionManager$OnActiveSessionsChangedListener;

    invoke-virtual {v0, v1}, Landroid/media/session/MediaSessionManager;->removeOnActiveSessionsChangedListener(Landroid/media/session/MediaSessionManager$OnActiveSessionsChangedListener;)V
    :try_end_d
    .catchall {:try_start_8 .. :try_end_d} :catchall_d

    .line 113
    .line 114
    :catchall_d
    :cond_d
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->audioManager:Landroid/media/AudioManager;

    if-eqz v0, :cond_16

    .line 115
    :try_start_11
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->audioDeviceCallback:Landroid/media/AudioDeviceCallback;

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->unregisterAudioDeviceCallback(Landroid/media/AudioDeviceCallback;)V
    :try_end_16
    .catchall {:try_start_11 .. :try_end_16} :catchall_16

    :catchall_16
    :cond_16
    const/4 v0, 0x0

    .line 118
    iput-boolean v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->listenerRegistered:Z

    const/4 v0, 0x0

    .line 119
    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->setCurrent(Landroid/media/session/MediaController;)V

    .line 120
    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->callback:Linv/exe/systemui/qs/controller/InvMediaSessionController$Callback;

    .line 121
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->artworkExecutor:Ljava/util/concurrent/ExecutorService;

    invoke-interface {p0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    return-void
.end method

.method public togglePlayPause()V
    .registers 2

    .line 506
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    if-nez v0, :cond_5

    goto :goto_1a

    .line 509
    :cond_5
    :try_start_5
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->isPlaying()Z

    move-result p0

    if-eqz p0, :cond_13

    invoke-virtual {v0}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object p0

    invoke-virtual {p0}, Landroid/media/session/MediaController$TransportControls;->pause()V

    return-void

    .line 510
    :cond_13
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object p0

    invoke-virtual {p0}, Landroid/media/session/MediaController$TransportControls;->play()V
    :try_end_1a
    .catchall {:try_start_5 .. :try_end_1a} :catchall_1a

    :catchall_1a
    :goto_1a
    return-void
.end method

.method public toggleShuffle()V
    .registers 6

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->current:Landroid/media/session/MediaController;

    if-eqz v0, :cond_3a

    :try_start_4
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object v1

    if-eqz v1, :cond_3a

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->shuffleCustomAction()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_15

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/media/session/MediaController$TransportControls;->sendCustomAction(Ljava/lang/String;Landroid/os/Bundle;)V

    goto :goto_31

    :cond_15
    iget v2, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->shuffleCompatMode:I

    if-eqz v2, :cond_1b

    const/4 v2, 0x0

    goto :goto_1c

    :cond_1b
    const/4 v2, 0x1

    :goto_1c
    new-instance v3, Landroid/os/Bundle;

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    const-string v4, "android.support.v4.media.session.action.ARGUMENT_SHUFFLE_MODE"

    invoke-virtual {v3, v4, v2}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    const-string v4, "android.support.v4.media.session.action.SET_SHUFFLE_MODE"

    invoke-virtual {v1, v4, v3}, Landroid/media/session/MediaController$TransportControls;->sendCustomAction(Ljava/lang/String;Landroid/os/Bundle;)V

    iput v2, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->shuffleCompatMode:I

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->notifyChanged()V

    goto :goto_3a

    :goto_31
    iget v2, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->shuffleCompatMode:I

    xor-int/lit8 v2, v2, 0x1

    iput v2, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController;->shuffleCompatMode:I

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->notifyChanged()V
    :try_end_3a
    .catchall {:try_start_4 .. :try_end_3a} :catchall_3a

    :catchall_3a
    :cond_3a
    :goto_3a
    return-void
.end method
