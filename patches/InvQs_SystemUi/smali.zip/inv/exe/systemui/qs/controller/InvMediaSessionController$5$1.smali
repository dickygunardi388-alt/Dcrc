.class public Linv/exe/systemui/qs/controller/InvMediaSessionController$5$1;
.super Ljava/lang/Object;
.source "MediaSessionController.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Linv/exe/systemui/qs/controller/InvMediaSessionController$5;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field public final synthetic this$1:Linv/exe/systemui/qs/controller/InvMediaSessionController$5;

.field private final synthetic val$bitmap:Landroid/graphics/Bitmap;

.field private final synthetic val$token:Landroid/media/session/MediaSession$Token;

.field private final synthetic val$uriText:Ljava/lang/String;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvMediaSessionController$5;Landroid/media/session/MediaSession$Token;Ljava/lang/String;Landroid/graphics/Bitmap;)V
    .registers 5

    .line 589
    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5$1;->this$1:Linv/exe/systemui/qs/controller/InvMediaSessionController$5;

    iput-object p2, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5$1;->val$token:Landroid/media/session/MediaSession$Token;

    iput-object p3, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5$1;->val$uriText:Ljava/lang/String;

    iput-object p4, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5$1;->val$bitmap:Landroid/graphics/Bitmap;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    .line 591
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5$1;->this$1:Linv/exe/systemui/qs/controller/InvMediaSessionController$5;

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController$5;->access$0(Linv/exe/systemui/qs/controller/InvMediaSessionController$5;)Linv/exe/systemui/qs/controller/InvMediaSessionController;

    move-result-object v0

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->access$5(Linv/exe/systemui/qs/controller/InvMediaSessionController;)Landroid/media/session/MediaController;

    move-result-object v0

    if-eqz v0, :cond_44

    .line 592
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5$1;->val$token:Landroid/media/session/MediaSession$Token;

    if-eqz v1, :cond_44

    .line 593
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getSessionToken()Landroid/media/session/MediaSession$Token;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/media/session/MediaSession$Token;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1b

    goto :goto_44

    .line 594
    :cond_1b
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5$1;->this$1:Linv/exe/systemui/qs/controller/InvMediaSessionController$5;

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController$5;->access$0(Linv/exe/systemui/qs/controller/InvMediaSessionController$5;)Linv/exe/systemui/qs/controller/InvMediaSessionController;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v0, v1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->access$6(Linv/exe/systemui/qs/controller/InvMediaSessionController;Ljava/lang/String;)V

    .line 595
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5$1;->this$1:Linv/exe/systemui/qs/controller/InvMediaSessionController$5;

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController$5;->access$0(Linv/exe/systemui/qs/controller/InvMediaSessionController$5;)Linv/exe/systemui/qs/controller/InvMediaSessionController;

    move-result-object v0

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5$1;->val$uriText:Ljava/lang/String;

    invoke-static {v0, v1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->access$7(Linv/exe/systemui/qs/controller/InvMediaSessionController;Ljava/lang/String;)V

    .line 596
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5$1;->this$1:Linv/exe/systemui/qs/controller/InvMediaSessionController$5;

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController$5;->access$0(Linv/exe/systemui/qs/controller/InvMediaSessionController$5;)Linv/exe/systemui/qs/controller/InvMediaSessionController;

    move-result-object v0

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5$1;->val$bitmap:Landroid/graphics/Bitmap;

    invoke-static {v0, v1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->access$8(Linv/exe/systemui/qs/controller/InvMediaSessionController;Landroid/graphics/Bitmap;)V

    .line 597
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5$1;->this$1:Linv/exe/systemui/qs/controller/InvMediaSessionController$5;

    invoke-static {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController$5;->access$0(Linv/exe/systemui/qs/controller/InvMediaSessionController$5;)Linv/exe/systemui/qs/controller/InvMediaSessionController;

    move-result-object p0

    invoke-static {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->access$1(Linv/exe/systemui/qs/controller/InvMediaSessionController;)V

    :cond_44
    :goto_44
    return-void
.end method
