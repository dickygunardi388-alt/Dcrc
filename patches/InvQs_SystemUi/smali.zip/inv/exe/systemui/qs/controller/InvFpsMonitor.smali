.class public final Linv/exe/systemui/qs/controller/InvFpsMonitor;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/Choreographer$FrameCallback;


# static fields
.field private static final INSTANCE:Linv/exe/systemui/qs/controller/InvFpsMonitor;


# instance fields
.field private fps:I

.field private frames:I

.field private lastFrameNs:J

.field private lastRequestMs:J

.field private running:Z


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Linv/exe/systemui/qs/controller/InvFpsMonitor;

    invoke-direct {v0}, Linv/exe/systemui/qs/controller/InvFpsMonitor;-><init>()V

    sput-object v0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->INSTANCE:Linv/exe/systemui/qs/controller/InvFpsMonitor;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static getFps()I
    .registers 5

    sget-object v0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->INSTANCE:Linv/exe/systemui/qs/controller/InvFpsMonitor;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    iput-wide v1, v0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->lastRequestMs:J

    iget-boolean v1, v0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->running:Z

    if-nez v1, :cond_1d

    const/4 v1, 0x1

    iput-boolean v1, v0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->running:Z

    const/4 v1, 0x0

    iput v1, v0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->frames:I

    const-wide/16 v1, 0x0

    iput-wide v1, v0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->lastFrameNs:J

    invoke-static {}, Landroid/view/Choreographer;->getInstance()Landroid/view/Choreographer;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/view/Choreographer;->postFrameCallback(Landroid/view/Choreographer$FrameCallback;)V

    :cond_1d
    iget v0, v0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->fps:I

    return v0
.end method


# virtual methods
.method public doFrame(J)V
    .registers 12

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->lastRequestMs:J

    sub-long/2addr v0, v2

    const-wide/16 v2, 0x9c4

    cmp-long v0, v0, v2

    if-lez v0, :cond_17

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->running:Z

    iput v0, p0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->frames:I

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->lastFrameNs:J

    return-void

    :cond_17
    iget-wide v0, p0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->lastFrameNs:J

    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    if-nez v2, :cond_22

    move-wide v0, p1

    iput-wide v0, p0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->lastFrameNs:J

    :cond_22
    iget v2, p0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->frames:I

    add-int/lit8 v2, v2, 0x1

    iput v2, p0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->frames:I

    iget-wide v0, p0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->lastFrameNs:J

    move-wide v3, p1

    sub-long/2addr v3, v0

    const-wide/32 v5, 0x3b9aca00

    cmp-long v0, v3, v5

    if-ltz v0, :cond_3f

    int-to-long v0, v2

    mul-long/2addr v0, v5

    div-long/2addr v0, v3

    long-to-int v0, v0

    iput v0, p0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->fps:I

    const/4 v0, 0x0

    iput v0, p0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->frames:I

    move-wide v0, p1

    iput-wide v0, p0, Linv/exe/systemui/qs/controller/InvFpsMonitor;->lastFrameNs:J

    :cond_3f
    invoke-static {}, Landroid/view/Choreographer;->getInstance()Landroid/view/Choreographer;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/Choreographer;->postFrameCallback(Landroid/view/Choreographer$FrameCallback;)V

    return-void
.end method
