.class public final Linv/exe/systemui/qs/controller/InvQsPanelController$AutoInfoRefreshRunnable;
.super Ljava/lang/Object;
.source "QsPanelController.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V
    .registers 2

    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$AutoInfoRefreshRunnable;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 1

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$AutoInfoRefreshRunnable;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->runInfoAutoRefreshTick()V

    return-void
.end method
