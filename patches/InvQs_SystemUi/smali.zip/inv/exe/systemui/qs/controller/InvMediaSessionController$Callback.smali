.class public interface abstract Linv/exe/systemui/qs/controller/InvMediaSessionController$Callback;
.super Ljava/lang/Object;
.source "MediaSessionController.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Linv/exe/systemui/qs/controller/InvMediaSessionController;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Callback"
.end annotation


# virtual methods
.method public abstract onMediaChanged()V
.end method
