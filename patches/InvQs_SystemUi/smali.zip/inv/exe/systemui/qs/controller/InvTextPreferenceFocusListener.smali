.class public final Linv/exe/systemui/qs/controller/InvTextPreferenceFocusListener;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnFocusChangeListener;


# instance fields
.field private final context:Landroid/content/Context;

.field private final key:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvTextPreferenceFocusListener;->context:Landroid/content/Context;

    iput-object p2, p0, Linv/exe/systemui/qs/controller/InvTextPreferenceFocusListener;->key:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public onFocusChange(Landroid/view/View;Z)V
    .registers 6

    if-nez p2, :cond_26

    instance-of p2, p1, Landroid/widget/EditText;

    if-eqz p2, :cond_26

    check-cast p1, Landroid/widget/EditText;

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvTextPreferenceFocusListener;->context:Landroid/content/Context;

    const-string v0, "invmod_panel"

    const/4 v1, 0x0

    invoke-virtual {p2, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p2

    invoke-interface {p2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvTextPreferenceFocusListener;->key:Ljava/lang/String;

    invoke-interface {p2, p0, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_26
    return-void
.end method
