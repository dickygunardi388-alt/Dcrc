.class public Linv/exe/systemui/qs/controller/InvMediaSessionController$3;
.super Landroid/media/AudioDeviceCallback;
.source "MediaSessionController.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Linv/exe/systemui/qs/controller/InvMediaSessionController;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field public final synthetic this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvMediaSessionController;)V
    .registers 2

    .line 85
    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$3;->this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-direct {p0}, Landroid/media/AudioDeviceCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onAudioDevicesAdded([Landroid/media/AudioDeviceInfo;)V
    .registers 2

    .line 87
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$3;->this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-static {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->access$1(Linv/exe/systemui/qs/controller/InvMediaSessionController;)V

    return-void
.end method

.method public onAudioDevicesRemoved([Landroid/media/AudioDeviceInfo;)V
    .registers 2

    .line 91
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$3;->this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-static {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->access$1(Linv/exe/systemui/qs/controller/InvMediaSessionController;)V

    return-void
.end method
