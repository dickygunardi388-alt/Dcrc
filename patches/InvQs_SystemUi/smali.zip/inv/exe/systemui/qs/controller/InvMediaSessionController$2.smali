.class public Linv/exe/systemui/qs/controller/InvMediaSessionController$2;
.super Ljava/lang/Object;
.source "MediaSessionController.java"

# interfaces
.implements Landroid/media/session/MediaSessionManager$OnActiveSessionsChangedListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Linv/exe/systemui/qs/controller/InvMediaSessionController;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field public final synthetic this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvMediaSessionController;)V
    .registers 2

    .line 79
    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$2;->this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onActiveSessionsChanged(Ljava/util/List;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/media/session/MediaController;",
            ">;)V"
        }
    .end annotation

    .line 81
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$2;->this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-static {p0, p1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->access$2(Linv/exe/systemui/qs/controller/InvMediaSessionController;Ljava/util/List;)V

    return-void
.end method
