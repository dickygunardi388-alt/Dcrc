.class public Linv/exe/systemui/qs/controller/InvMediaSessionController$1;
.super Landroid/media/session/MediaController$Callback;
.source "MediaSessionController.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Linv/exe/systemui/qs/controller/InvMediaSessionController;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field public final synthetic this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvMediaSessionController;)V
    .registers 2

    .line 63
    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$1;->this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-direct {p0}, Landroid/media/session/MediaController$Callback;-><init>()V

    return-void
.end method


# virtual methods
.method public onMetadataChanged(Landroid/media/MediaMetadata;)V
    .registers 2

    .line 65
    iget-object p1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$1;->this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-static {p1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->access$0(Linv/exe/systemui/qs/controller/InvMediaSessionController;)V

    .line 66
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$1;->this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-static {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->access$1(Linv/exe/systemui/qs/controller/InvMediaSessionController;)V

    return-void
.end method

.method public onPlaybackStateChanged(Landroid/media/session/PlaybackState;)V
    .registers 2

    .line 70
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$1;->this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-static {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->access$1(Linv/exe/systemui/qs/controller/InvMediaSessionController;)V

    return-void
.end method

.method public onSessionDestroyed()V
    .registers 1

    .line 74
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$1;->this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->refresh()V

    return-void
.end method
