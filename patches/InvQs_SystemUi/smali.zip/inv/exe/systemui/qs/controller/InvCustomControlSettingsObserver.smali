.class public final Linv/exe/systemui/qs/controller/InvCustomControlSettingsObserver;
.super Landroid/database/ContentObserver;
.source "InvCustomControlSettingsObserver.java"


# instance fields
.field private final controller:Linv/exe/systemui/qs/controller/InvQsPanelController;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V
    .registers 4

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    invoke-direct {p0, v0}, Landroid/database/ContentObserver;-><init>(Landroid/os/Handler;)V

    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvCustomControlSettingsObserver;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    return-void
.end method


# virtual methods
.method public onChange(Z)V
    .registers 2

    iget-object p1, p0, Linv/exe/systemui/qs/controller/InvCustomControlSettingsObserver;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    if-eqz p1, :cond_7

    invoke-virtual {p1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->onCustomControlSettingsChanged()V

    :cond_7
    return-void
.end method

.method public onChange(ZLandroid/net/Uri;)V
    .registers 3

    iget-object p1, p0, Linv/exe/systemui/qs/controller/InvCustomControlSettingsObserver;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    if-eqz p1, :cond_7

    invoke-virtual {p1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->onCustomControlSettingsChanged()V

    :cond_7
    return-void
.end method
