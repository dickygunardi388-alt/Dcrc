.class public final Linv/exe/systemui/qs/controller/InvCustomImageImportRunnable;
.super Ljava/lang/Object;
.source "InvCustomImageImportRunnable.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final context:Landroid/content/Context;

.field private final controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

.field private final root:Landroid/view/View;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/content/Context;Landroid/view/View;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvCustomImageImportRunnable;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iput-object p2, p0, Linv/exe/systemui/qs/controller/InvCustomImageImportRunnable;->context:Landroid/content/Context;

    iput-object p3, p0, Linv/exe/systemui/qs/controller/InvCustomImageImportRunnable;->root:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvCustomImageImportRunnable;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvCustomImageImportRunnable;->context:Landroid/content/Context;

    if-eqz v0, :cond_17

    if-eqz v1, :cond_17

    invoke-virtual {v0, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->syncCustomImageFile(Landroid/content/Context;)V

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvCustomImageImportRunnable;->root:Landroid/view/View;

    if-eqz v1, :cond_17

    new-instance v2, Linv/exe/systemui/qs/controller/InvCustomImageRenderRunnable;

    invoke-direct {v2, v0, v1}, Linv/exe/systemui/qs/controller/InvCustomImageRenderRunnable;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_17
    return-void
.end method
