.class public Linv/exe/systemui/qs/controller/InvMediaSessionController$4;
.super Ljava/lang/Object;
.source "MediaSessionController.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Linv/exe/systemui/qs/controller/InvMediaSessionController;->refresh()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field public final synthetic this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvMediaSessionController;)V
    .registers 2

    .line 142
    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$4;->this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 1

    .line 143
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$4;->this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->refresh()V

    return-void
.end method
