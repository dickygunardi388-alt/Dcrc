.class public final Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnTouchListener;


# instance fields
.field private final card:Landroid/view/View;

.field private final controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

.field private lastIndex:I

.field private lastResizeAt:J

.field private startCellH:I

.field private startCellW:I

.field private startIndex:I

.field private startX:F

.field private startY:F


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iput-object p2, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->card:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .registers 12

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$0(Linv/exe/systemui/qs/controller/InvQsPanelController;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_a

    return v1

    :cond_a
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v2, 0x1

    if-eqz v0, :cond_1a

    if-eq v0, v2, :cond_b4

    const/4 v3, 0x2

    if-eq v0, v3, :cond_5e

    const/4 v3, 0x3

    if-eq v0, v3, :cond_ca

    return v2

    :cond_1a
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result v0

    iput v0, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->startX:F

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result v0

    iput v0, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->startY:F

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$1(Linv/exe/systemui/qs/controller/InvQsPanelController;)Linv/exe/systemui/qs/model/InvPanelRepository;

    move-result-object v0

    invoke-virtual {v0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getCustomImageSizeIndex()I

    move-result v0

    iput v0, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->startIndex:I

    iput v0, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->lastIndex:I

    iget-object v3, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iget-object v4, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->card:Landroid/view/View;

    invoke-static {v3, v4, v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$5(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;I)[I

    move-result-object v0

    aget v3, v0, v1

    iput v3, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->startCellW:I

    aget v0, v0, v2

    iput v0, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->startCellH:I

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getEventTime()J

    move-result-wide v3

    const-wide/16 v5, 0x78

    sub-long/2addr v3, v5

    iput-wide v3, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->lastResizeAt:J

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p2

    if-eqz p2, :cond_56

    invoke-interface {p2, v2}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_56
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->card:Landroid/view/View;

    invoke-static {p2, v0, v2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$6(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;Z)V

    return v2

    :cond_5e
    iget-object v3, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result v0

    iget v1, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->startX:F

    sub-float v4, v0, v1

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result v0

    iget v1, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->startY:F

    sub-float v5, v0, v1

    iget v6, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->startIndex:I

    iget v7, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->startCellW:I

    iget v8, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->startCellH:I

    invoke-static/range {v3 .. v8}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$7(Linv/exe/systemui/qs/controller/InvQsPanelController;FFIII)I

    move-result v0

    iget v1, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->lastIndex:I

    if-eq v0, v1, :cond_b3

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getEventTime()J

    move-result-wide v3

    iget-wide v5, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->lastResizeAt:J

    sub-long/2addr v3, v5

    const-wide/16 v5, 0x0

    cmp-long v1, v3, v5

    if-ltz v1, :cond_b3

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$1(Linv/exe/systemui/qs/controller/InvQsPanelController;)Linv/exe/systemui/qs/model/InvPanelRepository;

    move-result-object v1

    invoke-virtual {v1, v0}, Linv/exe/systemui/qs/model/InvPanelRepository;->setCustomImageSizeIndex(I)V

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$1(Linv/exe/systemui/qs/controller/InvQsPanelController;)Linv/exe/systemui/qs/model/InvPanelRepository;

    move-result-object v0

    invoke-virtual {v0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getCustomImageSizeIndex()I

    move-result v0

    iput v0, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->lastIndex:I

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getEventTime()J

    move-result-wide v0

    iput-wide v0, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->lastResizeAt:J

    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$14(Linv/exe/systemui/qs/controller/InvQsPanelController;)Z

    move-result p2

    invoke-static {p1}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->pulse(Landroid/view/View;)V

    const/4 p0, 0x4

    invoke-virtual {p1, p0}, Landroid/view/View;->performHapticFeedback(I)Z

    :cond_b3
    return v2

    :cond_b4
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p2

    if-eqz p2, :cond_bd

    invoke-interface {p2, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_bd
    iget-object p1, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->card:Landroid/view/View;

    invoke-static {p1, p2, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$6(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;Z)V

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$14(Linv/exe/systemui/qs/controller/InvQsPanelController;)Z

    return v2

    :cond_ca
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p2

    if-eqz p2, :cond_d3

    invoke-interface {p2, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_d3
    iget-object p1, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;->card:Landroid/view/View;

    invoke-static {p1, p2, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$6(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;Z)V

    return v2
.end method
