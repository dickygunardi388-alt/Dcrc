.class public Linv/exe/systemui/qs/controller/InvQsPanelController$2;
.super Ljava/lang/Object;
.source "QsPanelController.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Linv/exe/systemui/qs/controller/InvQsPanelController;->attachMediaResize(Landroid/view/View;Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field public lastIndex:I

.field public lastResizeAt:J

.field public startCellH:I

.field public startCellW:I

.field public startIndex:I

.field public startX:F

.field public startY:F

.field public final synthetic this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

.field private final synthetic val$card:Landroid/view/View;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;)V
    .registers 3

    .line 360
    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iput-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->val$card:Landroid/view/View;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .registers 12

    .line 370
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$0(Linv/exe/systemui/qs/controller/InvQsPanelController;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_a

    return v1

    .line 371
    :cond_a
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v2, 0x1

    if-eqz v0, :cond_cd

    if-eq v0, v2, :cond_ab

    const/4 v3, 0x2

    if-eq v0, v3, :cond_1a

    const/4 p2, 0x3

    if-eq v0, p2, :cond_ab

    return v2

    .line 386
    :cond_1a
    iget-object v3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    .line 387
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result v0

    iget v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->startX:F

    sub-float v4, v0, v1

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result v0

    iget v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->startY:F

    sub-float v5, v0, v1

    .line 388
    iget v6, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->startIndex:I

    iget v7, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->startCellW:I

    iget v8, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->startCellH:I

    .line 386
    invoke-static/range {v3 .. v8}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$7(Linv/exe/systemui/qs/controller/InvQsPanelController;FFIII)I

    move-result v0

    .line 389
    iget v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->lastIndex:I

    if-eq v0, v1, :cond_aa

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getEventTime()J

    move-result-wide v3

    iget-wide v5, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->lastResizeAt:J

    sub-long/2addr v3, v5

    const-wide/16 v5, 0x0

    cmp-long v1, v3, v5

    if-ltz v1, :cond_aa

    .line 390
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$1(Linv/exe/systemui/qs/controller/InvQsPanelController;)Linv/exe/systemui/qs/model/InvPanelRepository;

    move-result-object v1

    invoke-virtual {v1, v0}, Linv/exe/systemui/qs/model/InvPanelRepository;->setMediaSizeIndex(I)V

    .line 391
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$1(Linv/exe/systemui/qs/controller/InvQsPanelController;)Linv/exe/systemui/qs/model/InvPanelRepository;

    move-result-object v0

    invoke-virtual {v0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getMediaSizeIndex()I

    move-result v0

    iput v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->lastIndex:I

    .line 392
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getEventTime()J

    move-result-wide v0

    iput-wide v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->lastResizeAt:J

    .line 393
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$8(Linv/exe/systemui/qs/controller/InvQsPanelController;)Z

    move-result p2

    if-nez p2, :cond_a3

    .line 394
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$9(Linv/exe/systemui/qs/controller/InvQsPanelController;)Ljava/util/Map;

    move-result-object p2

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->val$card:Landroid/view/View;

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$1(Linv/exe/systemui/qs/controller/InvQsPanelController;)Linv/exe/systemui/qs/model/InvPanelRepository;

    move-result-object v1

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->getMediaSpanW()I

    move-result v1

    iget-object v3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {v3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$1(Linv/exe/systemui/qs/controller/InvQsPanelController;)Linv/exe/systemui/qs/model/InvPanelRepository;

    move-result-object v3

    invoke-virtual {v3}, Linv/exe/systemui/qs/model/InvPanelRepository;->getMediaSpanH()I

    move-result v3

    filled-new-array {v1, v3}, [I

    move-result-object v1

    invoke-interface {p2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 395
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->val$card:Landroid/view/View;

    invoke-static {p2, v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$10(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;)V

    .line 396
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->val$card:Landroid/view/View;

    const-string p2, "media_content"

    invoke-static {p2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result p2

    invoke-virtual {p0, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p0

    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->softRefresh(Landroid/view/View;)V

    .line 398
    :cond_a3
    invoke-static {p1}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->pulse(Landroid/view/View;)V

    const/4 p0, 0x4

    .line 399
    invoke-virtual {p1, p0}, Landroid/view/View;->performHapticFeedback(I)Z

    :cond_aa
    return v2

    .line 405
    :cond_ab
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p2

    if-eqz p2, :cond_b8

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    invoke-interface {p1, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 406
    :cond_b8
    iget-object p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->val$card:Landroid/view/View;

    invoke-static {p1, p2, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$6(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;Z)V

    .line 407
    iget-object p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {p1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$8(Linv/exe/systemui/qs/controller/InvQsPanelController;)Z

    move-result p1

    if-nez p1, :cond_cc

    iget-object p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {p1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$11(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    .line 408
    :cond_cc
    return v2

    .line 373
    :cond_cd
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result v0

    iput v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->startX:F

    .line 374
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result v0

    iput v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->startY:F

    .line 375
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$1(Linv/exe/systemui/qs/controller/InvQsPanelController;)Linv/exe/systemui/qs/model/InvPanelRepository;

    move-result-object v0

    invoke-virtual {v0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getMediaSizeIndex()I

    move-result v0

    iput v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->startIndex:I

    .line 376
    iput v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->lastIndex:I

    .line 377
    iget-object v3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iget-object v4, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->val$card:Landroid/view/View;

    invoke-static {v3, v4, v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$5(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;I)[I

    move-result-object v0

    .line 378
    aget v3, v0, v1

    iput v3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->startCellW:I

    .line 379
    aget v0, v0, v2

    iput v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->startCellH:I

    .line 380
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getEventTime()J

    move-result-wide v3

    const-wide/16 v5, 0x78

    sub-long/2addr v3, v5

    iput-wide v3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->lastResizeAt:J

    .line 381
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p2

    if-eqz p2, :cond_10d

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    invoke-interface {p1, v2}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 382
    :cond_10d
    iget-object p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->val$card:Landroid/view/View;

    invoke-virtual {p1, v1}, Landroid/view/View;->performHapticFeedback(I)Z

    .line 383
    iget-object p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;->val$card:Landroid/view/View;

    invoke-static {p1, p0, v2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$6(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;Z)V

    return v2
.end method
