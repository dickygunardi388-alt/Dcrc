.class public final synthetic Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda18;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Linv/exe/systemui/qs/ui/InvVerticalLevelSlider$Listener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "b849e8a9f6cceff267251a73644faacc801ad726cc8f22a9c323c56a203f5446"
.end annotation


# instance fields
.field public final synthetic f$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

.field public final synthetic f$1:Z


# direct methods
.method public synthetic constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Z)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda18;->f$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iput-boolean p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda18;->f$1:Z

    return-void
.end method


# virtual methods
.method public final onChanged(I)V
    .registers 3

    .line 0
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda18;->f$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iget-boolean p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda18;->f$1:Z

    invoke-virtual {v0, p0, p1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->lambda$12$inv-exe-systemui-qs-QsPanelController(ZI)V

    return-void
.end method
