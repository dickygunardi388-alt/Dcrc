.class public Linv/exe/systemui/qs/controller/InvMediaSessionController$5;
.super Ljava/lang/Object;
.source "MediaSessionController.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Linv/exe/systemui/qs/controller/InvMediaSessionController;->loadArtwork(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field public final synthetic this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;

.field private final synthetic val$token:Landroid/media/session/MediaSession$Token;

.field private final synthetic val$uriText:Ljava/lang/String;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvMediaSessionController;Ljava/lang/String;Landroid/media/session/MediaSession$Token;)V
    .registers 4

    .line 586
    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5;->this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    iput-object p2, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5;->val$uriText:Ljava/lang/String;

    iput-object p3, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5;->val$token:Landroid/media/session/MediaSession$Token;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static synthetic access$0(Linv/exe/systemui/qs/controller/InvMediaSessionController$5;)Linv/exe/systemui/qs/controller/InvMediaSessionController;
    .registers 1

    .line 586
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5;->this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    return-object p0
.end method


# virtual methods
.method public run()V
    .registers 6

    .line 588
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5;->this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5;->val$uriText:Ljava/lang/String;

    invoke-static {v0, v1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->access$3(Linv/exe/systemui/qs/controller/InvMediaSessionController;Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    .line 589
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5;->this$0:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-static {v1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->access$4(Linv/exe/systemui/qs/controller/InvMediaSessionController;)Landroid/os/Handler;

    move-result-object v1

    new-instance v2, Linv/exe/systemui/qs/controller/InvMediaSessionController$5$1;

    iget-object v3, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5;->val$token:Landroid/media/session/MediaSession$Token;

    iget-object v4, p0, Linv/exe/systemui/qs/controller/InvMediaSessionController$5;->val$uriText:Ljava/lang/String;

    invoke-direct {v2, p0, v3, v4, v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController$5$1;-><init>(Linv/exe/systemui/qs/controller/InvMediaSessionController$5;Landroid/media/session/MediaSession$Token;Ljava/lang/String;Landroid/graphics/Bitmap;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
