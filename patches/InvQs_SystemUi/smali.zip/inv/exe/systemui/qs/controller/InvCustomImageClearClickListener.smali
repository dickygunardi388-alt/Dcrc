.class public final Linv/exe/systemui/qs/controller/InvCustomImageClearClickListener;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field private final card:Landroid/view/View;

.field private final controller:Linv/exe/systemui/qs/controller/InvQsPanelController;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvCustomImageClearClickListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iput-object p2, p0, Linv/exe/systemui/qs/controller/InvCustomImageClearClickListener;->card:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 4

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvCustomImageClearClickListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvCustomImageClearClickListener;->card:Landroid/view/View;

    invoke-virtual {v0, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->clearCustomImageFromEdit(Landroid/view/View;)V

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->performHapticFeedback(I)Z

    return-void
.end method
