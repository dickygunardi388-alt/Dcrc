.class public Linv/exe/systemui/qs/controller/InvConnectivityController;
.super Ljava/lang/Object;
.source "ConnectivityController.java"


# instance fields
.field private final bluetooth:Landroid/bluetooth/BluetoothAdapter;

.field private bluetoothController:Ljava/lang/Object;

.field private final context:Landroid/content/Context;

.field private final wifi:Landroid/net/wifi/WifiManager;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 4

    .line 34
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 35
    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->context:Landroid/content/Context;

    .line 36
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    if-nez v0, :cond_d

    move-object v0, p1

    goto :goto_11

    :cond_d
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    .line 37
    :goto_11
    const-string v1, "wifi"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/net/wifi/WifiManager;

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->wifi:Landroid/net/wifi/WifiManager;

    const/4 v0, 0x0

    .line 40
    :try_start_1c
    const-string v1, "bluetooth"

    invoke-virtual {p1, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/bluetooth/BluetoothManager;

    if-nez p1, :cond_27

    goto :goto_2c

    .line 41
    :cond_27
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothManager;->getAdapter()Landroid/bluetooth/BluetoothAdapter;

    move-result-object p1
    :try_end_2b
    .catchall {:try_start_1c .. :try_end_2b} :catchall_2c

    move-object v0, p1

    :catchall_2c
    :goto_2c
    if-nez v0, :cond_32

    .line 43
    invoke-static {}, Landroid/bluetooth/BluetoothAdapter;->getDefaultAdapter()Landroid/bluetooth/BluetoothAdapter;

    move-result-object v0

    :cond_32
    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->bluetooth:Landroid/bluetooth/BluetoothAdapter;

    .line 44
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->findSystemUiBluetoothController()Ljava/lang/Object;

    move-result-object p1

    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->bluetoothController:Ljava/lang/Object;

    return-void
.end method

.method private findSystemUiBluetoothController()Ljava/lang/Object;
    .registers 7

    const/4 p0, 0x0

    .line 286
    :try_start_1
    const-string v0, "com.android.systemui.Dependency"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    .line 287
    const-string v1, "com.android.systemui.statusbar.policy.BluetoothController"

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    .line 288
    const-string v2, "get"

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Class;

    const-class v4, Ljava/lang/Class;

    const/4 v5, 0x0

    aput-object v4, v3, v5

    invoke-virtual {v0, v2, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    .line 289
    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v0, p0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_23
    .catchall {:try_start_1 .. :try_end_23} :catchall_23

    :catchall_23
    return-object p0
.end method

.method private getBluetoothController()Ljava/lang/Object;
    .registers 2

    .line 280
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->bluetoothController:Ljava/lang/Object;

    if-nez v0, :cond_a

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->findSystemUiBluetoothController()Ljava/lang/Object;

    move-result-object v0

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->bluetoothController:Ljava/lang/Object;

    .line 281
    :cond_a
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->bluetoothController:Ljava/lang/Object;

    return-object p0
.end method

.method private getCarrierName()Ljava/lang/String;
    .registers 4

    .line 230
    :try_start_0
    invoke-static {}, Landroid/telephony/SubscriptionManager;->getDefaultDataSubscriptionId()I

    move-result v0

    .line 231
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->context:Landroid/content/Context;

    const-string v1, "telephony_subscription_service"

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/telephony/SubscriptionManager;

    if-nez p0, :cond_12

    const/4 p0, 0x0

    goto :goto_16

    .line 232
    :cond_12
    invoke-virtual {p0}, Landroid/telephony/SubscriptionManager;->getActiveSubscriptionInfoList()Ljava/util/List;

    move-result-object p0

    :goto_16
    if-eqz p0, :cond_40

    .line 234
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1c
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-nez v1, :cond_23

    goto :goto_40

    :cond_23
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/telephony/SubscriptionInfo;

    if-eqz v1, :cond_1c

    .line 235
    invoke-virtual {v1}, Landroid/telephony/SubscriptionInfo;->getSubscriptionId()I

    move-result v2

    if-ne v2, v0, :cond_1c

    invoke-virtual {v1}, Landroid/telephony/SubscriptionInfo;->getDisplayName()Ljava/lang/CharSequence;

    move-result-object v2

    if-eqz v2, :cond_1c

    .line 236
    invoke-virtual {v1}, Landroid/telephony/SubscriptionInfo;->getDisplayName()Ljava/lang/CharSequence;

    move-result-object p0

    invoke-interface {p0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_3f
    .catchall {:try_start_0 .. :try_end_3f} :catchall_40

    return-object p0

    .line 241
    :catchall_40
    :cond_40
    :goto_40
    const-string p0, "Mobile data"

    return-object p0
.end method

.method private getMobileNetworkLabel()Ljava/lang/String;
    .registers 2

    .line 246
    const-string v0, ""

    :try_start_2
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->getTelephonyManager()Landroid/telephony/TelephonyManager;

    move-result-object p0

    if-nez p0, :cond_9

    return-object v0

    .line 248
    :cond_9
    invoke-virtual {p0}, Landroid/telephony/TelephonyManager;->getDataNetworkType()I

    move-result p0

    invoke-static {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->networkTypeName(I)Ljava/lang/String;

    move-result-object p0
    :try_end_11
    .catchall {:try_start_2 .. :try_end_11} :catchall_12

    return-object p0

    :catchall_12
    return-object v0
.end method

.method private getTelephonyManager()Landroid/telephony/TelephonyManager;
    .registers 3

    .line 219
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->context:Landroid/content/Context;

    const-string v0, "phone"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/telephony/TelephonyManager;

    if-nez p0, :cond_e

    const/4 p0, 0x0

    return-object p0

    .line 222
    :cond_e
    :try_start_e
    invoke-static {}, Landroid/telephony/SubscriptionManager;->getDefaultDataSubscriptionId()I

    move-result v0

    .line 223
    invoke-static {v0}, Landroid/telephony/SubscriptionManager;->isValidSubscriptionId(I)Z

    move-result v1

    if-eqz v1, :cond_1c

    invoke-virtual {p0, v0}, Landroid/telephony/TelephonyManager;->createForSubscriptionId(I)Landroid/telephony/TelephonyManager;

    move-result-object p0
    :try_end_1c
    .catchall {:try_start_e .. :try_end_1c} :catchall_1c

    :catchall_1c
    :cond_1c
    return-object p0
.end method

.method public static invokeBoolean(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Boolean;
    .registers 5

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 298
    :cond_4
    :try_start_4
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Class;

    invoke-virtual {v1, p1, v0}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    invoke-virtual {p1, p0, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    .line 299
    instance-of p1, p0, Ljava/lang/Boolean;

    if-eqz p1, :cond_1a

    check-cast p0, Ljava/lang/Boolean;
    :try_end_19
    .catchall {:try_start_4 .. :try_end_19} :catchall_1a

    return-object p0

    :catchall_1a
    :cond_1a
    return-object v0
.end method

.method public static invokeObject(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;
    .registers 5

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 306
    :cond_4
    :try_start_4
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/Class;

    invoke-virtual {v1, p1, v0}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    invoke-virtual {p1, p0, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_13
    .catchall {:try_start_4 .. :try_end_13} :catchall_14

    return-object p0

    :catchall_14
    return-object v0
.end method

.method private static networkTypeName(I)Ljava/lang/String;
    .registers 3

    .line 254
    const-string v0, "2G"

    const-string v1, "3G"

    packed-switch p0, :pswitch_data_20

    .line 275
    const-string p0, ""

    return-object p0

    .line 255
    :pswitch_a  #0x14
    const-string p0, "5G"

    return-object p0

    .line 256
    :pswitch_d  #0x13
    const-string p0, "4G+"

    return-object p0

    .line 258
    :pswitch_10  #0x12
    const-string p0, "IWLAN"

    return-object p0

    :pswitch_13  #0x10, 0x11
    return-object v0

    :pswitch_14  #0xe, 0xf
    return-object v1

    .line 257
    :pswitch_15  #0xd
    const-string p0, "4G"

    return-object p0

    :pswitch_18  #0xc
    return-object v1

    :pswitch_19  #0xb
    return-object v0

    :pswitch_1a  #0x8, 0x9, 0xa
    return-object v1

    :pswitch_1b  #0x7
    return-object v0

    :pswitch_1c  #0x5, 0x6
    return-object v1

    :pswitch_1d  #0x4
    return-object v0

    :pswitch_1e  #0x3
    return-object v1

    :pswitch_1f  #0x1, 0x2
    return-object v0

    :pswitch_data_20
    .packed-switch 0x1
        :pswitch_1f  #00000001
        :pswitch_1f  #00000002
        :pswitch_1e  #00000003
        :pswitch_1d  #00000004
        :pswitch_1c  #00000005
        :pswitch_1c  #00000006
        :pswitch_1b  #00000007
        :pswitch_1a  #00000008
        :pswitch_1a  #00000009
        :pswitch_1a  #0000000a
        :pswitch_19  #0000000b
        :pswitch_18  #0000000c
        :pswitch_15  #0000000d
        :pswitch_14  #0000000e
        :pswitch_14  #0000000f
        :pswitch_13  #00000010
        :pswitch_13  #00000011
        :pswitch_10  #00000012
        :pswitch_d  #00000013
        :pswitch_a  #00000014
    .end packed-switch
.end method

.method private open(Ljava/lang/String;)V
    .registers 4

    .line 311
    :try_start_0
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->context:Landroid/content/Context;

    new-instance v1, Landroid/content/Intent;

    invoke-direct {v1, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/high16 p1, 0x10000000

    invoke-virtual {v1, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_10
    .catchall {:try_start_0 .. :try_end_10} :catchall_11

    return-void

    .line 312
    :catchall_11
    const-string p1, "Settings tidak tersedia"

    invoke-direct {p0, p1}, Linv/exe/systemui/qs/controller/InvConnectivityController;->toast(Ljava/lang/String;)V

    return-void
.end method

.method private toast(Ljava/lang/String;)V
    .registers 3

    .line 316
    :try_start_0
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->context:Landroid/content/Context;

    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V
    :try_end_a
    .catchall {:try_start_0 .. :try_end_a} :catchall_a

    :catchall_a
    return-void
.end method


# virtual methods
.method public getBluetoothSummary()Ljava/lang/String;
    .registers 7

    .line 191
    const-string v0, "On"

    const-string v1, "Off"

    :try_start_4
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->getBluetoothController()Ljava/lang/Object;

    move-result-object v2

    .line 192
    const-string v3, "isBluetoothEnabled"

    invoke-static {v2, v3}, Linv/exe/systemui/qs/controller/InvConnectivityController;->invokeBoolean(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v3

    if-eqz v3, :cond_17

    .line 193
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-nez v4, :cond_17

    return-object v1

    .line 194
    :cond_17
    const-string v4, "isBluetoothConnected"

    invoke-static {v2, v4}, Linv/exe/systemui/qs/controller/InvConnectivityController;->invokeBoolean(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v4

    .line 195
    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v5, v4}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3f

    .line 196
    const-string v3, "getConnectedDeviceName"

    invoke-static {v2, v3}, Linv/exe/systemui/qs/controller/InvConnectivityController;->invokeObject(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    if-eqz v2, :cond_3c

    .line 197
    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_3c

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0
    :try_end_3b
    .catchall {:try_start_4 .. :try_end_3b} :catchall_42

    return-object p0

    .line 198
    :cond_3c
    const-string p0, "Connected"

    return-object p0

    :cond_3f
    if-eqz v3, :cond_42

    return-object v0

    .line 202
    :catchall_42
    :cond_42
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->isBluetoothEnabled()Z

    move-result p0

    if-eqz p0, :cond_49

    goto :goto_4a

    :cond_49
    move-object v0, v1

    :goto_4a
    return-object v0
.end method

.method public getInternetSummary()Ljava/lang/String;
    .registers 3

    .line 139
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->isMobileDataEnabled()Z

    move-result v0

    .line 140
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->isWifiEnabled()Z

    move-result v1

    if-eqz v0, :cond_f

    if-eqz v1, :cond_f

    .line 141
    const-string p0, "Connected"

    return-object p0

    :cond_f
    if-eqz v1, :cond_16

    .line 142
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->getWifiSsid()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_16
    if-eqz v0, :cond_1d

    .line 143
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->getMobileSummary()Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 144
    :cond_1d
    const-string p0, "Off"

    return-object p0
.end method

.method public getMobileSummary()Ljava/lang/String;
    .registers 3

    .line 130
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->isMobileDataEnabled()Z

    move-result v0

    if-nez v0, :cond_9

    const-string p0, "Off"

    return-object p0

    .line 131
    :cond_9
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->getCarrierName()Ljava/lang/String;

    move-result-object v0

    .line 132
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->getMobileNetworkLabel()Ljava/lang/String;

    move-result-object p0

    .line 133
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_18

    return-object p0

    .line 134
    :cond_18
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_3d

    const-string v1, "UNKNOWN"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_27

    goto :goto_3d

    .line 135
    :cond_27
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v0, " "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_3d
    :goto_3d
    return-object v0
.end method

.method public getWifiScanLabels(I)Ljava/util/List;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 86
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 88
    :try_start_5
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->wifi:Landroid/net/wifi/WifiManager;

    if-eqz v1, :cond_48

    invoke-virtual {v1}, Landroid/net/wifi/WifiManager;->isWifiEnabled()Z

    move-result v1

    if-nez v1, :cond_10

    goto :goto_48

    .line 89
    :cond_10
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->wifi:Landroid/net/wifi/WifiManager;

    invoke-virtual {p0}, Landroid/net/wifi/WifiManager;->getScanResults()Ljava/util/List;

    move-result-object p0

    if-nez p0, :cond_19

    goto :goto_48

    .line 91
    :cond_19
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1d
    :goto_1d
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-nez v1, :cond_24

    goto :goto_48

    :cond_24
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/net/wifi/ScanResult;

    if-eqz v1, :cond_1d

    .line 92
    iget-object v2, v1, Landroid/net/wifi/ScanResult;->SSID:Ljava/lang/String;

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_35

    goto :goto_1d

    .line 93
    :cond_35
    iget-object v2, v1, Landroid/net/wifi/ScanResult;->SSID:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_42

    iget-object v1, v1, Landroid/net/wifi/ScanResult;->SSID:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 94
    :cond_42
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1
    :try_end_46
    .catchall {:try_start_5 .. :try_end_46} :catchall_48

    if-lt v1, p1, :cond_1d

    :catchall_48
    :cond_48
    :goto_48
    return-object v0
.end method

.method public getWifiSsid()Ljava/lang/String;
    .registers 5

    .line 70
    const-string v0, "Off"

    :try_start_2
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->isWifiEnabled()Z

    move-result v1

    if-nez v1, :cond_9

    return-object v0

    .line 71
    :cond_9
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->wifi:Landroid/net/wifi/WifiManager;

    if-nez v1, :cond_f

    const/4 v1, 0x0

    goto :goto_13

    :cond_f
    invoke-virtual {v1}, Landroid/net/wifi/WifiManager;->getConnectionInfo()Landroid/net/wifi/WifiInfo;

    move-result-object v1
    :try_end_13
    .catchall {:try_start_2 .. :try_end_13} :catchall_3d

    .line 72
    :goto_13
    const-string v2, "Not connected"

    if-nez v1, :cond_18

    return-object v2

    .line 73
    :cond_18
    :try_start_18
    invoke-virtual {v1}, Landroid/net/wifi/WifiInfo;->getSSID()Ljava/lang/String;

    move-result-object v1

    .line 74
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_3c

    .line 75
    const-string v3, "<unknown ssid>"

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_3c

    .line 76
    const-string v3, "0x"

    invoke-virtual {v1, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_33

    goto :goto_3c

    .line 79
    :cond_33
    const-string v2, "\""

    const-string v3, ""

    invoke-virtual {v1, v2, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0
    :try_end_3b
    .catchall {:try_start_18 .. :try_end_3b} :catchall_3d

    return-object p0

    :cond_3c
    :goto_3c
    return-object v2

    .line 81
    :catchall_3d
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->isWifiEnabled()Z

    move-result p0

    if-eqz p0, :cond_45

    const-string v0, "On"

    :cond_45
    return-object v0
.end method

.method public isAirplaneMode()Z
    .registers 3

    const/4 v0, 0x0

    .line 206
    :try_start_1
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->context:Landroid/content/Context;

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const-string v1, "airplane_mode_on"

    invoke-static {p0, v1, v0}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result p0
    :try_end_d
    .catchall {:try_start_1 .. :try_end_d} :catchall_11

    const/4 v1, 0x1

    if-ne p0, v1, :cond_11

    return v1

    :catchall_11
    :cond_11
    return v0
.end method

.method public isBluetoothEnabled()Z
    .registers 3

    .line 158
    :try_start_0
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->getBluetoothController()Ljava/lang/Object;

    move-result-object v0

    .line 159
    const-string v1, "isBluetoothEnabled"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/controller/InvConnectivityController;->invokeBoolean(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v0

    if-eqz v0, :cond_11

    .line 160
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0
    :try_end_10
    .catchall {:try_start_0 .. :try_end_10} :catchall_11

    return p0

    :catchall_11
    :cond_11
    const/4 v0, 0x0

    .line 162
    :try_start_12
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->bluetooth:Landroid/bluetooth/BluetoothAdapter;

    if-eqz p0, :cond_1e

    invoke-virtual {p0}, Landroid/bluetooth/BluetoothAdapter;->isEnabled()Z

    move-result p0
    :try_end_1a
    .catchall {:try_start_12 .. :try_end_1a} :catchall_1e

    if-eqz p0, :cond_1e

    const/4 p0, 0x1

    return p0

    :catchall_1e
    :cond_1e
    return v0
.end method

.method public isInternetEnabled()Z
    .registers 2

    .line 148
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->isWifiEnabled()Z

    move-result v0

    if-nez v0, :cond_e

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->isMobileDataEnabled()Z

    move-result p0

    if-nez p0, :cond_e

    const/4 p0, 0x0

    return p0

    :cond_e
    const/4 p0, 0x1

    return p0
.end method

.method public isMobileDataEnabled()Z
    .registers 3

    const/4 v0, 0x0

    .line 102
    :try_start_1
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->getTelephonyManager()Landroid/telephony/TelephonyManager;

    move-result-object p0

    .line 103
    const-string v1, "isDataEnabled"

    invoke-static {p0, v1}, Linv/exe/systemui/qs/controller/InvConnectivityController;->invokeBoolean(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v1

    if-eqz v1, :cond_12

    .line 104
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    return p0

    .line 105
    :cond_12
    const-string v1, "getDataEnabled"

    invoke-static {p0, v1}, Linv/exe/systemui/qs/controller/InvConnectivityController;->invokeBoolean(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object p0

    if-eqz p0, :cond_22

    .line 106
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0
    :try_end_1e
    .catchall {:try_start_1 .. :try_end_1e} :catchall_22

    if-eqz p0, :cond_22

    const/4 p0, 0x1

    return p0

    :catchall_22
    :cond_22
    return v0
.end method

.method public isWifiEnabled()Z
    .registers 2

    const/4 v0, 0x0

    .line 48
    :try_start_1
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->wifi:Landroid/net/wifi/WifiManager;

    if-eqz p0, :cond_d

    invoke-virtual {p0}, Landroid/net/wifi/WifiManager;->isWifiEnabled()Z

    move-result p0
    :try_end_9
    .catchall {:try_start_1 .. :try_end_9} :catchall_d

    if-eqz p0, :cond_d

    const/4 p0, 0x1

    return p0

    :catchall_d
    :cond_d
    return v0
.end method

.method public openAirplaneSettings()V
    .registers 2

    .line 210
    const-string v0, "android.settings.AIRPLANE_MODE_SETTINGS"

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->open(Ljava/lang/String;)V

    return-void
.end method

.method public openAlarmSettings()V
    .registers 2

    const-string v0, "android.intent.action.SET_ALARM"

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->open(Ljava/lang/String;)V

    return-void
.end method

.method public openBatterySettings()V
    .registers 2

    const-string v0, "android.settings.BATTERY_SAVER_SETTINGS"

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->open(Ljava/lang/String;)V

    return-void
.end method

.method public openBluetoothSettings()V
    .registers 2

    .line 213
    const-string v0, "android.settings.BLUETOOTH_SETTINGS"

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->open(Ljava/lang/String;)V

    return-void
.end method

.method public openCastSettings()V
    .registers 2

    const-string v0, "android.settings.CAST_SETTINGS"

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->open(Ljava/lang/String;)V

    return-void
.end method

.method public openDisplaySettings()V
    .registers 2

    .line 216
    const-string v0, "android.settings.DISPLAY_SETTINGS"

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->open(Ljava/lang/String;)V

    return-void
.end method

.method public openDndSettings()V
    .registers 2

    .line 215
    const-string v0, "android.settings.ZEN_MODE_PRIORITY_SETTINGS"

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->open(Ljava/lang/String;)V

    return-void
.end method

.method public openHotspotSettings()V
    .registers 2

    .line 214
    const-string v0, "android.settings.WIRELESS_SETTINGS"

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->open(Ljava/lang/String;)V

    return-void
.end method

.method public openNetworkSettings()V
    .registers 2

    .line 211
    const-string v0, "android.settings.WIRELESS_SETTINGS"

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->open(Ljava/lang/String;)V

    return-void
.end method

.method public openNfcSettings()V
    .registers 2

    const-string v0, "android.settings.NFC_SETTINGS"

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->open(Ljava/lang/String;)V

    return-void
.end method

.method public openWifiSettings()V
    .registers 2

    .line 212
    const-string v0, "android.settings.WIFI_SETTINGS"

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->open(Ljava/lang/String;)V

    return-void
.end method

.method public setBluetoothEnabled(Z)Z
    .registers 9

    const/4 v0, 0x0

    .line 168
    :try_start_1
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->getBluetoothController()Ljava/lang/Object;

    move-result-object v1

    if-eqz v1, :cond_24

    .line 170
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const-string v3, "setBluetoothEnabled"

    const/4 v4, 0x1

    new-array v5, v4, [Ljava/lang/Class;

    sget-object v6, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    aput-object v6, v5, v0

    invoke-virtual {v2, v3, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    .line 171
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v2, v1, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_23
    .catchall {:try_start_1 .. :try_end_23} :catchall_24

    return v4

    .line 176
    :catchall_24
    :cond_24
    :try_start_24
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->bluetooth:Landroid/bluetooth/BluetoothAdapter;

    if-nez p0, :cond_29

    return v0

    :cond_29
    if-eqz p1, :cond_30

    .line 177
    invoke-virtual {p0}, Landroid/bluetooth/BluetoothAdapter;->enable()Z

    move-result p0

    goto :goto_34

    :cond_30
    invoke-virtual {p0}, Landroid/bluetooth/BluetoothAdapter;->disable()Z

    move-result p0
    :try_end_34
    .catchall {:try_start_24 .. :try_end_34} :catchall_35

    :goto_34
    return p0

    :catchall_35
    return v0
.end method

.method public setMobileDataEnabled(Z)Z
    .registers 9

    const/4 v0, 0x0

    .line 114
    :try_start_1
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->getTelephonyManager()Landroid/telephony/TelephonyManager;

    move-result-object v1

    if-nez v1, :cond_8

    return v0

    .line 116
    :cond_8
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const-string v3, "setDataEnabled"

    const/4 v4, 0x1

    new-array v5, v4, [Ljava/lang/Class;

    sget-object v6, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    aput-object v6, v5, v0

    invoke-virtual {v2, v3, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    .line 117
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v2, v1, p1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_24
    .catchall {:try_start_1 .. :try_end_24} :catchall_25

    return v4

    .line 120
    :catchall_25
    const-string p1, "Mobile data unavailable"

    invoke-direct {p0, p1}, Linv/exe/systemui/qs/controller/InvConnectivityController;->toast(Ljava/lang/String;)V

    return v0
.end method

.method public setWifiEnabled(Z)Z
    .registers 3

    const/4 v0, 0x0

    .line 54
    :try_start_1
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvConnectivityController;->wifi:Landroid/net/wifi/WifiManager;

    if-nez p0, :cond_6

    return v0

    .line 55
    :cond_6
    invoke-virtual {p0, p1}, Landroid/net/wifi/WifiManager;->setWifiEnabled(Z)Z

    move-result p0
    :try_end_a
    .catchall {:try_start_1 .. :try_end_a} :catchall_b

    return p0

    :catchall_b
    return v0
.end method

.method public toggleBluetooth()Z
    .registers 3

    .line 184
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->isBluetoothEnabled()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->setBluetoothEnabled(Z)Z

    move-result v0

    if-nez v0, :cond_11

    .line 185
    const-string v1, "Bluetooth unavailable"

    invoke-direct {p0, v1}, Linv/exe/systemui/qs/controller/InvConnectivityController;->toast(Ljava/lang/String;)V

    :cond_11
    return v0
.end method

.method public toggleInternetPrimary()Z
    .registers 1

    .line 153
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->toggleMobileData()Z

    move-result p0

    return p0
.end method

.method public toggleMobileData()Z
    .registers 2

    .line 126
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->isMobileDataEnabled()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->setMobileDataEnabled(Z)Z

    move-result p0

    return p0
.end method

.method public toggleWifi()Z
    .registers 3

    .line 62
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->isWifiEnabled()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    .line 63
    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/controller/InvConnectivityController;->setWifiEnabled(Z)Z

    move-result v0

    if-nez v0, :cond_11

    .line 64
    const-string v1, "Wi‑Fi unavailable"

    invoke-direct {p0, v1}, Linv/exe/systemui/qs/controller/InvConnectivityController;->toast(Ljava/lang/String;)V

    :cond_11
    return v0
.end method
