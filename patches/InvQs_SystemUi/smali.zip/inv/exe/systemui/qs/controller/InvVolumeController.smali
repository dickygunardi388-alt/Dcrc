.class public Linv/exe/systemui/qs/controller/InvVolumeController;
.super Ljava/lang/Object;
.source "VolumeController.java"


# instance fields
.field private final audio:Landroid/media/AudioManager;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-nez p1, :cond_7

    const/4 p1, 0x0

    goto :goto_f

    .line 11
    :cond_7
    const-string v0, "audio"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/media/AudioManager;

    :goto_f
    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvVolumeController;->audio:Landroid/media/AudioManager;

    return-void
.end method


# virtual methods
.method public getMax()I
    .registers 3

    const/16 v0, 0xf

    .line 15
    :try_start_2
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvVolumeController;->audio:Landroid/media/AudioManager;

    if-nez p0, :cond_7

    return v0

    :cond_7
    const/4 v1, 0x3

    invoke-virtual {p0, v1}, Landroid/media/AudioManager;->getStreamMaxVolume(I)I

    move-result p0

    const/4 v1, 0x1

    invoke-static {v1, p0}, Ljava/lang/Math;->max(II)I

    move-result p0
    :try_end_11
    .catchall {:try_start_2 .. :try_end_11} :catchall_12

    return p0

    :catchall_12
    return v0
.end method

.method public getVolume()I
    .registers 3

    const/4 v0, 0x0

    .line 20
    :try_start_1
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvVolumeController;->audio:Landroid/media/AudioManager;

    if-nez p0, :cond_6

    return v0

    :cond_6
    const/4 v1, 0x3

    invoke-virtual {p0, v1}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result p0
    :try_end_b
    .catchall {:try_start_1 .. :try_end_b} :catchall_c

    return p0

    :catchall_c
    return v0
.end method

.method public setVolume(I)V
    .registers 4

    .line 26
    :try_start_0
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvVolumeController;->audio:Landroid/media/AudioManager;

    if-nez v0, :cond_5

    goto :goto_16

    .line 28
    :cond_5
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvVolumeController;->getMax()I

    move-result p0

    invoke-static {p1, p0}, Ljava/lang/Math;->min(II)I

    move-result p0

    const/4 p1, 0x0

    invoke-static {p1, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    const/4 v1, 0x3

    .line 27
    invoke-virtual {v0, v1, p0, p1}, Landroid/media/AudioManager;->setStreamVolume(III)V
    :try_end_16
    .catchall {:try_start_0 .. :try_end_16} :catchall_16

    :catchall_16
    :goto_16
    return-void
.end method
