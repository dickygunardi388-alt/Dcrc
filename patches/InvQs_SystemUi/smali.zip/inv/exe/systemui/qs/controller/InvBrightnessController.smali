.class public Linv/exe/systemui/qs/controller/InvBrightnessController;
.super Ljava/lang/Object;
.source "BrightnessController.java"


# instance fields
.field private final context:Landroid/content/Context;

.field private final displayManager:Landroid/hardware/display/DisplayManager;

.field private final resolver:Landroid/content/ContentResolver;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvBrightnessController;->context:Landroid/content/Context;

    const/4 v0, 0x0

    if-eqz p1, :cond_c

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    :cond_c
    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvBrightnessController;->resolver:Landroid/content/ContentResolver;

    const/4 v0, 0x0

    if-eqz p1, :cond_19

    const-string v0, "display"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/hardware/display/DisplayManager;

    :cond_19
    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvBrightnessController;->displayManager:Landroid/hardware/display/DisplayManager;

    return-void
.end method

.method private static clampGamma(I)I
    .registers 2

    const/16 v0, 0x3ff

    invoke-static {v0, p0}, Ljava/lang/Math;->min(II)I

    move-result p0

    const/4 v0, 0x0

    invoke-static {v0, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    return p0
.end method

.method private static clampLinear(I)I
    .registers 2

    const/16 v0, 0xff

    invoke-static {v0, p0}, Ljava/lang/Math;->min(II)I

    move-result p0

    const/4 v0, 0x0

    invoke-static {v0, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    return p0
.end method

.method private static gammaToLinear(I)I
    .registers 6

    invoke-static {p0}, Linv/exe/systemui/qs/controller/InvBrightnessController;->clampGamma(I)I

    move-result p0

    int-to-double v0, p0

    const-wide v2, 0x408ff80000000000L  # 1023.0

    div-double/2addr v0, v2

    const-wide/high16 v2, 0x4008000000000000L  # 3.0

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    const-wide v2, 0x406fe00000000000L  # 255.0

    mul-double/2addr v0, v2

    const-wide/high16 v2, 0x3fe0000000000000L  # 0.5

    add-double/2addr v0, v2

    double-to-int p0, v0

    invoke-static {p0}, Linv/exe/systemui/qs/controller/InvBrightnessController;->clampLinear(I)I

    move-result p0

    return p0
.end method

.method private static linearToGamma(I)I
    .registers 6

    invoke-static {p0}, Linv/exe/systemui/qs/controller/InvBrightnessController;->clampLinear(I)I

    move-result p0

    int-to-double v0, p0

    const-wide v2, 0x406fe00000000000L  # 255.0

    div-double/2addr v0, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->cbrt(D)D

    move-result-wide v0

    const-wide v2, 0x408ff80000000000L  # 1023.0

    mul-double/2addr v0, v2

    const-wide/high16 v2, 0x3fe0000000000000L  # 0.5

    add-double/2addr v0, v2

    double-to-int p0, v0

    invoke-static {p0}, Linv/exe/systemui/qs/controller/InvBrightnessController;->clampGamma(I)I

    move-result p0

    return p0
.end method

.method private setTemporaryBrightness(I)V
    .registers 2

    :try_start_0
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvBrightnessController;->displayManager:Landroid/hardware/display/DisplayManager;

    if-eqz p0, :cond_7

    invoke-virtual {p0, p1}, Landroid/hardware/display/DisplayManager;->setTemporaryBrightness(I)V
    :try_end_7
    .catchall {:try_start_0 .. :try_end_7} :catchall_7

    :catchall_7
    :cond_7
    return-void
.end method


# virtual methods
.method public getBrightness()I
    .registers 4

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvBrightnessController;->resolver:Landroid/content/ContentResolver;

    if-eqz p0, :cond_11

    :try_start_4
    const-string v0, "screen_brightness"

    const/16 v1, 0x80

    invoke-static {p0, v0, v1}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result p0

    invoke-static {p0}, Linv/exe/systemui/qs/controller/InvBrightnessController;->linearToGamma(I)I

    move-result p0
    :try_end_10
    .catchall {:try_start_4 .. :try_end_10} :catchall_11

    return p0

    :catchall_11
    :cond_11
    const/16 p0, 0x200

    return p0
.end method

.method public getMax()I
    .registers 1

    const/16 p0, 0x3ff

    return p0
.end method

.method public isAutoBrightness()Z
    .registers 4

    const/4 v0, 0x0

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvBrightnessController;->resolver:Landroid/content/ContentResolver;

    if-eqz p0, :cond_f

    :try_start_5
    const-string v1, "screen_brightness_mode"

    invoke-static {p0, v1, v0}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result p0

    const/4 v1, 0x1

    if-ne p0, v1, :cond_f
    :try_end_e
    .catchall {:try_start_5 .. :try_end_e} :catchall_f

    return v1

    :catchall_f
    :cond_f
    return v0
.end method

.method public setAutoBrightness(Z)Z
    .registers 3

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvBrightnessController;->resolver:Landroid/content/ContentResolver;

    if-eqz p0, :cond_10

    if-eqz p1, :cond_8

    const/4 p1, 0x1

    goto :goto_9

    :cond_8
    const/4 p1, 0x0

    :goto_9
    :try_start_9
    const-string v0, "screen_brightness_mode"

    invoke-static {p0, v0, p1}, Landroid/provider/Settings$System;->putInt(Landroid/content/ContentResolver;Ljava/lang/String;I)Z

    move-result p0
    :try_end_f
    .catchall {:try_start_9 .. :try_end_f} :catchall_10

    return p0

    :catchall_10
    :cond_10
    const/4 p0, 0x0

    return p0
.end method

.method public setBrightness(I)Z
    .registers 5

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvBrightnessController;->resolver:Landroid/content/ContentResolver;

    if-eqz v0, :cond_1c

    invoke-static {p1}, Linv/exe/systemui/qs/controller/InvBrightnessController;->gammaToLinear(I)I

    move-result p1

    invoke-direct {p0, p1}, Linv/exe/systemui/qs/controller/InvBrightnessController;->setTemporaryBrightness(I)V

    :try_start_b
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvBrightnessController;->resolver:Landroid/content/ContentResolver;

    const-string v1, "screen_brightness_mode"

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/provider/Settings$System;->putInt(Landroid/content/ContentResolver;Ljava/lang/String;I)Z

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvBrightnessController;->resolver:Landroid/content/ContentResolver;

    const-string v0, "screen_brightness"

    invoke-static {p0, v0, p1}, Landroid/provider/Settings$System;->putInt(Landroid/content/ContentResolver;Ljava/lang/String;I)Z

    move-result p0
    :try_end_1b
    .catchall {:try_start_b .. :try_end_1b} :catchall_1c

    return p0

    :catchall_1c
    :cond_1c
    const/4 p0, 0x0

    return p0
.end method

.method public toggleAutoBrightness()Z
    .registers 2

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvBrightnessController;->isAutoBrightness()Z

    move-result v0

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/controller/InvBrightnessController;->setAutoBrightness(Z)Z

    move-result p0

    return p0
.end method
