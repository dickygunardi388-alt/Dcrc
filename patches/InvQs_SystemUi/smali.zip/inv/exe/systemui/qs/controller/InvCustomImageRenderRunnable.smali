.class public final Linv/exe/systemui/qs/controller/InvCustomImageRenderRunnable;
.super Ljava/lang/Object;
.source "InvCustomImageRenderRunnable.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

.field private final root:Landroid/view/View;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvCustomImageRenderRunnable;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iput-object p2, p0, Linv/exe/systemui/qs/controller/InvCustomImageRenderRunnable;->root:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvCustomImageRenderRunnable;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvCustomImageRenderRunnable;->root:Landroid/view/View;

    if-eqz v0, :cond_b

    if-eqz v1, :cond_b

    invoke-virtual {v0, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderCustomImageView(Landroid/view/View;)V

    :cond_b
    return-void
.end method
