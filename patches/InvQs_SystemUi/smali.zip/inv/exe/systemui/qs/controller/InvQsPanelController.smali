.class public Linv/exe/systemui/qs/controller/InvQsPanelController;
.super Ljava/lang/Object;
.source "QsPanelController.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Linv/exe/systemui/qs/controller/InvQsPanelController$Place;,
        Linv/exe/systemui/qs/controller/InvQsPanelController$InfoFrameRefreshRunnable;,
        Linv/exe/systemui/qs/controller/InvQsPanelController$InfoSignalReceiver;
    }
.end annotation


# static fields
.field private static volatile synthetic $SWITCH_TABLE$inv$exe$systemui$qs$model$InvControlId:[I


# instance fields
.field private brightness:Linv/exe/systemui/qs/controller/InvBrightnessController;

.field private final brightnessH:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;",
            ">;"
        }
    .end annotation
.end field

.field private final brightnessV:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;",
            ">;"
        }
    .end annotation
.end field

.field private connectivity:Linv/exe/systemui/qs/controller/InvConnectivityController;

.field private final customSettingsObserver:Landroid/database/ContentObserver;

.field private customSettingsObserverRegistered:Z

.field private edit:Z

.field private final infoFrameRefreshRunnable:Ljava/lang/Runnable;

.field private infoRefreshActive:Z

.field private infoRefreshFramePosted:Z

.field private final infoRefreshRunnable:Ljava/lang/Runnable;

.field private final infoSignalReceiver:Landroid/content/BroadcastReceiver;

.field private infoSignalRegistered:Z

.field private media:Linv/exe/systemui/qs/controller/InvMediaSessionController;

.field private mediaRenderPosted:Z

.field private final mediaRenderRunnable:Ljava/lang/Runnable;

.field private final mediaSpans:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Landroid/view/View;",
            "[I>;"
        }
    .end annotation
.end field

.field private final mediaViews:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field

.field private mute:Z

.field private final panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

.field private repo:Linv/exe/systemui/qs/model/InvPanelRepository;

.field private final tileViews:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Landroid/view/View;",
            ">;>;"
        }
    .end annotation
.end field

.field private volume:Linv/exe/systemui/qs/controller/InvVolumeController;

.field private final volumeH:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;",
            ">;"
        }
    .end annotation
.end field

.field private final volumeV:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static synthetic $SWITCH_TABLE$inv$exe$systemui$qs$model$InvControlId()[I
    .registers 3

    .line 35
    sget-object v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->$SWITCH_TABLE$inv$exe$systemui$qs$model$InvControlId:[I

    if-eqz v0, :cond_5

    return-object v0

    :cond_5
    invoke-static {}, Linv/exe/systemui/qs/model/InvControlId;->values()[Linv/exe/systemui/qs/model/InvControlId;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    :try_start_c
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->AUTO_BRIGHTNESS:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/16 v2, 0x8

    aput v2, v0, v1
    :try_end_16
    .catch Ljava/lang/NoSuchFieldError; {:try_start_c .. :try_end_16} :catch_16

    :catch_16
    :try_start_16
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->BLUETOOTH:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/4 v2, 0x2

    aput v2, v0, v1
    :try_end_1f
    .catch Ljava/lang/NoSuchFieldError; {:try_start_16 .. :try_end_1f} :catch_1f

    :catch_1f
    :try_start_1f
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->BRIGHTNESS_H:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/4 v2, 0x4

    aput v2, v0, v1
    :try_end_28
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1f .. :try_end_28} :catch_28

    :catch_28
    :try_start_28
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->BRIGHTNESS_V:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/4 v2, 0x6

    aput v2, v0, v1
    :try_end_31
    .catch Ljava/lang/NoSuchFieldError; {:try_start_28 .. :try_end_31} :catch_31

    :catch_31
    :try_start_31
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->INTERNET:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/4 v2, 0x1

    aput v2, v0, v1
    :try_end_3a
    .catch Ljava/lang/NoSuchFieldError; {:try_start_31 .. :try_end_3a} :catch_3a

    :catch_3a
    :try_start_3a
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->MEDIA:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/4 v2, 0x3

    aput v2, v0, v1
    :try_end_43
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3a .. :try_end_43} :catch_43

    :catch_43
    :try_start_43
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->MUTE:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/16 v2, 0x9

    aput v2, v0, v1
    :try_end_4d
    .catch Ljava/lang/NoSuchFieldError; {:try_start_43 .. :try_end_4d} :catch_4d

    :catch_4d
    :try_start_4d
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->RINGER:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/16 v2, 0xa

    aput v2, v0, v1
    :try_end_57
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4d .. :try_end_57} :catch_57

    :catch_57
    :try_start_57
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->VOLUME_H:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/4 v2, 0x5

    aput v2, v0, v1
    :try_end_60
    .catch Ljava/lang/NoSuchFieldError; {:try_start_57 .. :try_end_60} :catch_60

    :catch_60
    :try_start_60
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->VOLUME_V:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/4 v2, 0x7

    aput v2, v0, v1
    :try_end_69
    .catch Ljava/lang/NoSuchFieldError; {:try_start_60 .. :try_end_69} :catch_69

    :catch_69
    :try_start_69
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->DATA_USAGE:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/16 v2, 0xb

    aput v2, v0, v1
    :try_end_73
    .catch Ljava/lang/NoSuchFieldError; {:try_start_69 .. :try_end_73} :catch_73

    :catch_73
    :try_start_73
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->BATTERY_VIEW:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/16 v2, 0xc

    aput v2, v0, v1
    :try_end_7d
    .catch Ljava/lang/NoSuchFieldError; {:try_start_73 .. :try_end_7d} :catch_7d

    :catch_7d
    :try_start_7d
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->FPS_INFO:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/16 v2, 0xd

    aput v2, v0, v1
    :try_end_87
    .catch Ljava/lang/NoSuchFieldError; {:try_start_7d .. :try_end_87} :catch_87

    :catch_87
    :try_start_87
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->CUSTOM_NAME:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/16 v2, 0xe

    aput v2, v0, v1
    :try_end_91
    .catch Ljava/lang/NoSuchFieldError; {:try_start_87 .. :try_end_91} :catch_91

    :catch_91
    :try_start_91
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->CUSTOM_IMAGE:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/16 v2, 0xf

    aput v2, v0, v1
    :try_end_9b
    .catch Ljava/lang/NoSuchFieldError; {:try_start_91 .. :try_end_9b} :catch_9b

    :catch_9b
    sput-object v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->$SWITCH_TABLE$inv$exe$systemui$qs$model$InvControlId:[I

    return-object v0
.end method

.method public static synthetic $r8$lambda$GpOjZg2g8b79H3DbC2qpdvw_uWQ(Linv/exe/systemui/qs/controller/InvQsPanelController;)V
    .registers 1

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->rebuildControls()V

    return-void
.end method

.method public static synthetic $r8$lambda$LbNBQVXmiaieffNQsd5m3h7R6Bg(Linv/exe/systemui/qs/controller/InvQsPanelController;)V
    .registers 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaRenderPosted:Z

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderMediaViews()V

    return-void
.end method

.method public static synthetic $r8$lambda$rgNj3YUjTmG4ycbvA5nagNpr9eA(Linv/exe/systemui/qs/controller/InvQsPanelController;)V
    .registers 1

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->rebuildTilesOnly()V

    return-void
.end method

.method public constructor <init>(Linv/exe/systemui/qs/ui/InvQsPanelView;)V
    .registers 4

    .line 59
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 46
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightnessV:Ljava/util/List;

    .line 47
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightnessH:Ljava/util/List;

    .line 48
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volumeV:Ljava/util/List;

    .line 49
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volumeH:Ljava/util/List;

    .line 50
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaViews:Ljava/util/List;

    .line 51
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaSpans:Ljava/util/Map;

    .line 52
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->tileViews:Ljava/util/Map;

    new-instance v0, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda20;

    invoke-direct {v0, p0}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda20;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaRenderRunnable:Ljava/lang/Runnable;

    new-instance v0, Linv/exe/systemui/qs/controller/InvQsPanelController$AutoInfoRefreshRunnable;

    invoke-direct {v0, p0}, Linv/exe/systemui/qs/controller/InvQsPanelController$AutoInfoRefreshRunnable;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoRefreshRunnable:Ljava/lang/Runnable;

    new-instance v0, Linv/exe/systemui/qs/controller/InvQsPanelController$InfoFrameRefreshRunnable;

    invoke-direct {v0, p0}, Linv/exe/systemui/qs/controller/InvQsPanelController$InfoFrameRefreshRunnable;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoFrameRefreshRunnable:Ljava/lang/Runnable;

    new-instance v0, Linv/exe/systemui/qs/controller/InvQsPanelController$InfoSignalReceiver;

    invoke-direct {v0, p0}, Linv/exe/systemui/qs/controller/InvQsPanelController$InfoSignalReceiver;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoSignalReceiver:Landroid/content/BroadcastReceiver;

    new-instance v0, Linv/exe/systemui/qs/controller/InvCustomControlSettingsObserver;

    invoke-direct {v0, p0}, Linv/exe/systemui/qs/controller/InvCustomControlSettingsObserver;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->customSettingsObserver:Landroid/database/ContentObserver;

    .line 59
    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    return-void
.end method

.method public static synthetic access$0(Linv/exe/systemui/qs/controller/InvQsPanelController;)Z
    .registers 1

    .line 44
    iget-boolean p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    return p0
.end method

.method public static synthetic access$1(Linv/exe/systemui/qs/controller/InvQsPanelController;)Linv/exe/systemui/qs/model/InvPanelRepository;
    .registers 1

    .line 37
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    return-object p0
.end method

.method public static synthetic access$10(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;)V
    .registers 2

    .line 351
    invoke-direct {p0, p1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderMediaView(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic access$11(Linv/exe/systemui/qs/controller/InvQsPanelController;)V
    .registers 1

    .line 147
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->rebuildControls()V

    return-void
.end method

.method public static synthetic access$12(Linv/exe/systemui/qs/controller/InvQsPanelController;)V
    .registers 1

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->rebuildTilesOnly()V

    return-void
.end method

.method public static synthetic access$13(Linv/exe/systemui/qs/controller/InvQsPanelController;Ljava/lang/String;)Landroid/view/View;
    .registers 2

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->tileViews:Ljava/util/Map;

    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    return-object p0
.end method

.method public static synthetic access$14(Linv/exe/systemui/qs/controller/InvQsPanelController;)Z
    .registers 1

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->relayoutControlsLive()Z

    move-result p0

    return p0
.end method

.method public static synthetic access$2(Linv/exe/systemui/qs/controller/InvQsPanelController;)Linv/exe/systemui/qs/ui/InvQsPanelView;
    .registers 1

    .line 36
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    return-object p0
.end method

.method public static synthetic access$5(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;I)[I
    .registers 3

    .line 436
    invoke-direct {p0, p1, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaCellsForCard(Landroid/view/View;I)[I

    move-result-object p0

    return-object p0
.end method

.method public static synthetic access$6(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;Z)V
    .registers 3

    .line 417
    invoke-direct {p0, p1, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->setResizeVisual(Landroid/view/View;Z)V

    return-void
.end method

.method public static synthetic access$7(Linv/exe/systemui/qs/controller/InvQsPanelController;FFIII)I
    .registers 6

    .line 445
    invoke-direct/range {p0 .. p5}, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaSizeIndexForDrag(FFIII)I

    move-result p0

    return p0
.end method

.method public static synthetic access$8(Linv/exe/systemui/qs/controller/InvQsPanelController;)Z
    .registers 1

    .line 499
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->relayoutControlsLive()Z

    move-result p0

    return p0
.end method

.method public static synthetic access$9(Linv/exe/systemui/qs/controller/InvQsPanelController;)Ljava/util/Map;
    .registers 1

    .line 51
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaSpans:Ljava/util/Map;

    return-object p0
.end method

.method private applyBrightness(I)V
    .registers 4

    .line 721
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightness:Linv/exe/systemui/qs/controller/InvBrightnessController;

    if-eqz v0, :cond_38

    invoke-virtual {v0, p1}, Linv/exe/systemui/qs/controller/InvBrightnessController;->setBrightness(I)Z

    move-result v0

    if-nez v0, :cond_b

    goto :goto_38

    .line 725
    :cond_b
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightnessV:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_11
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-nez v1, :cond_2e

    .line 726
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightnessH:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1d
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result p0

    if-nez p0, :cond_24

    return-void

    :cond_24
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;

    invoke-virtual {p0, p1}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->setProgress(I)V

    goto :goto_1d

    .line 725
    :cond_2e
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;

    invoke-virtual {v1, p1}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->setProgress(I)V

    goto :goto_11

    .line 722
    :cond_38
    :goto_38
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const-string p1, "Panel settings tidak tersedia"

    invoke-virtual {p0, p1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->showPanelToastText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method private applyNativeTileStableSize(Landroid/view/View;I)V
    .registers 6

    if-eqz p1, :cond_51

    const-string v0, "tile_circle"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_25

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    instance-of v2, v1, Landroid/view/View;

    if-eqz v2, :cond_25

    check-cast v1, Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    if-eqz v2, :cond_25

    iput p2, v2, Landroid/view/ViewGroup$LayoutParams;->width:I

    iput p2, v2, Landroid/view/ViewGroup$LayoutParams;->height:I

    invoke-virtual {v1, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_25
    const-string v0, "tile_icon"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    instance-of v0, p1, Landroid/widget/ImageView;

    if-eqz v0, :cond_51

    check-cast p1, Landroid/widget/ImageView;

    invoke-virtual {p1}, Landroid/widget/ImageView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    if-eqz v0, :cond_51

    const-string v1, "inv_qs_tile_icon_size"

    invoke-direct {p0, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->stableDimenPx(Ljava/lang/String;)I

    move-result v1

    invoke-static {v1, p2}, Ljava/lang/Math;->min(II)I

    move-result v1

    const/4 v2, 0x1

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    iput v1, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_51
    return-void
.end method

.method private static applyPillForeground(Landroid/widget/LinearLayout;Landroid/widget/TextView;Z)V
    .registers 8

    if-eqz p0, :cond_91

    if-eqz p1, :cond_91

    const-string v0, "inv_tile_anim_last_fg_state"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->getTag(I)Ljava/lang/Object;

    move-result-object v1

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_19

    goto :goto_19

    :cond_19
    :goto_19
    invoke-virtual {p0, v0, v2}, Landroid/widget/LinearLayout;->setTag(ILjava/lang/Object;)V

    if-eqz p2, :cond_21

    const-string v0, "inv_icon_on_accent"

    goto :goto_23

    :cond_21
    const-string v0, "inv_icon_primary"

    :goto_23
    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1}, Landroid/widget/TextView;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/Context;->getColor(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    const-string v2, "pill_summary"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p0, v2}, Landroid/widget/LinearLayout;->findViewById(I)Landroid/view/View;

    move-result-object v2

    instance-of v3, v2, Landroid/widget/TextView;

    if-eqz v3, :cond_57

    check-cast v2, Landroid/widget/TextView;

    if-eqz p2, :cond_46

    move v3, v0

    goto :goto_54

    :cond_46
    const-string v3, "inv_text_secondary"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {p1}, Landroid/widget/TextView;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-virtual {v4, v3}, Landroid/content/Context;->getColor(I)I

    move-result v3

    :goto_54
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_57
    const-string v1, "pill_icon"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/widget/LinearLayout;->findViewById(I)Landroid/view/View;

    move-result-object v1

    instance-of v2, v1, Landroid/widget/ImageView;

    if-eqz v2, :cond_6e

    check-cast v1, Landroid/widget/ImageView;

    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    :cond_6e
    const-string v1, "pill_divider"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/widget/LinearLayout;->findViewById(I)Landroid/view/View;

    move-result-object p0

    if-eqz p0, :cond_91

    if-eqz p2, :cond_80

    invoke-virtual {p0, v0}, Landroid/view/View;->setBackgroundColor(I)V

    goto :goto_91

    :cond_80
    const-string p2, "inv_component_outline"

    invoke-static {p2}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result p2

    invoke-virtual {p1}, Landroid/widget/TextView;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p1, p2}, Landroid/content/Context;->getColor(I)I

    move-result p1

    invoke-virtual {p0, p1}, Landroid/view/View;->setBackgroundColor(I)V

    :cond_91
    :goto_91
    return-void
.end method

.method private applyVolume(I)V
    .registers 4

    .line 730
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volume:Linv/exe/systemui/qs/controller/InvVolumeController;

    if-nez v0, :cond_5

    goto :goto_20

    .line 731
    :cond_5
    invoke-virtual {v0, p1}, Linv/exe/systemui/qs/controller/InvVolumeController;->setVolume(I)V

    .line 732
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volumeV:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-nez v1, :cond_2b

    .line 733
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volumeH:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1a
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result p0

    if-nez p0, :cond_21

    :goto_20
    return-void

    :cond_21
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;

    invoke-virtual {p0, p1}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->setProgress(I)V

    goto :goto_1a

    .line 732
    :cond_2b
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;

    invoke-virtual {v1, p1}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->setProgress(I)V

    goto :goto_e
.end method

.method private attachCustomImageResize(Landroid/view/View;Landroid/view/View;)V
    .registers 4

    const/4 v0, 0x1

    invoke-virtual {p2, v0}, Landroid/view/View;->setClickable(Z)V

    const/4 v0, 0x0

    invoke-virtual {p2, v0}, Landroid/view/View;->setLongClickable(Z)V

    new-instance v0, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;

    invoke-direct {v0, p0, p1}, Linv/exe/systemui/qs/controller/InvCustomImageResizeListener;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;)V

    invoke-virtual {p2, v0}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    return-void
.end method

.method private attachMediaResize(Landroid/view/View;Landroid/view/View;)V
    .registers 4

    const/4 v0, 0x1

    .line 358
    invoke-virtual {p2, v0}, Landroid/view/View;->setClickable(Z)V

    const/4 v0, 0x0

    .line 359
    invoke-virtual {p2, v0}, Landroid/view/View;->setLongClickable(Z)V

    .line 360
    new-instance v0, Linv/exe/systemui/qs/controller/InvQsPanelController$2;

    invoke-direct {v0, p0, p1}, Linv/exe/systemui/qs/controller/InvQsPanelController$2;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;)V

    invoke-virtual {p2, v0}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    return-void
.end method

.method private static bindConnectivityPillState(Landroid/widget/LinearLayout;Landroid/widget/TextView;Ljava/lang/String;Z)V
    .registers 6

    if-eqz p1, :cond_7a

    if-nez p2, :cond_6

    const-string p2, ""

    :cond_6
    invoke-static {p1, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->setTextIfDifferent(Landroid/widget/TextView;Ljava/lang/CharSequence;)V

    invoke-virtual {p1}, Landroid/widget/TextView;->getEllipsize()Landroid/text/TextUtils$TruncateAt;

    move-result-object v0

    sget-object v1, Landroid/text/TextUtils$TruncateAt;->MARQUEE:Landroid/text/TextUtils$TruncateAt;

    if-eq v0, v1, :cond_1f

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setSingleLine(Z)V

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    const/4 v1, -0x1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setMarqueeRepeatLimit(I)V

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setHorizontallyScrolling(Z)V

    :cond_1f
    invoke-virtual {p1}, Landroid/widget/TextView;->isSelected()Z

    move-result v0

    if-nez v0, :cond_29

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setSelected(Z)V

    :cond_29
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setLongClickable(Z)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setFocusable(Z)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setFocusableInTouchMode(Z)V

    if-eqz p0, :cond_7a

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setLongClickable(Z)V

    const-string v0, "pill_summary"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->findViewById(I)Landroid/view/View;

    move-result-object p0

    instance-of v0, p0, Landroid/widget/TextView;

    if-eqz v0, :cond_7a

    check-cast p0, Landroid/widget/TextView;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setLongClickable(Z)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setFocusable(Z)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setFocusableInTouchMode(Z)V

    if-eqz p3, :cond_61

    const-string p2, "On"

    goto :goto_63

    :cond_61
    const-string p2, "Off"

    :goto_63
    invoke-static {p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->setTextIfDifferent(Landroid/widget/TextView;Ljava/lang/CharSequence;)V

    invoke-virtual {p0}, Landroid/widget/TextView;->getVisibility()I

    move-result v0

    if-eqz v0, :cond_70

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_70
    invoke-virtual {p0}, Landroid/widget/TextView;->isSelected()Z

    move-result v0

    if-nez v0, :cond_7a

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setSelected(Z)V

    :cond_7a
    return-void
.end method

.method private static bindTwoLinePill(Landroid/widget/LinearLayout;Landroid/widget/TextView;Ljava/lang/String;)V
    .registers 8

    if-eqz p0, :cond_6a

    if-eqz p1, :cond_6a

    if-eqz p2, :cond_7

    goto :goto_9

    :cond_7
    const-string p2, ""

    :goto_9
    const/16 v0, 0xa

    invoke-virtual {p2, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    if-ltz v0, :cond_20

    const/4 v1, 0x0

    invoke-virtual {p2, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p2, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, v2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->setTextIfDifferent(Landroid/widget/TextView;Ljava/lang/CharSequence;)V

    goto :goto_25

    :cond_20
    invoke-static {p1, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->setTextIfDifferent(Landroid/widget/TextView;Ljava/lang/CharSequence;)V

    const-string p2, ""

    :goto_25
    const-string v0, "pill_summary"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->findViewById(I)Landroid/view/View;

    move-result-object p0

    instance-of v0, p0, Landroid/widget/TextView;

    if-eqz v0, :cond_6a

    check-cast p0, Landroid/widget/TextView;

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result p1

    if-lez p1, :cond_65

    invoke-virtual {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object p1

    invoke-static {p1, p2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_50

    instance-of p1, p0, Linv/exe/systemui/qs/ui/InvMarqueeTextView;

    if-eqz p1, :cond_4d

    invoke-virtual {p0, p2}, Landroid/widget/TextView;->setTextKeepState(Ljava/lang/CharSequence;)V

    goto :goto_50

    :cond_4d
    invoke-virtual {p0, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_50
    :goto_50
    invoke-virtual {p0}, Landroid/widget/TextView;->getVisibility()I

    move-result p1

    if-eqz p1, :cond_5a

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_5a
    invoke-virtual {p0}, Landroid/widget/TextView;->isSelected()Z

    move-result p1

    if-nez p1, :cond_6a

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setSelected(Z)V

    goto :goto_6a

    :cond_65
    const/16 p1, 0x8

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_6a
    :goto_6a
    return-void
.end method

.method private circle(Landroid/view/LayoutInflater;Linv/exe/systemui/qs/model/InvControlId;)Landroid/view/View;
    .registers 8

    .line 686
    const-string v0, "inv_item_control_circle"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->layout(Ljava/lang/String;)I

    move-result v0

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const/4 v2, 0x0

    invoke-virtual {p1, v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    .line 687
    const-string v0, "circle_body"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/FrameLayout;

    .line 688
    const-string v1, "circle_icon"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    .line 689
    const-string v3, "badge"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {p1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ImageView;

    .line 690
    iget v4, p2, Linv/exe/systemui/qs/model/InvControlId;->iconRes:I

    invoke-virtual {v1, v4}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 691
    invoke-direct {p0, p1, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderCircleState(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    .line 692
    iget-boolean v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-eqz v1, :cond_3e

    goto :goto_40

    :cond_3e
    const/16 v2, 0x8

    :goto_40
    invoke-virtual {v3, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    invoke-virtual {v3}, Landroid/view/View;->bringToFront()V

    .line 693
    new-instance v1, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda4;

    invoke-direct {v1, p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda4;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Linv/exe/systemui/qs/model/InvControlId;)V

    invoke-virtual {v3, v1}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 694
    new-instance v1, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda5;

    invoke-direct {v1, p0, p2, p1}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda5;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Linv/exe/systemui/qs/model/InvControlId;Landroid/view/View;)V

    invoke-virtual {v0, v1}, Landroid/widget/FrameLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-boolean v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-eqz v1, :cond_66

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    if-eqz v1, :cond_66

    iget-object v2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-static {v2, v1, p1, p2}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    invoke-static {v2, v1, v0, p2}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    :cond_66
    return-object p1
.end method

.method private color(I)I
    .registers 2

    .line 145
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/content/Context;->getColor(I)I

    move-result p0

    return p0
.end method

.method private createControl(Landroid/view/LayoutInflater;Linv/exe/systemui/qs/model/InvControlId;II)Landroid/view/View;
    .registers 8

    .line 233
    invoke-static {}, Linv/exe/systemui/qs/controller/InvQsPanelController;->$SWITCH_TABLE$inv$exe$systemui$qs$model$InvControlId()[I

    move-result-object v0

    invoke-virtual {p2}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/16 v1, 0xe

    if-ne v0, v1, :cond_13

    invoke-direct {p0, p1, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->customName(Landroid/view/LayoutInflater;Linv/exe/systemui/qs/model/InvControlId;)Landroid/view/View;

    move-result-object p0

    return-object p0

    :cond_13
    const/16 v1, 0xf

    if-ne v0, v1, :cond_1c

    invoke-direct {p0, p1, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->customImage(Landroid/view/LayoutInflater;Linv/exe/systemui/qs/model/InvControlId;)Landroid/view/View;

    move-result-object p0

    return-object p0

    :cond_1c
    const/16 v1, 0xd

    if-eq v0, v1, :cond_4f

    const/16 v1, 0xa

    if-eq v0, v1, :cond_4f

    const/16 v1, 0xb

    if-eq v0, v1, :cond_4f

    const/16 v1, 0xc

    if-eq v0, v1, :cond_4f

    const/4 v1, 0x0

    const/4 v2, 0x1

    packed-switch v0, :pswitch_data_54

    .line 249
    invoke-direct {p0, p1, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->circle(Landroid/view/LayoutInflater;Linv/exe/systemui/qs/model/InvControlId;)Landroid/view/View;

    move-result-object p0

    return-object p0

    .line 243
    :pswitch_36  #0x7
    invoke-direct {p0, p1, p2, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->vertical(Landroid/view/LayoutInflater;Linv/exe/systemui/qs/model/InvControlId;Z)Landroid/view/View;

    move-result-object p0

    return-object p0

    .line 241
    :pswitch_3b  #0x6
    invoke-direct {p0, p1, p2, v2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->vertical(Landroid/view/LayoutInflater;Linv/exe/systemui/qs/model/InvControlId;Z)Landroid/view/View;

    move-result-object p0

    return-object p0

    .line 247
    :pswitch_40  #0x5
    invoke-direct {p0, p1, p2, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->horizontal(Landroid/view/LayoutInflater;Linv/exe/systemui/qs/model/InvControlId;Z)Landroid/view/View;

    move-result-object p0

    return-object p0

    .line 245
    :pswitch_45  #0x4
    invoke-direct {p0, p1, p2, v2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->horizontal(Landroid/view/LayoutInflater;Linv/exe/systemui/qs/model/InvControlId;Z)Landroid/view/View;

    move-result-object p0

    return-object p0

    .line 239
    :pswitch_4a  #0x3
    invoke-direct {p0, p1, p2, p3, p4}, Linv/exe/systemui/qs/controller/InvQsPanelController;->media(Landroid/view/LayoutInflater;Linv/exe/systemui/qs/model/InvControlId;II)Landroid/view/View;

    move-result-object p0

    return-object p0

    .line 237
    :cond_4f
    :pswitch_4f  #0x1, 0x2
    invoke-direct {p0, p1, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->pill(Landroid/view/LayoutInflater;Linv/exe/systemui/qs/model/InvControlId;)Landroid/view/View;

    move-result-object p0

    return-object p0

    :pswitch_data_54
    .packed-switch 0x1
        :pswitch_4f  #00000001
        :pswitch_4f  #00000002
        :pswitch_4a  #00000003
        :pswitch_45  #00000004
        :pswitch_40  #00000005
        :pswitch_3b  #00000006
        :pswitch_36  #00000007
    .end packed-switch
.end method

.method private customImage(Landroid/view/LayoutInflater;Linv/exe/systemui/qs/model/InvControlId;)Landroid/view/View;
    .registers 16

    const-string v0, "inv_item_custom_image"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->layout(Ljava/lang/String;)I

    move-result v0

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const/4 v2, 0x0

    invoke-virtual {p1, v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p0, p1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderCustomImageView(Landroid/view/View;)V

    const-string v0, "custom_image_body"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setLongClickable(Z)V

    const-string v1, "badge"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    const-string v3, "custom_image_clear_badge"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {p1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ImageView;

    const-string v4, "media_resize_handle"

    invoke-static {v4}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {p1, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    iget-boolean v5, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-eqz v5, :cond_48

    const/4 v6, 0x0

    goto :goto_4a

    :cond_48
    const/16 v6, 0x8

    :goto_4a
    invoke-virtual {v1, v6}, Landroid/widget/ImageView;->setVisibility(I)V

    invoke-virtual {v4, v6}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v1}, Landroid/view/View;->bringToFront()V

    invoke-virtual {v4}, Landroid/view/View;->bringToFront()V

    const/16 v7, 0x8

    if-eqz v5, :cond_7e

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v8

    if-eqz v8, :cond_7e

    invoke-virtual {v8}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v8

    const-string v9, "invos_qs_custom_image"

    invoke-static {v8, v9}, Landroid/provider/Settings$System;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    if-eqz v9, :cond_7e

    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_7e

    new-instance v8, Ljava/io/File;

    invoke-direct {v8, v9}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8}, Ljava/io/File;->exists()Z

    move-result v8

    if-eqz v8, :cond_7e

    const/4 v7, 0x0

    :cond_7e
    invoke-virtual {v3, v7}, Landroid/widget/ImageView;->setVisibility(I)V

    invoke-virtual {v3}, Landroid/view/View;->bringToFront()V

    new-instance v6, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda1;

    invoke-direct {v6, p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda1;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Linv/exe/systemui/qs/model/InvControlId;)V

    invoke-virtual {v1, v6}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v6, Linv/exe/systemui/qs/controller/InvCustomImageClearClickListener;

    invoke-direct {v6, p0, p1}, Linv/exe/systemui/qs/controller/InvCustomImageClearClickListener;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/view/View;)V

    invoke-virtual {v3, v6}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    if-eqz v5, :cond_a3

    invoke-direct {p0, p1, v4}, Linv/exe/systemui/qs/controller/InvQsPanelController;->attachCustomImageResize(Landroid/view/View;Landroid/view/View;)V

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    iget-object v3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-static {v3, v1, p1, p2}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    invoke-static {v3, v1, v0, p2}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    :cond_a3
    return-object p1
.end method

.method private customName(Landroid/view/LayoutInflater;Linv/exe/systemui/qs/model/InvControlId;)Landroid/view/View;
    .registers 11

    const-string v0, "inv_item_custom_name"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->layout(Ljava/lang/String;)I

    move-result v0

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const/4 v2, 0x0

    invoke-virtual {p1, v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const-string v0, "custom_name_title"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const-string v1, "custom_name_subtitle"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v4

    const-string v5, "invos_qs_custom_username"

    invoke-static {v4, v5}, Landroid/provider/Settings$System;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_3c

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v6

    if-lez v6, :cond_3c

    goto :goto_3e

    :cond_3c
    const-string v5, "Username"

    :goto_3e
    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v5, "invos_qs_custom_subtitle"

    invoke-static {v4, v5}, Landroid/provider/Settings$System;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_50

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v6

    if-lez v6, :cond_50

    goto :goto_52

    :cond_50
    const-string v5, "Subtitle"

    :goto_52
    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setLongClickable(Z)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setFocusable(Z)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setLongClickable(Z)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setFocusable(Z)V

    const-string v0, "badge"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iget-boolean v4, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-eqz v4, :cond_79

    const/4 v1, 0x0

    goto :goto_7b

    :cond_79
    const/16 v1, 0x8

    :goto_7b
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    invoke-virtual {v0}, Landroid/view/View;->bringToFront()V

    new-instance v1, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda1;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Linv/exe/systemui/qs/model/InvControlId;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    if-eqz v4, :cond_9f

    const-string v0, "custom_name_body"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    iget-object v3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-static {v3, v1, p1, p2}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    invoke-static {v3, v1, v0, p2}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    :cond_9f
    return-object p1
.end method

.method private dp(I)I
    .registers 7

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-static {p1}, Linv/exe/systemui/qs/core/InvRes;->dimenNameForDp(I)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_23

    const-string v2, "dimen"

    iget-object v3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {v3}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    if-lez v1, :cond_23

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p0

    return p0

    :cond_23
    int-to-float p1, p1

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, p0

    const/high16 p0, 0x3f000000  # 0.5f

    add-float/2addr p1, p0

    float-to-int p0, p1

    return p0
.end method

.method private drawLiveEmptyControls(Landroid/widget/FrameLayout;[[ZIIIII)V
    .registers 15

    const-string v5, "inv_qs_control_grid_cell_size"

    invoke-direct {p0, v5}, Linv/exe/systemui/qs/controller/InvQsPanelController;->stableDimenPx(Ljava/lang/String;)I

    move-result v6

    const/4 v0, 0x0

    move v1, v0

    :goto_8
    if-lt v1, p3, :cond_b

    return-void

    :cond_b
    move v2, v0

    :goto_c
    if-lt v2, p4, :cond_11

    add-int/lit8 v1, v1, 0x1

    goto :goto_8

    .line 609
    :cond_11
    array-length v3, p2

    if-ge v1, v3, :cond_4c

    aget-object v3, p2, v1

    array-length v4, v3

    if-ge v2, v4, :cond_4c

    aget-boolean v3, v3, v2

    if-eqz v3, :cond_1e

    goto :goto_4c

    .line 610
    :cond_1e
    new-instance v3, Landroid/widget/FrameLayout;

    iget-object v4, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {v4}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-direct {v3, v4}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 611
    const-string v4, "inv_bg_grid_empty"

    invoke-static {v4}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/widget/FrameLayout;->setBackgroundResource(I)V

    .line 612
    sub-int v4, p5, v6

    if-gez v4, :cond_37

    const/4 v4, 0x0

    :cond_37
    div-int/lit8 v4, v4, 0x2

    add-int v5, p5, p6

    mul-int/2addr v5, v2

    add-int/2addr v5, v4

    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v4, v6, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 613
    iput v5, v4, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    add-int v5, v6, p7

    mul-int/2addr v5, v1

    .line 614
    iput v5, v4, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    .line 615
    invoke-virtual {p1, v3, v4}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 616
    :cond_4c
    :goto_4c
    add-int/lit8 v2, v2, 0x1

    goto :goto_c
.end method

.method private emptyTile(I)Landroid/view/View;
    .registers 4

    .line 773
    new-instance v0, Landroid/widget/LinearLayout;

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 774
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 775
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 776
    new-instance v1, Landroid/widget/FrameLayout;

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-direct {v1, p0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 777
    const-string p0, "inv_bg_grid_empty"

    invoke-static {p0}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result p0

    invoke-virtual {v1, p0}, Landroid/widget/FrameLayout;->setBackgroundResource(I)V

    .line 778
    new-instance p0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p0, p1, p1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, p0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private findControlGrid(Landroid/widget/FrameLayout;)Landroid/widget/GridLayout;
    .registers 3

    const/4 p0, 0x0

    .line 599
    :goto_1
    invoke-virtual {p1}, Landroid/widget/FrameLayout;->getChildCount()I

    move-result v0

    if-lt p0, v0, :cond_9

    const/4 p0, 0x0

    return-object p0

    .line 600
    :cond_9
    invoke-virtual {p1, p0}, Landroid/widget/FrameLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    instance-of v0, v0, Landroid/widget/GridLayout;

    if-eqz v0, :cond_18

    invoke-virtual {p1, p0}, Landroid/widget/FrameLayout;->getChildAt(I)Landroid/view/View;

    move-result-object p0

    check-cast p0, Landroid/widget/GridLayout;

    return-object p0

    :cond_18
    add-int/lit8 p0, p0, 0x1

    goto :goto_1
.end method

.method private static free([[ZIIII)Z
    .registers 8

    move v0, p1

    :goto_1
    add-int v1, p1, p4

    if-lt v0, v1, :cond_7

    const/4 p0, 0x1

    return p0

    :cond_7
    move v1, p2

    :goto_8
    add-int v2, p2, p3

    if-lt v1, v2, :cond_f

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 218
    :cond_f
    aget-object v2, p0, v0

    aget-boolean v2, v2, v1

    if-eqz v2, :cond_17

    const/4 p0, 0x0

    return p0

    :cond_17
    add-int/lit8 v1, v1, 0x1

    goto :goto_8
.end method

.method private horizontal(Landroid/view/LayoutInflater;Linv/exe/systemui/qs/model/InvControlId;Z)Landroid/view/View;
    .registers 16

    .line 655
    const-string v0, "inv_item_slider_horizontal"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->layout(Ljava/lang/String;)I

    move-result v0

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const/4 v2, 0x0

    invoke-virtual {p1, v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    move-object v11, p2

    .line 656
    const-string v0, "slider_body"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    move-object v3, v0

    check-cast v3, Landroid/widget/FrameLayout;

    .line 657
    const-string v0, "slider_fill"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    .line 658
    const-string v0, "slider_icon"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    move-object v7, v0

    check-cast v7, Landroid/widget/ImageView;

    const-string v5, "slider_title"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {p1, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    if-eqz p3, :cond_56

    const-string v6, "brightness"

    invoke-virtual {v3, v6}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const-string v1, "slider_body"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v3, v1, v6}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    if-eqz v5, :cond_6b

    const-string v6, "Brightness"

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_6b

    :cond_56
    const-string v6, "volume"

    invoke-virtual {v3, v6}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const-string v1, "slider_body"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v3, v1, v6}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    if-eqz v5, :cond_6b

    const-string v6, "Volume"

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_6b
    :goto_6b
    const-string v5, "slider_summary"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {p1, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/TextView;

    if-eqz v5, :cond_87

    if-eqz p3, :cond_7e

    const-string v6, "0%"

    goto :goto_80

    :cond_7e
    const-string v6, "0%"

    :goto_80
    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setSelected(Z)V

    .line 659
    :cond_87
    const-string v0, "badge"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    .line 660
    invoke-virtual {p1, v2}, Landroid/view/View;->setMinimumHeight(I)V

    .line 661
    invoke-virtual {v3, v2}, Landroid/widget/FrameLayout;->setMinimumHeight(I)V

    if-eqz p3, :cond_9e

    .line 662
    const-string v1, "inv_ic_brightness"

    goto :goto_a0

    :cond_9e
    const-string v1, "inv_ic_volume"

    :goto_a0
    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v7, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 668
    iget-boolean v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-eqz v1, :cond_ad

    move v1, v2

    goto :goto_af

    :cond_ad
    const/16 v1, 0x8

    :goto_af
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    invoke-virtual {v0}, Landroid/view/View;->bringToFront()V

    .line 669
    new-instance v1, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda8;

    invoke-direct {v1, p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda8;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Linv/exe/systemui/qs/model/InvControlId;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    if-eqz p3, :cond_c3

    const/16 p2, 0x3ff

    :goto_c1
    move v5, p2

    goto :goto_d4

    .line 670
    :cond_c3
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volume:Linv/exe/systemui/qs/controller/InvVolumeController;

    if-nez p2, :cond_ca

    const/16 p2, 0xf

    goto :goto_ce

    :cond_ca
    invoke-virtual {p2}, Linv/exe/systemui/qs/controller/InvVolumeController;->getMax()I

    move-result p2

    :goto_ce
    const/4 v0, 0x1

    invoke-static {v0, p2}, Ljava/lang/Math;->max(II)I

    move-result p2

    goto :goto_c1

    :goto_d4
    if-eqz p3, :cond_e2

    .line 671
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightness:Linv/exe/systemui/qs/controller/InvBrightnessController;

    if-nez p2, :cond_dd

    const/16 v2, 0x200

    goto :goto_eb

    :cond_dd
    invoke-virtual {p2}, Linv/exe/systemui/qs/controller/InvBrightnessController;->getBrightness()I

    move-result v2

    goto :goto_eb

    :cond_e2
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volume:Linv/exe/systemui/qs/controller/InvVolumeController;

    if-nez p2, :cond_e7

    goto :goto_eb

    :cond_e7
    invoke-virtual {p2}, Linv/exe/systemui/qs/controller/InvVolumeController;->getVolume()I

    move-result v2

    .line 672
    :goto_eb
    invoke-static {v3, v5, v2, v7}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->applyAdaptiveUi(Landroid/view/View;IILandroid/widget/ImageView;)V

    iget-boolean p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    const-string v0, "inv_text_on_accent"

    const-string v1, "inv_icon_primary"

    if-nez p2, :cond_125

    move v6, v5

    move-object v5, v4

    move-object v4, v3

    .line 673
    new-instance v3, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;

    move-object v8, v7

    .line 674
    new-instance v7, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda9;

    invoke-direct {v7, p0, p3}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda9;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Z)V

    .line 675
    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result p2

    invoke-direct {p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->color(I)I

    move-result v9

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result p2

    invoke-direct {p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->color(I)I

    move-result v10

    .line 673
    invoke-direct/range {v3 .. v10}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;-><init>(Landroid/view/View;Landroid/view/View;ILinv/exe/systemui/qs/ui/InvHorizontalLevelSlider$Listener;Landroid/widget/ImageView;II)V

    .line 676
    invoke-virtual {v3, v2}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->setProgress(I)V

    if-eqz p3, :cond_11f

    .line 677
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightnessH:Ljava/util/List;

    invoke-interface {p0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-object p1

    :cond_11f
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volumeH:Ljava/util/List;

    invoke-interface {p0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-object p1

    :cond_125
    move v6, v5

    move-object v8, v7

    move-object v5, v4

    move-object v4, v3

    .line 680
    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result p2

    invoke-direct {p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->color(I)I

    move-result p2

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result p3

    invoke-direct {p0, p3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->color(I)I

    move-result v9

    move-object v4, v5

    move v5, v6

    move v8, p2

    move v6, v2

    .line 679
    invoke-static/range {v3 .. v9}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->applyStaticProgress(Landroid/view/View;Landroid/view/View;IILandroid/widget/ImageView;II)V

    iget-object v10, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    if-eqz v10, :cond_158

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-static {v0, v10, p1, v11}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    const-string v1, "slider_body"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_158

    invoke-static {v0, v10, v1, v11}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    :cond_158
    return-object p1
.end method

.method private static mark([[ZIIII)V
    .registers 9

    move v0, p1

    :goto_1
    add-int v1, p1, p4

    if-lt v0, v1, :cond_6

    return-void

    :cond_6
    move v1, p2

    :goto_7
    add-int v2, p2, p3

    if-lt v1, v2, :cond_e

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 223
    :cond_e
    aget-object v2, p0, v0

    const/4 v3, 0x1

    aput-boolean v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_7
.end method

.method private media(Landroid/view/LayoutInflater;Linv/exe/systemui/qs/model/InvControlId;II)Landroid/view/View;
    .registers 13

    .line 308
    const-string v0, "inv_item_media"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->layout(Ljava/lang/String;)I

    move-result v0

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const/4 v2, 0x0

    invoke-virtual {p1, v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    move-object v7, p2

    .line 309
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaViews:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 310
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaSpans:Ljava/util/Map;

    filled-new-array {p3, p4}, [I

    move-result-object p3

    invoke-interface {v0, p1, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 311
    const-string p3, "badge"

    invoke-static {p3}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result p3

    invoke-virtual {p1, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p3

    check-cast p3, Landroid/widget/ImageView;

    .line 312
    const-string p4, "media_prev"

    invoke-static {p4}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result p4

    invoke-virtual {p1, p4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p4

    check-cast p4, Landroid/widget/ImageView;

    .line 313
    const-string v0, "media_play"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    .line 314
    const-string v1, "media_next"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    .line 315
    const-string v3, "media_shuffle"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {p1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ImageView;

    .line 316
    const-string v4, "media_body"

    invoke-static {v4}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {p1, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    const-string v5, "media_output_button"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {p1, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    if-eqz v5, :cond_76

    new-instance v6, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda21;

    invoke-direct {v6, p0}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda21;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    invoke-virtual {v5, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 317
    :cond_76
    iget-boolean v5, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    const/16 v6, 0x8

    if-eqz v5, :cond_7e

    move v5, v2

    goto :goto_7f

    :cond_7e
    move v5, v6

    :goto_7f
    invoke-virtual {p3, v5}, Landroid/widget/ImageView;->setVisibility(I)V

    invoke-virtual {p3}, Landroid/view/View;->bringToFront()V

    .line 318
    new-instance v5, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda11;

    invoke-direct {v5, p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda11;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Linv/exe/systemui/qs/model/InvControlId;)V

    invoke-virtual {p3, v5}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 319
    const-string p2, "media_resize_handle"

    invoke-static {p2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result p2

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    if-eqz p2, :cond_b1

    .line 321
    iget-boolean p3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-eqz p3, :cond_9e

    goto :goto_9f

    :cond_9e
    move v2, v6

    :goto_9f
    invoke-virtual {p2, v2}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p2}, Landroid/view/View;->bringToFront()V

    .line 322
    iget-boolean p3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-eqz p3, :cond_ad

    invoke-direct {p0, p1, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->attachMediaResize(Landroid/view/View;Landroid/view/View;)V

    goto :goto_b1

    :cond_ad
    const/4 p3, 0x0

    .line 323
    invoke-virtual {p2, p3}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 325
    :cond_b1
    :goto_b1
    new-instance p2, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda12;

    invoke-direct {p2, p0}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda12;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    invoke-virtual {p4, p2}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 326
    new-instance p2, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda13;

    invoke-direct {p2, p0}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda13;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    invoke-virtual {v0, p2}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 327
    new-instance p2, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda14;

    invoke-direct {p2, p0}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda14;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    invoke-virtual {v1, p2}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    if-eqz v3, :cond_d3

    .line 329
    new-instance p2, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda15;

    invoke-direct {p2, p0}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda15;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    invoke-virtual {v3, p2}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 331
    :cond_d3
    new-instance p2, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda16;

    invoke-direct {p2, p0}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda16;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    invoke-virtual {v4, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-static {p1}, Linv/exe/systemui/qs/ui/InvMediaEffects;->bindTouchRipples(Landroid/view/View;)V

    .line 336
    iget-boolean v2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-eqz v2, :cond_145

    iget-object v3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    if-eqz v3, :cond_145

    iget-object v4, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-static {v4, v3, p1, v7}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    const-string v2, "media_body"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    if-eqz v2, :cond_fa

    invoke-static {v4, v3, v2, v7}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    :cond_fa
    const-string v2, "media_output_button"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    if-eqz v2, :cond_109

    invoke-static {v4, v3, v2, v7}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    :cond_109
    const-string v2, "media_prev"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    if-eqz v2, :cond_118

    invoke-static {v4, v3, v2, v7}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    :cond_118
    const-string v2, "media_play"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    if-eqz v2, :cond_127

    invoke-static {v4, v3, v2, v7}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    :cond_127
    const-string v2, "media_next"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    if-eqz v2, :cond_136

    invoke-static {v4, v3, v2, v7}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    :cond_136
    const-string v2, "media_shuffle"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    if-eqz v2, :cond_145

    invoke-static {v4, v3, v2, v7}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    :cond_145
    invoke-direct {p0, p1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderMediaView(Landroid/view/View;)V

    return-object p1
.end method

.method private mediaCellsForCard(Landroid/view/View;I)[I
    .registers 6

    .line 437
    invoke-direct {p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaSpanWForIndex(I)I

    move-result v0

    .line 438
    invoke-direct {p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaSpanHForIndex(I)I

    move-result p2

    .line 439
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const-string v1, "inv_qs_control_grid_item_spacing"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->dimen(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p0

    .line 440
    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v1

    add-int/lit8 v2, v0, -0x1

    mul-int/2addr v2, p0

    sub-int/2addr v1, v2

    const/4 v2, 0x1

    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    div-int/2addr v1, v0

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 441
    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    add-int/lit8 v1, p2, -0x1

    mul-int/2addr p0, v1

    sub-int/2addr p1, p0

    invoke-static {v2, p2}, Ljava/lang/Math;->max(II)I

    move-result p0

    div-int/2addr p1, p0

    invoke-static {v2, p1}, Ljava/lang/Math;->max(II)I

    move-result p0

    .line 442
    filled-new-array {v0, p0}, [I

    move-result-object p0

    return-object p0
.end method

.method private mediaSizeIndexForDrag(FFIII)I
    .registers 11

    .line 446
    invoke-direct {p0, p3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaSpanWForIndex(I)I

    move-result v0

    .line 447
    invoke-direct {p0, p3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaSpanHForIndex(I)I

    move-result p3

    .line 448
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const-string v2, "inv_qs_control_grid_item_spacing"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->dimen(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v1

    add-int/2addr p4, v1

    int-to-float p4, p4

    const/high16 v2, 0x3f800000  # 1.0f

    .line 449
    invoke-static {v2, p4}, Ljava/lang/Math;->max(FF)F

    move-result p4

    add-int/2addr p5, v1

    int-to-float p5, p5

    .line 450
    invoke-static {v2, p5}, Ljava/lang/Math;->max(FF)F

    move-result p5

    const/16 v1, 0x30

    .line 451
    invoke-direct {p0, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->dp(I)I

    move-result v2

    int-to-float v2, v2

    const v3, 0x3f2e147b  # 0.68f

    mul-float v4, p4, v3

    invoke-static {v2, v4}, Ljava/lang/Math;->max(FF)F

    move-result v2

    .line 452
    invoke-direct {p0, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->dp(I)I

    move-result p0

    int-to-float p0, p0

    mul-float/2addr p5, v3

    invoke-static {p0, p5}, Ljava/lang/Math;->max(FF)F

    move-result p0

    cmpl-float p5, p1, v2

    if-lez p5, :cond_4b

    add-int/lit8 v0, v0, 0x1

    sub-float/2addr p1, v2

    div-float/2addr p1, p4

    float-to-int p1, p1

    add-int/2addr v0, p1

    goto :goto_57

    :cond_4b
    neg-float p5, v2

    cmpg-float p5, p1, p5

    if-gez p5, :cond_57

    add-int/lit8 v0, v0, -0x1

    neg-float p1, p1

    sub-float/2addr p1, v2

    div-float/2addr p1, p4

    float-to-int p1, p1

    sub-int/2addr v0, p1

    :cond_57
    :goto_57
    cmpl-float p1, p2, p0

    if-lez p1, :cond_5e

    add-int/lit8 p3, p3, 0x1

    goto :goto_65

    :cond_5e
    neg-float p0, p0

    cmpg-float p0, p2, p0

    if-gez p0, :cond_65

    add-int/lit8 p3, p3, -0x1

    :cond_65
    :goto_65
    const/4 p0, 0x4

    .line 467
    invoke-static {p0, v0}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 p2, 0x2

    invoke-static {p2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    .line 468
    invoke-static {p2, p3}, Ljava/lang/Math;->min(II)I

    move-result p3

    const/4 p4, 0x1

    invoke-static {p4, p3}, Ljava/lang/Math;->max(II)I

    move-result p3

    const/4 p5, 0x3

    if-gt p3, p4, :cond_84

    if-lt p1, p0, :cond_7f

    const/4 p0, 0x5

    return p0

    :cond_7f
    if-lt p1, p5, :cond_82

    return p0

    :cond_82
    const/4 p0, 0x0

    return p0

    :cond_84
    if-gt p1, p2, :cond_87

    return p4

    :cond_87
    if-ne p1, p5, :cond_8a

    return p2

    :cond_8a
    return p5
.end method

.method private mediaSpanHForIndex(I)I
    .registers 3

    const/4 p0, 0x5

    .line 495
    invoke-static {p0, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v0, 0x0

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    if-eqz p1, :cond_14

    const/4 v0, 0x4

    if-eq p1, v0, :cond_14

    if-ne p1, p0, :cond_12

    goto :goto_14

    :cond_12
    const/4 p0, 0x2

    return p0

    :cond_14
    :goto_14
    const/4 p0, 0x1

    return p0
.end method

.method private mediaSpanWForIndex(I)I
    .registers 5

    const/4 p0, 0x5

    .line 480
    invoke-static {p0, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v0, 0x0

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 v0, 0x3

    const/4 v1, 0x2

    if-eq p1, v1, :cond_17

    const/4 v2, 0x4

    if-eq p1, v0, :cond_16

    if-eq p1, v2, :cond_17

    if-eq p1, p0, :cond_16

    return v1

    :cond_16
    return v2

    :cond_17
    return v0
.end method

.method private nativeTile(Landroid/view/LayoutInflater;Ljava/lang/String;)Landroid/view/View;
    .registers 8

    const-string v0, "inv_item_tile"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->layout(Ljava/lang/String;)I

    move-result v0

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const/4 v2, 0x0

    invoke-virtual {p1, v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, p2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->tileViews:Ljava/util/Map;

    invoke-interface {v0, p2, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "badge"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iget-boolean v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-eqz v1, :cond_26

    goto :goto_28

    :cond_26
    const/16 v2, 0x8

    :goto_28
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    invoke-virtual {v0}, Landroid/view/View;->bringToFront()V

    new-instance v1, Linv/exe/systemui/qs/nativeqs/InvNativeTileRemoveClickListener;

    invoke-direct {v1, p0, p2}, Linv/exe/systemui/qs/nativeqs/InvNativeTileRemoveClickListener;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v0, "tile_circle"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0, p2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    new-instance v1, Linv/exe/systemui/qs/nativeqs/InvNativeTileClickListener;

    invoke-direct {v1, p0, p2}, Linv/exe/systemui/qs/nativeqs/InvNativeTileClickListener;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v1, Linv/exe/systemui/qs/nativeqs/InvNativeTileLongClickListener;

    invoke-direct {v1, p0, p2}, Linv/exe/systemui/qs/nativeqs/InvNativeTileLongClickListener;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnDragListener(Landroid/view/View$OnDragListener;)V

    const/4 v2, 0x1

    invoke-virtual {p1, v2}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {p1, v2}, Landroid/view/View;->setLongClickable(Z)V

    new-instance v1, Linv/exe/systemui/qs/nativeqs/InvNativeTileForwardListener;

    invoke-direct {v1, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileForwardListener;-><init>(Landroid/view/View;)V

    invoke-virtual {p1, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {p1, v1}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    new-instance v1, Linv/exe/systemui/qs/nativeqs/InvNativeTileDropListener;

    invoke-direct {v1, p0, p2}, Linv/exe/systemui/qs/nativeqs/InvNativeTileDropListener;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Ljava/lang/String;)V

    invoke-virtual {p1, v1}, Landroid/view/View;->setOnDragListener(Landroid/view/View$OnDragListener;)V

    invoke-direct {p0, p1, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderNativeTileState(Landroid/view/View;Ljava/lang/String;)V

    return-object p1
.end method

.method private pill(Landroid/view/LayoutInflater;Linv/exe/systemui/qs/model/InvControlId;)Landroid/view/View;
    .registers 7

    .line 254
    const-string v0, "inv_item_pill"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->layout(Ljava/lang/String;)I

    move-result v0

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const/4 v2, 0x0

    invoke-virtual {p1, v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    .line 255
    const-string v0, "pill_icon"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    .line 256
    const-string v1, "badge"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    .line 257
    iget v3, p2, Linv/exe/systemui/qs/model/InvControlId;->iconRes:I

    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 258
    invoke-direct {p0, p1, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderPillState(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    .line 259
    iget-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-eqz v0, :cond_32

    goto :goto_34

    :cond_32
    const/16 v2, 0x8

    :goto_34
    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    invoke-virtual {v1}, Landroid/view/View;->bringToFront()V

    .line 260
    new-instance v0, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda1;

    invoke-direct {v0, p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda1;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Linv/exe/systemui/qs/model/InvControlId;)V

    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 261
    const-string v0, "pill_body"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    .line 262
    new-instance v1, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0, p2, p1}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda2;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Linv/exe/systemui/qs/model/InvControlId;Landroid/view/View;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 282
    new-instance v1, Linv/exe/systemui/qs/nativeqs/InvNativeControlLongClickListener;

    invoke-direct {v1, p0, p2, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeControlLongClickListener;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Linv/exe/systemui/qs/model/InvControlId;Landroid/view/View;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    invoke-virtual {p1, v1}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    iget-boolean v2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-eqz v2, :cond_6f

    iget-object v2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    if-eqz v2, :cond_6f

    iget-object v3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-static {v3, v2, p1, p2}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    invoke-static {v3, v2, v0, p2}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    :cond_6f
    return-object p1
.end method

.method private postInfoFallbackTick(J)V
    .registers 5

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    if-eqz v0, :cond_c

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoRefreshRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->removeCallbacks(Ljava/lang/Runnable;)Z

    invoke-virtual {v0, p0, p1, p2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_c
    return-void
.end method

.method private rebuildControls()V
    .registers 3

    .line 148
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const-string v1, "controls_host"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    .line 149
    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->safeClearLinearLayout(Landroid/widget/LinearLayout;)V

    .line 150
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaViews:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->clear()V

    .line 151
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaSpans:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->clear()V

    .line 152
    new-instance v1, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda7;

    invoke-direct {v1, p0, v0}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda7;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/widget/LinearLayout;)V

    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method private rebuildTilesOnly()V
    .registers 3

    .line 737
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const-string v1, "tiles_host"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    .line 738
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->tileViews:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->clear()V

    .line 739
    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->safeClearLinearLayout(Landroid/widget/LinearLayout;)V

    .line 740
    new-instance v1, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda6;

    invoke-direct {v1, p0, v0}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda6;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Landroid/widget/LinearLayout;)V

    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method private refreshConnectivityControls()V
    .registers 6

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    if-eqz v0, :cond_4b

    const-string v1, "controls_host"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    instance-of v1, v0, Landroid/widget/LinearLayout;

    if-eqz v1, :cond_4b

    check-cast v0, Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v1

    if-lez v1, :cond_4b

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    instance-of v2, v0, Landroid/widget/FrameLayout;

    if-eqz v2, :cond_4b

    check-cast v0, Landroid/widget/FrameLayout;

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->findControlGrid(Landroid/widget/FrameLayout;)Landroid/widget/GridLayout;

    move-result-object v0

    if-eqz v0, :cond_4b

    const/4 v1, 0x0

    :goto_2c
    invoke-virtual {v0}, Landroid/widget/GridLayout;->getChildCount()I

    move-result v2

    if-lt v1, v2, :cond_33

    goto :goto_4b

    :cond_33
    invoke-virtual {v0, v1}, Landroid/widget/GridLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v3

    sget-object v4, Linv/exe/systemui/qs/model/InvControlId;->INTERNET:Linv/exe/systemui/qs/model/InvControlId;

    if-eq v3, v4, :cond_43

    sget-object v4, Linv/exe/systemui/qs/model/InvControlId;->BLUETOOTH:Linv/exe/systemui/qs/model/InvControlId;

    if-ne v3, v4, :cond_48

    :cond_43
    check-cast v3, Linv/exe/systemui/qs/model/InvControlId;

    invoke-direct {p0, v2, v3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderPillState(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    :cond_48
    add-int/lit8 v1, v1, 0x1

    goto :goto_2c

    :cond_4b
    :goto_4b
    return-void
.end method

.method private refreshControlStates()V
    .registers 8

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->refreshSliderValues()V

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const-string v1, "controls_host"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    instance-of v1, v0, Landroid/widget/LinearLayout;

    if-eqz v1, :cond_75

    check-cast v0, Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v1

    if-lez v1, :cond_75

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    instance-of v2, v0, Landroid/widget/FrameLayout;

    if-eqz v2, :cond_75

    check-cast v0, Landroid/widget/FrameLayout;

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->findControlGrid(Landroid/widget/FrameLayout;)Landroid/widget/GridLayout;

    move-result-object v0

    if-eqz v0, :cond_75

    const/4 v1, 0x0

    :goto_2d
    invoke-virtual {v0}, Landroid/widget/GridLayout;->getChildCount()I

    move-result v2

    if-lt v1, v2, :cond_34

    goto :goto_75

    :cond_34
    invoke-virtual {v0, v1}, Landroid/widget/GridLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v3

    instance-of v4, v3, Linv/exe/systemui/qs/model/InvControlId;

    if-eqz v4, :cond_72

    check-cast v3, Linv/exe/systemui/qs/model/InvControlId;

    invoke-static {}, Linv/exe/systemui/qs/controller/InvQsPanelController;->$SWITCH_TABLE$inv$exe$systemui$qs$model$InvControlId()[I

    move-result-object v4

    invoke-virtual {v3}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v5

    aget v4, v4, v5

    const/4 v5, 0x1

    if-eq v4, v5, :cond_6b

    const/4 v5, 0x2

    if-eq v4, v5, :cond_6b

    const/16 v5, 0xa

    if-eq v4, v5, :cond_6b

    const/16 v5, 0xb

    if-eq v4, v5, :cond_6b

    const/16 v5, 0xc

    if-eq v4, v5, :cond_6b

    const/16 v5, 0xd

    if-eq v4, v5, :cond_6b

    const/16 v5, 0x8

    if-eq v4, v5, :cond_6f

    const/16 v5, 0x9

    if-eq v4, v5, :cond_6f

    goto :goto_72

    :cond_6b
    invoke-direct {p0, v2, v3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderPillState(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    goto :goto_72

    :cond_6f
    invoke-direct {p0, v2, v3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderCircleState(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    :cond_72
    :goto_72
    add-int/lit8 v1, v1, 0x1

    goto :goto_2d

    :cond_75
    :goto_75
    return-void
.end method

.method private refreshCustomControls()V
    .registers 8

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    if-eqz v0, :cond_65

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v1

    if-eqz v1, :cond_65

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    const-string v3, "custom_name_title"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v3}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v3

    instance-of v4, v3, Landroid/widget/TextView;

    if-eqz v4, :cond_32

    check-cast v3, Landroid/widget/TextView;

    const-string v4, "invos_qs_custom_username"

    invoke-static {v2, v4}, Landroid/provider/Settings$System;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_2d

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v5

    if-lez v5, :cond_2d

    goto :goto_2f

    :cond_2d
    const-string v4, "Username"

    :goto_2f
    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setTextKeepState(Ljava/lang/CharSequence;)V

    :cond_32
    const-string v3, "custom_name_subtitle"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v3}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v3

    instance-of v4, v3, Landroid/widget/TextView;

    if-eqz v4, :cond_56

    check-cast v3, Landroid/widget/TextView;

    const-string v4, "invos_qs_custom_subtitle"

    invoke-static {v2, v4}, Landroid/provider/Settings$System;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_51

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v5

    if-lez v5, :cond_51

    goto :goto_53

    :cond_51
    const-string v4, "Subtitle"

    :goto_53
    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setTextKeepState(Ljava/lang/CharSequence;)V

    :cond_56
    const-string v3, "custom_image_body"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v3}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v3

    if-eqz v3, :cond_65

    invoke-virtual {p0, v3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderCustomImageView(Landroid/view/View;)V

    :cond_65
    return-void
.end method

.method private refreshInfoControls()V
    .registers 7

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const-string v1, "controls_host"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    instance-of v1, v0, Landroid/widget/LinearLayout;

    if-eqz v1, :cond_59

    check-cast v0, Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v1

    if-lez v1, :cond_59

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    instance-of v2, v0, Landroid/widget/FrameLayout;

    if-eqz v2, :cond_59

    check-cast v0, Landroid/widget/FrameLayout;

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->findControlGrid(Landroid/widget/FrameLayout;)Landroid/widget/GridLayout;

    move-result-object v0

    if-eqz v0, :cond_59

    const/4 v1, 0x0

    :goto_2a
    invoke-virtual {v0}, Landroid/widget/GridLayout;->getChildCount()I

    move-result v2

    if-lt v1, v2, :cond_31

    goto :goto_59

    :cond_31
    invoke-virtual {v0, v1}, Landroid/widget/GridLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v3

    sget-object v4, Linv/exe/systemui/qs/model/InvControlId;->DATA_USAGE:Linv/exe/systemui/qs/model/InvControlId;

    if-ne v3, v4, :cond_43

    check-cast v3, Linv/exe/systemui/qs/model/InvControlId;

    invoke-direct {p0, v2, v3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderPillState(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    goto :goto_56

    :cond_43
    sget-object v4, Linv/exe/systemui/qs/model/InvControlId;->BATTERY_VIEW:Linv/exe/systemui/qs/model/InvControlId;

    if-ne v3, v4, :cond_4d

    check-cast v3, Linv/exe/systemui/qs/model/InvControlId;

    invoke-direct {p0, v2, v3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderPillState(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    goto :goto_56

    :cond_4d
    sget-object v4, Linv/exe/systemui/qs/model/InvControlId;->FPS_INFO:Linv/exe/systemui/qs/model/InvControlId;

    if-ne v3, v4, :cond_56

    check-cast v3, Linv/exe/systemui/qs/model/InvControlId;

    invoke-direct {p0, v2, v3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderPillState(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    :cond_56
    :goto_56
    add-int/lit8 v1, v1, 0x1

    goto :goto_2a

    :cond_59
    :goto_59
    return-void
.end method

.method private refreshNativeTileStates()V
    .registers 8

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const-string v1, "tiles_host"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    instance-of v1, v0, Landroid/widget/LinearLayout;

    if-eqz v1, :cond_43

    check-cast v0, Landroid/widget/LinearLayout;

    const/4 v1, 0x0

    :goto_13
    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v2

    if-lt v1, v2, :cond_1a

    goto :goto_43

    :cond_1a
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    instance-of v3, v2, Landroid/widget/LinearLayout;

    if-eqz v3, :cond_40

    check-cast v2, Landroid/widget/LinearLayout;

    const/4 v3, 0x0

    :goto_25
    invoke-virtual {v2}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v4

    if-lt v3, v4, :cond_2c

    goto :goto_40

    :cond_2c
    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v5

    instance-of v6, v5, Ljava/lang/String;

    if-eqz v6, :cond_3d

    check-cast v5, Ljava/lang/String;

    invoke-direct {p0, v4, v5}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderNativeTileState(Landroid/view/View;Ljava/lang/String;)V

    :cond_3d
    add-int/lit8 v3, v3, 0x1

    goto :goto_25

    :cond_40
    :goto_40
    add-int/lit8 v1, v1, 0x1

    goto :goto_13

    :cond_43
    :goto_43
    return-void
.end method

.method private refreshSliderThemes()V
    .registers 3

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightnessV:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;

    invoke-virtual {v1}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->refreshTheme()V

    goto :goto_6

    :cond_16
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightnessH:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2c

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;

    invoke-virtual {v1}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->refreshTheme()V

    goto :goto_1c

    :cond_2c
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volumeV:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_32
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_42

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;

    invoke-virtual {v1}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->refreshTheme()V

    goto :goto_32

    :cond_42
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volumeH:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_48
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_58

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;

    invoke-virtual {v1}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->refreshTheme()V

    goto :goto_48

    :cond_58
    return-void
.end method

.method private refreshSliderValues()V
    .registers 4

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightness:Linv/exe/systemui/qs/controller/InvBrightnessController;

    if-eqz v0, :cond_34

    invoke-virtual {v0}, Linv/exe/systemui/qs/controller/InvBrightnessController;->getBrightness()I

    move-result v1

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightnessV:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1e

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;

    invoke-virtual {v2, v1}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->setProgress(I)V

    goto :goto_e

    :cond_1e
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightnessH:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_24
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_34

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;

    invoke-virtual {v2, v1}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->setProgress(I)V

    goto :goto_24

    :cond_34
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volume:Linv/exe/systemui/qs/controller/InvVolumeController;

    if-eqz v0, :cond_68

    invoke-virtual {v0}, Linv/exe/systemui/qs/controller/InvVolumeController;->getVolume()I

    move-result v1

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volumeV:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_42
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_52

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;

    invoke-virtual {v2, v1}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->setProgress(I)V

    goto :goto_42

    :cond_52
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volumeH:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_58
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_68

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;

    invoke-virtual {v0, v1}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->setProgress(I)V

    goto :goto_58

    :cond_68
    return-void
.end method

.method private registerCustomSettingsObserver()V
    .registers 5

    iget-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->customSettingsObserverRegistered:Z

    if-nez v0, :cond_57

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    if-eqz v0, :cond_57

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_57

    :try_start_e
    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    iget-object v2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->customSettingsObserver:Landroid/database/ContentObserver;

    const-string v3, "invos_qs_custom_username"

    invoke-static {v3}, Landroid/provider/Settings$System;->getUriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    const/4 v0, 0x0

    invoke-virtual {v1, v3, v0, v2}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V

    const-string v3, "invos_qs_custom_subtitle"

    invoke-static {v3}, Landroid/provider/Settings$System;->getUriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v1, v3, v0, v2}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V

    const-string v3, "invos_qs_custom_image"

    invoke-static {v3}, Landroid/provider/Settings$System;->getUriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v1, v3, v0, v2}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V

    const-string v3, "invos_qs_custom_image_alpha"

    invoke-static {v3}, Landroid/provider/Settings$System;->getUriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v1, v3, v0, v2}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V

    const-string v3, "invos_qs_custom_gif_animate"

    invoke-static {v3}, Landroid/provider/Settings$System;->getUriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v1, v3, v0, v2}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V

    const-string v3, "screen_brightness"

    invoke-static {v3}, Landroid/provider/Settings$System;->getUriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v1, v3, v0, v2}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V

    const-string v3, "screen_brightness_mode"

    invoke-static {v3}, Landroid/provider/Settings$System;->getUriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v1, v3, v0, v2}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V

    const/4 v0, 0x1

    iput-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->customSettingsObserverRegistered:Z
    :try_end_57
    .catch Ljava/lang/Throwable; {:try_start_e .. :try_end_57} :catch_57

    :catch_57
    :cond_57
    return-void
.end method

.method private registerInfoSignalReceiver()V
    .registers 4

    iget-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoSignalRegistered:Z

    if-nez v0, :cond_43

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    if-eqz v0, :cond_43

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_43

    :try_start_e
    new-instance v1, Landroid/content/IntentFilter;

    invoke-direct {v1}, Landroid/content/IntentFilter;-><init>()V

    const-string v2, "android.intent.action.BATTERY_CHANGED"

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v2, "android.intent.action.ACTION_POWER_CONNECTED"

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v2, "android.intent.action.ACTION_POWER_DISCONNECTED"

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v2, "android.intent.action.TIME_TICK"

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v2, "android.intent.action.DATE_CHANGED"

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v2, "android.net.conn.CONNECTIVITY_CHANGE"

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v2, "android.net.wifi.WIFI_STATE_CHANGED"

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v2, "android.bluetooth.adapter.action.STATE_CHANGED"

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    iget-object v2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoSignalReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v0, v2, v1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/4 v0, 0x1

    iput-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoSignalRegistered:Z
    :try_end_43
    .catch Ljava/lang/Throwable; {:try_start_e .. :try_end_43} :catch_43

    :catch_43
    :cond_43
    return-void
.end method

.method private relayoutControlsLive()Z
    .registers 33

    move-object/from16 v0, p0

    .line 500
    iget-boolean v1, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    const/4 v8, 0x0

    if-nez v1, :cond_8

    return v8

    .line 501
    :cond_8
    iget-object v1, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const-string v2, "controls_host"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v1

    move-object v9, v1

    check-cast v9, Landroid/widget/LinearLayout;

    if-eqz v9, :cond_338

    .line 502
    invoke-virtual {v9}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v1

    if-eqz v1, :cond_338

    invoke-virtual {v9, v8}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    instance-of v1, v1, Landroid/widget/FrameLayout;

    if-nez v1, :cond_29

    goto/16 :goto_338

    .line 503
    :cond_29
    invoke-virtual {v9, v8}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/FrameLayout;

    .line 504
    invoke-direct {v0, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->findControlGrid(Landroid/widget/FrameLayout;)Landroid/widget/GridLayout;

    move-result-object v10

    if-nez v10, :cond_36

    return v8

    .line 507
    :cond_36
    new-instance v11, Ljava/util/EnumMap;

    const-class v2, Linv/exe/systemui/qs/model/InvControlId;

    invoke-direct {v11, v2}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    move v2, v8

    .line 508
    :goto_3e
    invoke-virtual {v10}, Landroid/widget/GridLayout;->getChildCount()I

    move-result v3

    if-lt v2, v3, :cond_31e

    .line 514
    iget-object v2, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v2}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControls()Ljava/util/ArrayList;

    move-result-object v3

    .line 515
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_4e
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-nez v2, :cond_308

    .line 517
    invoke-virtual {v9}, Landroid/widget/LinearLayout;->getWidth()I

    move-result v2

    if-gtz v2, :cond_5b

    return v8

    .line 519
    :cond_5b
    iget-object v4, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v4}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlColumns()I

    move-result v4

    const/4 v5, 0x4

    invoke-static {v5, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    const/4 v5, 0x2

    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    .line 520
    iget-object v6, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v6}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlRows()I

    move-result v6

    const/4 v7, 0x3

    invoke-static {v7, v6}, Ljava/lang/Math;->min(II)I

    move-result v6

    const/4 v12, 0x1

    invoke-static {v12, v6}, Ljava/lang/Math;->max(II)I

    move-result v6

    .line 521
    const-string v14, "inv_qs_control_grid_cell_size"

    invoke-direct {v0, v14}, Linv/exe/systemui/qs/controller/InvQsPanelController;->stableDimenPx(Ljava/lang/String;)I

    move-result v14

    move/from16 v31, v14

    const-string v14, "inv_qs_control_grid_item_spacing"

    invoke-direct {v0, v14}, Linv/exe/systemui/qs/controller/InvQsPanelController;->stableDimenPx(Ljava/lang/String;)I

    move-result v13

    if-le v4, v12, :cond_9b

    add-int/lit8 v14, v4, -0x1

    mul-int/2addr v14, v13

    sub-int/2addr v2, v14

    invoke-static {v12, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    div-int v7, v2, v4

    invoke-static {v12, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    move v2, v13

    goto :goto_a0

    :cond_9b
    invoke-static {v12, v2}, Ljava/lang/Math;->max(II)I

    move-result v7

    move v2, v8

    .line 524
    :goto_a0
    new-array v5, v5, [I

    aput v4, v5, v12

    aput v6, v5, v8

    sget-object v14, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    invoke-static {v14, v5}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, [[Z

    .line 525
    new-instance v14, Ljava/util/ArrayList;

    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    .line 527
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_b7
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-nez v16, :cond_292

    .line 546
    invoke-interface {v14}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :goto_c1
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v15

    if-nez v15, :cond_26b

    .line 547
    new-array v15, v12, [Landroid/view/ViewGroup;

    aput-object v10, v15, v8

    invoke-static {v15}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->capture([Landroid/view/ViewGroup;)Ljava/util/Map;

    move-result-object v15

    .line 548
    invoke-static {v10}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->beginSmoothBounds(Landroid/view/ViewGroup;)Z

    move-result v17

    move/from16 v18, v8

    .line 549
    :goto_d5
    invoke-virtual {v1}, Landroid/widget/FrameLayout;->getChildCount()I

    move-result v8

    if-gt v8, v12, :cond_24d

    .line 550
    invoke-virtual {v10}, Landroid/widget/GridLayout;->getColumnCount()I

    move-result v8

    invoke-static {v4, v8}, Ljava/lang/Math;->max(II)I

    move-result v8

    invoke-virtual {v10, v8}, Landroid/widget/GridLayout;->setColumnCount(I)V

    .line 551
    invoke-virtual {v10}, Landroid/widget/GridLayout;->getRowCount()I

    move-result v8

    invoke-static {v6, v8}, Ljava/lang/Math;->max(II)I

    move-result v8

    invoke-virtual {v10, v8}, Landroid/widget/GridLayout;->setRowCount(I)V

    .line 553
    invoke-virtual {v10}, Landroid/widget/GridLayout;->getChildCount()I

    move-result v8

    sub-int/2addr v8, v12

    :goto_f6
    if-gez v8, :cond_212

    .line 559
    iget-object v3, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaViews:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->clear()V

    .line 560
    iget-object v3, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaSpans:Ljava/util/Map;

    invoke-interface {v3}, Ljava/util/Map;->clear()V

    .line 561
    invoke-interface {v14}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :goto_106
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-nez v3, :cond_127

    move v3, v6

    move v6, v2

    move-object v2, v5

    move v5, v7

    move v7, v13

    .line 588
    invoke-direct/range {v0 .. v7}, Linv/exe/systemui/qs/controller/InvQsPanelController;->drawLiveEmptyControls(Landroid/widget/FrameLayout;[[ZIIIII)V

    invoke-virtual {v10, v4}, Landroid/widget/GridLayout;->setColumnCount(I)V

    invoke-virtual {v10, v3}, Landroid/widget/GridLayout;->setRowCount(I)V

    .line 589
    invoke-virtual {v10}, Landroid/widget/GridLayout;->requestLayout()V

    .line 590
    invoke-virtual {v1}, Landroid/widget/FrameLayout;->requestLayout()V

    .line 591
    invoke-virtual {v9}, Landroid/widget/LinearLayout;->requestLayout()V

    .line 594
    invoke-static {v10, v15}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->play(Landroid/view/View;Ljava/util/Map;)V

    return v12

    :cond_127
    move-object/from16 v30, v5

    move v5, v4

    move-object/from16 v4, v30

    move/from16 v30, v13

    move v13, v7

    move/from16 v7, v30

    .line 561
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;

    .line 562
    iget-object v8, v3, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->id:Linv/exe/systemui/qs/model/InvControlId;

    invoke-interface {v11, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/view/View;

    if-nez v8, :cond_142

    return v18

    .line 564
    :cond_142
    iget v14, v3, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->w:I

    mul-int/2addr v14, v13

    move/from16 v19, v12

    iget v12, v3, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->w:I

    add-int/lit8 v12, v12, -0x1

    mul-int/2addr v12, v2

    add-int/2addr v14, v12

    .line 565
    iget v12, v3, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->h:I

    mul-int v12, v12, v31

    move/from16 v20, v2

    iget v2, v3, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->h:I

    add-int/lit8 v2, v2, -0x1

    mul-int/2addr v2, v7

    add-int/2addr v12, v2

    .line 566
    new-instance v2, Landroid/widget/GridLayout$LayoutParams;

    move/from16 v21, v7

    .line 567
    iget v7, v3, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->r:I

    move-object/from16 v22, v9

    iget v9, v3, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->h:I

    move/from16 v23, v13

    sget-object v13, Landroid/widget/GridLayout;->FILL:Landroid/widget/GridLayout$Alignment;

    invoke-static {v7, v9, v13}, Landroid/widget/GridLayout;->spec(IILandroid/widget/GridLayout$Alignment;)Landroid/widget/GridLayout$Spec;

    move-result-object v7

    .line 568
    iget v9, v3, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->c:I

    iget v13, v3, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->w:I

    move-object/from16 v24, v15

    sget-object v15, Landroid/widget/GridLayout;->FILL:Landroid/widget/GridLayout$Alignment;

    invoke-static {v9, v13, v15}, Landroid/widget/GridLayout;->spec(IILandroid/widget/GridLayout$Alignment;)Landroid/widget/GridLayout$Spec;

    move-result-object v9

    .line 566
    invoke-direct {v2, v7, v9}, Landroid/widget/GridLayout$LayoutParams;-><init>(Landroid/widget/GridLayout$Spec;Landroid/widget/GridLayout$Spec;)V

    .line 569
    iput v14, v2, Landroid/widget/GridLayout$LayoutParams;->width:I

    .line 570
    iput v12, v2, Landroid/widget/GridLayout$LayoutParams;->height:I

    .line 571
    iget v7, v3, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->c:I

    iget v9, v3, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->w:I

    add-int/2addr v7, v9

    if-ge v7, v5, :cond_188

    move/from16 v7, v20

    goto :goto_18a

    :cond_188
    move/from16 v7, v18

    :goto_18a
    iput v7, v2, Landroid/widget/GridLayout$LayoutParams;->rightMargin:I

    .line 572
    iget v7, v3, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->r:I

    iget v9, v3, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->h:I

    add-int/2addr v7, v9

    if-ge v7, v6, :cond_196

    move/from16 v13, v21

    goto :goto_198

    :cond_196
    move/from16 v13, v18

    :goto_198
    iput v13, v2, Landroid/widget/GridLayout$LayoutParams;->bottomMargin:I

    const/16 v7, 0x77

    .line 573
    invoke-virtual {v2, v7}, Landroid/widget/GridLayout$LayoutParams;->setGravity(I)V

    .line 574
    iget-object v7, v3, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->id:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v8, v7}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 575
    invoke-virtual {v8, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 576
    invoke-virtual {v8}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    if-nez v2, :cond_1b0

    invoke-virtual {v10, v8}, Landroid/widget/GridLayout;->addView(Landroid/view/View;)V

    :cond_1b0
    const/high16 v2, 0x3f800000  # 1.0f

    .line 577
    invoke-virtual {v8, v2}, Landroid/view/View;->setAlpha(F)V

    .line 578
    iget-object v2, v3, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->id:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v7, Linv/exe/systemui/qs/model/InvControlId;->MEDIA:Linv/exe/systemui/qs/model/InvControlId;

    if-ne v2, v7, :cond_1ff

    .line 579
    iget-object v2, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaViews:Ljava/util/List;

    invoke-interface {v2, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 580
    iget-object v2, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaSpans:Ljava/util/Map;

    iget v7, v3, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->w:I

    iget v3, v3, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->h:I

    filled-new-array {v7, v3}, [I

    move-result-object v3

    invoke-interface {v2, v8, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 581
    invoke-direct {v0, v8}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderMediaView(Landroid/view/View;)V

    .line 582
    const-string v2, "media_content"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v8, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    invoke-static {v2}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->softRefresh(Landroid/view/View;)V

    .line 583
    const-string v2, "media_resize_handle"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v8, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    if-eqz v2, :cond_1ff

    move/from16 v3, v18

    .line 584
    invoke-virtual {v2, v3}, Landroid/view/View;->setVisibility(I)V

    move v2, v5

    move-object v5, v4

    move v4, v2

    move/from16 v12, v19

    move/from16 v2, v20

    move/from16 v13, v21

    move-object/from16 v9, v22

    move/from16 v7, v23

    move-object/from16 v15, v24

    goto/16 :goto_106

    :cond_1ff
    move v2, v5

    move-object v5, v4

    move v4, v2

    move/from16 v12, v19

    move/from16 v2, v20

    move/from16 v13, v21

    move-object/from16 v9, v22

    move/from16 v7, v23

    move-object/from16 v15, v24

    const/16 v18, 0x0

    goto/16 :goto_106

    :cond_212
    move-object/from16 v19, v5

    move v5, v4

    move-object/from16 v4, v19

    move/from16 v20, v2

    move/from16 v23, v7

    move-object/from16 v22, v9

    move/from16 v19, v12

    move/from16 v21, v13

    move-object/from16 v24, v15

    .line 554
    invoke-virtual {v10, v8}, Landroid/widget/GridLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    .line 555
    invoke-virtual {v2}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v2

    .line 556
    instance-of v7, v2, Linv/exe/systemui/qs/model/InvControlId;

    if-eqz v7, :cond_235

    invoke-interface {v3, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_238

    :cond_235
    invoke-virtual {v10, v8}, Landroid/widget/GridLayout;->removeViewAt(I)V

    :cond_238
    add-int/lit8 v8, v8, -0x1

    move v2, v5

    move-object v5, v4

    move v4, v2

    move/from16 v12, v19

    move/from16 v2, v20

    move/from16 v13, v21

    move-object/from16 v9, v22

    move/from16 v7, v23

    move-object/from16 v15, v24

    const/16 v18, 0x0

    goto/16 :goto_f6

    :cond_24d
    move-object/from16 v20, v5

    move v5, v4

    move-object/from16 v4, v20

    move/from16 v20, v2

    move/from16 v23, v7

    move-object/from16 v22, v9

    move v2, v12

    move/from16 v21, v13

    move-object/from16 v24, v15

    .line 549
    invoke-virtual {v1, v2}, Landroid/widget/FrameLayout;->removeViewAt(I)V

    move v7, v5

    move-object v5, v4

    move v4, v7

    move/from16 v2, v20

    move/from16 v7, v23

    const/16 v18, 0x0

    goto/16 :goto_d5

    :cond_26b
    move-object/from16 v20, v5

    move v5, v4

    move-object/from16 v4, v20

    move/from16 v20, v2

    move/from16 v23, v7

    move-object/from16 v22, v9

    move/from16 v21, v13

    .line 546
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;

    iget v7, v2, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->r:I

    iget v2, v2, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->h:I

    add-int/2addr v7, v2

    invoke-static {v6, v7}, Ljava/lang/Math;->max(II)I

    move-result v6

    move v2, v5

    move-object v5, v4

    move v4, v2

    move/from16 v2, v20

    move/from16 v7, v23

    const/4 v8, 0x0

    const/4 v12, 0x1

    goto/16 :goto_c1

    :cond_292
    move-object/from16 v20, v5

    move v5, v4

    move-object/from16 v4, v20

    move/from16 v20, v2

    move/from16 v23, v7

    move-object/from16 v22, v9

    move/from16 v21, v13

    .line 527
    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Linv/exe/systemui/qs/model/InvControlId;

    .line 528
    iget-object v7, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v7, v2}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlSpanW(Linv/exe/systemui/qs/model/InvControlId;)I

    move-result v7

    invoke-static {v5, v7}, Ljava/lang/Math;->min(II)I

    move-result v7

    const/4 v8, 0x1

    invoke-static {v8, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    .line 529
    iget-object v9, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v9, v2}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlSpanH(Linv/exe/systemui/qs/model/InvControlId;)I

    move-result v9

    invoke-static {v8, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    const/4 v12, 0x0

    :goto_2bf
    sub-int v13, v6, v9

    if-le v12, v13, :cond_2c6

    const/16 v18, 0x0

    return v18

    :cond_2c6
    const/4 v13, 0x0

    :goto_2c7
    sub-int v8, v5, v7

    if-le v13, v8, :cond_2cf

    add-int/lit8 v12, v12, 0x1

    const/4 v8, 0x1

    goto :goto_2bf

    .line 534
    :cond_2cf
    invoke-static {v4, v12, v13, v7, v9}, Linv/exe/systemui/qs/controller/InvQsPanelController;->free([[ZIIII)Z

    move-result v8

    if-eqz v8, :cond_2fb

    .line 535
    invoke-static {v4, v12, v13, v7, v9}, Linv/exe/systemui/qs/controller/InvQsPanelController;->mark([[ZIIII)V

    .line 536
    new-instance v24, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;

    move-object/from16 v25, v2

    move/from16 v28, v7

    move/from16 v29, v9

    move/from16 v26, v12

    move/from16 v27, v13

    invoke-direct/range {v24 .. v29}, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;-><init>(Linv/exe/systemui/qs/model/InvControlId;IIII)V

    move-object/from16 v2, v24

    invoke-interface {v14, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move v2, v5

    move-object v5, v4

    move v4, v2

    move/from16 v2, v20

    move/from16 v13, v21

    move-object/from16 v9, v22

    move/from16 v7, v23

    const/4 v8, 0x0

    const/4 v12, 0x1

    goto/16 :goto_b7

    :cond_2fb
    move-object/from16 v25, v2

    move/from16 v28, v7

    move/from16 v29, v9

    move/from16 v26, v12

    move/from16 v27, v13

    add-int/lit8 v13, v27, 0x1

    goto :goto_2c7

    :cond_308
    move-object/from16 v22, v9

    .line 515
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Linv/exe/systemui/qs/model/InvControlId;

    invoke-interface {v11, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_319

    const/16 v18, 0x0

    return v18

    :cond_319
    move-object/from16 v9, v22

    const/4 v8, 0x0

    goto/16 :goto_4e

    :cond_31e
    move-object/from16 v22, v9

    .line 509
    invoke-virtual {v10, v2}, Landroid/widget/GridLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    .line 510
    invoke-virtual {v3}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v4

    .line 511
    instance-of v5, v4, Linv/exe/systemui/qs/model/InvControlId;

    if-eqz v5, :cond_331

    check-cast v4, Linv/exe/systemui/qs/model/InvControlId;

    invoke-interface {v11, v4, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_331
    add-int/lit8 v2, v2, 0x1

    move-object/from16 v9, v22

    const/4 v8, 0x0

    goto/16 :goto_3e

    :cond_338
    :goto_338
    move/from16 v18, v8

    return v18
.end method

.method private renderCircleState(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V
    .registers 7

    .line 711
    const-string v0, "circle_body"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/FrameLayout;

    .line 712
    const-string v1, "circle_icon"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    .line 713
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->AUTO_BRIGHTNESS:Linv/exe/systemui/qs/model/InvControlId;

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ne p2, v1, :cond_29

    .line 714
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightness:Linv/exe/systemui/qs/controller/InvBrightnessController;

    if-eqz p2, :cond_34

    invoke-virtual {p2}, Linv/exe/systemui/qs/controller/InvBrightnessController;->isAutoBrightness()Z

    move-result p2

    if-eqz p2, :cond_34

    goto :goto_35

    .line 715
    :cond_29
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volume:Linv/exe/systemui/qs/controller/InvVolumeController;

    if-eqz p2, :cond_34

    invoke-virtual {p2}, Linv/exe/systemui/qs/controller/InvVolumeController;->getVolume()I

    move-result p2

    if-nez p2, :cond_34

    goto :goto_35

    :cond_34
    move v2, v3

    :goto_35
    if-eqz v2, :cond_39

    .line 716
    const/4 p2, 0x2

    goto :goto_3a

    :cond_39
    const/4 p2, 0x1

    :goto_3a
    const/16 v3, 0xff

    invoke-static {v0, p2, v3}, Linv/exe/systemui/qs/ui/InvTileAnimation;->tileBackground(Landroid/view/View;II)V

    if-eqz v2, :cond_44

    .line 717
    const-string p2, "inv_icon_on_accent"

    goto :goto_46

    :cond_44
    const-string p2, "inv_icon_primary"

    :goto_46
    invoke-static {p2}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result p2

    invoke-direct {p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->color(I)I

    move-result p0

    invoke-static {p0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p0

    invoke-virtual {p1, p0}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    const/4 p0, 0x0

    invoke-static {v0, p1, p0, v2}, Linv/exe/systemui/qs/ui/InvTileAnimation;->state(Landroid/view/View;Landroid/widget/ImageView;Landroid/widget/TextView;I)V

    return-void
.end method

.method private renderMediaView(Landroid/view/View;)V
    .registers 6

    .line 352
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaSpans:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [I

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_1f

    const/4 v0, 0x2

    .line 353
    new-array v0, v0, [I

    iget-object v3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v3}, Linv/exe/systemui/qs/model/InvPanelRepository;->getMediaSpanW()I

    move-result v3

    aput v3, v0, v2

    iget-object v3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v3}, Linv/exe/systemui/qs/model/InvPanelRepository;->getMediaSpanH()I

    move-result v3

    aput v3, v0, v1

    .line 354
    :cond_1f
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->media:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    aget v2, v0, v2

    aget v0, v0, v1

    invoke-static {p1, p0, v2, v0}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->render(Landroid/view/View;Linv/exe/systemui/qs/controller/InvMediaSessionController;II)V

    return-void
.end method

.method private renderMediaViews()V
    .registers 4

    .line 341
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaViews:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    .line 342
    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-nez v1, :cond_d

    return-void

    .line 343
    :cond_d
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    .line 344
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    if-nez v2, :cond_22

    .line 345
    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    .line 346
    iget-object v2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaSpans:Ljava/util/Map;

    invoke-interface {v2, v1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_6

    .line 347
    :cond_22
    invoke-direct {p0, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderMediaView(Landroid/view/View;)V

    goto :goto_6
.end method

.method private renderNativeTileState(Landroid/view/View;Ljava/lang/String;)V
    .registers 11

    const-string v0, "tile_circle"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/FrameLayout;

    const-string v1, "tile_icon"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    const-string v2, "tile_label"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    iget-object v3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {v3}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isFullLandscapeMode()Z

    move-result v3

    if-eqz v3, :cond_2d

    goto :goto_37

    :cond_2d
    iget-object v3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v3}, Linv/exe/systemui/qs/model/InvPanelRepository;->getShowTileLabels()Z

    move-result v3

    if-eqz v3, :cond_37

    const/4 v3, 0x0

    goto :goto_39

    :cond_37
    :goto_37
    const/16 v3, 0x8

    :goto_39
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-static {v3, p2}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->label(Landroid/view/View;Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-static {v3, p2}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->icon(Landroid/view/View;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    if-eqz v3, :cond_51

    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_55

    :cond_51
    const/4 v3, 0x0

    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    :goto_55
    iget-object v3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-static {v3, p2}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->stateValue(Landroid/view/View;Ljava/lang/String;)I

    move-result p2

    move v7, p2

    const/4 v3, 0x0

    if-ne p2, v3, :cond_6b

    const-string p1, "inv_bg_tile_unavailable"

    const-string p2, "inv_icon_primary"

    const-string v3, "inv_text_secondary"

    const/16 v4, 0x4d

    const v5, 0x3e99999a  # 0.3f

    goto :goto_83

    :cond_6b
    const/4 v3, 0x2

    if-ne p2, v3, :cond_79

    const-string p1, "inv_bg_tile_on"

    const-string p2, "inv_icon_on_accent"

    const-string v3, "inv_text_secondary"

    const/16 v4, 0xff

    const/high16 v5, 0x3f800000  # 1.0f

    goto :goto_83

    :cond_79
    const-string p1, "inv_bg_tile_off"

    const-string p2, "inv_icon_primary"

    const-string v3, "inv_text_secondary"

    const/16 v4, 0xff

    const/high16 v5, 0x3f800000  # 1.0f

    :goto_83
    invoke-static {v0, v7, v4}, Linv/exe/systemui/qs/ui/InvTileAnimation;->tileBackground(Landroid/view/View;II)V

    invoke-static {p2}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result p1

    invoke-direct {p0, p1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->color(I)I

    move-result p1

    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p1

    invoke-virtual {v1, p1}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    invoke-virtual {v1, v5}, Landroid/widget/ImageView;->setAlpha(F)V

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result p1

    invoke-direct {p0, p1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->color(I)I

    move-result p0

    invoke-virtual {v2, p0}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setAlpha(F)V

    invoke-static {v0, v1, v2, v7}, Linv/exe/systemui/qs/ui/InvTileAnimation;->state(Landroid/view/View;Landroid/widget/ImageView;Landroid/widget/TextView;I)V

    return-void
.end method

.method private renderPillState(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V
    .registers 9

    .line 291
    const-string v0, "pill_body"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    .line 292
    const-string v1, "pill_label"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    if-eqz v0, :cond_1c

    if-nez p1, :cond_1d

    :cond_1c
    return-void

    :cond_1d
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->FPS_INFO:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p2, v1, :cond_43

    invoke-static {}, Linv/exe/systemui/qs/controller/InvFpsMonitor;->getFps()I

    move-result v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "FPS\n"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " FPS"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, p1, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->bindTwoLinePill(Landroid/widget/LinearLayout;Landroid/widget/TextView;Ljava/lang/String;)V

    const/4 v1, 0x0

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvTileAnimation;->pillBackground(Landroid/view/View;Z)V

    invoke-static {v0, p1, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->applyPillForeground(Landroid/widget/LinearLayout;Landroid/widget/TextView;Z)V

    return-void

    .line 293
    :cond_43
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->INTERNET:Linv/exe/systemui/qs/model/InvControlId;

    const-string v2, "inv_bg_pill_on"

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v5, "inv_bg_pill"

    if-ne p2, v1, :cond_81

    .line 294
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->connectivity:Linv/exe/systemui/qs/controller/InvConnectivityController;

    if-eqz p2, :cond_58

    invoke-virtual {p2}, Linv/exe/systemui/qs/controller/InvConnectivityController;->isInternetEnabled()Z

    move-result p2

    if-eqz p2, :cond_58

    goto :goto_59

    :cond_58
    move v3, v4

    :goto_59
    if-eqz v3, :cond_64

    .line 295
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->connectivity:Linv/exe/systemui/qs/controller/InvConnectivityController;

    if-eqz p2, :cond_64

    invoke-virtual {p2}, Linv/exe/systemui/qs/controller/InvConnectivityController;->getInternetSummary()Ljava/lang/String;

    move-result-object p0

    goto :goto_6c

    :cond_64
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object p0

    const-string p0, "Internet"

    :goto_6c
    invoke-static {v0, p1, p0, v3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->bindConnectivityPillState(Landroid/widget/LinearLayout;Landroid/widget/TextView;Ljava/lang/String;Z)V

    if-eqz v3, :cond_76

    .line 296
    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result p0

    goto :goto_7a

    :cond_76
    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result p0

    :goto_7a
    invoke-static {v0, v3}, Linv/exe/systemui/qs/ui/InvTileAnimation;->pillBackground(Landroid/view/View;Z)V

    invoke-static {v0, p1, v3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->applyPillForeground(Landroid/widget/LinearLayout;Landroid/widget/TextView;Z)V

    return-void

    .line 297
    :cond_81
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->BLUETOOTH:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p2, v1, :cond_b9

    .line 298
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->connectivity:Linv/exe/systemui/qs/controller/InvConnectivityController;

    if-eqz p2, :cond_90

    invoke-virtual {p2}, Linv/exe/systemui/qs/controller/InvConnectivityController;->isBluetoothEnabled()Z

    move-result p2

    if-eqz p2, :cond_90

    goto :goto_91

    :cond_90
    move v3, v4

    :goto_91
    if-eqz v3, :cond_9c

    .line 299
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->connectivity:Linv/exe/systemui/qs/controller/InvConnectivityController;

    if-eqz p2, :cond_9c

    invoke-virtual {p2}, Linv/exe/systemui/qs/controller/InvConnectivityController;->getBluetoothSummary()Ljava/lang/String;

    move-result-object p0

    goto :goto_a4

    :cond_9c
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object p0

    const-string p0, "Bluetooth"

    :goto_a4
    invoke-static {v0, p1, p0, v3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->bindConnectivityPillState(Landroid/widget/LinearLayout;Landroid/widget/TextView;Ljava/lang/String;Z)V

    if-eqz v3, :cond_ae

    .line 300
    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result p0

    goto :goto_b2

    :cond_ae
    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result p0

    :goto_b2
    invoke-static {v0, v3}, Linv/exe/systemui/qs/ui/InvTileAnimation;->pillBackground(Landroid/view/View;Z)V

    invoke-static {v0, p1, v3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->applyPillForeground(Landroid/widget/LinearLayout;Landroid/widget/TextView;Z)V

    return-void

    .line 302
    :cond_b9
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->DATA_USAGE:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p2, v1, :cond_f6

    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {p2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object p2

    invoke-static {p2}, Linv/exe/systemui/qs/helper/InvDataUsageControlHelper;->label(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, p1, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->bindTwoLinePill(Landroid/widget/LinearLayout;Landroid/widget/TextView;Ljava/lang/String;)V

    invoke-static {p2}, Linv/exe/systemui/qs/helper/InvDataUsageControlHelper;->activeTransport(Landroid/content/Context;)I

    move-result v3

    const/4 p0, 0x1

    if-ne v3, p0, :cond_d4

    const-string p0, "inv_ic_wifi"

    goto :goto_db

    :cond_d4
    if-nez v3, :cond_d9

    const-string p0, "inv_ic_mobile_signal"

    goto :goto_db

    :cond_d9
    const-string p0, "inv_ic_internet"

    :goto_db
    invoke-static {v0, p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->setPillIcon(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    return-void

    if-gez v3, :cond_e3

    const/4 v3, 0x0

    goto :goto_e4

    :cond_e3
    const/4 v3, 0x1

    :goto_e4
    if-eqz v3, :cond_eb

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result p0

    goto :goto_ef

    :cond_eb
    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result p0

    :goto_ef
    invoke-static {v0, v3}, Linv/exe/systemui/qs/ui/InvTileAnimation;->pillBackground(Landroid/view/View;Z)V

    invoke-static {v0, p1, v3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->applyPillForeground(Landroid/widget/LinearLayout;Landroid/widget/TextView;Z)V

    return-void

    :cond_f6
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->BATTERY_VIEW:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p2, v1, :cond_127

    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {p2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object p2

    invoke-static {p2}, Linv/exe/systemui/qs/helper/InvBatteryControlHelper;->label(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, p1, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->bindTwoLinePill(Landroid/widget/LinearLayout;Landroid/widget/TextView;Ljava/lang/String;)V

    invoke-static {p2}, Linv/exe/systemui/qs/helper/InvBatteryControlHelper;->isCharging(Landroid/content/Context;)Z

    move-result v3

    if-eqz v3, :cond_110

    const-string p0, "inv_ic_battery_charging"

    goto :goto_112

    :cond_110
    const-string p0, "inv_ic_battery_view"

    :goto_112
    invoke-static {v0, p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->setPillIcon(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    if-eqz v3, :cond_11c

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result p0

    goto :goto_120

    :cond_11c
    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result p0

    :goto_120
    invoke-static {v0, v3}, Linv/exe/systemui/qs/ui/InvTileAnimation;->pillBackground(Landroid/view/View;Z)V

    invoke-static {v0, p1, v3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->applyPillForeground(Landroid/widget/LinearLayout;Landroid/widget/TextView;Z)V

    return-void

    :cond_127
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->RINGER:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p2, v1, :cond_12f

    invoke-static {v0, p1}, Linv/exe/systemui/qs/helper/InvRingerModeHelper;->render(Landroid/view/View;Landroid/widget/TextView;)V

    return-void

    :cond_12f
    invoke-virtual {p2}, Linv/exe/systemui/qs/model/InvControlId;->labelText()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 303
    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result p0

    invoke-static {v0, v4}, Linv/exe/systemui/qs/ui/InvTileAnimation;->pillBackground(Landroid/view/View;Z)V

    return-void
.end method

.method private static safeClearLinearLayout(Landroid/widget/LinearLayout;)V
    .registers 3

    if-eqz p0, :cond_1a

    invoke-virtual {p0}, Landroid/view/View;->clearFocus()V

    :goto_5
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-lez v0, :cond_1a

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_16

    invoke-virtual {v1}, Landroid/view/View;->clearFocus()V

    :cond_16
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->removeViewAt(I)V

    goto :goto_5

    :cond_1a
    return-void
.end method

.method private scheduleInfoFrameRefresh()V
    .registers 3

    iget-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoRefreshActive:Z

    if-nez v0, :cond_5

    return-void

    :cond_5
    iget-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoRefreshFramePosted:Z

    if-eqz v0, :cond_a

    return-void

    :cond_a
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    if-eqz v0, :cond_22

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isAttachedToWindow()Z

    move-result v1

    if-eqz v1, :cond_22

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isShown()Z

    move-result v1

    if-eqz v1, :cond_22

    const/4 v1, 0x1

    iput-boolean v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoRefreshFramePosted:Z

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoFrameRefreshRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->postOnAnimation(Ljava/lang/Runnable;)V

    :cond_22
    return-void
.end method

.method private static setPillIcon(Landroid/widget/LinearLayout;Ljava/lang/String;)V
    .registers 4

    if-eqz p0, :cond_2a

    if-eqz p1, :cond_2a

    const-string v0, "pill_icon"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->findViewById(I)Landroid/view/View;

    move-result-object p0

    instance-of v0, p0, Landroid/widget/ImageView;

    if-eqz v0, :cond_2a

    check-cast p0, Landroid/widget/ImageView;

    invoke-virtual {p0}, Landroid/widget/ImageView;->getTag()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2a

    invoke-static {p1}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v0

    if-lez v0, :cond_2a

    invoke-virtual {p0, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    invoke-virtual {p0, p1}, Landroid/widget/ImageView;->setTag(Ljava/lang/Object;)V

    :cond_2a
    return-void
.end method

.method private setResizeVisual(Landroid/view/View;Z)V
    .registers 4

    .line 418
    invoke-virtual {p1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->cancel()V

    const/high16 v0, 0x3f800000  # 1.0f

    .line 419
    invoke-virtual {p1, v0}, Landroid/view/View;->setScaleX(F)V

    .line 420
    invoke-virtual {p1, v0}, Landroid/view/View;->setScaleY(F)V

    if-eqz p2, :cond_2b

    .line 422
    invoke-virtual {p1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const/4 p0, 0x0

    invoke-virtual {p1, p0}, Landroid/view/ViewPropertyAnimator;->translationZ(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const p1, 0x3f7851ec  # 0.97f

    .line 424
    invoke-virtual {p0, p1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const-wide/16 p1, 0xb4

    .line 425
    invoke-virtual {p0, p1, p2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    .line 426
    invoke-virtual {p0}, Landroid/view/ViewPropertyAnimator;->start()V

    return-void

    .line 428
    :cond_2b
    invoke-virtual {p1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const/4 p1, 0x0

    .line 429
    invoke-virtual {p0, p1}, Landroid/view/ViewPropertyAnimator;->translationZ(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    .line 430
    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const-wide/16 p1, 0x104

    .line 431
    invoke-virtual {p0, p1, p2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    .line 432
    invoke-virtual {p0}, Landroid/view/ViewPropertyAnimator;->start()V

    return-void
.end method

.method private static setTextIfDifferent(Landroid/widget/TextView;Ljava/lang/CharSequence;)V
    .registers 3

    if-eqz p0, :cond_f

    invoke-virtual {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    invoke-static {v0, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_f

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_f
    return-void
.end method

.method private stableDimenPx(Ljava/lang/String;)I
    .registers 8

    invoke-static {p1}, Linv/exe/systemui/qs/core/InvRes;->dimen(Ljava/lang/String;)I

    move-result v0

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v2

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v3

    iget v4, v3, Landroid/util/DisplayMetrics;->densityDpi:I

    if-lez v4, :cond_24

    sget v5, Landroid/util/DisplayMetrics;->DENSITY_DEVICE_STABLE:I

    if-lez v5, :cond_24

    mul-int/2addr v2, v5

    div-int/lit8 v3, v4, 0x2

    add-int/2addr v2, v3

    div-int/2addr v2, v4

    const/4 v0, 0x1

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    :cond_24
    return v2
.end method

.method private startInfoAutoRefresh()V
    .registers 4

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    if-eqz v0, :cond_2d

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isAttachedToWindow()Z

    move-result v1

    if-eqz v1, :cond_2d

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isShown()Z

    move-result v1

    if-eqz v1, :cond_2d

    iget-boolean v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoRefreshActive:Z

    if-nez v1, :cond_2d

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoRefreshRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v0, 0x1

    iput-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoRefreshActive:Z

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->registerInfoSignalReceiver()V

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->registerCustomSettingsObserver()V

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->refreshCustomControls()V

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->refreshInfoControls()V

    const-wide/16 v0, 0x3e8

    invoke-direct {p0, v0, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->postInfoFallbackTick(J)V

    :cond_2d
    return-void
.end method

.method private stopInfoAutoRefresh()V
    .registers 3

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoRefreshActive:Z

    iput-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoRefreshFramePosted:Z

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    if-eqz v0, :cond_13

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoRefreshRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoFrameRefreshRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->removeCallbacks(Ljava/lang/Runnable;)Z

    :cond_13
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->unregisterInfoSignalReceiver()V

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->unregisterCustomSettingsObserver()V

    return-void
.end method

.method private unregisterCustomSettingsObserver()V
    .registers 3

    iget-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->customSettingsObserverRegistered:Z

    if-eqz v0, :cond_1a

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->customSettingsObserverRegistered:Z

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    if-eqz v0, :cond_1a

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_1a

    :try_start_11
    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->customSettingsObserver:Landroid/database/ContentObserver;

    invoke-virtual {v0, v1}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V
    :try_end_1a
    .catch Ljava/lang/Throwable; {:try_start_11 .. :try_end_1a} :catch_1a

    :catch_1a
    :cond_1a
    return-void
.end method

.method private unregisterInfoSignalReceiver()V
    .registers 3

    iget-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoSignalRegistered:Z

    if-eqz v0, :cond_16

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoSignalRegistered:Z

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    if-eqz v0, :cond_16

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_16

    :try_start_11
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoSignalReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v0, p0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_16
    .catch Ljava/lang/Throwable; {:try_start_11 .. :try_end_16} :catch_16

    :catch_16
    :cond_16
    return-void
.end method

.method private vertical(Landroid/view/LayoutInflater;Linv/exe/systemui/qs/model/InvControlId;Z)Landroid/view/View;
    .registers 16

    .line 631
    const-string v0, "inv_item_slider_vertical"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->layout(Ljava/lang/String;)I

    move-result v0

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const/4 v2, 0x0

    invoke-virtual {p1, v0, v1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    move-object v11, p2

    .line 632
    const-string v0, "slider_body"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    move-object v3, v0

    check-cast v3, Landroid/widget/FrameLayout;

    if-eqz p3, :cond_2c

    const-string v0, "brightness"

    invoke-virtual {v3, v0}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const-string v1, "slider_body"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v3, v1, v0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    goto :goto_3a

    :cond_2c
    const-string v0, "volume"

    invoke-virtual {v3, v0}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const-string v1, "slider_body"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v3, v1, v0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 633
    :goto_3a
    const-string v0, "slider_fill"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    .line 634
    const-string v0, "slider_icon"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    move-object v7, v0

    check-cast v7, Landroid/widget/ImageView;

    .line 635
    const-string v0, "badge"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    if-eqz p3, :cond_62

    .line 636
    const-string v1, "inv_ic_brightness"

    goto :goto_64

    :cond_62
    const-string v1, "inv_ic_volume"

    :goto_64
    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v7, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    if-eqz p3, :cond_70

    const-string v8, "brightness"

    goto :goto_72

    :cond_70
    const-string v8, "volume"

    :goto_72
    invoke-virtual {v7, v8}, Landroid/widget/ImageView;->setTag(Ljava/lang/Object;)V

    const-string v9, "slider_body"

    invoke-static {v9}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v9

    invoke-virtual {v7, v9, v8}, Landroid/widget/ImageView;->setTag(ILjava/lang/Object;)V

    .line 637
    iget-boolean v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-eqz v1, :cond_84

    move v1, v2

    goto :goto_86

    :cond_84
    const/16 v1, 0x8

    :goto_86
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 638
    new-instance v1, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda17;

    invoke-direct {v1, p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda17;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Linv/exe/systemui/qs/model/InvControlId;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    if-eqz p3, :cond_97

    const/16 p2, 0x3ff

    :goto_95
    move v5, p2

    goto :goto_a8

    .line 639
    :cond_97
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volume:Linv/exe/systemui/qs/controller/InvVolumeController;

    if-nez p2, :cond_9e

    const/16 p2, 0xf

    goto :goto_a2

    :cond_9e
    invoke-virtual {p2}, Linv/exe/systemui/qs/controller/InvVolumeController;->getMax()I

    move-result p2

    :goto_a2
    const/4 v0, 0x1

    invoke-static {v0, p2}, Ljava/lang/Math;->max(II)I

    move-result p2

    goto :goto_95

    :goto_a8
    if-eqz p3, :cond_b6

    .line 640
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightness:Linv/exe/systemui/qs/controller/InvBrightnessController;

    if-nez p2, :cond_b1

    const/16 v2, 0x200

    goto :goto_bf

    :cond_b1
    invoke-virtual {p2}, Linv/exe/systemui/qs/controller/InvBrightnessController;->getBrightness()I

    move-result v2

    goto :goto_bf

    :cond_b6
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volume:Linv/exe/systemui/qs/controller/InvVolumeController;

    if-nez p2, :cond_bb

    goto :goto_bf

    :cond_bb
    invoke-virtual {p2}, Linv/exe/systemui/qs/controller/InvVolumeController;->getVolume()I

    move-result v2

    .line 641
    :goto_bf
    iget-boolean p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    const-string v0, "inv_text_on_accent"

    const-string v1, "inv_icon_primary"

    if-nez p2, :cond_f6

    move v6, v5

    move-object v5, v4

    move-object v4, v3

    .line 642
    new-instance v3, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;

    move-object v8, v7

    .line 643
    new-instance v7, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda18;

    invoke-direct {v7, p0, p3}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda18;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Z)V

    .line 644
    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result p2

    invoke-direct {p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->color(I)I

    move-result v9

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result p2

    invoke-direct {p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->color(I)I

    move-result v10

    .line 642
    invoke-direct/range {v3 .. v10}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;-><init>(Landroid/view/View;Landroid/view/View;ILinv/exe/systemui/qs/ui/InvVerticalLevelSlider$Listener;Landroid/widget/ImageView;II)V

    .line 645
    invoke-virtual {v3, v2}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->setProgress(I)V

    if-eqz p3, :cond_f0

    .line 646
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightnessV:Ljava/util/List;

    invoke-interface {p0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-object p1

    :cond_f0
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volumeV:Ljava/util/List;

    invoke-interface {p0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-object p1

    :cond_f6
    move v6, v5

    move-object v8, v7

    move-object v5, v4

    move-object v4, v3

    .line 649
    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result p2

    invoke-direct {p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->color(I)I

    move-result p2

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result p3

    invoke-direct {p0, p3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->color(I)I

    move-result v9

    move-object v4, v5

    move v5, v6

    move v8, p2

    move v6, v2

    .line 648
    invoke-static/range {v3 .. v9}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->applyStaticProgress(Landroid/view/View;Landroid/view/View;IILandroid/widget/ImageView;II)V

    iget-object v10, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    if-eqz v10, :cond_129

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-static {v0, v10, p1, v11}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    const-string v1, "slider_body"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_129

    invoke-static {v0, v10, v1, v11}, Linv/exe/systemui/qs/drag/InvDragSupport;->control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    :cond_129
    return-object p1
.end method


# virtual methods
.method public bind()V
    .registers 4

    .line 63
    new-instance v0, Linv/exe/systemui/qs/model/InvPanelRepository;

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Linv/exe/systemui/qs/model/InvPanelRepository;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    const/4 v0, 0x0

    .line 64
    :try_start_e
    new-instance v1, Linv/exe/systemui/qs/controller/InvBrightnessController;

    iget-object v2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Linv/exe/systemui/qs/controller/InvBrightnessController;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightness:Linv/exe/systemui/qs/controller/InvBrightnessController;
    :try_end_1b
    .catchall {:try_start_e .. :try_end_1b} :catchall_1c

    goto :goto_1e

    :catchall_1c
    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightness:Linv/exe/systemui/qs/controller/InvBrightnessController;

    .line 66
    :goto_1e
    :try_start_1e
    new-instance v1, Linv/exe/systemui/qs/controller/InvVolumeController;

    iget-object v2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Linv/exe/systemui/qs/controller/InvVolumeController;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volume:Linv/exe/systemui/qs/controller/InvVolumeController;
    :try_end_2b
    .catchall {:try_start_1e .. :try_end_2b} :catchall_2c

    goto :goto_2e

    :catchall_2c
    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volume:Linv/exe/systemui/qs/controller/InvVolumeController;

    .line 67
    :goto_2e
    :try_start_2e
    new-instance v1, Linv/exe/systemui/qs/controller/InvConnectivityController;

    iget-object v2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Linv/exe/systemui/qs/controller/InvConnectivityController;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->connectivity:Linv/exe/systemui/qs/controller/InvConnectivityController;
    :try_end_3b
    .catchall {:try_start_2e .. :try_end_3b} :catchall_3c

    goto :goto_3e

    :catchall_3c
    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->connectivity:Linv/exe/systemui/qs/controller/InvConnectivityController;

    .line 68
    .line 69
    :goto_3e
    :try_start_3e
    new-instance v1, Linv/exe/systemui/qs/controller/InvMediaSessionController;

    iget-object v2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Linv/exe/systemui/qs/controller/InvMediaSessionController;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->media:Linv/exe/systemui/qs/controller/InvMediaSessionController;
    :try_end_4b
    .catchall {:try_start_3e .. :try_end_4b} :catchall_4c

    goto :goto_4e

    :catchall_4c
    iput-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->media:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    .line 70
    .line 71
    :goto_4e
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->media:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    if-eqz v0, :cond_5a

    new-instance v1, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda19;

    invoke-direct {v1, p0}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda19;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    invoke-virtual {v0, v1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->start(Linv/exe/systemui/qs/controller/InvMediaSessionController$Callback;)V

    .line 72
    :cond_5a
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->rebuildUi()V

    return-void
.end method

.method public clearCustomImageFromEdit(Landroid/view/View;)V
    .registers 7

    if-eqz p1, :cond_3d

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_3d

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const-string v2, "invos_qs_custom_image"

    invoke-static {v1, v2}, Landroid/provider/Settings$System;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_24

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v4

    if-lez v4, :cond_24

    :try_start_1a
    new-instance v4, Ljava/io/File;

    invoke-direct {v4, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/io/File;->delete()Z
    :try_end_22
    .catch Ljava/lang/Throwable; {:try_start_1a .. :try_end_22} :catch_23

    goto :goto_24

    :catch_23
    move-exception v4

    :cond_24
    :goto_24
    const-string v3, ""

    invoke-static {v1, v2, v3}, Landroid/provider/Settings$System;->putString(Landroid/content/ContentResolver;Ljava/lang/String;Ljava/lang/String;)Z

    invoke-virtual {p0, p1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderCustomImageView(Landroid/view/View;)V

    const-string v1, "custom_image_clear_badge"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_3d

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_3d
    return-void
.end method

.method public isEditMode()Z
    .registers 1

    .line 60
    iget-boolean p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    return p0
.end method

.method public synthetic lambda$1$inv-exe-systemui-qs-QsPanelController()V
    .registers 3

    .line 71
    iget-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaRenderPosted:Z

    if-nez v0, :cond_e

    const/4 v0, 0x1

    iput-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaRenderPosted:Z

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaRenderRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->postOnAnimation(Ljava/lang/Runnable;)V

    :cond_e
    return-void
.end method

.method public synthetic lambda$10$inv-exe-systemui-qs-QsPanelController(Landroid/view/View;)V
    .registers 2

    .line 332
    iget-boolean p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-nez p1, :cond_22

    iget-object p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->media:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    if-nez p1, :cond_9

    goto :goto_22

    .line 333
    :cond_9
    invoke-virtual {p1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->hasSession()Z

    move-result p1

    if-eqz p1, :cond_15

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->media:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->openApp()V

    return-void

    .line 334
    :cond_15
    iget-object p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->media:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-virtual {p1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->hasAccess()Z

    move-result p1

    if-nez p1, :cond_22

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->media:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->requestAccess()V

    :cond_22
    :goto_22
    return-void
.end method

.method public synthetic lambda$11$inv-exe-systemui-qs-QsPanelController(Linv/exe/systemui/qs/model/InvControlId;Landroid/view/View;)V
    .registers 3

    .line 638
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {p2, p1}, Linv/exe/systemui/qs/model/InvPanelRepository;->removeControl(Linv/exe/systemui/qs/model/InvControlId;)V

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->rebuildUi()V

    return-void
.end method

.method public synthetic lambda$12$inv-exe-systemui-qs-QsPanelController(ZI)V
    .registers 3

    .line 0
    if-eqz p1, :cond_6

    .line 643
    invoke-direct {p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->applyBrightness(I)V

    return-void

    :cond_6
    invoke-direct {p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->applyVolume(I)V

    return-void
.end method

.method public synthetic lambda$13$inv-exe-systemui-qs-QsPanelController(Linv/exe/systemui/qs/model/InvControlId;Landroid/view/View;)V
    .registers 3

    .line 669
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {p2, p1}, Linv/exe/systemui/qs/model/InvPanelRepository;->removeControl(Linv/exe/systemui/qs/model/InvControlId;)V

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->rebuildUi()V

    return-void
.end method

.method public synthetic lambda$14$inv-exe-systemui-qs-QsPanelController(ZI)V
    .registers 3

    .line 0
    if-eqz p1, :cond_6

    .line 674
    invoke-direct {p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->applyBrightness(I)V

    return-void

    :cond_6
    invoke-direct {p0, p2}, Linv/exe/systemui/qs/controller/InvQsPanelController;->applyVolume(I)V

    return-void
.end method

.method public synthetic lambda$15$inv-exe-systemui-qs-QsPanelController(Linv/exe/systemui/qs/model/InvControlId;Landroid/view/View;)V
    .registers 3

    .line 693
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {p2, p1}, Linv/exe/systemui/qs/model/InvPanelRepository;->removeControl(Linv/exe/systemui/qs/model/InvControlId;)V

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->rebuildUi()V

    return-void
.end method

.method public synthetic lambda$16$inv-exe-systemui-qs-QsPanelController(Linv/exe/systemui/qs/model/InvControlId;Landroid/view/View;Landroid/view/View;)V
    .registers 6

    .line 695
    iget-boolean p3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-eqz p3, :cond_5

    return-void

    .line 696
    :cond_5
    sget-object p3, Linv/exe/systemui/qs/model/InvControlId;->AUTO_BRIGHTNESS:Linv/exe/systemui/qs/model/InvControlId;

    const/4 v0, 0x0

    if-ne p1, p3, :cond_1c

    .line 697
    iget-object p3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightness:Linv/exe/systemui/qs/controller/InvBrightnessController;

    if-eqz p3, :cond_14

    invoke-virtual {p3}, Linv/exe/systemui/qs/controller/InvBrightnessController;->toggleAutoBrightness()Z

    move-result p3

    if-nez p3, :cond_42

    .line 698
    :cond_14
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const-string p1, "Panel settings tidak tersedia"

    invoke-virtual {p0, p1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->showPanelToastText(Ljava/lang/CharSequence;)V

    return-void

    .line 702
    :cond_1c
    iget-object p3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volume:Linv/exe/systemui/qs/controller/InvVolumeController;

    const/4 v1, 0x1

    if-eqz p3, :cond_29

    invoke-virtual {p3}, Linv/exe/systemui/qs/controller/InvVolumeController;->getVolume()I

    move-result p3

    if-lez p3, :cond_29

    move p3, v1

    goto :goto_2a

    :cond_29
    move p3, v0

    :goto_2a
    iput-boolean p3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mute:Z

    if-eqz p3, :cond_2f

    goto :goto_3f

    .line 703
    :cond_2f
    iget-object p3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volume:Linv/exe/systemui/qs/controller/InvVolumeController;

    if-nez p3, :cond_35

    move p3, v1

    goto :goto_3b

    :cond_35
    invoke-virtual {p3}, Linv/exe/systemui/qs/controller/InvVolumeController;->getMax()I

    move-result p3

    div-int/lit8 p3, p3, 0x2

    :goto_3b
    invoke-static {v1, p3}, Ljava/lang/Math;->max(II)I

    move-result v0

    :goto_3f
    invoke-direct {p0, v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->applyVolume(I)V

    .line 705
    :cond_42
    invoke-direct {p0, p2, p1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderCircleState(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    return-void
.end method

.method public synthetic lambda$17$inv-exe-systemui-qs-QsPanelController(Landroid/widget/LinearLayout;)V
    .registers 15

    .line 741
    invoke-virtual {p1}, Landroid/widget/LinearLayout;->getWidth()I

    move-result v0

    if-gtz v0, :cond_f

    .line 743
    new-instance v0, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda10;

    invoke-direct {v0, p0}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda10;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->post(Ljava/lang/Runnable;)Z

    return-void

    .line 746
    :cond_f
    invoke-static {p1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->safeClearLinearLayout(Landroid/widget/LinearLayout;)V

    .line 747
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->tileViews:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->clear()V

    .line 748
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->getTileColumns()I

    move-result v1

    const/4 v2, 0x4

    invoke-static {v2, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    const/4 v2, 0x2

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 749
    const-string v4, "inv_qs_control_grid_item_spacing"

    invoke-direct {p0, v4}, Linv/exe/systemui/qs/controller/InvQsPanelController;->stableDimenPx(Ljava/lang/String;)I

    move-result v4

    const/4 v2, 0x1

    add-int/lit8 v12, v1, -0x1

    mul-int/2addr v12, v4

    sub-int v2, v0, v12

    const/4 v12, 0x1

    invoke-static {v12, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    div-int/2addr v2, v1

    invoke-static {v12, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    const/4 v3, 0x0

    move v0, v4

    .line 752
    iget-object v5, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    iget-object v6, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v6}, Linv/exe/systemui/qs/model/InvPanelRepository;->maxVisibleTiles()I

    move-result v6

    if-lez v6, :cond_64

    invoke-static {v5, v6}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->pruneToCapacity(Landroid/view/View;I)Z

    invoke-static {v5, v6}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->visibleSpecs(Landroid/view/View;I)Ljava/util/ArrayList;

    move-result-object v5

    .line 753
    iget-boolean v6, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-eqz v6, :cond_5c

    iget-object v6, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v6}, Linv/exe/systemui/qs/model/InvPanelRepository;->getTileRows()I

    move-result v6

    mul-int/2addr v6, v1

    goto :goto_60

    :cond_5c
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v6

    :goto_60
    const/4 v7, 0x0

    move v8, v3

    :goto_62
    if-lt v8, v6, :cond_65

    .line 768
    :cond_64
    return-void

    .line 756
    :cond_65
    rem-int v9, v8, v1

    const/4 v10, -0x2

    if-nez v9, :cond_89

    .line 757
    new-instance v7, Landroid/widget/LinearLayout;

    iget-object v11, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {v11}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v11

    invoke-direct {v7, v11}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 758
    invoke-virtual {v7, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 759
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v12, -0x1

    invoke-direct {v11, v12, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 760
    invoke-virtual {p1}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v12

    if-lez v12, :cond_86

    iput v4, v11, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 761
    :cond_86
    invoke-virtual {p1, v7, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 763
    :cond_89
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v11

    if-ge v8, v11, :cond_a4

    iget-object v11, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {v11}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v11

    invoke-static {v11}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v11

    invoke-interface {v5, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    invoke-direct {p0, v11, v12}, Linv/exe/systemui/qs/controller/InvQsPanelController;->nativeTile(Landroid/view/LayoutInflater;Ljava/lang/String;)Landroid/view/View;

    move-result-object v11

    goto :goto_b2

    :cond_a4
    const-string v11, "inv_qs_control_grid_cell_size"

    invoke-direct {p0, v11}, Linv/exe/systemui/qs/controller/InvQsPanelController;->stableDimenPx(Ljava/lang/String;)I

    move-result v11

    invoke-static {v11, v2}, Ljava/lang/Math;->min(II)I

    move-result v11

    invoke-direct {p0, v11}, Linv/exe/systemui/qs/controller/InvQsPanelController;->emptyTile(I)Landroid/view/View;

    move-result-object v11

    .line 764
    :goto_b2
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v12

    if-ge v8, v12, :cond_c5

    const-string v12, "inv_qs_control_grid_cell_size"

    invoke-direct {p0, v12}, Linv/exe/systemui/qs/controller/InvQsPanelController;->stableDimenPx(Ljava/lang/String;)I

    move-result v12

    invoke-static {v12, v2}, Ljava/lang/Math;->min(II)I

    move-result v12

    invoke-direct {p0, v11, v12}, Linv/exe/systemui/qs/controller/InvQsPanelController;->applyNativeTileStableSize(Landroid/view/View;I)V

    :cond_c5
    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v12, v2, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    if-lez v9, :cond_ce

    .line 765
    iput v0, v12, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 766
    :cond_ce
    invoke-virtual {v7, v11, v12}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v8, v8, 0x1

    goto :goto_62
.end method

.method public synthetic lambda$2$inv-exe-systemui-qs-QsPanelController(Landroid/widget/LinearLayout;)V
    .registers 27

    .line 0
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 153
    invoke-virtual {v1}, Landroid/widget/LinearLayout;->getWidth()I

    move-result v2

    if-gtz v2, :cond_13

    .line 155
    new-instance v2, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda3;

    invoke-direct {v2, v0}, Linv/exe/systemui/qs/controller/InvQsPanelController$$ExternalSyntheticLambda3;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->post(Ljava/lang/Runnable;)Z

    return-void

    .line 158
    :cond_13
    invoke-static {v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->safeClearLinearLayout(Landroid/widget/LinearLayout;)V

    .line 159
    iget-object v3, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaViews:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->clear()V

    .line 160
    iget-object v3, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->mediaSpans:Ljava/util/Map;

    invoke-interface {v3}, Ljava/util/Map;->clear()V

    .line 161
    iget-object v3, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightnessV:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->clear()V

    .line 162
    iget-object v3, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->brightnessH:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->clear()V

    .line 163
    iget-object v3, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volumeV:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->clear()V

    .line 164
    iget-object v3, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->volumeH:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->clear()V

    .line 165
    iget-object v3, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v3}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlColumns()I

    move-result v3

    const/4 v4, 0x4

    invoke-static {v4, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    const/4 v4, 0x2

    invoke-static {v4, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    .line 166
    iget-object v5, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v5}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlRows()I

    move-result v5

    const/4 v6, 0x3

    invoke-static {v6, v5}, Ljava/lang/Math;->min(II)I

    move-result v5

    const/4 v6, 0x1

    invoke-static {v6, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    .line 167
    const-string v9, "inv_qs_control_grid_cell_size"

    invoke-direct {v0, v9}, Linv/exe/systemui/qs/controller/InvQsPanelController;->stableDimenPx(Ljava/lang/String;)I

    move-result v9

    move/from16 v24, v9

    const-string v9, "inv_qs_control_grid_item_spacing"

    invoke-direct {v0, v9}, Linv/exe/systemui/qs/controller/InvQsPanelController;->stableDimenPx(Ljava/lang/String;)I

    move-result v8

    const/4 v9, 0x0

    if-le v3, v6, :cond_75

    add-int/lit8 v10, v3, -0x1

    mul-int/2addr v10, v8

    sub-int/2addr v2, v10

    invoke-static {v6, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    div-int v7, v2, v3

    invoke-static {v6, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    move v2, v8

    goto :goto_7a

    :cond_75
    invoke-static {v6, v2}, Ljava/lang/Math;->max(II)I

    move-result v7

    move v2, v9

    .line 170
    :goto_7a
    new-array v4, v4, [I

    aput v3, v4, v6

    aput v5, v4, v9

    sget-object v10, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    invoke-static {v10, v4}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [[Z

    .line 171
    new-instance v10, Ljava/util/ArrayList;

    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    .line 172
    iget-object v11, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v11}, Linv/exe/systemui/qs/model/InvPanelRepository;->visibleControls()Ljava/util/List;

    move-result-object v11

    invoke-interface {v11}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_97
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-nez v12, :cond_18a

    .line 186
    iget-boolean v4, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-eqz v4, :cond_a2

    goto :goto_a3

    :cond_a2
    move v5, v6

    .line 187
    :goto_a3
    invoke-interface {v10}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_a7
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-nez v4, :cond_171

    .line 188
    new-instance v4, Landroid/widget/FrameLayout;

    iget-object v11, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {v11}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v11

    invoke-direct {v4, v11}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 189
    new-instance v11, Landroid/widget/GridLayout;

    iget-object v12, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {v12}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v12

    invoke-direct {v11, v12}, Landroid/widget/GridLayout;-><init>(Landroid/content/Context;)V

    .line 190
    invoke-virtual {v11, v3}, Landroid/widget/GridLayout;->setColumnCount(I)V

    .line 191
    invoke-virtual {v11, v5}, Landroid/widget/GridLayout;->setRowCount(I)V

    .line 192
    invoke-virtual {v11, v9}, Landroid/widget/GridLayout;->setAlignmentMode(I)V

    .line 193
    invoke-virtual {v11, v9}, Landroid/widget/GridLayout;->setUseDefaultMargins(Z)V

    .line 194
    new-instance v12, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v13, -0x1

    const/4 v14, -0x2

    invoke-direct {v12, v13, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, v11, v12}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 195
    iget-object v12, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {v12}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v12

    invoke-static {v12}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v15

    .line 196
    invoke-interface {v10}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :goto_e7
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-nez v10, :cond_fa

    .line 212
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v4, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 213
    invoke-direct {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->relayoutControlsLive()Z

    move-result v2

    return-void

    .line 196
    :cond_fa
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;

    .line 197
    iget-object v12, v10, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->id:Linv/exe/systemui/qs/model/InvControlId;

    iget v9, v10, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->w:I

    iget v13, v10, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->h:I

    invoke-direct {v0, v15, v12, v9, v13}, Linv/exe/systemui/qs/controller/InvQsPanelController;->createControl(Landroid/view/LayoutInflater;Linv/exe/systemui/qs/model/InvControlId;II)Landroid/view/View;

    move-result-object v9

    .line 198
    iget-object v12, v10, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->id:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v9, v12}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 199
    iget v12, v10, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->w:I

    mul-int/2addr v12, v7

    iget v13, v10, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->w:I

    sub-int/2addr v13, v6

    mul-int/2addr v13, v2

    add-int/2addr v12, v13

    .line 200
    iget v13, v10, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->h:I

    mul-int v13, v13, v24

    iget v14, v10, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->h:I

    sub-int/2addr v14, v6

    mul-int/2addr v14, v8

    add-int/2addr v13, v14

    .line 201
    new-instance v14, Landroid/widget/GridLayout$LayoutParams;

    .line 202
    iget v6, v10, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->r:I

    iget v1, v10, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->h:I

    move/from16 v17, v2

    sget-object v2, Landroid/widget/GridLayout;->FILL:Landroid/widget/GridLayout$Alignment;

    invoke-static {v6, v1, v2}, Landroid/widget/GridLayout;->spec(IILandroid/widget/GridLayout$Alignment;)Landroid/widget/GridLayout$Spec;

    move-result-object v1

    .line 203
    iget v2, v10, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->c:I

    iget v6, v10, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->w:I

    move-object/from16 v18, v4

    sget-object v4, Landroid/widget/GridLayout;->FILL:Landroid/widget/GridLayout$Alignment;

    invoke-static {v2, v6, v4}, Landroid/widget/GridLayout;->spec(IILandroid/widget/GridLayout$Alignment;)Landroid/widget/GridLayout$Spec;

    move-result-object v2

    .line 201
    invoke-direct {v14, v1, v2}, Landroid/widget/GridLayout$LayoutParams;-><init>(Landroid/widget/GridLayout$Spec;Landroid/widget/GridLayout$Spec;)V

    .line 204
    iput v12, v14, Landroid/widget/GridLayout$LayoutParams;->width:I

    .line 205
    iput v13, v14, Landroid/widget/GridLayout$LayoutParams;->height:I

    .line 206
    iget v1, v10, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->c:I

    iget v2, v10, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->w:I

    add-int/2addr v1, v2

    if-ge v1, v3, :cond_14b

    move/from16 v1, v17

    goto :goto_14c

    :cond_14b
    const/4 v1, 0x0

    :goto_14c
    iput v1, v14, Landroid/widget/GridLayout$LayoutParams;->rightMargin:I

    .line 207
    iget v1, v10, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->r:I

    iget v2, v10, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->h:I

    add-int/2addr v1, v2

    if-ge v1, v5, :cond_157

    move v1, v8

    goto :goto_158

    :cond_157
    const/4 v1, 0x0

    :goto_158
    iput v1, v14, Landroid/widget/GridLayout$LayoutParams;->bottomMargin:I

    const/16 v1, 0x77

    .line 208
    invoke-virtual {v14, v1}, Landroid/widget/GridLayout$LayoutParams;->setGravity(I)V

    .line 209
    invoke-virtual {v9, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 210
    invoke-virtual {v11, v9}, Landroid/widget/GridLayout;->addView(Landroid/view/View;)V

    move-object/from16 v1, p1

    move/from16 v2, v17

    move-object/from16 v4, v18

    const/4 v6, 0x1

    const/4 v9, 0x0

    const/4 v13, -0x1

    const/4 v14, -0x2

    goto/16 :goto_e7

    :cond_171
    move/from16 v17, v2

    .line 187
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;

    iget v2, v1, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->r:I

    iget v1, v1, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;->h:I

    add-int/2addr v2, v1

    invoke-static {v5, v2}, Ljava/lang/Math;->max(II)I

    move-result v5

    move-object/from16 v1, p1

    move/from16 v2, v17

    const/4 v6, 0x1

    const/4 v9, 0x0

    goto/16 :goto_a7

    :cond_18a
    move/from16 v17, v2

    .line 172
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Linv/exe/systemui/qs/model/InvControlId;

    .line 173
    iget-object v2, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v2, v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlSpanW(Linv/exe/systemui/qs/model/InvControlId;)I

    move-result v2

    invoke-static {v3, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/4 v6, 0x1

    invoke-static {v6, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    .line 174
    iget-object v9, v0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v9, v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlSpanH(Linv/exe/systemui/qs/model/InvControlId;)I

    move-result v9

    invoke-static {v6, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    const/4 v12, 0x0

    :goto_1ac
    sub-int v13, v5, v9

    if-le v12, v13, :cond_1b7

    :goto_1b0
    move-object/from16 v1, p1

    move/from16 v2, v17

    const/4 v9, 0x0

    goto/16 :goto_97

    :cond_1b7
    const/4 v13, 0x0

    :goto_1b8
    sub-int v14, v3, v2

    if-le v13, v14, :cond_1bf

    add-int/lit8 v12, v12, 0x1

    goto :goto_1ac

    .line 178
    :cond_1bf
    invoke-static {v4, v12, v13, v2, v9}, Linv/exe/systemui/qs/controller/InvQsPanelController;->free([[ZIIII)Z

    move-result v14

    if-eqz v14, :cond_1dd

    .line 179
    invoke-static {v4, v12, v13, v2, v9}, Linv/exe/systemui/qs/controller/InvQsPanelController;->mark([[ZIIII)V

    .line 180
    new-instance v18, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;

    move-object/from16 v19, v1

    move/from16 v22, v2

    move/from16 v23, v9

    move/from16 v20, v12

    move/from16 v21, v13

    invoke-direct/range {v18 .. v23}, Linv/exe/systemui/qs/controller/InvQsPanelController$Place;-><init>(Linv/exe/systemui/qs/model/InvControlId;IIII)V

    move-object/from16 v1, v18

    invoke-interface {v10, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_1b0

    :cond_1dd
    move-object/from16 v19, v1

    move/from16 v22, v2

    move/from16 v23, v9

    move/from16 v20, v12

    move/from16 v21, v13

    add-int/lit8 v13, v21, 0x1

    goto :goto_1b8
.end method

.method public synthetic lambda$3$inv-exe-systemui-qs-QsPanelController(Linv/exe/systemui/qs/model/InvControlId;Landroid/view/View;)V
    .registers 3

    .line 260
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {p2, p1}, Linv/exe/systemui/qs/model/InvPanelRepository;->removeControl(Linv/exe/systemui/qs/model/InvControlId;)V

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->rebuildUi()V

    return-void
.end method

.method public synthetic lambda$4$inv-exe-systemui-qs-QsPanelController(Linv/exe/systemui/qs/model/InvControlId;Landroid/view/View;Landroid/view/View;)V
    .registers 6

    iget-boolean p3, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-eqz p3, :cond_5

    return-void

    :cond_5
    sget-object p3, Linv/exe/systemui/qs/model/InvControlId;->INTERNET:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p1, p3, :cond_15

    const-string v0, "internet"

    invoke-static {p2, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->click(Landroid/view/View;Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_14

    invoke-static {p2, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->openDetails(Landroid/view/View;Ljava/lang/String;)Z

    :cond_14
    goto :goto_40

    :cond_15
    sget-object p3, Linv/exe/systemui/qs/model/InvControlId;->BLUETOOTH:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p1, p3, :cond_25

    const-string v0, "bt"

    invoke-static {p2, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->click(Landroid/view/View;Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_24

    invoke-static {p2, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->openDetails(Landroid/view/View;Ljava/lang/String;)Z

    :cond_24
    goto :goto_40

    :cond_25
    sget-object p3, Linv/exe/systemui/qs/model/InvControlId;->DATA_USAGE:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p1, p3, :cond_33

    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "android.settings.DATA_USAGE_SETTINGS"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/helper/InvControlIntentHelper;->openSetting(Landroid/content/Context;Ljava/lang/String;)V

    goto :goto_40

    :cond_33
    sget-object p3, Linv/exe/systemui/qs/model/InvControlId;->BATTERY_VIEW:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p1, p3, :cond_47

    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "android.settings.BATTERY_SETTINGS"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/helper/InvControlIntentHelper;->openSetting(Landroid/content/Context;Ljava/lang/String;)V

    :goto_40
    invoke-direct {p0, p2, p1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderPillState(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->rebuildTilesOnly()V

    return-void

    :cond_47
    sget-object p3, Linv/exe/systemui/qs/model/InvControlId;->RINGER:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p1, p3, :cond_55

    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Linv/exe/systemui/qs/helper/InvRingerModeHelper;->cycle(Landroid/content/Context;)V

    invoke-direct {p0, p2, p1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderPillState(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V

    :cond_55
    return-void
.end method

.method public synthetic lambda$5$inv-exe-systemui-qs-QsPanelController(Linv/exe/systemui/qs/model/InvControlId;Landroid/view/View;)V
    .registers 3

    .line 318
    iget-object p2, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {p2, p1}, Linv/exe/systemui/qs/model/InvPanelRepository;->removeControl(Linv/exe/systemui/qs/model/InvControlId;)V

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->rebuildUi()V

    return-void
.end method

.method public synthetic lambda$6$inv-exe-systemui-qs-QsPanelController(Landroid/view/View;)V
    .registers 2

    .line 325
    iget-boolean p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-nez p1, :cond_b

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->media:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    if-eqz p0, :cond_b

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->previous()V

    :cond_b
    return-void
.end method

.method public synthetic lambda$7$inv-exe-systemui-qs-QsPanelController(Landroid/view/View;)V
    .registers 2

    .line 326
    iget-boolean p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-nez p1, :cond_b

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->media:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    if-eqz p0, :cond_b

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->togglePlayPause()V

    :cond_b
    return-void
.end method

.method public synthetic lambda$8$inv-exe-systemui-qs-QsPanelController(Landroid/view/View;)V
    .registers 2

    .line 327
    iget-boolean p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-nez p1, :cond_b

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->media:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    if-eqz p0, :cond_b

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->next()V

    :cond_b
    return-void
.end method

.method public synthetic lambda$9$inv-exe-systemui-qs-QsPanelController(Landroid/view/View;)V
    .registers 2

    .line 329
    iget-boolean p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-nez p1, :cond_b

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->media:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    if-eqz p0, :cond_b

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->toggleShuffle()V

    :cond_b
    return-void
.end method

.method public onConnectivitySignalChanged()V
    .registers 3

    iget-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoRefreshActive:Z

    if-eqz v0, :cond_17

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    if-eqz v0, :cond_17

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isAttachedToWindow()Z

    move-result v1

    if-eqz v1, :cond_17

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isShown()Z

    move-result v0

    if-eqz v0, :cond_17

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->refreshConnectivityControls()V

    :cond_17
    return-void
.end method

.method public onCustomControlSettingsChanged()V
    .registers 3

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    if-eqz v0, :cond_19

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isAttachedToWindow()Z

    move-result v1

    if-eqz v1, :cond_19

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isShown()Z

    move-result v0

    if-eqz v0, :cond_19

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->refreshCustomControls()V

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->refreshSliderValues()V

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->refreshControlStates()V

    :cond_19
    return-void
.end method

.method public onDestroy()V
    .registers 3

    .line 82
    .line 83
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->stopInfoAutoRefresh()V

    .line 87
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->media:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    if-eqz p0, :cond_a

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->stop()V

    :cond_a
    return-void
.end method

.method public onHostHidden()V
    .registers 1

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->stopInfoAutoRefresh()V

    return-void
.end method

.method public onInfoSignalChanged()V
    .registers 4

    iget-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoRefreshActive:Z

    if-nez v0, :cond_5

    return-void

    :cond_5
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    if-eqz v0, :cond_1d

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isAttachedToWindow()Z

    move-result v1

    if-eqz v1, :cond_1d

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isShown()Z

    move-result v0

    if-eqz v0, :cond_1d

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->scheduleInfoFrameRefresh()V

    const-wide/16 v0, 0x3e8

    invoke-direct {p0, v0, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->postInfoFallbackTick(J)V

    :cond_1d
    return-void
.end method

.method public onResume()V
    .registers 2

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    if-eqz v0, :cond_25

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_25

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isShown()Z

    move-result v0

    if-eqz v0, :cond_25

    .line 76
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->media:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    if-eqz v0, :cond_1c

    invoke-virtual {v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->refresh()V

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderMediaViews()V

    :cond_1c
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->refreshControlStates()V

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->startInfoAutoRefresh()V

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->refreshNativeTileStates()V

    :cond_25
    return-void
.end method

.method public openPanelSettings()V
    .registers 3

    .line 122
    :try_start_0
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    new-instance v1, Linv/exe/systemui/qs/controller/InvQsPanelController$1;

    invoke-direct {v1, p0}, Linv/exe/systemui/qs/controller/InvQsPanelController$1;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->show(Landroid/view/View;Ljava/lang/Runnable;)Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;
    :try_end_a
    .catchall {:try_start_0 .. :try_end_a} :catchall_b

    return-void

    .line 129
    :catchall_b
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const-string v0, "Panel settings tidak tersedia"

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->showPanelToastText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public rebuildUi()V
    .registers 2

    .line 117
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->rebuildControls()V

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->rebuildTilesOnly()V

    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    if-eqz v0, :cond_d

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->scheduleResponsiveLayoutRefresh()V

    :cond_d
    return-void
.end method

.method public renderCustomImageView(Landroid/view/View;)V
    .registers 12

    if-eqz p1, :cond_db

    const-string v0, "custom_image_view"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    instance-of v1, v0, Landroid/widget/ImageView;

    if-eqz v1, :cond_db

    check-cast v0, Landroid/widget/ImageView;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    if-eqz v1, :cond_c3

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    const-string v3, "invos_qs_custom_image_alpha"

    const/16 v4, 0xff

    invoke-static {v2, v3, v4}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v3

    if-ltz v3, :cond_27

    goto :goto_28

    :cond_27
    const/4 v3, 0x0

    :goto_28
    const/16 v4, 0xff

    if-le v3, v4, :cond_2e

    const/16 v3, 0xff

    :cond_2e
    int-to-float v3, v3

    const/high16 v4, 0x437f0000  # 255.0f

    div-float/2addr v3, v4

    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setAlpha(F)V

    const-string v3, "invos_qs_custom_image"

    invoke-static {v2, v3}, Landroid/provider/Settings$System;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_c3

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v4

    if-lez v4, :cond_c3

    new-instance v4, Ljava/io/File;

    invoke-direct {v4, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v4

    if-eqz v4, :cond_c3

    invoke-virtual {v0}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v5

    instance-of v6, v5, Ljava/lang/String;

    if-eqz v6, :cond_82

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_82

    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v7

    const-string v8, ".gif"

    invoke-virtual {v7, v8}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_db

    instance-of v7, v0, Linv/exe/systemui/qs/ui/InvGifImageView;

    if-eqz v7, :cond_db

    move-object v7, v0

    check-cast v7, Linv/exe/systemui/qs/ui/InvGifImageView;

    const-string v8, "invos_qs_custom_gif_animate"

    const/4 v9, 0x0

    invoke-static {v2, v8, v9}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v8

    if-nez v8, :cond_7c

    const/4 v9, 0x1

    goto :goto_7e

    :cond_7c
    iget-boolean v9, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    :goto_7e
    invoke-virtual {v7, v9}, Linv/exe/systemui/qs/ui/InvGifImageView;->setGifPaused(Z)V

    goto :goto_db

    :cond_82
    invoke-virtual {v3}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v5

    const-string v6, ".gif"

    invoke-virtual {v5, v6}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_ac

    instance-of v6, v0, Linv/exe/systemui/qs/ui/InvGifImageView;

    if-eqz v6, :cond_ac

    move-object v6, v0

    check-cast v6, Linv/exe/systemui/qs/ui/InvGifImageView;

    const-string v7, "invos_qs_custom_gif_animate"

    const/4 v8, 0x0

    invoke-static {v2, v7, v8}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v7

    if-nez v7, :cond_a0

    const/4 v8, 0x1

    goto :goto_a2

    :cond_a0
    iget-boolean v8, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    :goto_a2
    invoke-virtual {v6, v8}, Linv/exe/systemui/qs/ui/InvGifImageView;->setGifPaused(Z)V

    invoke-virtual {v6, v3}, Linv/exe/systemui/qs/ui/InvGifImageView;->setGifPath(Ljava/lang/String;)V

    invoke-virtual {v0, v3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    goto :goto_db

    :cond_ac
    instance-of v6, v0, Linv/exe/systemui/qs/ui/InvGifImageView;

    if-eqz v6, :cond_b6

    move-object v6, v0

    check-cast v6, Linv/exe/systemui/qs/ui/InvGifImageView;

    invoke-virtual {v6}, Linv/exe/systemui/qs/ui/InvGifImageView;->clearGif()V

    :cond_b6
    invoke-static {v3}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v7

    if-eqz v7, :cond_c3

    invoke-virtual {v0, v7}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    invoke-virtual {v0, v3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    goto :goto_db

    :cond_c3
    const/high16 v1, 0x3f800000  # 1.0f

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setAlpha(F)V

    instance-of v1, v0, Linv/exe/systemui/qs/ui/InvGifImageView;

    if-eqz v1, :cond_d3

    move-object v1, v0

    check-cast v1, Linv/exe/systemui/qs/ui/InvGifImageView;

    invoke-virtual {v1}, Linv/exe/systemui/qs/ui/InvGifImageView;->clearGif()V

    goto :goto_d7

    :cond_d3
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    :goto_d7
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    :cond_db
    :goto_db
    return-void
.end method

.method public resetLayout()V
    .registers 3

    .line 134
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v0}, Linv/exe/systemui/qs/model/InvPanelRepository;->resetDefaults()V

    .line 135
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->maxVisibleTiles()I

    move-result v1

    invoke-static {v0, v1}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->resetToDefault(Landroid/view/View;I)Z

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->rebuildUi()V

    .line 136
    .line 137
    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const-string v0, "Layout di-reset"

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->showPanelToastText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public runInfoAutoRefreshTick()V
    .registers 4

    iget-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoRefreshActive:Z

    if-nez v0, :cond_5

    return-void

    :cond_5
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    if-eqz v0, :cond_1e

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isAttachedToWindow()Z

    move-result v1

    if-eqz v1, :cond_1e

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isShown()Z

    move-result v0

    if-eqz v0, :cond_1e

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->scheduleInfoFrameRefresh()V

    const-wide/16 v0, 0x3e8

    invoke-direct {p0, v0, v1}, Linv/exe/systemui/qs/controller/InvQsPanelController;->postInfoFallbackTick(J)V

    return-void

    :cond_1e
    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->stopInfoAutoRefresh()V

    return-void
.end method

.method public runInfoFrameRefresh()V
    .registers 3

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoRefreshFramePosted:Z

    iget-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->infoRefreshActive:Z

    if-nez v0, :cond_8

    return-void

    :cond_8
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    if-eqz v0, :cond_1b

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isAttachedToWindow()Z

    move-result v1

    if-eqz v1, :cond_1b

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isShown()Z

    move-result v0

    if-eqz v0, :cond_1b

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->refreshInfoControls()V

    :cond_1b
    return-void
.end method

.method public setEditMode(Z)V
    .registers 7

    .line 91
    iget-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-ne v0, p1, :cond_5

    return-void

    :cond_5
    iput-boolean p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    .line 92
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const-string v1, "header_normal"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/16 v1, 0x8

    const/4 v2, 0x0

    if-eqz p1, :cond_1a

    move v3, v1

    goto :goto_1b

    :cond_1a
    move v3, v2

    :goto_1b
    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    .line 93
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const-string v3, "header_edit"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v3}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz p1, :cond_2e

    move v3, v2

    goto :goto_2f

    :cond_2e
    move v3, v1

    :goto_2f
    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    .line 94
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const-string v3, "txt_edit_hint"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v3}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz p1, :cond_42

    move v3, v2

    goto :goto_43

    :cond_42
    move v3, v1

    :goto_43
    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    .line 95
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const-string v3, "label_controls"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v3}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz p1, :cond_56

    move v3, v2

    goto :goto_57

    :cond_56
    move v3, v1

    :goto_57
    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    .line 96
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const-string v3, "label_tiles"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v3}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz p1, :cond_69

    move v1, v2

    :cond_69
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 97
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const-string v1, "controls_box"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/FrameLayout;

    .line 98
    iget-object v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    const-string v3, "tiles_box"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v1, v3}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/FrameLayout;

    const/4 v3, 0x0

    .line 99
    invoke-direct {p0, v3}, Linv/exe/systemui/qs/controller/InvQsPanelController;->dp(I)I

    move-result v3

    if-eqz p1, :cond_aa

    .line 101
    const/4 p1, 0x0

    invoke-virtual {v0, p1}, Landroid/widget/FrameLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v1, p1}, Landroid/widget/FrameLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 103
    invoke-virtual {v0, v3, v3, v3, v3}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    .line 104
    invoke-virtual {v1, v3, v3, v3, v3}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    .line 105
    const/4 v4, 0x0

    invoke-virtual {v0, v4}, Landroid/widget/FrameLayout;->setClipChildren(Z)V

    invoke-virtual {v0, v4}, Landroid/widget/FrameLayout;->setClipToPadding(Z)V

    .line 106
    invoke-virtual {v1, v4}, Landroid/widget/FrameLayout;->setClipChildren(Z)V

    invoke-virtual {v1, v4}, Landroid/widget/FrameLayout;->setClipToPadding(Z)V

    goto :goto_c9

    :cond_aa
    const/4 p1, 0x0

    .line 108
    invoke-virtual {v0, p1}, Landroid/widget/FrameLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 109
    invoke-virtual {v1, p1}, Landroid/widget/FrameLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 110
    invoke-virtual {v0, v2, v2, v2, v2}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    .line 111
    invoke-virtual {v1, v2, v2, v2, v2}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    .line 111
    invoke-virtual {v0, v2}, Landroid/widget/FrameLayout;->setClipChildren(Z)V

    invoke-virtual {v0, v2}, Landroid/widget/FrameLayout;->setClipToPadding(Z)V

    invoke-virtual {v1, v2}, Landroid/widget/FrameLayout;->setClipChildren(Z)V

    invoke-virtual {v1, v2}, Landroid/widget/FrameLayout;->setClipToPadding(Z)V

    invoke-virtual {v0}, Landroid/widget/FrameLayout;->requestLayout()V

    invoke-virtual {v1}, Landroid/widget/FrameLayout;->requestLayout()V

    .line 113
    :goto_c9
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->rebuildUi()V

    iget-object p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    iget-boolean v1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    const-string v0, "header_edit"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->editModeTransition(Landroid/view/View;Z)V

    const-string v0, "header_normal"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->editModeTransition(Landroid/view/View;Z)V

    const-string v0, "txt_edit_hint"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->editModeTransition(Landroid/view/View;Z)V

    const-string v0, "label_controls"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->editModeTransition(Landroid/view/View;Z)V

    const-string v0, "label_tiles"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->editModeTransition(Landroid/view/View;Z)V

    const-string v0, "controls_host"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->editModeTransition(Landroid/view/View;Z)V

    const-string v0, "tiles_host"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p1, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->editModeTransition(Landroid/view/View;Z)V

    .line 114
    invoke-virtual {p1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->requestLayout()V

    invoke-virtual {p1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->invalidate()V

    return-void
.end method

.method public showNativeMediaOutputDialog(Landroid/view/View;)V
    .registers 6

    iget-boolean v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->edit:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    iget-object v0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->media:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    if-eqz v0, :cond_38

    invoke-virtual {v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->hasSession()Z

    move-result v1

    if-nez v1, :cond_19

    invoke-virtual {v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->hasAccess()Z

    move-result p0

    if-nez p0, :cond_38

    invoke-virtual {v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->requestAccess()V

    return-void

    :cond_19
    invoke-virtual {v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->getPackageName()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_38

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_38

    const-class v1, Lcom/android/systemui/media/dialog/MediaOutputDialogFactory;

    invoke-static {v1}, Lcom/android/systemui/Dependency;->get(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/systemui/media/dialog/MediaOutputDialogFactory;

    if-eqz v1, :cond_38

    if-eqz p1, :cond_32

    goto :goto_34

    :cond_32
    iget-object p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController;->panel:Linv/exe/systemui/qs/ui/InvQsPanelView;

    :goto_34
    const/4 p0, 0x1

    invoke-virtual {v1, v0, p0, p1}, Lcom/android/systemui/media/dialog/MediaOutputDialogFactory;->create(Ljava/lang/String;ZLandroid/view/View;)V

    :cond_38
    return-void
.end method

.method public updateResources()V
    .registers 2

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->refreshSliderThemes()V

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->refreshControlStates()V

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->renderMediaViews()V

    invoke-direct {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->refreshNativeTileStates()V

    return-void
.end method
