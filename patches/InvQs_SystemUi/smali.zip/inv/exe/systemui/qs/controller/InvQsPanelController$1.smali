.class public Linv/exe/systemui/qs/controller/InvQsPanelController$1;
.super Ljava/lang/Object;
.source "QsPanelController.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Linv/exe/systemui/qs/controller/InvQsPanelController;->openPanelSettings()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field public final synthetic this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V
    .registers 2

    .line 122
    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$1;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Linv/exe/systemui/qs/controller/InvQsPanelController$1$1;

    invoke-direct {v1, p0}, Linv/exe/systemui/qs/controller/InvQsPanelController$1$1;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController$1;)V

    const-wide/16 v2, 0x50

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
