.class public final Linv/exe/systemui/qs/controller/InvQsPanelController$InfoSignalReceiver;
.super Landroid/content/BroadcastReceiver;
.source "QsPanelController.java"


# instance fields
.field public final synthetic this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V
    .registers 2

    iput-object p1, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$InfoSignalReceiver;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 7

    iget-object p0, p0, Linv/exe/systemui/qs/controller/InvQsPanelController$InfoSignalReceiver;->this$0:Linv/exe/systemui/qs/controller/InvQsPanelController;

    if-eqz p2, :cond_44

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_44

    const-string v1, "android.net.wifi.WIFI_STATE_CHANGED"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_20

    const-string v1, "wifi_state"

    const/4 v2, -0x1

    invoke-virtual {p2, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v2

    const/4 v3, 0x1

    if-eq v2, v3, :cond_40

    const/4 v3, 0x3

    if-eq v2, v3, :cond_40

    return-void

    :cond_20
    const-string v1, "android.bluetooth.adapter.action.STATE_CHANGED"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_38

    const-string v1, "android.bluetooth.adapter.extra.STATE"

    const/4 v2, -0x1

    invoke-virtual {p2, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v2

    const/16 v3, 0xa

    if-eq v2, v3, :cond_40

    const/16 v3, 0xc

    if-eq v2, v3, :cond_40

    return-void

    :cond_38
    const-string v1, "android.net.conn.CONNECTIVITY_CHANGE"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_44

    :cond_40
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->onConnectivitySignalChanged()V

    return-void

    :cond_44
    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->onInfoSignalChanged()V

    return-void
.end method
