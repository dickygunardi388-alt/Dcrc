.class public Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;
.super Ljava/lang/Object;
.source "MediaViewRenderer.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->bindProgress(Landroid/widget/FrameLayout;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;Linv/exe/systemui/qs/controller/InvMediaSessionController;II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final synthetic val$duration:[J

.field private final synthetic val$fill:Landroid/view/View;

.field private final synthetic val$hasProgress:[Z

.field private final synthetic val$mediaSession:Linv/exe/systemui/qs/controller/InvMediaSessionController;

.field private final synthetic val$seek:Landroid/widget/FrameLayout;

.field private final synthetic val$showTime:Z

.field private final synthetic val$timeEnd:Landroid/widget/TextView;

.field private final synthetic val$timeStart:Landroid/widget/TextView;

.field private final synthetic val$track:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroid/widget/FrameLayout;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;ZLinv/exe/systemui/qs/controller/InvMediaSessionController;[Z[J)V
    .registers 10

    .line 376
    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;->val$seek:Landroid/widget/FrameLayout;

    iput-object p2, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;->val$track:Landroid/view/View;

    iput-object p3, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;->val$fill:Landroid/view/View;

    iput-object p4, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;->val$timeStart:Landroid/widget/TextView;

    iput-object p5, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;->val$timeEnd:Landroid/widget/TextView;

    iput-boolean p6, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;->val$showTime:Z

    iput-object p7, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;->val$mediaSession:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    iput-object p8, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;->val$hasProgress:[Z

    iput-object p9, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;->val$duration:[J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 10

    .line 378
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;->val$seek:Landroid/widget/FrameLayout;

    iget-object v1, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;->val$track:Landroid/view/View;

    iget-object v2, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;->val$fill:Landroid/view/View;

    iget-object v3, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;->val$timeStart:Landroid/widget/TextView;

    iget-object v4, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;->val$timeEnd:Landroid/widget/TextView;

    iget-boolean v5, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;->val$showTime:Z

    iget-object v6, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;->val$mediaSession:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    iget-object v7, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;->val$hasProgress:[Z

    iget-object v8, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;->val$duration:[J

    invoke-static/range {v0 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->access$0(Landroid/widget/FrameLayout;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;ZLinv/exe/systemui/qs/controller/InvMediaSessionController;[Z[J)V

    return-void
.end method
