.class public final Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;
.super Landroid/view/View;
.source "InvMediaSurfaceEffectsView.java"


# instance fields
.field private active:Z

.field private final paint:Landroid/graphics/Paint;

.field private playing:Z

.field private primaryColor:I

.field private rippleActive:Z

.field private rippleStart:J

.field private rippleX:F

.field private rippleY:F

.field private secondaryColor:I

.field private shader:Landroid/graphics/RuntimeShader;

.field private touchBoostStart:J


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 4

    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->paint:Landroid/graphics/Paint;

    const v0, -0x777778

    iput v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->primaryColor:I

    iput v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->secondaryColor:I

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->initShader()V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->setWillNotDraw(Z)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setFocusable(Z)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 5

    invoke-direct {p0, p1, p2}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->paint:Landroid/graphics/Paint;

    const v0, -0x777778

    iput v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->primaryColor:I

    iput v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->secondaryColor:I

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->initShader()V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->setWillNotDraw(Z)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setFocusable(Z)V

    return-void
.end method

.method private initShader()V
    .registers 4

    const/4 v0, 0x0

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->shader:Landroid/graphics/RuntimeShader;

    :try_start_3
    const-string v0, "uniform float u_width; uniform float u_height; uniform float u_time; uniform float u_play; uniform float u_boost; uniform float u_touch_x; uniform float u_touch_y; uniform float u_ripple; uniform float u_pr; uniform float u_pg; uniform float u_pb; uniform float u_sr; uniform float u_sg; uniform float u_sb; float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);} float noise(vec2 p){vec2 i=floor(p);vec2 f=fract(p);float a=hash(i);float b=hash(i+vec2(1.0,0.0));float c=hash(i+vec2(0.0,1.0));float d=hash(i+vec2(1.0,1.0));vec2 q=f*f*(3.0-2.0*f);return mix(a,b,q.x)+(c-a)*q.y*(1.0-q.x)+(d-b)*q.x*q.y;} vec4 main(vec2 p){float w=max(u_width,1.0);float h=max(u_height,1.0);vec2 uv=vec2(p.x/w,p.y/h);float t=u_time*0.10;float n1=noise(uv*2.15+vec2(t*0.31,-t*0.17));float n2=noise(uv*3.70+vec2(-t*0.13,t*0.23));float n3=noise(uv*1.35+vec2(t*0.08,t*0.11));float field=clamp(n1*0.52+n2*0.28+n3*0.20,0.0,1.0);field=smoothstep(0.30,0.76,field);vec3 pc=vec3(u_pr,u_pg,u_pb);vec3 sc=vec3(u_sr,u_sg,u_sb);float pl=dot(pc,vec3(0.2126,0.7152,0.0722));float sl=dot(sc,vec3(0.2126,0.7152,0.0722));pc=mix(vec3(pl),pc,0.42);sc=mix(vec3(sl),sc,0.38);pc=mix(pc,vec3(1.0),0.12);sc=mix(sc,vec3(1.0),0.16);float palette=noise(uv*1.70+vec2(-t*0.09,t*0.07));vec3 col=mix(pc,sc,smoothstep(0.34,0.72,palette));float base=field*(0.045*u_play+0.095*u_boost);float rp=clamp(u_ripple,0.0,1.0);float ease=rp*rp*(3.0-2.0*rp);vec2 tp=vec2(u_touch_x,u_touch_y);float dist=distance(p,tp);float radius=mix(18.0,w*2.0,ease);float fade=1.0-rp;float fill=(1.0-smoothstep(radius*0.22,radius,dist))*fade*fade*0.26;float halo=(1.0-smoothstep(radius*0.62,radius*1.18,dist))*fade*0.065;float a=clamp(base+fill+halo,0.0,0.32);return vec4(col*a,a);}"

    new-instance v1, Landroid/graphics/RuntimeShader;

    invoke-direct {v1, v0}, Landroid/graphics/RuntimeShader;-><init>(Ljava/lang/String;)V

    iput-object v1, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->shader:Landroid/graphics/RuntimeShader;

    iget-object v2, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->paint:Landroid/graphics/Paint;

    invoke-virtual {v2, v1}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    const/4 v0, 0x1

    invoke-virtual {v2, v0}, Landroid/graphics/Paint;->setDither(Z)V

    sget-object v0, Landroid/graphics/BlendMode;->PLUS:Landroid/graphics/BlendMode;

    invoke-virtual {v2, v0}, Landroid/graphics/Paint;->setBlendMode(Landroid/graphics/BlendMode;)V

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->updatePaletteUniforms()V
    :try_end_1d
    .catch Ljava/lang/Throwable; {:try_start_3 .. :try_end_1d} :catch_1e

    return-void

    :catch_1e
    const/4 v0, 0x0

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->shader:Landroid/graphics/RuntimeShader;

    iget-object v1, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    return-void
.end method

.method private rippleProgress(J)F
    .registers 8

    iget-boolean v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->rippleActive:Z

    if-eqz v0, :cond_17

    iget-wide v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->rippleStart:J

    sub-long v0, p1, v0

    const-wide/16 v2, 0x5dc

    cmp-long v4, v0, v2

    if-ltz v4, :cond_14

    long-to-float v4, v0

    const v1, 0x44bb8000  # 1500.0f

    div-float/2addr v4, v1

    return v4

    :cond_14
    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->rippleActive:Z

    :cond_17
    const/high16 v0, 0x3f800000  # 1.0f

    return v0
.end method

.method private static setFloatSafe(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V
    .registers 3

    if-eqz p0, :cond_5

    :try_start_2
    invoke-virtual {p0, p1, p2}, Landroid/graphics/RuntimeShader;->setFloatUniform(Ljava/lang/String;F)V
    :try_end_5
    .catch Ljava/lang/Throwable; {:try_start_2 .. :try_end_5} :catch_5

    :catch_5
    :cond_5
    return-void
.end method

.method private touchBoostProgress(J)F
    .registers 8

    iget-wide v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->touchBoostStart:J

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    if-lez v4, :cond_1e

    sub-long v0, p1, v0

    const-wide/16 v2, 0x1d4c

    cmp-long v4, v0, v2

    if-ltz v4, :cond_1a

    long-to-float v4, v0

    const v1, 0x45ea6000  # 7500.0f

    div-float/2addr v4, v1

    const/high16 v1, 0x3f800000  # 1.0f

    sub-float v4, v1, v4

    return v4

    :cond_1a
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->touchBoostStart:J

    :cond_1e
    const/4 v0, 0x0

    int-to-float v0, v0

    return v0
.end method

.method private updatePaletteUniforms()V
    .registers 5

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->shader:Landroid/graphics/RuntimeShader;

    if-eqz v0, :cond_54

    const/high16 v3, 0x437f0000  # 255.0f

    iget v1, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->primaryColor:I

    invoke-static {v1}, Landroid/graphics/Color;->red(I)I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v2, v3

    const-string v1, "u_pr"

    invoke-static {v0, v1, v2}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->setFloatSafe(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    iget v1, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->primaryColor:I

    invoke-static {v1}, Landroid/graphics/Color;->green(I)I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v2, v3

    const-string v1, "u_pg"

    invoke-static {v0, v1, v2}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->setFloatSafe(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    iget v1, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->primaryColor:I

    invoke-static {v1}, Landroid/graphics/Color;->blue(I)I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v2, v3

    const-string v1, "u_pb"

    invoke-static {v0, v1, v2}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->setFloatSafe(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    iget v1, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->secondaryColor:I

    invoke-static {v1}, Landroid/graphics/Color;->red(I)I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v2, v3

    const-string v1, "u_sr"

    invoke-static {v0, v1, v2}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->setFloatSafe(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    iget v1, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->secondaryColor:I

    invoke-static {v1}, Landroid/graphics/Color;->green(I)I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v2, v3

    const-string v1, "u_sg"

    invoke-static {v0, v1, v2}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->setFloatSafe(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    iget v1, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->secondaryColor:I

    invoke-static {v1}, Landroid/graphics/Color;->blue(I)I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v2, v3

    const-string v1, "u_sb"

    invoke-static {v0, v1, v2}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->setFloatSafe(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    :cond_54
    return-void
.end method


# virtual methods
.method protected onDetachedFromWindow()V
    .registers 3

    invoke-super {p0}, Landroid/view/View;->onDetachedFromWindow()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->playing:Z

    iput-boolean v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->rippleActive:Z

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->touchBoostStart:J

    return-void
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 12

    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    iget-boolean v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->active:Z

    if-eqz v0, :cond_93

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->shader:Landroid/graphics/RuntimeShader;

    if-eqz v0, :cond_93

    invoke-virtual {p1}, Landroid/graphics/Canvas;->isHardwareAccelerated()Z

    move-result v1

    if-eqz v1, :cond_93

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v1

    if-lez v1, :cond_93

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v2

    if-lez v2, :cond_93

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    int-to-float v5, v1

    const-string v6, "u_width"

    invoke-static {v0, v6, v5}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->setFloatSafe(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    int-to-float v5, v2

    const-string v6, "u_height"

    invoke-static {v0, v6, v5}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->setFloatSafe(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    long-to-float v5, v3

    const/high16 v6, 0x447a0000  # 1000.0f

    div-float/2addr v5, v6

    const v6, 0x400ccccd  # 2.2f

    mul-float/2addr v5, v6

    const-string v6, "u_time"

    invoke-static {v0, v6, v5}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->setFloatSafe(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    iget-boolean v5, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->playing:Z

    if-eqz v5, :cond_42

    const v5, 0x40266666  # 2.6f

    goto :goto_44

    :cond_42
    const/4 v5, 0x0

    int-to-float v5, v5

    :goto_44
    const-string v6, "u_play"

    invoke-static {v0, v6, v5}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->setFloatSafe(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    invoke-direct {p0, v3, v4}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->touchBoostProgress(J)F

    move-result v7

    const v5, 0x3fe66666  # 1.8f

    mul-float/2addr v7, v5

    const-string v5, "u_boost"

    invoke-static {v0, v5, v7}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->setFloatSafe(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    invoke-direct {p0, v3, v4}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->rippleProgress(J)F

    move-result v7

    const-string v5, "u_ripple"

    invoke-static {v0, v5, v7}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->setFloatSafe(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    iget-boolean v5, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->playing:Z

    if-nez v5, :cond_6f

    iget-boolean v5, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->rippleActive:Z

    if-nez v5, :cond_6f

    iget-wide v5, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->touchBoostStart:J

    const-wide/16 v8, 0x0

    cmp-long v7, v5, v8

    if-eqz v7, :cond_93

    :cond_6f
    iget-object v5, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->paint:Landroid/graphics/Paint;

    :try_start_71
    invoke-virtual {p1, v5}, Landroid/graphics/Canvas;->drawPaint(Landroid/graphics/Paint;)V
    :try_end_74
    .catch Ljava/lang/Throwable; {:try_start_71 .. :try_end_74} :catch_88

    iget-boolean v5, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->playing:Z

    if-nez v5, :cond_84

    iget-boolean v5, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->rippleActive:Z

    if-nez v5, :cond_84

    iget-wide v5, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->touchBoostStart:J

    const-wide/16 v8, 0x0

    cmp-long v7, v5, v8

    if-eqz v7, :cond_93

    :cond_84
    invoke-virtual {p0}, Landroid/view/View;->postInvalidateOnAnimation()V

    goto :goto_93

    :catch_88
    const/4 v5, 0x0

    iput-object v5, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->shader:Landroid/graphics/RuntimeShader;

    iput-boolean v5, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->rippleActive:Z

    iput-boolean v5, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->playing:Z

    const-wide/16 v6, 0x0

    iput-wide v6, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->touchBoostStart:J

    :cond_93
    :goto_93
    return-void
.end method

.method public setActive(Z)V
    .registers 4

    iget-boolean v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->active:Z

    if-ne v0, p1, :cond_5

    return-void

    :cond_5
    iput-boolean p1, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->active:Z

    if-nez p1, :cond_16

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->playing:Z

    iput-boolean v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->rippleActive:Z

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->touchBoostStart:J

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void

    :cond_16
    invoke-virtual {p0}, Landroid/view/View;->postInvalidateOnAnimation()V

    return-void
.end method

.method public setPalette(II)V
    .registers 4

    iget v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->primaryColor:I

    if-ne v0, p1, :cond_9

    iget v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->secondaryColor:I

    if-ne v0, p2, :cond_9

    return-void

    :cond_9
    iput p1, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->primaryColor:I

    iput p2, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->secondaryColor:I

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->updatePaletteUniforms()V

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public setPlaying(Z)V
    .registers 3

    iget-boolean v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->playing:Z

    if-ne v0, p1, :cond_5

    return-void

    :cond_5
    iput-boolean p1, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->playing:Z

    iget-boolean v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->active:Z

    if-eqz v0, :cond_e

    invoke-virtual {p0}, Landroid/view/View;->postInvalidateOnAnimation()V

    :cond_e
    return-void
.end method

.method public startRipple(FF)V
    .registers 7

    iget-boolean v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->active:Z

    if-eqz v0, :cond_24

    iput p1, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->rippleX:F

    iput p2, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->rippleY:F

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->rippleStart:J

    iput-wide v0, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->touchBoostStart:J

    const/4 v2, 0x1

    iput-boolean v2, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->rippleActive:Z

    iget-object v2, p0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->shader:Landroid/graphics/RuntimeShader;

    if-eqz v2, :cond_21

    const-string v3, "u_touch_x"

    invoke-static {v2, v3, p1}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->setFloatSafe(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    const-string v3, "u_touch_y"

    invoke-static {v2, v3, p2}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->setFloatSafe(Landroid/graphics/RuntimeShader;Ljava/lang/String;F)V

    :cond_21
    invoke-virtual {p0}, Landroid/view/View;->postInvalidateOnAnimation()V

    :cond_24
    return-void
.end method
