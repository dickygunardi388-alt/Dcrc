.class public final Linv/exe/systemui/qs/ui/InvTileAnimation;
.super Ljava/lang/Object;
.source "InvTileAnimation.java"


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static animatorInterpolator()Landroid/animation/TimeInterpolator;
    .registers 5

    new-instance v0, Landroid/view/animation/PathInterpolator;

    const v1, 0x3ecccccd  # 0.4f

    const/4 v2, 0x0

    const v3, 0x3e4ccccd  # 0.2f

    const/high16 v4, 0x3f800000  # 1.0f

    invoke-direct {v0, v1, v2, v3, v4}, Landroid/view/animation/PathInterpolator;-><init>(FFFF)V

    return-object v0
.end method

.method private static color(Landroid/view/View;Ljava/lang/String;)I
    .registers 2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-static {p1}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result p1

    invoke-virtual {p0, p1}, Landroid/content/Context;->getColor(I)I

    move-result p0

    return p0
.end method

.method private static dimen(Landroid/view/View;Ljava/lang/String;)F
    .registers 3

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-static {p1}, Linv/exe/systemui/qs/core/InvRes;->dimen(Ljava/lang/String;)I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p0

    return p0
.end method

.method public static pillBackground(Landroid/view/View;Z)V
    .registers 16

    if-eqz p0, :cond_a1

    if-eqz p1, :cond_6

    const/4 v0, 0x2

    goto :goto_7

    :cond_6
    const/4 v0, 0x1

    :goto_7
    const-string v1, "inv_control_pill_bg_on"

    invoke-static {p0, v1}, Linv/exe/systemui/qs/ui/InvTileAnimation;->color(Landroid/view/View;Ljava/lang/String;)I

    move-result v1

    const-string v2, "inv_control_pill_bg_off"

    invoke-static {p0, v2}, Linv/exe/systemui/qs/ui/InvTileAnimation;->color(Landroid/view/View;Ljava/lang/String;)I

    move-result v2

    if-eqz p1, :cond_17

    move v3, v1

    goto :goto_18

    :cond_17
    move v3, v2

    :goto_18
    const-string v4, "inv_component_pill_corner_radius"

    invoke-static {p0, v4}, Linv/exe/systemui/qs/ui/InvTileAnimation;->dimen(Landroid/view/View;Ljava/lang/String;)F

    move-result v4

    const-string v5, "inv_tile_anim_last_bg_state"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {p0, v5}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object v6

    instance-of v7, v6, Ljava/lang/Integer;

    if-eqz v7, :cond_33

    check-cast v6, Ljava/lang/Integer;

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v6

    goto :goto_34

    :cond_33
    const/4 v6, -0x1

    :goto_34
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {p0, v5, v7}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    const/4 v5, -0x1

    if-ne v6, v5, :cond_3f

    goto :goto_8a

    :cond_3f
    if-ne v6, v0, :cond_42

    goto :goto_8a

    :cond_42
    const/4 v5, 0x2

    if-ne v6, v5, :cond_47

    move v7, v1

    goto :goto_48

    :cond_47
    move v7, v2

    :goto_48
    new-instance v8, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v8}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v9, 0x0

    invoke-virtual {v8, v9}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    invoke-virtual {v8, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-virtual {v8, v4}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    const/16 v9, 0xff

    invoke-virtual {v8, v9}, Landroid/graphics/drawable/GradientDrawable;->setAlpha(I)V

    invoke-virtual {p0, v8}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v10, 0x2

    new-array v10, v10, [F

    const/4 v11, 0x0

    aput v4, v10, v11

    const/4 v11, 0x1

    aput v4, v10, v11

    invoke-static {v10}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object v10

    move v2, v7

    move v5, v4

    move v6, v9

    move v7, v9

    new-instance v0, Linv/exe/systemui/qs/ui/InvTileAnimation$ShapeUpdate;

    move-object v1, v8

    invoke-direct/range {v0 .. v7}, Linv/exe/systemui/qs/ui/InvTileAnimation$ShapeUpdate;-><init>(Landroid/graphics/drawable/GradientDrawable;IIFFII)V

    invoke-virtual {v10, v0}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    const-wide/16 v11, 0xdc

    invoke-virtual {v10, v11, v12}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    move-result-object v10

    invoke-static {}, Linv/exe/systemui/qs/ui/InvTileAnimation;->animatorInterpolator()Landroid/animation/TimeInterpolator;

    move-result-object v11

    invoke-virtual {v10, v11}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    invoke-virtual {v10}, Landroid/animation/ValueAnimator;->start()V

    return-void

    :goto_8a
    new-instance v5, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v5}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    invoke-virtual {v5, v3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-virtual {v5, v4}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    const/16 v6, 0xff

    invoke-virtual {v5, v6}, Landroid/graphics/drawable/GradientDrawable;->setAlpha(I)V

    invoke-virtual {p0, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_a1
    return-void
.end method

.method public static press(Landroid/view/View;)V
    .registers 5

    if-eqz p0, :cond_41

    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvTileAnimation;->tileCircle(Landroid/view/View;)Landroid/view/View;

    move-result-object p0

    if-eqz p0, :cond_41

    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->cancel()V

    const v0, 0x3f6b851f  # 0.92f

    invoke-virtual {p0, v0}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setScaleY(F)V

    const v0, 0x3f5c28f6  # 0.86f

    invoke-virtual {p0, v0}, Landroid/view/View;->setAlpha(F)V

    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const/high16 v0, 0x3f800000  # 1.0f

    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const-wide/16 v0, 0xb4

    invoke-virtual {p0, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    invoke-static {}, Linv/exe/systemui/qs/ui/InvTileAnimation;->animatorInterpolator()Landroid/animation/TimeInterpolator;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/ViewPropertyAnimator;->start()V

    :cond_41
    return-void
.end method

.method public static state(Landroid/view/View;Landroid/widget/ImageView;Landroid/widget/TextView;I)V
    .registers 12

    if-eqz p0, :cond_c8

    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvTileAnimation;->tileCircle(Landroid/view/View;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_c8

    const-string v1, "inv_tile_anim_last_state"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object v2

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    if-nez v2, :cond_1c

    return-void

    :cond_1c
    invoke-virtual {v3, v2}, Ljava/lang/Integer;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_23

    return-void

    :cond_23
    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p3

    invoke-virtual {p3}, Landroid/view/ViewPropertyAnimator;->cancel()V

    const v2, 0x3f70a3d7  # 0.94f

    invoke-virtual {v0, v2}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setScaleY(F)V

    const v2, 0x3f51eb85  # 0.82f

    invoke-virtual {v0, v2}, Landroid/view/View;->setAlpha(F)V

    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p3

    const/high16 v2, 0x3f800000  # 1.0f

    invoke-virtual {p3, v2}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p3

    invoke-virtual {p3, v2}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p3

    invoke-virtual {p3, v2}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p3

    const-wide/16 v4, 0xdc

    invoke-virtual {p3, v4, v5}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p3

    invoke-static {}, Linv/exe/systemui/qs/ui/InvTileAnimation;->animatorInterpolator()Landroid/animation/TimeInterpolator;

    move-result-object v0

    invoke-virtual {p3, v0}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object p3

    invoke-virtual {p3}, Landroid/view/ViewPropertyAnimator;->start()V

    if-eqz p1, :cond_9b

    invoke-virtual {p1}, Landroid/widget/ImageView;->getAlpha()F

    move-result p3

    invoke-virtual {p1}, Landroid/widget/ImageView;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->cancel()V

    const v0, 0x3f47ae14  # 0.78f

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setScaleX(F)V

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setScaleY(F)V

    const v0, 0x3f266666  # 0.65f

    mul-float v1, p3, v0

    invoke-virtual {p1, v1}, Landroid/widget/ImageView;->setAlpha(F)V

    invoke-virtual {p1}, Landroid/widget/ImageView;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    invoke-virtual {p1, v2}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    invoke-virtual {p1, v2}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    invoke-virtual {p1, p3}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const-wide/16 v0, 0xf0

    invoke-virtual {p1, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    invoke-static {}, Linv/exe/systemui/qs/ui/InvTileAnimation;->animatorInterpolator()Landroid/animation/TimeInterpolator;

    move-result-object p3

    invoke-virtual {p1, p3}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewPropertyAnimator;->start()V

    :cond_9b
    if-eqz p2, :cond_c8

    invoke-virtual {p2}, Landroid/widget/TextView;->getAlpha()F

    move-result p1

    invoke-virtual {p2}, Landroid/widget/TextView;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p3

    invoke-virtual {p3}, Landroid/view/ViewPropertyAnimator;->cancel()V

    const/high16 p3, 0x3f400000  # 0.75f

    mul-float v0, p1, p3

    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setAlpha(F)V

    invoke-virtual {p2}, Landroid/widget/TextView;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p2

    invoke-virtual {p2, p1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const-wide/16 p2, 0xc8

    invoke-virtual {p1, p2, p3}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    invoke-static {}, Linv/exe/systemui/qs/ui/InvTileAnimation;->animatorInterpolator()Landroid/animation/TimeInterpolator;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewPropertyAnimator;->start()V

    :cond_c8
    return-void
.end method

.method public static tileBackground(Landroid/view/View;II)V
    .registers 16

    if-eqz p0, :cond_b4

    const-string v0, "inv_tile_bg_on"

    invoke-static {p0, v0}, Linv/exe/systemui/qs/ui/InvTileAnimation;->color(Landroid/view/View;Ljava/lang/String;)I

    move-result v0

    const-string v1, "inv_tile_bg_off"

    invoke-static {p0, v1}, Linv/exe/systemui/qs/ui/InvTileAnimation;->color(Landroid/view/View;Ljava/lang/String;)I

    move-result v1

    const/4 v2, 0x2

    if-ne p1, v2, :cond_19

    move v2, v0

    const-string v3, "inv_component_pill_corner_radius"

    invoke-static {p0, v3}, Linv/exe/systemui/qs/ui/InvTileAnimation;->dimen(Landroid/view/View;Ljava/lang/String;)F

    move-result v3

    goto :goto_20

    :cond_19
    move v2, v1

    const-string v3, "inv_qs_tile_corner_radius"

    invoke-static {p0, v3}, Linv/exe/systemui/qs/ui/InvTileAnimation;->dimen(Landroid/view/View;Ljava/lang/String;)F

    move-result v3

    :goto_20
    const-string v4, "inv_tile_anim_last_bg_state"

    invoke-static {v4}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {p0, v4}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object v5

    instance-of v6, v5, Ljava/lang/Integer;

    if-eqz v6, :cond_35

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v6

    goto :goto_36

    :cond_35
    const/4 v6, -0x1

    :goto_36
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {p0, v4, v7}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    const/4 v5, -0x1

    if-ne v6, v5, :cond_41

    goto :goto_9f

    :cond_41
    if-ne v6, p1, :cond_44

    goto :goto_9f

    :cond_44
    goto :goto_9f

    const/4 v5, 0x2

    if-ne v6, v5, :cond_50

    move v7, v0

    const-string v8, "inv_component_pill_corner_radius"

    invoke-static {p0, v8}, Linv/exe/systemui/qs/ui/InvTileAnimation;->dimen(Landroid/view/View;Ljava/lang/String;)F

    move-result v8

    goto :goto_57

    :cond_50
    move v7, v1

    const-string v8, "inv_qs_tile_corner_radius"

    invoke-static {p0, v8}, Linv/exe/systemui/qs/ui/InvTileAnimation;->dimen(Landroid/view/View;Ljava/lang/String;)F

    move-result v8

    :goto_57
    const/4 v5, 0x0

    if-ne v6, v5, :cond_5d

    const/16 v6, 0x4d

    goto :goto_5f

    :cond_5d
    const/16 v6, 0xff

    :goto_5f
    new-instance v9, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v9}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    invoke-virtual {v9, v5}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    invoke-virtual {v9, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-virtual {v9, v8}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-virtual {v9, v6}, Landroid/graphics/drawable/GradientDrawable;->setAlpha(I)V

    invoke-virtual {p0, v9}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v10, 0x2

    new-array v10, v10, [F

    const/4 v11, 0x0

    aput v8, v10, v11

    const/4 v11, 0x1

    aput v3, v10, v11

    invoke-static {v10}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object v10

    move v5, v3

    move v4, v8

    move v3, v2

    move v2, v7

    move v7, p2

    new-instance v0, Linv/exe/systemui/qs/ui/InvTileAnimation$ShapeUpdate;

    move-object v1, v9

    invoke-direct/range {v0 .. v7}, Linv/exe/systemui/qs/ui/InvTileAnimation$ShapeUpdate;-><init>(Landroid/graphics/drawable/GradientDrawable;IIFFII)V

    invoke-virtual {v10, v0}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    const-wide/16 v11, 0xdc

    invoke-virtual {v10, v11, v12}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    move-result-object v10

    invoke-static {}, Linv/exe/systemui/qs/ui/InvTileAnimation;->animatorInterpolator()Landroid/animation/TimeInterpolator;

    move-result-object v11

    invoke-virtual {v10, v11}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    invoke-virtual {v10}, Landroid/animation/ValueAnimator;->start()V

    return-void

    :goto_9f
    new-instance v5, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v5}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    invoke-virtual {v5, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-virtual {v5, v3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-virtual {v5, p2}, Landroid/graphics/drawable/GradientDrawable;->setAlpha(I)V

    invoke-virtual {p0, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_b4
    return-void
.end method

.method private static tileCircle(Landroid/view/View;)Landroid/view/View;
    .registers 3

    if-eqz p0, :cond_17

    const-string v0, "tile_circle"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getId()I

    move-result v1

    if-ne v1, v0, :cond_f

    return-object p0

    :cond_f
    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_16

    return-object v1

    :cond_16
    return-object p0

    :cond_17
    const/4 p0, 0x0

    return-object p0
.end method
