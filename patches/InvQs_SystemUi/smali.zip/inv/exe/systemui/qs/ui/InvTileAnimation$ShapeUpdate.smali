.class final Linv/exe/systemui/qs/ui/InvTileAnimation$ShapeUpdate;
.super Ljava/lang/Object;
.source "InvTileAnimation.java"

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# instance fields
.field private final drawable:Landroid/graphics/drawable/GradientDrawable;

.field private final endAlpha:I

.field private final endColor:I

.field private final endRadius:F

.field private final startAlpha:I

.field private final startColor:I

.field private final startRadius:F


# direct methods
.method public constructor <init>(Landroid/graphics/drawable/GradientDrawable;IIFFII)V
    .registers 8

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvTileAnimation$ShapeUpdate;->drawable:Landroid/graphics/drawable/GradientDrawable;

    iput p2, p0, Linv/exe/systemui/qs/ui/InvTileAnimation$ShapeUpdate;->startColor:I

    iput p3, p0, Linv/exe/systemui/qs/ui/InvTileAnimation$ShapeUpdate;->endColor:I

    iput p4, p0, Linv/exe/systemui/qs/ui/InvTileAnimation$ShapeUpdate;->startRadius:F

    iput p5, p0, Linv/exe/systemui/qs/ui/InvTileAnimation$ShapeUpdate;->endRadius:F

    iput p6, p0, Linv/exe/systemui/qs/ui/InvTileAnimation$ShapeUpdate;->startAlpha:I

    iput p7, p0, Linv/exe/systemui/qs/ui/InvTileAnimation$ShapeUpdate;->endAlpha:I

    return-void
.end method


# virtual methods
.method public onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .registers 8

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedFraction()F

    move-result v0

    iget-object v1, p0, Linv/exe/systemui/qs/ui/InvTileAnimation$ShapeUpdate;->drawable:Landroid/graphics/drawable/GradientDrawable;

    invoke-static {}, Landroid/animation/ArgbEvaluator;->getInstance()Landroid/animation/ArgbEvaluator;

    move-result-object v2

    iget v3, p0, Linv/exe/systemui/qs/ui/InvTileAnimation$ShapeUpdate;->startColor:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    iget v4, p0, Linv/exe/systemui/qs/ui/InvTileAnimation$ShapeUpdate;->endColor:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v2, v0, v3, v4}, Landroid/animation/ArgbEvaluator;->evaluate(FLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    iget p1, p0, Linv/exe/systemui/qs/ui/InvTileAnimation$ShapeUpdate;->endAlpha:I

    iget v2, p0, Linv/exe/systemui/qs/ui/InvTileAnimation$ShapeUpdate;->startAlpha:I

    sub-int/2addr p1, v2

    int-to-float p1, p1

    mul-float/2addr p1, v0

    int-to-float v0, v2

    add-float/2addr p1, v0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/GradientDrawable;->setAlpha(I)V

    invoke-virtual {v1}, Landroid/graphics/drawable/GradientDrawable;->invalidateSelf()V

    return-void
.end method
