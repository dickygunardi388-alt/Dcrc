.class public Linv/exe/systemui/qs/ui/InvQsPanelView$5;
.super Ljava/lang/Object;
.source "QsPanelView.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Linv/exe/systemui/qs/ui/InvQsPanelView;->scheduleResponsiveLayoutRefresh()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field public final synthetic this$0:Linv/exe/systemui/qs/ui/InvQsPanelView;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/ui/InvQsPanelView;)V
    .registers 2

    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvQsPanelView$5;->this$0:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 1

    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView$5;->this$0:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->forceResponsiveLayoutNow()V

    return-void
.end method
