.class public final Linv/exe/systemui/qs/ui/InvFooterActionsHider;
.super Ljava/lang/Object;
.source "InvFooterActionsHider.java"


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static hide(Landroid/view/View;)V
    .registers 2

    if-eqz p0, :cond_12

    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_12

    const-string p0, "pm_lite"

    invoke-static {v0, p0}, Linv/exe/systemui/qs/ui/InvFooterActionsHider;->hideByName(Landroid/view/View;Ljava/lang/String;)V

    const-string p0, "settings_button_container"

    invoke-static {v0, p0}, Linv/exe/systemui/qs/ui/InvFooterActionsHider;->hideByName(Landroid/view/View;Ljava/lang/String;)V

    :cond_12
    return-void
.end method

.method private static hideByName(Landroid/view/View;Ljava/lang/String;)V
    .registers 7

    if-eqz p0, :cond_27

    if-eqz p1, :cond_27

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    if-eqz v0, :cond_27

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    if-eqz v1, :cond_27

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const-string v2, "id"

    invoke-virtual {v0, p1, v2, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    if-lez v0, :cond_27

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_27

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_27
    return-void
.end method
