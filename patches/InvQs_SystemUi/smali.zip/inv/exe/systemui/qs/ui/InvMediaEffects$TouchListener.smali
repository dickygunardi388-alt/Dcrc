.class final Linv/exe/systemui/qs/ui/InvMediaEffects$TouchListener;
.super Ljava/lang/Object;
.source "InvMediaEffects.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# instance fields
.field private final target:Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;


# direct methods
.method constructor <init>(Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvMediaEffects$TouchListener;->target:Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;

    return-void
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .registers 11

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    if-nez v0, :cond_30

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvMediaEffects$TouchListener;->target:Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;

    if-eqz v0, :cond_30

    const/4 v1, 0x2

    new-array v2, v1, [I

    new-array v3, v1, [I

    invoke-virtual {p1, v2}, Landroid/view/View;->getLocationOnScreen([I)V

    invoke-virtual {v0, v3}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v1, 0x0

    aget v4, v2, v1

    aget v5, v3, v1

    sub-int/2addr v4, v5

    int-to-float v4, v4

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result v5

    add-float/2addr v4, v5

    const/4 v1, 0x1

    aget v6, v2, v1

    aget v7, v3, v1

    sub-int/2addr v6, v7

    int-to-float v2, v6

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result v3

    add-float/2addr v2, v3

    invoke-virtual {v0, v4, v2}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->startRipple(FF)V

    :cond_30
    const/4 v0, 0x0

    return v0
.end method
