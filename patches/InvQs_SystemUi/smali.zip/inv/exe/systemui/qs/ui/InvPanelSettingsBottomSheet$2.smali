.class public Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$2;
.super Ljava/lang/Object;
.source "PanelSettingsBottomSheet.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->init()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field public final synthetic this$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V
    .registers 2

    .line 106
    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$2;->this$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 2

    .line 106
    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$2;->this$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dismiss()V

    return-void
.end method
