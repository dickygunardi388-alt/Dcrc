.class public Linv/exe/systemui/qs/ui/InvGifImageView;
.super Landroid/widget/ImageView;
.source "InvGifImageView.java"


# instance fields
.field private mMovie:Landroid/graphics/Movie;

.field private mPaint:Landroid/graphics/Paint;

.field private mPath:Ljava/lang/String;

.field private mPaused:Z

.field private mStart:J


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    invoke-direct {p0, p1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvGifImageView;->init()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvGifImageView;->init()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvGifImageView;->init()V

    return-void
.end method

.method private init()V
    .registers 3

    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvGifImageView;->mPaint:Landroid/graphics/Paint;

    sget-object v0, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {p0, v0}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    return-void
.end method


# virtual methods
.method public clearGif()V
    .registers 4

    const/4 v0, 0x0

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvGifImageView;->mMovie:Landroid/graphics/Movie;

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvGifImageView;->mPath:Ljava/lang/String;

    const-wide/16 v1, 0x0

    iput-wide v1, p0, Linv/exe/systemui/qs/ui/InvGifImageView;->mStart:J

    invoke-virtual {p0, v0}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 15

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvGifImageView;->mMovie:Landroid/graphics/Movie;

    if-eqz v0, :cond_7b

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v1

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v2

    if-lez v1, :cond_7e

    if-lez v2, :cond_7e

    invoke-virtual {v0}, Landroid/graphics/Movie;->width()I

    move-result v3

    invoke-virtual {v0}, Landroid/graphics/Movie;->height()I

    move-result v4

    if-lez v3, :cond_7e

    if-lez v4, :cond_7e

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v5

    iget-wide v7, p0, Linv/exe/systemui/qs/ui/InvGifImageView;->mStart:J

    const-wide/16 v9, 0x0

    cmp-long v11, v7, v9

    if-nez v11, :cond_2b

    iput-wide v5, p0, Linv/exe/systemui/qs/ui/InvGifImageView;->mStart:J

    move-wide v7, v5

    :cond_2b
    invoke-virtual {v0}, Landroid/graphics/Movie;->duration()I

    move-result v9

    if-lez v9, :cond_32

    goto :goto_34

    :cond_32
    const/16 v9, 0x3e8

    :goto_34
    iget-boolean v10, p0, Linv/exe/systemui/qs/ui/InvGifImageView;->mPaused:Z

    if-eqz v10, :cond_3d

    const/4 v5, 0x0

    invoke-virtual {v0, v5}, Landroid/graphics/Movie;->setTime(I)Z

    goto :goto_44

    :cond_3d
    sub-long/2addr v5, v7

    int-to-long v7, v9

    rem-long/2addr v5, v7

    long-to-int v5, v5

    invoke-virtual {v0, v5}, Landroid/graphics/Movie;->setTime(I)Z

    :goto_44
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v5

    int-to-float v6, v1

    int-to-float v7, v3

    div-float/2addr v6, v7

    int-to-float v8, v2

    int-to-float v9, v4

    div-float/2addr v8, v9

    cmpl-float v10, v6, v8

    if-ltz v10, :cond_53

    move v8, v6

    :cond_53
    int-to-float v1, v1

    int-to-float v3, v3

    mul-float v6, v3, v8

    sub-float/2addr v1, v6

    const/high16 v6, 0x40000000  # 2.0f

    div-float/2addr v1, v6

    int-to-float v2, v2

    int-to-float v4, v4

    mul-float v4, v4, v8

    sub-float/2addr v2, v4

    div-float/2addr v2, v6

    invoke-virtual {p1, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p1, v8, v8}, Landroid/graphics/Canvas;->scale(FF)V

    iget-object v1, p0, Linv/exe/systemui/qs/ui/InvGifImageView;->mPaint:Landroid/graphics/Paint;

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, p1, v2, v3, v1}, Landroid/graphics/Movie;->draw(Landroid/graphics/Canvas;FFLandroid/graphics/Paint;)V

    invoke-virtual {p1, v5}, Landroid/graphics/Canvas;->restoreToCount(I)V

    iget-boolean v1, p0, Linv/exe/systemui/qs/ui/InvGifImageView;->mPaused:Z

    if-nez v1, :cond_7a

    const-wide/16 v2, 0x42

    invoke-virtual {p0, v2, v3}, Landroid/view/View;->postInvalidateDelayed(J)V

    :cond_7a
    return-void

    :cond_7b
    invoke-super {p0, p1}, Landroid/widget/ImageView;->onDraw(Landroid/graphics/Canvas;)V

    :cond_7e
    return-void
.end method

.method public setGifPath(Ljava/lang/String;)V
    .registers 5

    if-eqz p1, :cond_23

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvGifImageView;->mPath:Ljava/lang/String;

    if-eqz v0, :cond_d

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_d

    return-void

    :cond_d
    invoke-static {p1}, Landroid/graphics/Movie;->decodeFile(Ljava/lang/String;)Landroid/graphics/Movie;

    move-result-object v0

    if-eqz v0, :cond_23

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvGifImageView;->mMovie:Landroid/graphics/Movie;

    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvGifImageView;->mPath:Ljava/lang/String;

    const-wide/16 v1, 0x0

    iput-wide v1, p0, Linv/exe/systemui/qs/ui/InvGifImageView;->mStart:J

    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void

    :cond_23
    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvGifImageView;->clearGif()V

    return-void
.end method

.method public setGifPaused(Z)V
    .registers 4

    iget-boolean v0, p0, Linv/exe/systemui/qs/ui/InvGifImageView;->mPaused:Z

    if-ne v0, p1, :cond_5

    return-void

    :cond_5
    iput-boolean p1, p0, Linv/exe/systemui/qs/ui/InvGifImageView;->mPaused:Z

    if-eqz p1, :cond_d

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Linv/exe/systemui/qs/ui/InvGifImageView;->mStart:J

    :cond_d
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method
