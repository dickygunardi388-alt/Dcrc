.class public final Linv/exe/systemui/qs/ui/InvSmoothLayout$1;
.super Ljava/lang/Object;
.source "SmoothLayout.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final synthetic val$before:Ljava/util/Map;


# direct methods
.method public constructor <init>(Ljava/util/Map;)V
    .registers 2

    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvSmoothLayout$1;->val$before:Ljava/util/Map;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 2

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvSmoothLayout$1;->val$before:Ljava/util/Map;

    invoke-static {v0}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->playNow(Ljava/util/Map;)V

    return-void
.end method
