.class public Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$6;
.super Ljava/lang/Object;
.source "PanelSettingsBottomSheet.java"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->listen(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$Change;)Landroid/widget/SeekBar$OnSeekBarChangeListener;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private pending:I

.field public final synthetic this$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

.field private final synthetic val$c:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$Change;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$Change;)V
    .registers 3

    .line 200
    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$6;->this$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    iput-object p2, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$6;->val$c:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$Change;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .registers 4

    if-eqz p3, :cond_4

    iput p2, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$6;->pending:I

    :cond_4
    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 2

    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 3

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$6;->val$c:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$Change;

    iget p0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$6;->pending:I

    invoke-interface {v0, p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$Change;->value(I)V

    return-void
.end method
