.class public final Linv/exe/systemui/qs/ui/InvRoundedClipOutlineProvider;
.super Landroid/view/ViewOutlineProvider;
.source "RoundedClipOutlineProvider.java"


# instance fields
.field private final circle:Z

.field private final corner:F


# direct methods
.method public constructor <init>(ZF)V
    .registers 3

    invoke-direct {p0}, Landroid/view/ViewOutlineProvider;-><init>()V

    iput-boolean p1, p0, Linv/exe/systemui/qs/ui/InvRoundedClipOutlineProvider;->circle:Z

    iput p2, p0, Linv/exe/systemui/qs/ui/InvRoundedClipOutlineProvider;->corner:F

    return-void
.end method


# virtual methods
.method public getOutline(Landroid/view/View;Landroid/graphics/Outline;)V
    .registers 10

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v3

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result v4

    if-lez v3, :cond_22

    if-lez v4, :cond_22

    iget-boolean v6, p0, Linv/exe/systemui/qs/ui/InvRoundedClipOutlineProvider;->circle:Z

    if-eqz v6, :cond_19

    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    move-result v5

    int-to-float v5, v5

    const/high16 v6, 0x40000000  # 2.0f

    div-float/2addr v5, v6

    goto :goto_1b

    :cond_19
    iget v5, p0, Linv/exe/systemui/qs/ui/InvRoundedClipOutlineProvider;->corner:F

    :goto_1b
    move-object v0, p2

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Outline;->setRoundRect(IIIIF)V

    return-void

    :cond_22
    invoke-virtual {p2}, Landroid/graphics/Outline;->setEmpty()V

    return-void
.end method
