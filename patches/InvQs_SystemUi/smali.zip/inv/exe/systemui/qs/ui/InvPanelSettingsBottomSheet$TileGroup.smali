.class public Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$TileGroup;
.super Ljava/lang/Object;
.source "PanelSettingsBottomSheet.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "TileGroup"
.end annotation


# instance fields
.field public final iconRes:I

.field public final titleText:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;I)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$TileGroup;->titleText:Ljava/lang/String;

    iput p2, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$TileGroup;->iconRes:I

    return-void
.end method
