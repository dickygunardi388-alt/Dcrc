.class public Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;
.super Ljava/lang/Object;
.source "MediaViewRenderer.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->bindProgress(Landroid/widget/FrameLayout;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;Linv/exe/systemui/qs/controller/InvMediaSessionController;II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final synthetic val$duration:[J

.field private final synthetic val$fill:Landroid/view/View;

.field private final synthetic val$hasProgress:[Z

.field private final synthetic val$mediaSession:Linv/exe/systemui/qs/controller/InvMediaSessionController;

.field private final synthetic val$seek:Landroid/widget/FrameLayout;

.field private final synthetic val$showTime:Z

.field private final synthetic val$timeEnd:Landroid/widget/TextView;

.field private final synthetic val$timeStart:Landroid/widget/TextView;

.field private final synthetic val$track:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroid/widget/FrameLayout;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;ZLinv/exe/systemui/qs/controller/InvMediaSessionController;[Z[J)V
    .registers 10

    .line 403
    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$seek:Landroid/widget/FrameLayout;

    iput-object p2, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$track:Landroid/view/View;

    iput-object p3, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$fill:Landroid/view/View;

    iput-object p4, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$timeStart:Landroid/widget/TextView;

    iput-object p5, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$timeEnd:Landroid/widget/TextView;

    iput-boolean p6, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$showTime:Z

    iput-object p7, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$mediaSession:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    iput-object p8, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$hasProgress:[Z

    iput-object p9, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$duration:[J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 11

    .line 405
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$seek:Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Landroid/widget/FrameLayout;->getVisibility()I

    move-result v0

    if-nez v0, :cond_44

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$seek:Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Landroid/widget/FrameLayout;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    if-nez v0, :cond_11

    goto :goto_44

    .line 409
    :cond_11
    iget-object v1, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$seek:Landroid/widget/FrameLayout;

    iget-object v2, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$track:Landroid/view/View;

    iget-object v3, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$fill:Landroid/view/View;

    iget-object v4, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$timeStart:Landroid/widget/TextView;

    iget-object v5, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$timeEnd:Landroid/widget/TextView;

    iget-boolean v6, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$showTime:Z

    iget-object v7, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$mediaSession:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    iget-object v8, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$hasProgress:[Z

    iget-object v9, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$duration:[J

    invoke-static/range {v1 .. v9}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->access$0(Landroid/widget/FrameLayout;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;ZLinv/exe/systemui/qs/controller/InvMediaSessionController;[Z[J)V

    .line 410
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$mediaSession:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-virtual {v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->hasSession()Z

    move-result v0

    if-eqz v0, :cond_3e

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$mediaSession:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-virtual {v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->isPlaying()Z

    move-result v0

    if-eqz v0, :cond_3e

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$seek:Landroid/widget/FrameLayout;

    const-wide/16 v1, 0x3e8

    invoke-virtual {v0, p0, v1, v2}, Landroid/widget/FrameLayout;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    .line 411
    :cond_3e
    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$seek:Landroid/widget/FrameLayout;

    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->access$3(Landroid/view/View;)V

    return-void

    .line 406
    :cond_44
    :goto_44
    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;->val$seek:Landroid/widget/FrameLayout;

    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->access$3(Landroid/view/View;)V

    return-void
.end method
