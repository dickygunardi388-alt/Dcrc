.class public Linv/exe/systemui/qs/ui/InvLaunchableFrameLayout;
.super Landroid/widget/FrameLayout;
.source "LaunchableFrameLayout.java"

# interfaces
.implements Lcom/android/systemui/animation/LaunchableView;


# instance fields
.field private blockVisibilityChanges:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    invoke-direct {p0, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method


# virtual methods
.method public setShouldBlockVisibilityChanges(Z)V
    .registers 3

    iput-boolean p1, p0, Linv/exe/systemui/qs/ui/InvLaunchableFrameLayout;->blockVisibilityChanges:Z

    if-nez p1, :cond_8

    const/4 v0, 0x0

    invoke-super {p0, v0}, Landroid/widget/FrameLayout;->setVisibility(I)V

    :cond_8
    return-void
.end method

.method public setVisibility(I)V
    .registers 2

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->setVisibility(I)V

    return-void
.end method
