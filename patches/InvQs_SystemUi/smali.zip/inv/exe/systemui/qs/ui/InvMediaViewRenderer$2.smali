.class public Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;
.super Ljava/lang/Object;
.source "MediaViewRenderer.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->bindProgress(Landroid/widget/FrameLayout;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;Linv/exe/systemui/qs/controller/InvMediaSessionController;II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final synthetic val$duration:[J

.field private final synthetic val$fill:Landroid/view/View;

.field private final synthetic val$mediaSession:Linv/exe/systemui/qs/controller/InvMediaSessionController;

.field private final synthetic val$seek:Landroid/widget/FrameLayout;

.field private final synthetic val$showTime:Z

.field private final synthetic val$timeEnd:Landroid/widget/TextView;

.field private final synthetic val$timeStart:Landroid/widget/TextView;

.field private final synthetic val$track:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroid/view/View;Landroid/widget/FrameLayout;[JLandroid/view/View;ZLandroid/widget/TextView;Landroid/widget/TextView;Linv/exe/systemui/qs/controller/InvMediaSessionController;)V
    .registers 9

    .line 383
    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$track:Landroid/view/View;

    iput-object p2, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$seek:Landroid/widget/FrameLayout;

    iput-object p3, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$duration:[J

    iput-object p4, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$fill:Landroid/view/View;

    iput-boolean p5, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$showTime:Z

    iput-object p6, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$timeStart:Landroid/widget/TextView;

    iput-object p7, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$timeEnd:Landroid/widget/TextView;

    iput-object p8, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$mediaSession:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .registers 11

    .line 385
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p1

    const/4 v0, 0x1

    if-eqz p1, :cond_d

    const/4 v1, 0x2

    if-eq p1, v1, :cond_d

    if-eq p1, v0, :cond_d

    return v0

    .line 388
    :cond_d
    iget-object p1, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$track:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p1

    if-lez p1, :cond_1c

    iget-object p1, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$track:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p1

    goto :goto_22

    :cond_1c
    iget-object p1, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$seek:Landroid/widget/FrameLayout;

    invoke-virtual {p1}, Landroid/widget/FrameLayout;->getWidth()I

    move-result p1

    :goto_22
    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    int-to-float p1, p1

    .line 389
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result p2

    invoke-static {p1, p2}, Ljava/lang/Math;->min(FF)F

    move-result p2

    const/4 v1, 0x0

    invoke-static {v1, p2}, Ljava/lang/Math;->max(FF)F

    move-result p2

    div-float/2addr p2, p1

    .line 391
    iget-object p1, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$duration:[J

    const/4 v1, 0x0

    aget-wide v2, p1, v1

    long-to-float p1, v2

    mul-float/2addr p1, p2

    float-to-long v4, p1

    .line 392
    iget-object p1, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$track:Landroid/view/View;

    iget-object v2, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$fill:Landroid/view/View;

    invoke-static {p1, v2, p2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->access$1(Landroid/view/View;Landroid/view/View;F)V

    .line 393
    iget-boolean p1, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$showTime:Z

    if-eqz p1, :cond_53

    iget-object v2, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$timeStart:Landroid/widget/TextView;

    iget-object v3, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$timeEnd:Landroid/widget/TextView;

    iget-object p1, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$duration:[J

    aget-wide v6, p1, v1

    invoke-static/range {v2 .. v7}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->access$2(Landroid/widget/TextView;Landroid/widget/TextView;JJ)V

    .line 394
    :cond_53
    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;->val$mediaSession:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-virtual {p0, v4, v5}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->seekTo(J)V

    return v0
.end method
