.class public Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$3;
.super Ljava/lang/Object;
.source "PanelSettingsBottomSheet.java"

# interfaces
.implements Linv/exe/systemui/qs/controller/InvMediaSessionController$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->init()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field public final synthetic this$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V
    .registers 2

    .line 112
    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$3;->this$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onMediaChanged()V
    .registers 4

    .line 114
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$3;->this$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    invoke-static {v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->access$1(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_2b

    .line 115
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$3;->this$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    invoke-static {v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->access$1(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)Landroid/view/View;

    move-result-object v0

    iget-object v1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$3;->this$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    invoke-static {v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->access$2(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)Linv/exe/systemui/qs/controller/InvMediaSessionController;

    move-result-object v1

    iget-object v2, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$3;->this$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    invoke-static {v2}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->access$3(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)Linv/exe/systemui/qs/model/InvPanelRepository;

    move-result-object v2

    invoke-virtual {v2}, Linv/exe/systemui/qs/model/InvPanelRepository;->getMediaSpanW()I

    move-result v2

    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$3;->this$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->access$3(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)Linv/exe/systemui/qs/model/InvPanelRepository;

    move-result-object p0

    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getMediaSpanH()I

    move-result p0

    invoke-static {v0, v1, v2, p0}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->render(Landroid/view/View;Linv/exe/systemui/qs/controller/InvMediaSessionController;II)V

    :cond_2b
    return-void
.end method
