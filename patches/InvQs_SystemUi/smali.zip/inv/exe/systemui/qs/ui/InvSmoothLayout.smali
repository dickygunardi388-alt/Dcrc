.class public final Linv/exe/systemui/qs/ui/InvSmoothLayout;
.super Ljava/lang/Object;
.source "SmoothLayout.java"


# static fields
.field private static final DURATION_MS:J = 0x12cL

.field private static final EASE_OUT:Landroid/view/animation/PathInterpolator;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    .line 16
    new-instance v0, Landroid/view/animation/PathInterpolator;

    const v1, 0x3ecccccd  # 0.4f

    const/4 v2, 0x0

    const v3, 0x3e4ccccd  # 0.2f

    const/high16 v4, 0x3f800000  # 1.0f

    invoke-direct {v0, v1, v2, v3, v4}, Landroid/view/animation/PathInterpolator;-><init>(FFFF)V

    sput-object v0, Linv/exe/systemui/qs/ui/InvSmoothLayout;->EASE_OUT:Landroid/view/animation/PathInterpolator;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static appear(Landroid/view/View;)V
    .registers 2

    if-eqz p0, :cond_14

    const/high16 v0, 0x3f800000  # 1.0f

    invoke-virtual {p0, v0}, Landroid/view/View;->setAlpha(F)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setScaleY(F)V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->setTranslationX(F)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setTranslationY(F)V

    :cond_14
    return-void
.end method

.method public static beginSmoothBounds(Landroid/view/ViewGroup;)Z
    .registers 4

    if-eqz p0, :cond_1e

    :try_start_2
    invoke-static {p0}, Landroid/transition/TransitionManager;->endTransitions(Landroid/view/ViewGroup;)V

    new-instance v0, Landroid/transition/ChangeBounds;

    invoke-direct {v0}, Landroid/transition/ChangeBounds;-><init>()V

    const-wide/16 v1, 0x104

    invoke-virtual {v0, v1, v2}, Landroid/transition/Transition;->setDuration(J)Landroid/transition/Transition;

    sget-object v1, Linv/exe/systemui/qs/ui/InvSmoothLayout;->EASE_OUT:Landroid/view/animation/PathInterpolator;

    invoke-virtual {v0, v1}, Landroid/transition/Transition;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/transition/Transition;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/transition/ChangeBounds;->setResizeClip(Z)V

    invoke-static {p0, v0}, Landroid/transition/TransitionManager;->beginDelayedTransition(Landroid/view/ViewGroup;Landroid/transition/Transition;)V
    :try_end_1b
    .catch Ljava/lang/Throwable; {:try_start_2 .. :try_end_1b} :catch_1d

    const/4 p0, 0x1

    return p0

    :catch_1d
    move-exception p0

    :cond_1e
    const/4 p0, 0x0

    return p0
.end method

.method public static varargs capture([Landroid/view/ViewGroup;)Ljava/util/Map;
    .registers 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Landroid/view/ViewGroup;",
            ")",
            "Ljava/util/Map<",
            "Landroid/view/View;",
            "Landroid/graphics/Rect;",
            ">;"
        }
    .end annotation

    .line 39
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    if-nez p0, :cond_8

    goto :goto_10

    :cond_8
    const/4 v1, 0x2

    .line 41
    new-array v1, v1, [I

    .line 42
    array-length v2, p0

    const/4 v3, 0x0

    move v4, v3

    :goto_e
    if-lt v4, v2, :cond_11

    :goto_10
    return-object v0

    :cond_11
    aget-object v5, p0, v4

    if-nez v5, :cond_16

    goto :goto_1d

    :cond_16
    move v6, v3

    .line 44
    :goto_17
    invoke-virtual {v5}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v7

    if-lt v6, v7, :cond_20

    :goto_1d
    add-int/lit8 v4, v4, 0x1

    goto :goto_e

    .line 45
    :cond_20
    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v7

    if-eqz v7, :cond_53

    .line 46
    invoke-virtual {v7}, Landroid/view/View;->getVisibility()I

    move-result v8

    const/16 v9, 0x8

    if-ne v8, v9, :cond_2f

    goto :goto_53

    .line 47
    :cond_2f
    invoke-virtual {v7, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 48
    new-instance v8, Landroid/graphics/Rect;

    aget v9, v1, v3

    const/4 v10, 0x1

    aget v11, v1, v10

    invoke-virtual {v7}, Landroid/view/View;->getWidth()I

    move-result v12

    invoke-static {v10, v12}, Ljava/lang/Math;->max(II)I

    move-result v12

    add-int/2addr v12, v9

    aget v13, v1, v10

    invoke-virtual {v7}, Landroid/view/View;->getHeight()I

    move-result v14

    invoke-static {v10, v14}, Ljava/lang/Math;->max(II)I

    move-result v10

    add-int/2addr v13, v10

    invoke-direct {v8, v9, v11, v12, v13}, Landroid/graphics/Rect;-><init>(IIII)V

    invoke-virtual {v0, v7, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_53
    :goto_53
    add-int/lit8 v6, v6, 0x1

    goto :goto_17
.end method

.method public static editModeTransition(Landroid/view/View;Z)V
    .registers 5

    if-nez p0, :cond_3

    return-void

    :cond_3
    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->cancel()V

    const/high16 v0, 0x3f800000  # 1.0f

    if-eqz p1, :cond_23

    const v1, 0x3f3851ec  # 0.72f

    invoke-virtual {p0, v1}, Landroid/view/View;->setAlpha(F)V

    const v1, 0x3f75c28f  # 0.96f

    invoke-virtual {p0, v1}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {p0, v1}, Landroid/view/View;->setScaleY(F)V

    const/high16 v1, 0x41400000  # 12.0f

    invoke-virtual {p0, v1}, Landroid/view/View;->setTranslationY(F)V

    goto :goto_37

    :cond_23
    const v1, 0x3f6147ae  # 0.88f

    invoke-virtual {p0, v1}, Landroid/view/View;->setAlpha(F)V

    const v1, 0x3f7ae148  # 0.98f

    invoke-virtual {p0, v1}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {p0, v1}, Landroid/view/View;->setScaleY(F)V

    const/high16 v1, -0x3f000000  # -8.0f

    invoke-virtual {p0, v1}, Landroid/view/View;->setTranslationY(F)V

    :goto_37
    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const-wide/16 v0, 0xdc

    invoke-virtual {p0, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    sget-object v0, Linv/exe/systemui/qs/ui/InvSmoothLayout;->EASE_OUT:Landroid/view/animation/PathInterpolator;

    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/ViewPropertyAnimator;->start()V

    return-void
.end method

.method public static play(Landroid/view/View;Ljava/util/Map;)V
    .registers 5

    if-eqz p0, :cond_15

    if-eqz p1, :cond_15

    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_b

    goto :goto_15

    :cond_b
    new-instance v0, Linv/exe/systemui/qs/ui/InvSmoothLayout$1;

    invoke-direct {v0, p1}, Linv/exe/systemui/qs/ui/InvSmoothLayout$1;-><init>(Ljava/util/Map;)V

    const-wide/16 v1, 0x60

    invoke-virtual {p0, v0, v1, v2}, Landroid/view/View;->postOnAnimationDelayed(Ljava/lang/Runnable;J)V

    :cond_15
    :goto_15
    return-void
.end method

.method public static playNow(Ljava/util/Map;)V
    .registers 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Landroid/view/View;",
            "Landroid/graphics/Rect;",
            ">;)V"
        }
    .end annotation

    if-eqz p0, :cond_f9

    invoke-interface {p0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_9

    return-void

    :cond_9
    const/4 v0, 0x2

    new-array v1, v0, [I

    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_14
    :goto_14
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-nez v2, :cond_1b

    return-void

    :cond_1b
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/view/View;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/graphics/Rect;

    if-eqz v3, :cond_14

    if-eqz v2, :cond_14

    invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v4

    if-eqz v4, :cond_14

    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    move-result v4

    const/16 v5, 0x8

    if-ne v4, v5, :cond_40

    goto :goto_14

    :cond_40
    invoke-virtual {v3, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    invoke-virtual {v3}, Landroid/view/View;->getWidth()I

    move-result v4

    const/4 v5, 0x1

    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    move-result v6

    invoke-static {v5, v6}, Ljava/lang/Math;->max(II)I

    move-result v6

    iget v7, v2, Landroid/graphics/Rect;->left:I

    const/4 v8, 0x0

    aget v9, v1, v8

    sub-int/2addr v7, v9

    int-to-float v7, v7

    iget v9, v2, Landroid/graphics/Rect;->top:I

    aget v10, v1, v5

    sub-int/2addr v9, v10

    int-to-float v9, v9

    const/high16 v11, 0x3f800000  # 1.0f

    invoke-static {v7}, Ljava/lang/Math;->abs(F)F

    move-result v10

    cmpl-float v10, v10, v11

    if-gez v10, :cond_75

    invoke-static {v9}, Ljava/lang/Math;->abs(F)F

    move-result v10

    cmpl-float v10, v10, v11

    if-gez v10, :cond_75

    move v10, v8

    goto :goto_76

    :cond_75
    move v10, v5

    :goto_76
    invoke-virtual {v2}, Landroid/graphics/Rect;->width()I

    move-result v12

    sub-int v13, v12, v4

    invoke-static {v13}, Ljava/lang/Math;->abs(I)I

    move-result v13

    if-ge v13, v0, :cond_90

    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    move-result v14

    sub-int v13, v14, v6

    invoke-static {v13}, Ljava/lang/Math;->abs(I)I

    move-result v13

    if-ge v13, v0, :cond_90

    move v5, v8

    goto :goto_91

    :cond_90
    move v5, v5

    :goto_91
    move v5, v8

    if-nez v10, :cond_98

    if-nez v5, :cond_98

    goto/16 :goto_14

    :cond_98
    invoke-virtual {v3}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v13

    invoke-virtual {v13}, Landroid/view/ViewPropertyAnimator;->cancel()V

    if-eqz v10, :cond_a8

    invoke-virtual {v3, v7}, Landroid/view/View;->setTranslationX(F)V

    invoke-virtual {v3, v9}, Landroid/view/View;->setTranslationY(F)V

    goto :goto_af

    :cond_a8
    const/4 v7, 0x0

    invoke-virtual {v3, v7}, Landroid/view/View;->setTranslationX(F)V

    invoke-virtual {v3, v7}, Landroid/view/View;->setTranslationY(F)V

    :goto_af
    if-eqz v5, :cond_cd

    const/4 v7, 0x0

    invoke-virtual {v3, v7}, Landroid/view/View;->setPivotX(F)V

    invoke-virtual {v3, v7}, Landroid/view/View;->setPivotY(F)V

    invoke-virtual {v2}, Landroid/graphics/Rect;->width()I

    move-result v12

    int-to-float v12, v12

    int-to-float v13, v4

    div-float/2addr v12, v13

    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    move-result v13

    int-to-float v13, v13

    int-to-float v14, v6

    div-float/2addr v13, v14

    invoke-virtual {v3, v12}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v3, v13}, Landroid/view/View;->setScaleY(F)V

    goto :goto_d3

    :cond_cd
    invoke-virtual {v3, v11}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v3, v11}, Landroid/view/View;->setScaleY(F)V

    :goto_d3
    invoke-virtual {v3}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/view/ViewPropertyAnimator;->translationX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v2

    invoke-virtual {v2, v3}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v2

    invoke-virtual {v2, v11}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v2

    invoke-virtual {v2, v11}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v2

    const-wide/16 v3, 0x104

    invoke-virtual {v2, v3, v4}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v2

    sget-object v3, Linv/exe/systemui/qs/ui/InvSmoothLayout;->EASE_OUT:Landroid/view/animation/PathInterpolator;

    invoke-virtual {v2, v3}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/ViewPropertyAnimator;->start()V

    goto/16 :goto_14

    :cond_f9
    return-void
.end method

.method public static pulse(Landroid/view/View;)V
    .registers 3

    if-nez p0, :cond_3

    return-void

    .line 111
    :cond_3
    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->cancel()V

    const v0, 0x3f47ae14  # 0.78f

    .line 112
    invoke-virtual {p0, v0}, Landroid/view/View;->setAlpha(F)V

    .line 113
    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const/high16 v0, 0x3f800000  # 1.0f

    .line 114
    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const-wide/16 v0, 0x8c

    .line 115
    invoke-virtual {p0, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    .line 116
    sget-object v0, Linv/exe/systemui/qs/ui/InvSmoothLayout;->EASE_OUT:Landroid/view/animation/PathInterpolator;

    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    .line 117
    invoke-virtual {p0}, Landroid/view/ViewPropertyAnimator;->start()V

    return-void
.end method

.method public static sectionTransition(Landroid/view/View;)V
    .registers 4

    if-nez p0, :cond_3

    return-void

    :cond_3
    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->cancel()V

    const v0, 0x3f666666  # 0.9f

    invoke-virtual {p0, v0}, Landroid/view/View;->setAlpha(F)V

    const/high16 v0, 0x40c00000  # 6.0f

    invoke-virtual {p0, v0}, Landroid/view/View;->setTranslationY(F)V

    const/high16 v0, 0x3f800000  # 1.0f

    invoke-virtual {p0, v0}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setScaleY(F)V

    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const/high16 v0, 0x3f800000  # 1.0f

    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const-wide/16 v0, 0xb4

    invoke-virtual {p0, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    sget-object v0, Linv/exe/systemui/qs/ui/InvSmoothLayout;->EASE_OUT:Landroid/view/animation/PathInterpolator;

    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/ViewPropertyAnimator;->start()V

    return-void
.end method

.method public static softRefresh(Landroid/view/View;)V
    .registers 3

    if-nez p0, :cond_3

    return-void

    .line 122
    :cond_3
    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->cancel()V

    const/high16 v0, 0x3f800000  # 1.0f

    .line 123
    invoke-virtual {p0, v0}, Landroid/view/View;->setScaleX(F)V

    .line 124
    invoke-virtual {p0, v0}, Landroid/view/View;->setScaleY(F)V

    const/4 v1, 0x0

    .line 125
    invoke-virtual {p0, v1}, Landroid/view/View;->setTranslationX(F)V

    .line 126
    invoke-virtual {p0, v1}, Landroid/view/View;->setTranslationY(F)V

    const v1, 0x3f6147ae  # 0.88f

    .line 127
    invoke-virtual {p0, v1}, Landroid/view/View;->setAlpha(F)V

    .line 128
    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    .line 129
    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const-wide/16 v0, 0x96

    .line 130
    invoke-virtual {p0, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    .line 131
    sget-object v0, Linv/exe/systemui/qs/ui/InvSmoothLayout;->EASE_OUT:Landroid/view/animation/PathInterpolator;

    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    .line 132
    invoke-virtual {p0}, Landroid/view/ViewPropertyAnimator;->start()V

    return-void
.end method
