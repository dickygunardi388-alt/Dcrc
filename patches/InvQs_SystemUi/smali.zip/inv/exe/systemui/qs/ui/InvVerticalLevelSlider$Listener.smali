.class public interface abstract Linv/exe/systemui/qs/ui/InvVerticalLevelSlider$Listener;
.super Ljava/lang/Object;
.source "VerticalLevelSlider.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Listener"
.end annotation


# virtual methods
.method public abstract onChanged(I)V
.end method
