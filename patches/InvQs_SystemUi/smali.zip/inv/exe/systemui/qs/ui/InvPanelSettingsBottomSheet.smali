.class public Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;
.super Landroid/widget/FrameLayout;
.source "PanelSettingsBottomSheet.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$Change;,
        Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$TileGroup;
    }
.end annotation


# static fields
.field private static volatile synthetic $SWITCH_TABLE$inv$exe$systemui$qs$model$InvControlId:[I = null

.field private static final GOOGLE_SANS:Landroid/graphics/Typeface;

.field private static final GOOGLE_SANS_MEDIUM:Landroid/graphics/Typeface;

.field private static final TAG:Ljava/lang/String; = "inv_settings_sheet"


# instance fields
.field private anchorHeight:I

.field private anchorWidth:I

.field private brightness:Linv/exe/systemui/qs/controller/InvBrightnessController;

.field private closing:Z

.field private controls:Landroid/widget/GridLayout;

.field private ctrlCols:Landroid/widget/SeekBar;

.field private ctrlRowText:Landroid/widget/TextView;

.field private ctrlRows:Landroid/widget/SeekBar;

.field private ctrlText:Landroid/widget/TextView;

.field private labels:Landroid/widget/Switch;

.field private mediaPreview:Landroid/view/View;

.field private mediaSession:Linv/exe/systemui/qs/controller/InvMediaSessionController;

.field private onDismiss:Ljava/lang/Runnable;

.field private repo:Linv/exe/systemui/qs/model/InvPanelRepository;

.field private rowText:Landroid/widget/TextView;

.field private strip:Landroid/widget/LinearLayout;

.field private tileCols:Landroid/widget/SeekBar;

.field private tileRows:Landroid/widget/SeekBar;

.field private tileText:Landroid/widget/TextView;

.field private tiles:Landroid/widget/LinearLayout;

.field private volume:Linv/exe/systemui/qs/controller/InvVolumeController;


# direct methods
.method public static synthetic $SWITCH_TABLE$inv$exe$systemui$qs$model$InvControlId()[I
    .registers 3

    .line 37
    sget-object v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->$SWITCH_TABLE$inv$exe$systemui$qs$model$InvControlId:[I

    if-eqz v0, :cond_5

    return-object v0

    :cond_5
    invoke-static {}, Linv/exe/systemui/qs/model/InvControlId;->values()[Linv/exe/systemui/qs/model/InvControlId;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [I

    :try_start_c
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->AUTO_BRIGHTNESS:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/16 v2, 0x8

    aput v2, v0, v1
    :try_end_16
    .catch Ljava/lang/NoSuchFieldError; {:try_start_c .. :try_end_16} :catch_16

    :catch_16
    :try_start_16
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->BLUETOOTH:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/4 v2, 0x2

    aput v2, v0, v1
    :try_end_1f
    .catch Ljava/lang/NoSuchFieldError; {:try_start_16 .. :try_end_1f} :catch_1f

    :catch_1f
    :try_start_1f
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->BRIGHTNESS_H:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/4 v2, 0x4

    aput v2, v0, v1
    :try_end_28
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1f .. :try_end_28} :catch_28

    :catch_28
    :try_start_28
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->BRIGHTNESS_V:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/4 v2, 0x6

    aput v2, v0, v1
    :try_end_31
    .catch Ljava/lang/NoSuchFieldError; {:try_start_28 .. :try_end_31} :catch_31

    :catch_31
    :try_start_31
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->INTERNET:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/4 v2, 0x1

    aput v2, v0, v1
    :try_end_3a
    .catch Ljava/lang/NoSuchFieldError; {:try_start_31 .. :try_end_3a} :catch_3a

    :catch_3a
    :try_start_3a
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->MEDIA:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/4 v2, 0x3

    aput v2, v0, v1
    :try_end_43
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3a .. :try_end_43} :catch_43

    :catch_43
    :try_start_43
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->MUTE:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/16 v2, 0x9

    aput v2, v0, v1
    :try_end_4d
    .catch Ljava/lang/NoSuchFieldError; {:try_start_43 .. :try_end_4d} :catch_4d

    :catch_4d
    :try_start_4d
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->RINGER:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/16 v2, 0xa

    aput v2, v0, v1
    :try_end_57
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4d .. :try_end_57} :catch_57

    :catch_57
    :try_start_57
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->VOLUME_H:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/4 v2, 0x5

    aput v2, v0, v1
    :try_end_60
    .catch Ljava/lang/NoSuchFieldError; {:try_start_57 .. :try_end_60} :catch_60

    :catch_60
    :try_start_60
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->VOLUME_V:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/4 v2, 0x7

    aput v2, v0, v1
    :try_end_69
    .catch Ljava/lang/NoSuchFieldError; {:try_start_60 .. :try_end_69} :catch_69

    :catch_69
    :try_start_69
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->DATA_USAGE:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/16 v2, 0xb

    aput v2, v0, v1
    :try_end_73
    .catch Ljava/lang/NoSuchFieldError; {:try_start_69 .. :try_end_73} :catch_73

    :catch_73
    :try_start_73
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->BATTERY_VIEW:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/16 v2, 0xc

    aput v2, v0, v1
    :try_end_7d
    .catch Ljava/lang/NoSuchFieldError; {:try_start_73 .. :try_end_7d} :catch_7d

    :catch_7d
    :try_start_7d
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->FPS_INFO:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/16 v2, 0xd

    aput v2, v0, v1
    :try_end_87
    .catch Ljava/lang/NoSuchFieldError; {:try_start_7d .. :try_end_87} :catch_87

    :catch_87
    :try_start_87
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->CUSTOM_NAME:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/16 v2, 0xe

    aput v2, v0, v1
    :try_end_91
    .catch Ljava/lang/NoSuchFieldError; {:try_start_87 .. :try_end_91} :catch_91

    :catch_91
    :try_start_91
    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->CUSTOM_IMAGE:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v1

    const/16 v2, 0xf

    aput v2, v0, v1
    :try_end_9b
    .catch Ljava/lang/NoSuchFieldError; {:try_start_91 .. :try_end_9b} :catch_9b

    :catch_9b
    sput-object v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->$SWITCH_TABLE$inv$exe$systemui$qs$model$InvControlId:[I

    return-object v0
.end method

.method public static synthetic $r8$lambda$eRtjxonZlMQ9QliABxeD9Kl1ZXM(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V
    .registers 1

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->buildControlGrid()V

    return-void
.end method

.method public static synthetic $r8$lambda$y0t_vha19vnI_EOFESLPQWodxuQ(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V
    .registers 1

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->buildTileGrid()V

    return-void
.end method

.method static constructor <clinit>()V
    .registers 2

    .line 53
    const-string v0, "google-sans"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v0

    sput-object v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->GOOGLE_SANS:Landroid/graphics/Typeface;

    .line 54
    const-string v0, "google-sans-medium"

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v0

    sput-object v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->GOOGLE_SANS_MEDIUM:Landroid/graphics/Typeface;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 56
    invoke-direct {p0, p1, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4

    const/4 v0, 0x0

    .line 57
    invoke-direct {p0, p1, p2, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4

    .line 59
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 60
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->init()V

    return-void
.end method

.method public static synthetic access$0(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V
    .registers 1

    .line 162
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->animateIn()V

    return-void
.end method

.method public static synthetic access$1(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)Landroid/view/View;
    .registers 1

    .line 42
    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->mediaPreview:Landroid/view/View;

    return-object p0
.end method

.method public static synthetic access$2(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)Linv/exe/systemui/qs/controller/InvMediaSessionController;
    .registers 1

    .line 41
    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->mediaSession:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    return-object p0
.end method

.method public static synthetic access$3(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)Linv/exe/systemui/qs/model/InvPanelRepository;
    .registers 1

    .line 38
    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    return-object p0
.end method

.method public static synthetic access$4(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)Ljava/lang/Runnable;
    .registers 1

    .line 48
    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->onDismiss:Ljava/lang/Runnable;

    return-object p0
.end method

.method public static synthetic access$5(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;Ljava/lang/Runnable;)V
    .registers 2

    .line 48
    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->onDismiss:Ljava/lang/Runnable;

    return-void
.end method

.method private addControlCell(Linv/exe/systemui/qs/model/InvControlId;IIIIII)V
    .registers 24

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p3

    move/from16 v3, p4

    move/from16 v4, p5

    move/from16 v5, p7

    const/4 v10, 0x0

    invoke-static {v10, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    const/4 v10, 0x1

    invoke-static {v10, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    const/4 v10, 0x4

    invoke-static {v10, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    const/4 v10, 0x1

    invoke-static {v10, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    const/4 v10, 0x3

    invoke-static {v10, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    const/4 v10, 0x0

    invoke-static {v10, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    mul-int v6, p6, v3

    add-int/lit8 v7, v3, -0x1

    mul-int/2addr v7, v5

    add-int/2addr v6, v7

    mul-int v7, p6, v4

    add-int/lit8 v8, v4, -0x1

    mul-int/2addr v8, v5

    add-int/2addr v7, v8

    const/16 v8, 0x2e

    .line 322
    invoke-direct {v0, v8}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v8

    .line 323
    new-instance v9, Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object v10

    invoke-direct {v9, v10}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    const/4 v10, 0x0

    .line 324
    invoke-virtual {v9, v10}, Landroid/widget/FrameLayout;->setClipChildren(Z)V

    .line 326
    invoke-direct {v0, v1, v3, v4}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->previewControl(Linv/exe/systemui/qs/model/InvControlId;II)Landroid/view/View;

    move-result-object v11

    .line 327
    new-instance v12, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v13, 0x31

    invoke-direct {v12, v6, v7, v13}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v9, v11, v12}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 329
    new-instance v11, Landroid/widget/TextView;

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object v12

    invoke-direct {v11, v12}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 330
    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->labelText()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 331
    const-string v12, "inv_text_secondary"

    invoke-static {v12}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v12

    invoke-direct {v0, v12}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getColor(I)I

    move-result v12

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextColor(I)V

    const-string v12, "inv_panel_settings_toast_text_size"

    .line 332
    invoke-direct {v0, v11, v12}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->setTextSizeDimen(Landroid/widget/TextView;Ljava/lang/String;)V

    .line 333
    sget-object v12, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->GOOGLE_SANS:Landroid/graphics/Typeface;

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const/16 v12, 0x11

    .line 334
    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setGravity(I)V

    .line 335
    invoke-virtual {v11, v10}, Landroid/widget/TextView;->setSingleLine(Z)V

    const/4 v12, 0x2

    .line 336
    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 337
    invoke-virtual {v11, v10}, Landroid/widget/TextView;->setIncludeFontPadding(Z)V

    .line 338
    sget-object v12, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 339
    new-instance v12, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v13, 0x51

    invoke-direct {v12, v6, v8, v13}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v9, v11, v12}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 341
    new-instance v11, Landroid/widget/ImageView;

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object v12

    invoke-direct {v11, v12}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 342
    const-string v12, "inv_bg_badge"

    invoke-static {v12}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v11, v12}, Landroid/widget/ImageView;->setBackgroundResource(I)V

    .line 343
    const-string v12, "inv_ic_add"

    invoke-static {v12}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v11, v12}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 344
    const-string v12, "inv_edit_badge_icon_tint"

    invoke-static {v12}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v12

    invoke-direct {v0, v12}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getColor(I)I

    move-result v12

    invoke-static {v12}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v12

    invoke-virtual {v11, v12}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    const/4 v12, 0x3

    .line 345
    invoke-direct {v0, v12}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v13

    invoke-direct {v0, v12}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v14

    invoke-direct {v0, v12}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v15

    invoke-direct {v0, v12}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v12

    invoke-virtual {v11, v13, v14, v15, v12}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 346
    const-string v12, "Add"

    invoke-virtual {v11, v12}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 347
    new-instance v12, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda3;

    invoke-direct {v12, v0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda3;-><init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;Linv/exe/systemui/qs/model/InvControlId;)V

    invoke-virtual {v11, v12}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 356
    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v12, 0x16

    invoke-direct {v0, v12}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v13

    invoke-direct {v0, v12}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v12

    const v14, 0x800035

    invoke-direct {v1, v13, v12, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v9, v11, v1}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 358
    new-instance v1, Landroid/widget/GridLayout$LayoutParams;

    invoke-direct {v1}, Landroid/widget/GridLayout$LayoutParams;-><init>()V

    move/from16 v10, p2

    const/4 v11, 0x0

    invoke-static {v11, v10}, Ljava/lang/Math;->max(II)I

    move-result v10

    invoke-static {v10, v4}, Landroid/widget/GridLayout;->spec(II)Landroid/widget/GridLayout$Spec;

    move-result-object v11

    iput-object v11, v1, Landroid/widget/GridLayout$LayoutParams;->rowSpec:Landroid/widget/GridLayout$Spec;

    invoke-static {v2, v3}, Landroid/widget/GridLayout;->spec(II)Landroid/widget/GridLayout$Spec;

    move-result-object v11

    iput-object v11, v1, Landroid/widget/GridLayout$LayoutParams;->columnSpec:Landroid/widget/GridLayout$Spec;

    .line 360
    iput v6, v1, Landroid/widget/GridLayout$LayoutParams;->width:I

    add-int/2addr v7, v8

    .line 361
    iput v7, v1, Landroid/widget/GridLayout$LayoutParams;->height:I

    .line 362
    add-int v10, v2, v3

    const/4 v11, 0x4

    if-ge v10, v11, :cond_123

    iput v5, v1, Landroid/widget/GridLayout$LayoutParams;->rightMargin:I

    goto :goto_126

    :cond_123
    const/4 v10, 0x0

    iput v10, v1, Landroid/widget/GridLayout$LayoutParams;->rightMargin:I

    .line 363
    :goto_126
    iput v5, v1, Landroid/widget/GridLayout$LayoutParams;->bottomMargin:I

    .line 364
    iget-object v0, v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->controls:Landroid/widget/GridLayout;

    invoke-virtual {v0, v9, v1}, Landroid/widget/GridLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private addEmptyTilesMessage()V
    .registers 5

    .line 477
    new-instance v0, Landroid/widget/TextView;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 478
    const-string v1, "Semua tile sudah masuk panel"

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 479
    const-string v1, "inv_text_secondary"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v1

    invoke-direct {p0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    const-string v1, "inv_panel_settings_toast_text_size"

    .line 480
    invoke-direct {p0, v0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->setTextSizeDimen(Landroid/widget/TextView;Ljava/lang/String;)V

    .line 481
    sget-object v1, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->GOOGLE_SANS:Landroid/graphics/Typeface;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 482
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    const/4 v3, -0x2

    invoke-direct {v1, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v2, 0x4

    .line 483
    invoke-direct {p0, v2}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v2

    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 484
    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tiles:Landroid/widget/LinearLayout;

    invoke-virtual {p0, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private addNativeSpecCell(Landroid/widget/GridLayout;Ljava/lang/String;III)V
    .registers 11

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const-string v1, "inv_item_catalog_tile"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->layout(Ljava/lang/String;)I

    move-result v1

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    const-string v1, "tile_body"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/FrameLayout;

    const/16 v2, 0x28

    invoke-direct {p0, v2}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v2

    const/16 v3, 0x8

    invoke-direct {p0, v3}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v3

    sub-int v3, p5, v3

    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    move-result v2

    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, 0x1

    invoke-direct {v3, v2, v2, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v1, v3}, Landroid/widget/FrameLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const-string v1, "icon"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageView;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const-string v4, "inv_qs_tile_icon_size"

    invoke-static {v4}, Linv/exe/systemui/qs/core/InvRes;->dimen(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v3

    int-to-float v2, v2

    const v4, 0x3ecccccd  # 0.4f

    mul-float/2addr v2, v4

    float-to-int v2, v2

    invoke-static {v3, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v4, 0x11

    invoke-direct {v3, v2, v2, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {p0, p2}, Linv/exe/systemui/qs/nativeqs/InvNativeTileCatalogRes;->icon(Landroid/view/View;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    if-eqz v2, :cond_72

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_76

    :cond_72
    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    :goto_76
    const-string v2, "inv_icon_primary"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v2

    invoke-direct {p0, v2}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getColor(I)I

    move-result v2

    invoke-static {v2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    const-string v1, "tile_title"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    invoke-static {p0, p2}, Linv/exe/systemui/qs/nativeqs/InvNativeTileCatalogRes;->label(Landroid/view/View;Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v1, "btn_add"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v2, Linv/exe/systemui/qs/nativeqs/InvNativeTileAddClickListener;

    invoke-direct {v2, p0, p2}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAddClickListener;-><init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v1, Landroid/widget/GridLayout$LayoutParams;

    invoke-direct {v1}, Landroid/widget/GridLayout$LayoutParams;-><init>()V

    iput p5, v1, Landroid/widget/GridLayout$LayoutParams;->width:I

    const/4 v2, -0x2

    iput v2, v1, Landroid/widget/GridLayout$LayoutParams;->height:I

    invoke-virtual {p1, v0, v1}, Landroid/widget/GridLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private addTileGroupHeader(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$TileGroup;Z)V
    .registers 9

    .line 456
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v1, 0x10

    .line 457
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/4 v1, 0x0

    .line 458
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 459
    new-instance v1, Landroid/widget/ImageView;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 460
    iget v2, p1, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$TileGroup;->iconRes:I

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 461
    const-string v2, "inv_icon_primary"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v2

    invoke-direct {p0, v2}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getColor(I)I

    move-result v2

    invoke-static {v2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    .line 462
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x12

    invoke-direct {p0, v3}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v4

    invoke-direct {p0, v3}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v5

    invoke-direct {v2, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 463
    new-instance v1, Landroid/widget/TextView;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 464
    iget-object p1, p1, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$TileGroup;->titleText:Ljava/lang/String;

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 465
    const-string p1, "inv_text_primary"

    invoke-static {p1}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result p1

    invoke-direct {p0, p1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getColor(I)I

    move-result p1

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setTextColor(I)V

    const-string p1, "inv_panel_settings_setting_label_text_size"

    .line 466
    invoke-direct {p0, v1, p1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->setTextSizeDimen(Landroid/widget/TextView;Ljava/lang/String;)V

    .line 467
    sget-object p1, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->GOOGLE_SANS_MEDIUM:Landroid/graphics/Typeface;

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 468
    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x2

    invoke-direct {p1, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v4, 0x8

    .line 469
    invoke-direct {p0, v4}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v4

    invoke-virtual {p1, v4}, Landroid/widget/LinearLayout$LayoutParams;->setMarginStart(I)V

    .line 470
    invoke-virtual {v0, v1, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 471
    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    invoke-direct {p1, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    if-eqz p2, :cond_88

    .line 472
    invoke-direct {p0, v3}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result p2

    iput p2, p1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 473
    :cond_88
    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tiles:Landroid/widget/LinearLayout;

    invoke-virtual {p0, v0, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private animateIn()V
    .registers 4

    .line 163
    const-string v0, "bottom_sheet_root"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewById(I)Landroid/view/View;

    move-result-object v0

    .line 164
    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const/high16 v1, 0x3f800000  # 1.0f

    invoke-virtual {p0, v1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const-wide/16 v1, 0xa0

    invoke-virtual {p0, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/ViewPropertyAnimator;->start()V

    if-eqz v0, :cond_31

    .line 165
    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const-wide/16 v0, 0x12c

    invoke-virtual {p0, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/ViewPropertyAnimator;->start()V

    :cond_31
    return-void
.end method

.method private applyResponsiveSheet()V
    .registers 14

    const-string v0, "bottom_sheet_root"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_5f

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v2

    iget v2, v2, Landroid/content/res/Configuration;->orientation:I

    iget v3, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->anchorWidth:I

    if-lez v3, :cond_1b

    goto :goto_21

    :cond_1b
    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v3

    iget v3, v3, Landroid/util/DisplayMetrics;->widthPixels:I

    :goto_21
    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v4

    iget v4, v4, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-ne v2, v6, :cond_33

    mul-int/lit8 v2, v3, 0x64

    mul-int/lit8 v6, v4, 0x41

    if-ge v2, v6, :cond_32

    goto :goto_33

    :cond_32
    const/4 v5, 0x1

    :cond_33
    :goto_33
    new-instance v6, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v7, -0x1

    const/4 v8, -0x1

    const/16 v9, 0x50

    if-eqz v5, :cond_51

    mul-int/lit8 v10, v4, 0x3c

    div-int/lit8 v10, v10, 0x64

    const/16 v11, 0x18

    invoke-direct {p0, v11}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v11

    const/16 v12, 0x15

    invoke-direct {v6, v10, v7, v12}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    iput v11, v6, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    iput v11, v6, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    iput v11, v6, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    goto :goto_5c

    :cond_51
    invoke-direct {v6, v7, v7, v9}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    const/16 v10, 0x5c

    invoke-direct {p0, v10}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v10

    iput v10, v6, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    :goto_5c
    invoke-virtual {v0, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_5f
    return-void
.end method

.method private bind()V
    .registers 5

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->labels:Landroid/widget/Switch;

    iget-object v1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->getShowTileLabels()Z

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Switch;->setChecked(Z)V

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->ctrlCols:Landroid/widget/SeekBar;

    iget-object v1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlColumns()I

    move-result v1

    const-string v2, "inv_panel_settings_control_grid_columns_min"

    const/4 v3, 0x2

    invoke-static {v2, v3}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v2

    sub-int/2addr v1, v2

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setProgress(I)V

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->ctrlRows:Landroid/widget/SeekBar;

    iget-object v1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlRows()I

    move-result v1

    const-string v2, "inv_panel_settings_control_grid_rows_min"

    const/4 v3, 0x1

    invoke-static {v2, v3}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v2

    sub-int/2addr v1, v2

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setProgress(I)V

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tileCols:Landroid/widget/SeekBar;

    iget-object v1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->getTileColumns()I

    move-result v1

    const-string v2, "inv_panel_settings_tile_grid_columns_min"

    const/4 v3, 0x2

    invoke-static {v2, v3}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v2

    sub-int/2addr v1, v2

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setProgress(I)V

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tileRows:Landroid/widget/SeekBar;

    iget-object v1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->getTileRows()I

    move-result v1

    const-string v2, "inv_panel_settings_tile_grid_rows_min"

    const/4 v3, 0x1

    invoke-static {v2, v3}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v2

    sub-int/2addr v1, v2

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setProgress(I)V

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->text()V

    return-void
.end method

.method private buildControlGrid()V
    .registers 16

    .line 286
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->controls:Landroid/widget/GridLayout;

    invoke-virtual {v0}, Landroid/widget/GridLayout;->getWidth()I

    move-result v0

    if-gtz v0, :cond_13

    .line 288
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->controls:Landroid/widget/GridLayout;

    new-instance v1, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda1;-><init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V

    invoke-virtual {v0, v1}, Landroid/widget/GridLayout;->post(Ljava/lang/Runnable;)Z

    return-void

    .line 292
    :cond_13
    const/4 v2, 0x4

    const/16 v3, 0x8

    invoke-direct {p0, v3}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v10

    const/4 v3, 0x3

    mul-int v3, v10, v3

    sub-int v3, v0, v3

    const/4 v4, 0x4

    div-int v9, v3, v4

    const/4 v3, 0x1

    invoke-static {v3, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    const/4 v1, 0x0

    .line 294
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->controls:Landroid/widget/GridLayout;

    invoke-virtual {v0, v2}, Landroid/widget/GridLayout;->setColumnCount(I)V

    .line 295
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->controls:Landroid/widget/GridLayout;

    invoke-virtual {v0, v1}, Landroid/widget/GridLayout;->setUseDefaultMargins(Z)V

    .line 296
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->controls:Landroid/widget/GridLayout;

    invoke-virtual {v0}, Landroid/widget/GridLayout;->removeAllViews()V

    .line 298
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 299
    invoke-static {}, Linv/exe/systemui/qs/model/InvControlId;->all()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_44
    :goto_44
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-nez v4, :cond_c8

    new-instance v3, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$ControlCatalogComparator;

    invoke-direct {v3}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$ControlCatalogComparator;-><init>()V

    invoke-static {v0, v3}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 301
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    const/4 v4, 0x3

    mul-int/2addr v3, v4

    add-int/2addr v3, v4

    invoke-static {v4, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    const/4 v4, 0x2

    new-array v4, v4, [I

    const/4 v11, 0x1

    aput v2, v4, v11

    aput v3, v4, v1

    sget-object v3, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    invoke-static {v3, v4}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v3

    move-object v12, v3

    check-cast v12, [[Z

    .line 303
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v13

    move v4, v1

    :goto_73
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-nez v0, :cond_7a

    .line 316
    return-void

    .line 303
    :cond_7a
    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Linv/exe/systemui/qs/model/InvControlId;

    .line 304
    invoke-static {v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$ControlCatalogComparator;->previewSpanW(Linv/exe/systemui/qs/model/InvControlId;)I

    move-result v3

    invoke-static {v11, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    invoke-static {v2, v3}, Ljava/lang/Math;->min(II)I

    move-result v7

    .line 305
    invoke-static {v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$ControlCatalogComparator;->previewSpanH(Linv/exe/systemui/qs/model/InvControlId;)I

    move-result v3

    invoke-static {v11, v3}, Ljava/lang/Math;->max(II)I

    move-result v8

    const/4 v3, 0x3

    invoke-static {v3, v8}, Ljava/lang/Math;->min(II)I

    move-result v8

    move v5, v1

    .line 307
    :goto_9a
    array-length v3, v12

    sub-int/2addr v3, v8

    if-lt v5, v3, :cond_9f

    goto :goto_73

    :cond_9f
    move v6, v1

    :goto_a0
    sub-int v3, v2, v7

    if-le v6, v3, :cond_a7

    add-int/lit8 v5, v5, 0x1

    goto :goto_9a

    .line 308
    :cond_a7
    invoke-static {v12, v5, v6, v7, v8}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->free([[ZIIII)Z

    move-result v3

    if-eqz v3, :cond_bd

    .line 309
    invoke-static {v12, v5, v6, v7, v8}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->mark([[ZIIII)V

    add-int v3, v5, v8

    .line 310
    invoke-static {v4, v3}, Ljava/lang/Math;->max(II)I

    move-result v14

    move-object v3, p0

    move-object v4, v0

    .line 311
    invoke-direct/range {v3 .. v10}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->addControlCell(Linv/exe/systemui/qs/model/InvControlId;IIIIII)V

    move v4, v14

    goto :goto_73

    :cond_bd
    move v14, v6

    move-object v6, v0

    move v0, v14

    move v14, v5

    add-int/lit8 v0, v0, 0x1

    move-object v5, v6

    move v6, v0

    move-object v0, v5

    move v5, v14

    goto :goto_a0

    .line 299
    :cond_c8
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Linv/exe/systemui/qs/model/InvControlId;

    iget-object v6, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v6}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControls()Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_44

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto/16 :goto_44
.end method

.method private buildTileGrid()V
    .registers 21

    move-object/from16 v15, p0

    iget-object v0, v15, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tiles:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getWidth()I

    move-result v0

    if-gtz v0, :cond_15

    iget-object v0, v15, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tiles:Landroid/widget/LinearLayout;

    new-instance v1, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda2;

    invoke-direct {v1, v15}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda2;-><init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_15
    const/16 v1, 0x28

    invoke-direct {v15, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v1

    const/4 v6, 0x4

    div-int/2addr v0, v6

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v7

    iget-object v0, v15, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tiles:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    const/4 v0, 0x0

    invoke-static {v15, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->allSpecs(Landroid/view/View;I)Ljava/util/ArrayList;

    move-result-object v8

    invoke-static {v15, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->visibleSpecs(Landroid/view/View;I)Ljava/util/ArrayList;

    move-result-object v9

    const/4 v10, 0x0

    const/4 v11, 0x0

    :goto_31
    const/4 v0, 0x4

    if-lt v11, v0, :cond_36

    goto/16 :goto_af

    :cond_36
    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v13, 0x0

    :goto_39
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lt v13, v0, :cond_41

    goto/16 :goto_ab

    :cond_41
    invoke-virtual {v8, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    if-eqz v12, :cond_a7

    invoke-static {v9, v12}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->listContainsSpec(Ljava/util/ArrayList;Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_a7

    const-string v0, "custom("

    invoke-virtual {v12, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_59

    goto/16 :goto_a7

    :cond_59
    invoke-static {v15, v12}, Linv/exe/systemui/qs/nativeqs/InvNativeTileCatalogRes;->icon(Landroid/view/View;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v19

    invoke-static {v12}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->groupRank(Ljava/lang/String;)I

    move-result v14

    if-ne v14, v11, :cond_a7

    if-nez v3, :cond_9e

    invoke-direct {v15, v11}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->nativeTileGroup(I)Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$TileGroup;

    move-result-object v0

    if-lez v10, :cond_6d

    const/4 v1, 0x1

    goto :goto_6e

    :cond_6d
    const/4 v1, 0x0

    :goto_6e
    invoke-direct {v15, v0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->addTileGroupHeader(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$TileGroup;Z)V

    new-instance v3, Landroid/widget/GridLayout;

    invoke-virtual {v15}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {v3, v0}, Landroid/widget/GridLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v3, v6}, Landroid/widget/GridLayout;->setColumnCount(I)V

    const/4 v0, 0x0

    invoke-virtual {v3, v0}, Landroid/widget/GridLayout;->setAlignmentMode(I)V

    invoke-virtual {v3, v0}, Landroid/widget/GridLayout;->setClipChildren(Z)V

    invoke-virtual {v3, v0}, Landroid/widget/GridLayout;->setClipToPadding(Z)V

    invoke-virtual {v3, v0}, Landroid/widget/GridLayout;->setUseDefaultMargins(Z)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v0, -0x1

    const/4 v2, -0x2

    invoke-direct {v1, v0, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v0, 0xa

    invoke-direct {v15, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v0

    iput v0, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    iget-object v0, v15, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tiles:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v3, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_9e
    move-object v2, v15

    move-object v4, v12

    invoke-direct/range {v2 .. v7}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->addNativeSpecCell(Landroid/widget/GridLayout;Ljava/lang/String;III)V

    add-int/lit8 v5, v5, 0x1

    add-int/lit8 v10, v10, 0x1

    :cond_a7
    :goto_a7
    add-int/lit8 v13, v13, 0x1

    goto/16 :goto_39

    :goto_ab
    add-int/lit8 v11, v11, 0x1

    goto/16 :goto_31

    :goto_af
    if-nez v10, :cond_b9

    iget-object v0, v15, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tiles:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    invoke-direct {v15}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->addEmptyTilesMessage()V

    :cond_b9
    return-void
.end method

.method private catalog()V
    .registers 3

    const/4 v0, 0x0

    .line 278
    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->mediaPreview:Landroid/view/View;

    .line 279
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->controls:Landroid/widget/GridLayout;

    invoke-virtual {v0}, Landroid/widget/GridLayout;->removeAllViews()V

    .line 280
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tiles:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 281
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->controls:Landroid/widget/GridLayout;

    new-instance v1, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda1;-><init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V

    invoke-virtual {v0, v1}, Landroid/widget/GridLayout;->post(Ljava/lang/Runnable;)Z

    .line 282
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tiles:Landroid/widget/LinearLayout;

    new-instance v1, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda2;-><init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private configureSeekRanges()V
    .registers 6

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->ctrlCols:Landroid/widget/SeekBar;

    const-string v1, "inv_panel_settings_control_grid_columns_min"

    const/4 v2, 0x2

    const-string v3, "inv_panel_settings_control_grid_columns_max"

    const/4 v4, 0x4

    invoke-static {v1, v2, v3, v4}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->rangeFromIntegers(Ljava/lang/String;ILjava/lang/String;I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setMax(I)V

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->ctrlRows:Landroid/widget/SeekBar;

    const-string v1, "inv_panel_settings_control_grid_rows_min"

    const/4 v2, 0x1

    const-string v3, "inv_panel_settings_control_grid_rows_max"

    const/4 v4, 0x3

    invoke-static {v1, v2, v3, v4}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->rangeFromIntegers(Ljava/lang/String;ILjava/lang/String;I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setMax(I)V

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tileCols:Landroid/widget/SeekBar;

    const-string v1, "inv_panel_settings_tile_grid_columns_min"

    const/4 v2, 0x2

    const-string v3, "inv_panel_settings_tile_grid_columns_max"

    const/4 v4, 0x4

    invoke-static {v1, v2, v3, v4}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->rangeFromIntegers(Ljava/lang/String;ILjava/lang/String;I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setMax(I)V

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tileRows:Landroid/widget/SeekBar;

    const-string v1, "inv_panel_settings_tile_grid_rows_min"

    const/4 v2, 0x1

    const-string v3, "inv_panel_settings_tile_grid_rows_max"

    const/4 v4, 0x5

    invoke-static {v1, v2, v3, v4}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->rangeFromIntegers(Ljava/lang/String;ILjava/lang/String;I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setMax(I)V

    return-void
.end method

.method public static dismissIfShowing(Landroid/view/View;)V
    .registers 3

    if-nez p0, :cond_3

    return-void

    :cond_3
    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findRoot(Landroid/view/View;)Landroid/view/ViewGroup;

    move-result-object v0

    if-eqz v0, :cond_18

    const-string v1, "inv_settings_sheet"

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    move-result-object v0

    instance-of v1, v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    if-eqz v1, :cond_18

    check-cast v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dismiss()V

    :cond_18
    return-void
.end method

.method private dp(I)I
    .registers 7

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-static {p1}, Linv/exe/systemui/qs/core/InvRes;->dimenNameForDp(I)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_1f

    const-string v2, "dimen"

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    if-lez v1, :cond_1f

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p0

    return p0

    :cond_1f
    int-to-float p1, p1

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, p0

    const/high16 p0, 0x3f000000  # 0.5f

    add-float/2addr p1, p0

    float-to-int p0, p1

    return p0
.end method

.method private static findRoot(Landroid/view/View;)Landroid/view/ViewGroup;
    .registers 3

    .line 82
    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v0

    .line 83
    instance-of v1, v0, Landroid/view/ViewGroup;

    if-eqz v1, :cond_b

    check-cast v0, Landroid/view/ViewGroup;

    return-object v0

    .line 84
    :cond_b
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v0, v0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_1a

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    check-cast p0, Landroid/view/ViewGroup;

    return-object p0

    :cond_1a
    const/4 p0, 0x0

    return-object p0
.end method

.method private static free([[ZIIII)Z
    .registers 8

    move v0, p1

    :goto_1
    add-int v1, p1, p4

    if-lt v0, v1, :cond_7

    const/4 p0, 0x1

    return p0

    :cond_7
    move v1, p2

    :goto_8
    add-int v2, p2, p3

    if-lt v1, v2, :cond_f

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 539
    :cond_f
    aget-object v2, p0, v0

    aget-boolean v2, v2, v1

    if-eqz v2, :cond_17

    const/4 p0, 0x0

    return p0

    :cond_17
    add-int/lit8 v1, v1, 0x1

    goto :goto_8
.end method

.method private getColor(I)I
    .registers 2

    .line 194
    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/content/Context;->getColor(I)I

    move-result p0

    return p0
.end method

.method private init()V
    .registers 4

    .line 91
    const-string v0, "inv_settings_sheet"

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->setTag(Ljava/lang/Object;)V

    const/4 v0, 0x1

    .line 92
    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->setClickable(Z)V

    .line 93
    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->setFocusable(Z)V

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->setFocusableInTouchMode(Z)V

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->requestFocus()Z

    const/4 v1, 0x0

    .line 94
    invoke-virtual {p0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->setClipChildren(Z)V

    .line 95
    invoke-virtual {p0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->setClipToPadding(Z)V

    .line 96
    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->init(Landroid/content/Context;)V

    const-string v2, "inv_panel_settings_sheet_scrim"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v2

    invoke-direct {p0, v2}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getColor(I)I

    move-result v2

    invoke-virtual {p0, v2}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->setBackgroundColor(I)V

    .line 98
    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    const-string v2, "inv_panel_settings_bottomsheet"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->layout(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2, p0, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    const-string v1, "inv_settings_overlay"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_52

    new-instance v2, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$2;

    invoke-direct {v2, p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$2;-><init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 99
    :cond_52
    const-string v1, "bottom_sheet_root"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_71

    .line 101
    invoke-virtual {v1, v0}, Landroid/view/View;->setClickable(Z)V

    .line 102
    invoke-virtual {v1, v0}, Landroid/view/View;->setFocusable(Z)V

    const/16 v0, 0x168

    .line 103
    invoke-direct {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v1, v0}, Landroid/view/View;->setTranslationY(F)V

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->applyResponsiveSheet()V

    :cond_71
    const/4 v0, 0x0

    .line 105
    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->setAlpha(F)V

    .line 106
    new-instance v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$2;

    invoke-direct {v0, p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$2;-><init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 108
    new-instance v0, Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Linv/exe/systemui/qs/model/InvPanelRepository;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    .line 109
    new-instance v0, Linv/exe/systemui/qs/controller/InvBrightnessController;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Linv/exe/systemui/qs/controller/InvBrightnessController;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->brightness:Linv/exe/systemui/qs/controller/InvBrightnessController;

    .line 110
    new-instance v0, Linv/exe/systemui/qs/controller/InvVolumeController;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Linv/exe/systemui/qs/controller/InvVolumeController;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->volume:Linv/exe/systemui/qs/controller/InvVolumeController;

    .line 111
    new-instance v0, Linv/exe/systemui/qs/controller/InvMediaSessionController;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->mediaSession:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    .line 112
    new-instance v1, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$3;

    invoke-direct {v1, p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$3;-><init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V

    invoke-virtual {v0, v1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->start(Linv/exe/systemui/qs/controller/InvMediaSessionController$Callback;)V

    .line 120
    const-string v0, "switch_labels"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Switch;

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->labels:Landroid/widget/Switch;

    .line 121
    const-string v0, "seek_ctrl_cols"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/SeekBar;

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->ctrlCols:Landroid/widget/SeekBar;

    .line 122
    const-string v0, "seek_ctrl_rows"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/SeekBar;

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->ctrlRows:Landroid/widget/SeekBar;

    .line 123
    const-string v0, "seek_tile_cols"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/SeekBar;

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tileCols:Landroid/widget/SeekBar;

    .line 124
    const-string v0, "seek_tile_rows"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/SeekBar;

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tileRows:Landroid/widget/SeekBar;

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->configureSeekRanges()V

    .line 125
    const-string v0, "txt_ctrl_cols"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->ctrlText:Landroid/widget/TextView;

    .line 126
    const-string v0, "txt_ctrl_rows"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->ctrlRowText:Landroid/widget/TextView;

    .line 127
    const-string v0, "txt_tile_cols"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tileText:Landroid/widget/TextView;

    .line 128
    const-string v0, "txt_tile_rows"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->rowText:Landroid/widget/TextView;

    .line 129
    const-string v0, "catalog_controls"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/GridLayout;

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->controls:Landroid/widget/GridLayout;

    .line 130
    const-string v0, "catalog_tiles"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tiles:Landroid/widget/LinearLayout;

    .line 131
    const-string v0, "preview_tile_strip"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->strip:Landroid/widget/LinearLayout;

    .line 133
    const-string v0, "btn_back"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$4;

    invoke-direct {v1, p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$4;-><init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 134
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->labels:Landroid/widget/Switch;

    new-instance v1, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda4;

    invoke-direct {v1, p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda4;-><init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V

    invoke-virtual {v0, v1}, Landroid/widget/Switch;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 135
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->ctrlCols:Landroid/widget/SeekBar;

    new-instance v1, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda5;

    invoke-direct {v1, p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda5;-><init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V

    invoke-direct {p0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->listen(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$Change;)Landroid/widget/SeekBar$OnSeekBarChangeListener;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 140
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->ctrlRows:Landroid/widget/SeekBar;

    new-instance v1, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda6;

    invoke-direct {v1, p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda6;-><init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V

    invoke-direct {p0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->listen(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$Change;)Landroid/widget/SeekBar$OnSeekBarChangeListener;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 145
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tileCols:Landroid/widget/SeekBar;

    new-instance v1, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda7;

    invoke-direct {v1, p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda7;-><init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V

    invoke-direct {p0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->listen(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$Change;)Landroid/widget/SeekBar$OnSeekBarChangeListener;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 151
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tileRows:Landroid/widget/SeekBar;

    new-instance v1, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda8;

    invoke-direct {v1, p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda8;-><init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V

    invoke-direct {p0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->listen(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$Change;)Landroid/widget/SeekBar$OnSeekBarChangeListener;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 157
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->bind()V

    .line 158
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->catalog()V

    .line 159
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->strip()V

    return-void
.end method

.method private listen(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$Change;)Landroid/widget/SeekBar$OnSeekBarChangeListener;
    .registers 3

    .line 200
    new-instance v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$6;

    invoke-direct {v0, p0, p1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$6;-><init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$Change;)V

    return-object v0
.end method

.method private static mark([[ZIIII)V
    .registers 9

    move v0, p1

    :goto_1
    add-int v1, p1, p4

    if-lt v0, v1, :cond_6

    return-void

    :cond_6
    move v1, p2

    :goto_7
    add-int v2, p2, p3

    if-lt v1, v2, :cond_e

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 544
    :cond_e
    aget-object v2, p0, v0

    const/4 v3, 0x1

    aput-boolean v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_7
.end method

.method private nativeTileGroup(I)Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$TileGroup;
    .registers 5

    if-eqz p1, :cond_11

    const/4 v0, 0x1

    if-eq p1, v0, :cond_1a

    const/4 v0, 0x2

    if-eq p1, v0, :cond_23

    const-string v0, "Utilities"

    const-string v1, "inv_ic_settings"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v1

    goto :goto_2b

    :cond_11
    const-string v0, "Connectivity"

    const-string v1, "inv_ic_wifi"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v1

    goto :goto_2b

    :cond_1a
    const-string v0, "Display"

    const-string v1, "inv_ic_rotation"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v1

    goto :goto_2b

    :cond_23
    const-string v0, "Sound"

    const-string v1, "inv_ic_notifications"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v1

    :goto_2b
    new-instance v2, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$TileGroup;

    invoke-direct {v2, v0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$TileGroup;-><init>(Ljava/lang/String;I)V

    return-object v2
.end method

.method private navigationBarHeight()I
    .registers 6

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string v1, "navigation_bar_height"

    const-string v2, "dimen"

    const-string v3, "android"

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    const/4 v2, 0x0

    if-lez v1, :cond_15

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v2

    :cond_15
    if-lez v2, :cond_18

    return v2

    :cond_18
    const/16 v0, 0x18

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result p0

    return p0
.end method

.method private previewControl(Linv/exe/systemui/qs/model/InvControlId;II)Landroid/view/View;
    .registers 23

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 368
    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v2

    .line 370
    invoke-static {}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->$SWITCH_TABLE$inv$exe$systemui$qs$model$InvControlId()[I

    move-result-object v3

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->ordinal()I

    move-result v4

    aget v3, v3, v4

    const/16 v4, 0xa

    const/4 v5, 0x0

    if-eq v3, v4, :cond_1e9

    const/16 v4, 0xb

    if-eq v3, v4, :cond_1e9

    const/16 v4, 0xc

    if-eq v3, v4, :cond_1e9

    const/16 v4, 0xd

    if-eq v3, v4, :cond_1e9

    const/16 v4, 0xe

    if-eq v3, v4, :cond_1e9

    const/16 v4, 0xf

    if-eq v3, v4, :cond_18f

    const-string v4, "inv_text_on_accent"

    const-string v6, "inv_icon_primary"

    const/16 v7, 0xff

    const-string v8, "slider_icon"

    const-string v9, "slider_fill"

    const-string v10, "slider_body"

    const/4 v11, 0x1

    packed-switch v3, :pswitch_data_236

    .line 412
    const-string v3, "inv_item_control_circle"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->layout(Ljava/lang/String;)I

    move-result v3

    iget-object v0, v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->controls:Landroid/widget/GridLayout;

    invoke-virtual {v2, v3, v0, v5}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    .line 413
    const-string v2, "circle_icon"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    iget v1, v1, Linv/exe/systemui/qs/model/InvControlId;->iconRes:I

    invoke-virtual {v2, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    goto/16 :goto_219

    .line 378
    :pswitch_5e  #0x6, 0x7
    const-string v3, "inv_item_slider_vertical"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->layout(Ljava/lang/String;)I

    move-result v3

    iget-object v12, v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->controls:Landroid/widget/GridLayout;

    invoke-virtual {v2, v3, v12, v5}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v2

    .line 379
    invoke-static {v10}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    move-object v12, v3

    check-cast v12, Landroid/widget/FrameLayout;

    .line 380
    invoke-static {v9}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v13

    .line 381
    invoke-static {v8}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ImageView;

    .line 382
    iget v8, v1, Linv/exe/systemui/qs/model/InvControlId;->iconRes:I

    invoke-virtual {v3, v8}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 383
    sget-object v8, Linv/exe/systemui/qs/model/InvControlId;->BRIGHTNESS_V:Linv/exe/systemui/qs/model/InvControlId;

    if-ne v1, v8, :cond_91

    move v5, v11

    :cond_91
    if-eqz v5, :cond_99

    const-string v8, "brightness"

    invoke-virtual {v12, v8}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    goto :goto_9e

    :cond_99
    const-string v8, "volume"

    invoke-virtual {v12, v8}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    :goto_9e
    invoke-static {v10}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v12, v1, v8}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    invoke-virtual {v3, v8}, Landroid/widget/ImageView;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v3, v1, v8}, Landroid/widget/ImageView;->setTag(ILjava/lang/Object;)V

    if-eqz v5, :cond_ae

    goto :goto_b8

    .line 384
    :cond_ae
    iget-object v1, v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->volume:Linv/exe/systemui/qs/controller/InvVolumeController;

    invoke-virtual {v1}, Linv/exe/systemui/qs/controller/InvVolumeController;->getMax()I

    move-result v1

    invoke-static {v11, v1}, Ljava/lang/Math;->max(II)I

    move-result v7

    :goto_b8
    move v14, v7

    if-eqz v5, :cond_c2

    .line 385
    iget-object v1, v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->brightness:Linv/exe/systemui/qs/controller/InvBrightnessController;

    invoke-virtual {v1}, Linv/exe/systemui/qs/controller/InvBrightnessController;->getBrightness()I

    move-result v1

    goto :goto_c8

    :cond_c2
    iget-object v1, v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->volume:Linv/exe/systemui/qs/controller/InvVolumeController;

    invoke-virtual {v1}, Linv/exe/systemui/qs/controller/InvVolumeController;->getVolume()I

    move-result v1

    :goto_c8
    move v15, v1

    .line 387
    invoke-static {v6}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v1

    invoke-direct {v0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getColor(I)I

    move-result v17

    invoke-static {v4}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v1

    invoke-direct {v0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getColor(I)I

    move-result v18

    move-object/from16 v16, v3

    .line 386
    invoke-static/range {v12 .. v18}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->applyStaticProgress(Landroid/view/View;Landroid/view/View;IILandroid/widget/ImageView;II)V

    goto/16 :goto_172

    .line 392
    :pswitch_e0  #0x4, 0x5
    const-string v3, "inv_item_slider_horizontal"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->layout(Ljava/lang/String;)I

    move-result v3

    iget-object v12, v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->controls:Landroid/widget/GridLayout;

    invoke-virtual {v2, v3, v12, v5}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v2

    .line 393
    invoke-static {v10}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    move-object v12, v3

    check-cast v12, Landroid/widget/FrameLayout;

    .line 394
    invoke-static {v9}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v13

    .line 395
    invoke-static {v8}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ImageView;

    .line 396
    iget v8, v1, Linv/exe/systemui/qs/model/InvControlId;->iconRes:I

    invoke-virtual {v3, v8}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 397
    sget-object v8, Linv/exe/systemui/qs/model/InvControlId;->BRIGHTNESS_H:Linv/exe/systemui/qs/model/InvControlId;

    if-ne v1, v8, :cond_113

    move v5, v11

    :cond_113
    if-eqz v5, :cond_11b

    const-string v8, "brightness"

    invoke-virtual {v12, v8}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    goto :goto_120

    :cond_11b
    const-string v8, "volume"

    invoke-virtual {v12, v8}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    :goto_120
    invoke-static {v10}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v12, v1, v8}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    const-string v8, "slider_title"

    invoke-static {v8}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v8

    invoke-virtual {v2, v8}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v8

    check-cast v8, Landroid/widget/TextView;

    if-eqz v8, :cond_13f

    if-eqz v5, :cond_13a

    const-string v10, "Brightness"

    goto :goto_13c

    :cond_13a
    const-string v10, "Volume"

    :goto_13c
    invoke-virtual {v8, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_13f
    if-eqz v5, :cond_142

    goto :goto_14c

    .line 398
    :cond_142
    iget-object v1, v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->volume:Linv/exe/systemui/qs/controller/InvVolumeController;

    invoke-virtual {v1}, Linv/exe/systemui/qs/controller/InvVolumeController;->getMax()I

    move-result v1

    invoke-static {v11, v1}, Ljava/lang/Math;->max(II)I

    move-result v7

    :goto_14c
    move v14, v7

    if-eqz v5, :cond_156

    .line 399
    iget-object v1, v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->brightness:Linv/exe/systemui/qs/controller/InvBrightnessController;

    invoke-virtual {v1}, Linv/exe/systemui/qs/controller/InvBrightnessController;->getBrightness()I

    move-result v1

    goto :goto_15c

    :cond_156
    iget-object v1, v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->volume:Linv/exe/systemui/qs/controller/InvVolumeController;

    invoke-virtual {v1}, Linv/exe/systemui/qs/controller/InvVolumeController;->getVolume()I

    move-result v1

    :goto_15c
    move v15, v1

    .line 401
    invoke-static {v6}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v1

    invoke-direct {v0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getColor(I)I

    move-result v17

    invoke-static {v4}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v1

    invoke-direct {v0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getColor(I)I

    move-result v18

    move-object/from16 v16, v3

    .line 400
    invoke-static/range {v12 .. v18}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->applyStaticProgress(Landroid/view/View;Landroid/view/View;IILandroid/widget/ImageView;II)V

    :goto_172
    move-object v0, v2

    goto/16 :goto_219

    .line 372
    :pswitch_175  #0x3
    const-string v1, "inv_item_media"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->layout(Ljava/lang/String;)I

    move-result v1

    iget-object v3, v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->controls:Landroid/widget/GridLayout;

    invoke-virtual {v2, v1, v3, v5}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    .line 373
    iput-object v1, v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->mediaPreview:Landroid/view/View;

    .line 374
    iget-object v0, v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->mediaSession:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    move/from16 v2, p2

    move/from16 v3, p3

    invoke-static {v1, v0, v2, v3}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->render(Landroid/view/View;Linv/exe/systemui/qs/controller/InvMediaSessionController;II)V

    move-object v0, v1

    goto/16 :goto_219

    .line 406
    :cond_18f
    const-string v3, "inv_item_custom_image"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->layout(Ljava/lang/String;)I

    move-result v3

    iget-object v4, v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->controls:Landroid/widget/GridLayout;

    invoke-virtual {v2, v3, v4, v5}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    const-string v2, "custom_image_view"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    instance-of v3, v2, Landroid/widget/ImageView;

    if-eqz v3, :cond_1b5

    check-cast v2, Landroid/widget/ImageView;

    sget-object v3, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    iget v1, v1, Linv/exe/systemui/qs/model/InvControlId;->iconRes:I

    invoke-virtual {v2, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    :cond_1b5
    const-string v1, "badge"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_1c6

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_1c6
    const-string v1, "custom_image_clear_badge"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_1d7

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_1d7
    const-string v1, "media_resize_handle"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_219

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    goto :goto_219

    .line 407
    :cond_1e9
    :pswitch_1e9  #0x1, 0x2
    const-string v3, "inv_item_pill"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->layout(Ljava/lang/String;)I

    move-result v3

    iget-object v0, v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->controls:Landroid/widget/GridLayout;

    invoke-virtual {v2, v3, v0, v5}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    .line 408
    const-string v2, "pill_icon"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    iget v3, v1, Linv/exe/systemui/qs/model/InvControlId;->iconRes:I

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 409
    const-string v2, "pill_label"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvControlId;->labelText()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 416
    :cond_219
    :goto_219
    const v1, 0x3f0ccccd  # 0.55f

    invoke-virtual {v0, v1}, Landroid/view/View;->setAlpha(F)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setEnabled(Z)V

    const-string v1, "badge"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_234

    const/16 v2, 0x8

    .line 417
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_234
    return-object v0

    nop

    :pswitch_data_236
    .packed-switch 0x1
        :pswitch_1e9  #00000001
        :pswitch_1e9  #00000002
        :pswitch_175  #00000003
        :pswitch_e0  #00000004
        :pswitch_e0  #00000005
        :pswitch_5e  #00000006
        :pswitch_5e  #00000007
    .end packed-switch
.end method

.method private static rangeFromIntegers(Ljava/lang/String;ILjava/lang/String;I)I
    .registers 4

    invoke-static {p0, p1}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result p0

    invoke-static {p2, p3}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result p1

    sub-int/2addr p1, p0

    if-ltz p1, :cond_c

    return p1

    :cond_c
    const/4 p0, 0x0

    return p0
.end method

.method private setAnchorViewMetrics(Landroid/view/View;)V
    .registers 3

    if-eqz p1, :cond_e

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v0

    iput v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->anchorWidth:I

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result v0

    iput v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->anchorHeight:I

    :cond_e
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->applyResponsiveSheet()V

    return-void
.end method

.method private setTextSizeDimen(Landroid/widget/TextView;Ljava/lang/String;)V
    .registers 5

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-static {p2}, Linv/exe/systemui/qs/core/InvRes;->dimen(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result v0

    const/4 v1, 0x0

    invoke-virtual {p1, v1, v0}, Landroid/widget/TextView;->setTextSize(IF)V

    return-void
.end method

.method public static show(Landroid/view/View;Ljava/lang/Runnable;)Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;
    .registers 5

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 65
    :cond_4
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->init(Landroid/content/Context;)V

    .line 66
    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findRoot(Landroid/view/View;)Landroid/view/ViewGroup;

    move-result-object v1

    if-nez v1, :cond_12

    return-object v0

    .line 68
    :cond_12
    const-string v0, "inv_settings_sheet"

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    move-result-object v0

    .line 69
    instance-of v2, v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    if-eqz v2, :cond_22

    .line 70
    invoke-virtual {v0}, Landroid/view/View;->bringToFront()V

    .line 71
    check-cast v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    return-object v0

    .line 73
    :cond_22
    new-instance v0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    move-object v2, p0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-direct {v0, p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;-><init>(Landroid/content/Context;)V

    invoke-direct {v0, v2}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->setAnchorViewMetrics(Landroid/view/View;)V

    .line 74
    invoke-virtual {v0, p1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->setOnDismissRunnable(Ljava/lang/Runnable;)V

    .line 75
    new-instance p0, Landroid/view/ViewGroup$LayoutParams;

    const/4 p1, -0x1

    .line 76
    invoke-direct {p0, p1, p1}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 75
    invoke-virtual {v1, v0, p0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->requestFocus()Z

    .line 77
    new-instance p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$1;

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$1;-><init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V

    invoke-virtual {v0, p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->post(Ljava/lang/Runnable;)Z

    return-object v0
.end method

.method private showSheetToastText(Ljava/lang/CharSequence;)V
    .registers 11

    const-string v0, "inv_sheet_toast"

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_b

    invoke-virtual {p0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->removeView(Landroid/view/View;)V

    :cond_b
    new-instance v1, Landroid/widget/TextView;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v2, "inv_panel_settings_toast_text_size"

    invoke-direct {p0, v1, v2}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->setTextSizeDimen(Landroid/widget/TextView;Ljava/lang/String;)V

    const/16 v2, 0x11

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setGravity(I)V

    const-string v2, "inv_icon_on_accent"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v2

    invoke-direct {p0, v2}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getColor(I)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    sget-object v2, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->GOOGLE_SANS_MEDIUM:Landroid/graphics/Typeface;

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const/16 v2, 0x10

    invoke-direct {p0, v2}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v2

    const/16 v3, 0xa

    invoke-direct {p0, v3}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v3

    invoke-virtual {v1, v2, v3, v2, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    const-string v2, "inv_bg_btn_done"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setBackgroundResource(I)V

    const/16 v2, 0x20

    invoke-direct {p0, v2}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setElevation(F)V

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTranslationZ(F)V

    const/4 v2, -0x1

    const/4 v5, -0x2

    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v4, 0x51

    invoke-direct {v3, v2, v5, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    const/16 v4, 0x14

    invoke-direct {p0, v4}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v4

    iput v4, v3, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    iput v4, v3, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->navigationBarHeight()I

    move-result v4

    iput v4, v3, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    invoke-virtual {p0, v1, v3}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v1}, Landroid/widget/TextView;->bringToFront()V

    const/4 v3, 0x0

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setAlpha(F)V

    const/16 v4, 0x8

    invoke-direct {p0, v4}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v4

    int-to-float v4, v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setTranslationY(F)V

    invoke-virtual {v1}, Landroid/widget/TextView;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v5

    const/high16 v6, 0x3f800000  # 1.0f

    invoke-virtual {v5, v6}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v5

    invoke-virtual {v5, v3}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v5

    const-wide/16 v6, 0x8c

    invoke-virtual {v5, v6, v7}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v5

    invoke-virtual {v5}, Landroid/view/ViewPropertyAnimator;->start()V

    new-instance v5, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$SheetToastRemoveRunnable;

    invoke-direct {v5, p0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$SheetToastRemoveRunnable;-><init>(Landroid/view/ViewGroup;Landroid/view/View;)V

    const-wide/16 v6, 0x6a4

    invoke-virtual {v1, v5, v6, v7}, Landroid/widget/TextView;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method private strip()V
    .registers 2

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->strip:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    return-void
.end method

.method private text()V
    .registers 5

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->ctrlText:Landroid/widget/TextView;

    const-string v1, "%d columns"

    iget-object v2, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v2}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlColumns()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->ctrlRowText:Landroid/widget/TextView;

    const-string v1, "%d rows"

    iget-object v2, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v2}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlRows()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->tileText:Landroid/widget/TextView;

    const-string v1, "%d columns"

    iget-object v2, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v2}, Linv/exe/systemui/qs/model/InvPanelRepository;->getTileColumns()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->rowText:Landroid/widget/TextView;

    const-string v1, "%d rows"

    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getTileRows()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-static {v1, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method


# virtual methods
.method public addNativeSpec(Ljava/lang/String;Landroid/view/View;)V
    .registers 7

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {v0}, Linv/exe/systemui/qs/model/InvPanelRepository;->maxVisibleTiles()I

    move-result v0

    if-lez v0, :cond_18

    invoke-static {p0, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->visibleSpecs(Landroid/view/View;I)Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lt v1, v0, :cond_18

    const-string v0, "Grid tile penuh. Hapus satu tile dulu baru tambah tile baru."

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->showSheetToastText(Ljava/lang/CharSequence;)V

    return-void

    :cond_18
    if-eqz p2, :cond_1c

    move-object v0, p2

    goto :goto_1d

    :cond_1c
    move-object v0, p0

    :goto_1d
    invoke-static {v0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->add(Landroid/view/View;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_27

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dismiss()V

    return-void

    :cond_27
    const-string v1, "Tile gagal ditambahkan oleh native QS. Coba hapus tile dulu atau pilih tile lain."

    invoke-direct {p0, v1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->showSheetToastText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public dismiss()V
    .registers 6

    .line 169
    iget-boolean v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->closing:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    const/4 v0, 0x1

    .line 170
    iput-boolean v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->closing:Z

    .line 171
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->mediaSession:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    if-eqz v0, :cond_f

    .line 172
    :try_start_c
    invoke-virtual {v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->stop()V
    :try_end_f
    .catchall {:try_start_c .. :try_end_f} :catchall_f

    .line 174
    :catchall_f
    :cond_f
    const-string v0, "bottom_sheet_root"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const-wide/16 v1, 0xb4

    if-eqz v0, :cond_3b

    .line 175
    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v3

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v0

    const/16 v4, 0x168

    invoke-direct {p0, v4}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dp(I)I

    move-result v4

    invoke-static {v0, v4}, Ljava/lang/Math;->max(II)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v3, v0}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    .line 176
    :cond_3b
    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/4 v3, 0x0

    invoke-virtual {v0, v3}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    new-instance v1, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$5;

    invoke-direct {v1, p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$5;-><init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->setListener(Landroid/animation/Animator$AnimatorListener;)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    .line 184
    invoke-virtual {p0}, Landroid/view/ViewPropertyAnimator;->start()V

    return-void
.end method

.method public dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .registers 4

    if-eqz p1, :cond_15

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    const/4 v1, 0x4

    if-ne v0, v1, :cond_15

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_13

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dismiss()V

    :cond_13
    const/4 p0, 0x1

    return p0

    :cond_15
    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result p0

    return p0
.end method

.method public synthetic lambda$1$inv-exe-systemui-qs-PanelSettingsBottomSheet(Landroid/widget/CompoundButton;Z)V
    .registers 3

    .line 134
    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {p0, p2}, Linv/exe/systemui/qs/model/InvPanelRepository;->setShowTileLabels(Z)V

    return-void
.end method

.method public synthetic lambda$2$inv-exe-systemui-qs-PanelSettingsBottomSheet(I)V
    .registers 5

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    const-string v1, "inv_panel_settings_control_grid_columns_min"

    const/4 v2, 0x2

    invoke-static {v1, v2}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v1

    add-int/2addr p1, v1

    invoke-virtual {v0, p1}, Linv/exe/systemui/qs/model/InvPanelRepository;->setControlColumns(I)V

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->bind()V

    return-void
.end method

.method public synthetic lambda$3$inv-exe-systemui-qs-PanelSettingsBottomSheet(I)V
    .registers 5

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    const-string v1, "inv_panel_settings_control_grid_rows_min"

    const/4 v2, 0x1

    invoke-static {v1, v2}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v1

    add-int/2addr p1, v1

    invoke-virtual {v0, p1}, Linv/exe/systemui/qs/model/InvPanelRepository;->setControlRows(I)V

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->bind()V

    return-void
.end method

.method public synthetic lambda$4$inv-exe-systemui-qs-PanelSettingsBottomSheet(I)V
    .registers 5

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    const-string v1, "inv_panel_settings_tile_grid_columns_min"

    const/4 v2, 0x2

    invoke-static {v1, v2}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v1

    add-int/2addr p1, v1

    invoke-virtual {v0, p1}, Linv/exe/systemui/qs/model/InvPanelRepository;->setTileColumns(I)V

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->text()V

    return-void
.end method

.method public synthetic lambda$5$inv-exe-systemui-qs-PanelSettingsBottomSheet(I)V
    .registers 5

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    const-string v1, "inv_panel_settings_tile_grid_rows_min"

    const/4 v2, 0x1

    invoke-static {v1, v2}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v1

    add-int/2addr p1, v1

    invoke-virtual {v0, p1}, Linv/exe/systemui/qs/model/InvPanelRepository;->setTileRows(I)V

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->text()V

    return-void
.end method

.method public synthetic lambda$6$inv-exe-systemui-qs-PanelSettingsBottomSheet(Linv/exe/systemui/qs/model/InvControlId;Landroid/view/View;)V
    .registers 4

    iget-object p2, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->repo:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-virtual {p2, p1}, Linv/exe/systemui/qs/model/InvPanelRepository;->addControl(Linv/exe/systemui/qs/model/InvControlId;)Ljava/lang/String;

    move-result-object p1

    const-string p2, "control_full"

    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_14

    const-string p1, "Grid control penuh. Naikkan row/column control atau hapus control dulu."

    invoke-direct {p0, p1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->showSheetToastText(Ljava/lang/CharSequence;)V

    return-void

    :cond_14
    const-string p2, "exists"

    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_22

    const-string p1, "Item sudah ada di panel"

    invoke-direct {p0, p1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->showSheetToastText(Ljava/lang/CharSequence;)V

    return-void

    :cond_22
    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dismiss()V

    return-void
.end method

.method protected onConfigurationChanged(Landroid/content/res/Configuration;)V
    .registers 2

    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Linv/exe/systemui/qs/core/InvRes;->init(Landroid/content/Context;)V

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dismiss()V

    return-void
.end method

.method protected onDetachedFromWindow()V
    .registers 3

    .line 188
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->mediaSession:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    if-eqz v0, :cond_b

    iget-boolean v1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->closing:Z

    if-nez v1, :cond_b

    .line 189
    :try_start_8
    invoke-virtual {v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->stop()V
    :try_end_b
    .catchall {:try_start_8 .. :try_end_b} :catchall_b

    .line 191
    :catchall_b
    :cond_b
    invoke-super {p0}, Landroid/widget/FrameLayout;->onDetachedFromWindow()V

    return-void
.end method

.method public setOnDismissRunnable(Ljava/lang/Runnable;)V
    .registers 2

    .line 88
    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->onDismiss:Ljava/lang/Runnable;

    return-void
.end method
