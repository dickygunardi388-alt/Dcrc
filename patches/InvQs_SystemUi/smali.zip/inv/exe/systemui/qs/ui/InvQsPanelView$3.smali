.class public Linv/exe/systemui/qs/ui/InvQsPanelView$3;
.super Ljava/lang/Object;
.source "QsPanelView.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Linv/exe/systemui/qs/ui/InvQsPanelView;->bind()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field public final synthetic this$0:Linv/exe/systemui/qs/ui/InvQsPanelView;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/ui/InvQsPanelView;)V
    .registers 2

    .line 47
    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvQsPanelView$3;->this$0:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 2

    .line 47
    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView$3;->this$0:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->access$0(Linv/exe/systemui/qs/ui/InvQsPanelView;)Linv/exe/systemui/qs/controller/InvQsPanelController;

    move-result-object p0

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->resetLayout()V

    return-void
.end method
