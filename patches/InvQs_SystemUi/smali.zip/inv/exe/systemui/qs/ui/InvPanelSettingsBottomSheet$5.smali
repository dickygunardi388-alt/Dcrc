.class public Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$5;
.super Landroid/animation/AnimatorListenerAdapter;
.source "PanelSettingsBottomSheet.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dismiss()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field public final synthetic this$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V
    .registers 2

    .line 176
    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$5;->this$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .registers 3

    .line 178
    iget-object p1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$5;->this$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    invoke-virtual {p1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    check-cast p1, Landroid/view/ViewGroup;

    if-eqz p1, :cond_f

    .line 179
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$5;->this$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 180
    :cond_f
    iget-object p1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$5;->this$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    invoke-static {p1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->access$4(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)Ljava/lang/Runnable;

    move-result-object p1

    .line 181
    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$5;->this$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    const/4 v0, 0x0

    invoke-static {p0, v0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->access$5(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;Ljava/lang/Runnable;)V

    if-eqz p1, :cond_20

    .line 182
    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    :cond_20
    return-void
.end method
