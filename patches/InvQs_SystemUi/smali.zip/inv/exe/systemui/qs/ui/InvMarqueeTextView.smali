.class public Linv/exe/systemui/qs/ui/InvMarqueeTextView;
.super Landroid/widget/TextView;
.source "MarqueeTextView.java"


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    .line 11
    invoke-direct {p0, p1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 12
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvMarqueeTextView;->init()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3

    .line 16
    invoke-direct {p0, p1, p2}, Landroid/widget/TextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 17
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvMarqueeTextView;->init()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4

    .line 21
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 22
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvMarqueeTextView;->init()V

    return-void
.end method

.method private init()V
    .registers 3

    const/4 v0, 0x1

    .line 26
    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvMarqueeTextView;->setSingleLine(Z)V

    .line 27
    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvMarqueeTextView;->setMaxLines(I)V

    .line 28
    sget-object v1, Landroid/text/TextUtils$TruncateAt;->MARQUEE:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {p0, v1}, Linv/exe/systemui/qs/ui/InvMarqueeTextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    const/4 v1, -0x1

    .line 29
    invoke-virtual {p0, v1}, Linv/exe/systemui/qs/ui/InvMarqueeTextView;->setMarqueeRepeatLimit(I)V

    .line 30
    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvMarqueeTextView;->setHorizontallyScrolling(Z)V

    const/4 v1, 0x0

    .line 31
    invoke-virtual {p0, v1}, Linv/exe/systemui/qs/ui/InvMarqueeTextView;->setFocusable(Z)V

    .line 32
    invoke-virtual {p0, v1}, Linv/exe/systemui/qs/ui/InvMarqueeTextView;->setFocusableInTouchMode(Z)V

    .line 33
    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvMarqueeTextView;->setSelected(Z)V

    return-void
.end method


# virtual methods
.method public isFocused()Z
    .registers 1

    const/4 p0, 0x1

    return p0
.end method

.method protected onAttachedToWindow()V
    .registers 2

    .line 43
    invoke-super {p0}, Landroid/widget/TextView;->onAttachedToWindow()V

    const/4 v0, 0x1

    .line 44
    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvMarqueeTextView;->setSelected(Z)V

    return-void
.end method

.method public onWindowFocusChanged(Z)V
    .registers 2

    .line 49
    invoke-super {p0, p1}, Landroid/widget/TextView;->onWindowFocusChanged(Z)V

    const/4 p1, 0x1

    .line 50
    invoke-virtual {p0, p1}, Linv/exe/systemui/qs/ui/InvMarqueeTextView;->setSelected(Z)V

    return-void
.end method
