.class public final Linv/exe/systemui/qs/ui/InvMediaEffects;
.super Ljava/lang/Object;
.source "InvMediaEffects.java"


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static apply(Landroid/view/View;Landroid/graphics/Bitmap;ZZ)V
    .registers 16

    if-eqz p0, :cond_a6

    const-string v0, "media_scrim"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    const-string v0, "media_surface_fx"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;

    if-eqz p2, :cond_90

    if-eqz p1, :cond_90

    if-eqz v1, :cond_82

    const/4 v0, 0x0

    invoke-virtual {v1, v0}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    if-eq v0, p1, :cond_82

    const v3, -0x777778

    move v4, v3

    :try_start_2c
    const/16 v5, 0x20

    const/4 v6, 0x1

    invoke-static {p1, v5, v5, v6}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v5

    invoke-static {v5}, Landroid/app/WallpaperColors;->fromBitmap(Landroid/graphics/Bitmap;)Landroid/app/WallpaperColors;

    move-result-object v6

    if-eqz v6, :cond_4e

    invoke-virtual {v6}, Landroid/app/WallpaperColors;->getPrimaryColor()Landroid/graphics/Color;

    move-result-object v7

    if-eqz v7, :cond_44

    invoke-virtual {v7}, Landroid/graphics/Color;->toArgb()I

    move-result v3

    move v4, v3

    :cond_44
    invoke-virtual {v6}, Landroid/app/WallpaperColors;->getSecondaryColor()Landroid/graphics/Color;

    move-result-object v7

    if-eqz v7, :cond_4e

    invoke-virtual {v7}, Landroid/graphics/Color;->toArgb()I

    move-result v4
    :try_end_4e
    .catchall {:try_start_2c .. :try_end_4e} :catchall_4e

    :catchall_4e
    :cond_4e
    const/16 v5, 0x38

    invoke-static {v3, v5}, Linv/exe/systemui/qs/ui/InvMediaEffects;->withAlpha(II)I

    move-result v5

    const/16 v6, 0x88

    invoke-static {v4, v6}, Linv/exe/systemui/qs/ui/InvMediaEffects;->withAlpha(II)I

    move-result v6

    invoke-static {v3}, Linv/exe/systemui/qs/ui/InvMediaEffects;->darken(I)I

    move-result v7

    const/16 v8, 0xe0

    invoke-static {v7, v8}, Linv/exe/systemui/qs/ui/InvMediaEffects;->withAlpha(II)I

    move-result v7

    const/4 v8, 0x3

    new-array v8, v8, [I

    const/4 v9, 0x0

    aput v5, v8, v9

    const/4 v9, 0x1

    aput v6, v8, v9

    const/4 v9, 0x2

    aput v7, v8, v9

    new-instance v9, Landroid/graphics/drawable/GradientDrawable;

    sget-object v10, Landroid/graphics/drawable/GradientDrawable$Orientation;->TOP_BOTTOM:Landroid/graphics/drawable/GradientDrawable$Orientation;

    invoke-direct {v9, v10, v8}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    invoke-virtual {v1, v9}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v1, p1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    if-eqz v2, :cond_82

    invoke-virtual {v2, v3, v4}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->setPalette(II)V

    :cond_82
    if-eqz v2, :cond_a6

    const/4 v0, 0x1

    invoke-virtual {v2, v0}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->setActive(Z)V

    invoke-virtual {v2, p3}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->setPlaying(Z)V

    const/4 v0, 0x0

    invoke-virtual {v2, v0}, Landroid/view/View;->setVisibility(I)V

    goto :goto_a6

    :cond_90
    if-eqz v1, :cond_9b

    const/16 v0, 0x8

    invoke-virtual {v1, v0}, Landroid/view/View;->setVisibility(I)V

    const/4 v0, 0x0

    invoke-virtual {v1, v0}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    :cond_9b
    if-eqz v2, :cond_a6

    const/4 v0, 0x0

    invoke-virtual {v2, v0}, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;->setActive(Z)V

    const/16 v0, 0x8

    invoke-virtual {v2, v0}, Landroid/view/View;->setVisibility(I)V

    :cond_a6
    :goto_a6
    return-void
.end method

.method private static bindOne(Landroid/view/View;Landroid/view/View$OnTouchListener;Ljava/lang/String;)V
    .registers 5

    if-eqz p0, :cond_11

    invoke-static {p2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_11

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_11

    invoke-virtual {v1, p1}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    :cond_11
    return-void
.end method

.method public static bindTouchRipples(Landroid/view/View;)V
    .registers 4

    if-eqz p0, :cond_30

    const-string v0, "media_surface_fx"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_30

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;

    if-eqz v0, :cond_30

    new-instance v1, Linv/exe/systemui/qs/ui/InvMediaEffects$TouchListener;

    invoke-direct {v1, v0}, Linv/exe/systemui/qs/ui/InvMediaEffects$TouchListener;-><init>(Linv/exe/systemui/qs/ui/InvMediaSurfaceEffectsView;)V

    const-string v2, "media_prev"

    invoke-static {p0, v1, v2}, Linv/exe/systemui/qs/ui/InvMediaEffects;->bindOne(Landroid/view/View;Landroid/view/View$OnTouchListener;Ljava/lang/String;)V

    const-string v2, "media_play"

    invoke-static {p0, v1, v2}, Linv/exe/systemui/qs/ui/InvMediaEffects;->bindOne(Landroid/view/View;Landroid/view/View$OnTouchListener;Ljava/lang/String;)V

    const-string v2, "media_next"

    invoke-static {p0, v1, v2}, Linv/exe/systemui/qs/ui/InvMediaEffects;->bindOne(Landroid/view/View;Landroid/view/View$OnTouchListener;Ljava/lang/String;)V

    const-string v2, "media_shuffle"

    invoke-static {p0, v1, v2}, Linv/exe/systemui/qs/ui/InvMediaEffects;->bindOne(Landroid/view/View;Landroid/view/View$OnTouchListener;Ljava/lang/String;)V

    const-string v2, "media_output_button"

    invoke-static {p0, v1, v2}, Linv/exe/systemui/qs/ui/InvMediaEffects;->bindOne(Landroid/view/View;Landroid/view/View$OnTouchListener;Ljava/lang/String;)V

    :cond_30
    return-void
.end method

.method private static darken(I)I
    .registers 5

    invoke-static {p0}, Landroid/graphics/Color;->red(I)I

    move-result v0

    mul-int/lit8 v0, v0, 0x2

    div-int/lit8 v0, v0, 0x5

    invoke-static {p0}, Landroid/graphics/Color;->green(I)I

    move-result v1

    mul-int/lit8 v1, v1, 0x2

    div-int/lit8 v1, v1, 0x5

    invoke-static {p0}, Landroid/graphics/Color;->blue(I)I

    move-result v2

    mul-int/lit8 v2, v2, 0x2

    div-int/lit8 v2, v2, 0x5

    invoke-static {v0, v1, v2}, Landroid/graphics/Color;->rgb(III)I

    move-result v3

    return v3
.end method

.method private static withAlpha(II)I
    .registers 3

    const v0, 0xffffff

    and-int/2addr p0, v0

    shl-int/lit8 p1, p1, 0x18

    or-int/2addr p0, p1

    return p0
.end method
