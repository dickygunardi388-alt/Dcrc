.class public Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;
.super Ljava/lang/Object;
.source "VerticalLevelSlider.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Linv/exe/systemui/qs/ui/InvVerticalLevelSlider$Listener;
    }
.end annotation


# instance fields
.field private final box:Landroid/view/View;

.field private final fill:Landroid/view/View;

.field private final icon:Landroid/widget/ImageView;

.field private final listener:Linv/exe/systemui/qs/ui/InvVerticalLevelSlider$Listener;

.field private final max:I

.field private onFill:I

.field private onTrack:I

.field private progress:I

.field private tracking:Z


# direct methods
.method public constructor <init>(Landroid/view/View;Landroid/view/View;ILinv/exe/systemui/qs/ui/InvVerticalLevelSlider$Listener;Landroid/widget/ImageView;II)V
    .registers 8

    .line 22
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 24
    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->box:Landroid/view/View;

    .line 25
    iput-object p2, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->fill:Landroid/view/View;

    .line 26
    iput p3, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->max:I

    .line 27
    iput-object p4, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->listener:Linv/exe/systemui/qs/ui/InvVerticalLevelSlider$Listener;

    .line 28
    iput-object p5, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->icon:Landroid/widget/ImageView;

    .line 29
    iput p6, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->onTrack:I

    .line 30
    iput p7, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->onFill:I

    .line 31
    invoke-virtual {p1, p0}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    const/4 p2, 0x1

    .line 32
    invoke-virtual {p1, p2}, Landroid/view/View;->setClickable(Z)V

    .line 33
    invoke-static {p1}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClipToRounded(Landroid/view/View;)V

    .line 34
    new-instance p2, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider$$ExternalSyntheticLambda1;

    invoke-direct {p2, p0}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider$$ExternalSyntheticLambda1;-><init>(Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;)V

    invoke-virtual {p1, p2}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    return-void
.end method

.method private apply(FI)V
    .registers 3

    if-gtz p2, :cond_3

    return-void

    :cond_3
    int-to-float p2, p2

    div-float/2addr p1, p2

    const/high16 p2, 0x3f800000  # 1.0f

    sub-float/2addr p2, p1

    .line 74
    iget p1, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->max:I

    int-to-float p1, p1

    mul-float/2addr p2, p1

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p1

    .line 75
    iget p2, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->max:I

    invoke-static {p2, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 p2, 0x0

    invoke-static {p2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    .line 76
    iget p2, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->progress:I

    if-eq p1, p2, :cond_2c

    .line 77
    iput p1, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->progress:I

    .line 78
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->update()V

    .line 79
    iget-object p1, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->listener:Linv/exe/systemui/qs/ui/InvVerticalLevelSlider$Listener;

    iget p0, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->progress:I

    invoke-interface {p1, p0}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider$Listener;->onChanged(I)V

    return-void

    .line 80
    :cond_2c
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->update()V

    return-void
.end method

.method public static applyStaticProgress(Landroid/view/View;Landroid/view/View;IILandroid/widget/ImageView;II)V
    .registers 15

    .line 89
    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClipToRounded(Landroid/view/View;)V

    .line 90
    new-instance v0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider$$ExternalSyntheticLambda2;

    move-object v1, p0

    move-object v4, p1

    move v2, p2

    move v3, p3

    move-object v5, p4

    move v7, p5

    move v6, p6

    invoke-direct/range {v0 .. v7}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider$$ExternalSyntheticLambda2;-><init>(Landroid/view/View;IILandroid/view/View;Landroid/widget/ImageView;II)V

    .line 119
    invoke-virtual {v1}, Landroid/view/View;->getHeight()I

    move-result p0

    if-lez p0, :cond_19

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    return-void

    :cond_19
    invoke-virtual {v1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private static applyVerticalAdaptiveIcon(Landroid/view/View;IILandroid/widget/ImageView;)V
    .registers 10

    if-eqz p3, :cond_40

    const/4 v0, 0x1

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result v1

    mul-int/lit8 v2, p2, 0x64

    div-int/2addr v2, v1

    const/4 v0, 0x0

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    const/16 v3, 0x64

    invoke-static {v3, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    invoke-virtual {p3}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v4

    invoke-static {v4}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->tagLooksVolume(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_27

    if-lez v2, :cond_24

    const-string v5, "inv_ic_volume"

    goto :goto_37

    :cond_24
    const-string v5, "inv_ic_volume_off"

    goto :goto_37

    :cond_27
    const/16 v5, 0x21

    if-gt v2, v5, :cond_2e

    const-string v5, "inv_ic_brightness_low"

    goto :goto_37

    :cond_2e
    const/16 v5, 0x42

    if-gt v2, v5, :cond_35

    const-string v5, "inv_ic_brightness_medium"

    goto :goto_37

    :cond_35
    const-string v5, "inv_ic_brightness_full"

    :goto_37
    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v5

    if-lez v5, :cond_40

    invoke-virtual {p3, v5}, Landroid/widget/ImageView;->setImageResource(I)V

    :cond_40
    return-void
.end method

.method private static dimenDp(Landroid/view/View;Ljava/lang/String;F)F
    .registers 5

    if-eqz p0, :cond_18

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-static {p1}, Linv/exe/systemui/qs/core/InvRes;->dimen(Ljava/lang/String;)I

    move-result v1

    if-lez v1, :cond_18

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    div-float/2addr p0, v0

    return p0

    :cond_18
    return p2
.end method

.method public static enableClip(Landroid/view/View;ZF)V
    .registers 7

    if-eqz p0, :cond_2a

    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_10

    move-object v0, p0

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setClipToPadding(Z)V

    :cond_10
    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Landroid/view/View;->setClipToOutline(Z)V

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p2, v0

    new-instance v2, Linv/exe/systemui/qs/ui/InvRoundedClipOutlineProvider;

    invoke-direct {v2, p1, p2}, Linv/exe/systemui/qs/ui/InvRoundedClipOutlineProvider;-><init>(ZF)V

    invoke-virtual {p0, v2}, Landroid/view/View;->setOutlineProvider(Landroid/view/ViewOutlineProvider;)V

    invoke-virtual {p0}, Landroid/view/View;->invalidateOutline()V

    :cond_2a
    return-void
.end method

.method public static enableClipRoundedRect(Landroid/view/View;F)V
    .registers 3

    const/4 v0, 0x0

    .line 123
    invoke-static {p0, v0, p1}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClip(Landroid/view/View;ZF)V

    return-void
.end method

.method public static enableClipToRounded(Landroid/view/View;)V
    .registers 4

    const/4 v0, 0x1

    const/high16 v1, 0x41900000  # 18.0f

    const-string v2, "inv_control_slider_corner_radius"

    invoke-static {p0, v2, v1}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->dimenDp(Landroid/view/View;Ljava/lang/String;F)F

    move-result v1

    .line 122
    invoke-static {p0, v0, v1}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClip(Landroid/view/View;ZF)V

    return-void
.end method

.method public static synthetic lambda$2(Landroid/view/View;IILandroid/view/View;Landroid/widget/ImageView;II)V
    .registers 16

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v0

    if-gtz v0, :cond_8

    goto/16 :goto_71

    :cond_8
    const/4 v3, 0x0

    invoke-virtual {p3, v3}, Landroid/view/View;->setVisibility(I)V

    const/4 v1, 0x1

    invoke-static {v1, p1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-static {p1, p2}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/4 v3, 0x0

    invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    int-to-float v4, v0

    int-to-float v5, v2

    int-to-float v6, v1

    div-float/2addr v5, v6

    mul-float v6, v4, v5

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    invoke-virtual {p3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v7

    iget v8, v7, Landroid/view/ViewGroup$LayoutParams;->height:I

    if-eq v8, v6, :cond_31

    iput v6, v7, Landroid/view/ViewGroup$LayoutParams;->height:I

    invoke-virtual {p3, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_31
    if-eqz p4, :cond_71

    invoke-static {p0, v1, v2, p4}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->applyVerticalAdaptiveIcon(Landroid/view/View;IILandroid/widget/ImageView;)V

    invoke-virtual {p4}, Landroid/widget/ImageView;->getBottom()I

    move-result v7

    if-lez v7, :cond_43

    invoke-virtual {p4}, Landroid/widget/ImageView;->getTop()I

    move-result v3

    sub-int v3, v0, v3

    goto :goto_66

    :cond_43
    invoke-virtual {p4}, Landroid/widget/ImageView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v7

    instance-of v8, v7, Landroid/view/ViewGroup$MarginLayoutParams;

    if-eqz v8, :cond_4f

    check-cast v7, Landroid/view/ViewGroup$MarginLayoutParams;

    iget v3, v7, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    :cond_4f
    invoke-virtual {p4}, Landroid/widget/ImageView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v7

    iget v8, v7, Landroid/view/ViewGroup$LayoutParams;->height:I

    if-lez v8, :cond_58

    goto :goto_5c

    :cond_58
    invoke-virtual {p4}, Landroid/widget/ImageView;->getHeight()I

    move-result v8

    :goto_5c
    const/4 v4, 0x0

    invoke-static {v4, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    invoke-static {v4, v8}, Ljava/lang/Math;->max(II)I

    move-result v8

    add-int/2addr v3, v8

    :goto_66
    if-le v6, v3, :cond_69

    goto :goto_6a

    :cond_69
    move p5, p6

    :goto_6a
    invoke-static {p5}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v7

    invoke-virtual {p4, v7}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    :cond_71
    :goto_71
    return-void
.end method

.method private static tagLooksVolume(Ljava/lang/Object;)Z
    .registers 3

    if-eqz p0, :cond_20

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_20

    const-string v0, "volume"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_22

    const-string v0, "VOLUME"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_22

    const-string v0, "Volume"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_22

    :cond_20
    const/4 p0, 0x0

    return p0

    :cond_22
    const/4 p0, 0x1

    return p0
.end method

.method private update()V
    .registers 8

    .line 84
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->box:Landroid/view/View;

    iget-object v1, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->fill:Landroid/view/View;

    iget v2, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->max:I

    iget v3, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->progress:I

    iget-object v4, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->icon:Landroid/widget/ImageView;

    iget v5, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->onTrack:I

    iget v6, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->onFill:I

    invoke-static/range {v0 .. v6}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->applyStaticProgress(Landroid/view/View;Landroid/view/View;IILandroid/widget/ImageView;II)V

    return-void
.end method


# virtual methods
.method public getProgress()I
    .registers 1

    .line 45
    iget p0, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->progress:I

    return p0
.end method

.method public synthetic lambda$1$inv-exe-systemui-qs-VerticalLevelSlider(Landroid/view/View;IIIIIIII)V
    .registers 10

    .line 34
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->update()V

    return-void
.end method

.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .registers 7

    .line 48
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_3b

    const/4 v2, 0x0

    if-eq v0, v1, :cond_21

    const/4 v3, 0x2

    if-eq v0, v3, :cond_11

    const/4 v3, 0x3

    if-eq v0, v3, :cond_21

    goto :goto_3a

    .line 55
    :cond_11
    iget-boolean v0, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->tracking:Z

    if-eqz v0, :cond_3a

    .line 56
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result p2

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    invoke-direct {p0, p2, p1}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->apply(FI)V

    return v1

    .line 62
    :cond_21
    iget-boolean v0, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->tracking:Z

    if-eqz v0, :cond_3a

    .line 63
    iput-boolean v2, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->tracking:Z

    .line 64
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    invoke-interface {v0, v2}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 65
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result p2

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    invoke-direct {p0, p2, p1}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->apply(FI)V

    return v1

    :cond_3a
    :goto_3a
    return v2

    .line 50
    :cond_3b
    iput-boolean v1, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->tracking:Z

    .line 51
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    invoke-interface {v0, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 52
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result p2

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    invoke-direct {p0, p2, p1}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->apply(FI)V

    return v1
.end method

.method public refreshTheme()V
    .registers 4

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->box:Landroid/view/View;

    if-eqz v0, :cond_3d

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_3d

    const-string v1, "inv_icon_primary"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getColor(I)I

    move-result v1

    iput v1, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->onTrack:I

    const-string v1, "inv_text_on_accent"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getColor(I)I

    move-result v1

    iput v1, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->onFill:I

    iget-object v1, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->box:Landroid/view/View;

    const-string v2, "inv_bg_slider_track"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackgroundResource(I)V

    iget-object v1, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->fill:Landroid/view/View;

    if-eqz v1, :cond_3a

    const-string v2, "inv_bg_slider_fill_vertical"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackgroundResource(I)V

    :cond_3a
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->update()V

    :cond_3d
    return-void
.end method

.method public setProgress(I)V
    .registers 3

    const/4 v0, 0x0

    .line 37
    invoke-virtual {p0, p1, v0}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->setProgress(IZ)V

    return-void
.end method

.method public setProgress(IZ)V
    .registers 4

    .line 40
    iget v0, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->max:I

    invoke-static {v0, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v0, 0x0

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    iput p1, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->progress:I

    .line 41
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->update()V

    if-eqz p2, :cond_19

    .line 42
    iget-object p1, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->listener:Linv/exe/systemui/qs/ui/InvVerticalLevelSlider$Listener;

    iget p0, p0, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->progress:I

    invoke-interface {p1, p0}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider$Listener;->onChanged(I)V

    :cond_19
    return-void
.end method
