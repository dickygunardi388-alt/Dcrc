.class public final Linv/exe/systemui/qs/ui/InvMediaViewRenderer;
.super Ljava/lang/Object;
.source "MediaViewRenderer.java"


# static fields
.field private static final PROGRESS_TICKERS:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Landroid/view/View;",
            "Ljava/lang/Runnable;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 29
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->PROGRESS_TICKERS:Ljava/util/Map;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static synthetic access$0(Landroid/widget/FrameLayout;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;ZLinv/exe/systemui/qs/controller/InvMediaSessionController;[Z[J)V
    .registers 9

    .line 424
    invoke-static/range {p0 .. p8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->updateProgressNow(Landroid/widget/FrameLayout;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;ZLinv/exe/systemui/qs/controller/InvMediaSessionController;[Z[J)V

    return-void
.end method

.method public static synthetic access$1(Landroid/view/View;Landroid/view/View;F)V
    .registers 3

    .line 459
    invoke-static {p0, p1, p2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->updateFill(Landroid/view/View;Landroid/view/View;F)V

    return-void
.end method

.method public static synthetic access$2(Landroid/widget/TextView;Landroid/widget/TextView;JJ)V
    .registers 6

    .line 438
    invoke-static/range {p0 .. p5}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->updateTimeLabels(Landroid/widget/TextView;Landroid/widget/TextView;JJ)V

    return-void
.end method

.method public static synthetic access$3(Landroid/view/View;)V
    .registers 1

    .line 419
    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->cancelProgressTicker(Landroid/view/View;)V

    return-void
.end method

.method private static applyAppIconChrome(Landroid/view/View;Linv/exe/systemui/qs/controller/InvMediaSessionController;Z)V
    .registers 7

    if-eqz p0, :cond_3d

    const-string v0, "media_art"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const-string v1, "media_app_button"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz p2, :cond_32

    if-eqz p1, :cond_32

    invoke-virtual {p1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->hasSession()Z

    move-result v2

    if-eqz v2, :cond_32

    const-string v2, "inv_bg_media_output_button"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v2

    if-eqz v0, :cond_2b

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackgroundResource(I)V

    :cond_2b
    if-eqz v1, :cond_3d

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_3d

    :cond_32
    const/4 v2, 0x0

    if-eqz v0, :cond_38

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_38
    if-eqz v1, :cond_3d

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_3d
    :goto_3d
    return-void
.end method

.method private static applyFullArtChrome(Landroid/view/View;Landroid/widget/TextView;Landroid/widget/ImageView;Linv/exe/systemui/qs/controller/InvMediaSessionController;Z)V
    .registers 9

    if-eqz p4, :cond_41

    if-eqz p0, :cond_19

    const-string v0, "inv_bg_media_output_button"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/view/View;->setBackgroundResource(I)V

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    if-eqz v2, :cond_19

    const/4 v3, -0x2

    iput v3, v2, Landroid/view/ViewGroup$LayoutParams;->width:I

    invoke-virtual {p0, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_19
    if-eqz p1, :cond_1f

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_1f
    if-eqz p2, :cond_88

    if-eqz p3, :cond_3c

    invoke-virtual {p3}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->hasSession()Z

    move-result v1

    if-eqz v1, :cond_3c

    invoke-virtual {p3}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->isPlaying()Z

    move-result v0

    if-eqz v0, :cond_32

    const-string v0, "inv_bg_media_pause_button"

    goto :goto_34

    :cond_32
    const-string v0, "inv_bg_media_play_button"

    :goto_34
    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p2, v0}, Landroid/widget/ImageView;->setBackgroundResource(I)V

    goto :goto_88

    :cond_3c
    const/4 v0, 0x0

    invoke-virtual {p2, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_88

    :cond_41
    const/4 v0, 0x0

    if-eqz p0, :cond_47

    invoke-virtual {p0, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_47
    if-eqz p1, :cond_82

    if-eqz p3, :cond_51

    invoke-virtual {p3}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->hasSession()Z

    move-result v1

    if-nez v1, :cond_6c

    :cond_51
    const-string v1, "Output"

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setContentDescription(Ljava/lang/CharSequence;)V

    const/4 v1, 0x0

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setVisibility(I)V

    if-eqz p0, :cond_82

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    if-eqz v1, :cond_82

    const/4 v2, -0x2

    iput v2, v1, Landroid/view/ViewGroup$LayoutParams;->width:I

    invoke-virtual {p0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_82

    :cond_6c
    const/16 v1, 0x8

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setVisibility(I)V

    if-eqz p0, :cond_82

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    if-eqz v1, :cond_82

    iget v2, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    if-lez v2, :cond_82

    iput v2, v1, Landroid/view/ViewGroup$LayoutParams;->width:I

    invoke-virtual {p0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_82
    :goto_82
    if-eqz p2, :cond_88

    const/4 v1, 0x0

    invoke-virtual {p2, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_88
    :goto_88
    return-void
.end method

.method private static applyMediaArtClip(Landroid/view/View;II)V
    .registers 8

    if-nez p0, :cond_3

    return-void

    :cond_3
    const-string v0, "inv_media_standard_album_art_corner_radius"

    invoke-static {p0, v0}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->dimenDp(Landroid/view/View;Ljava/lang/String;)F

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    if-ne p2, v1, :cond_18

    const/4 v1, 0x2

    if-ne p1, v1, :cond_18

    const-string v0, "inv_component_pill_corner_radius"

    invoke-static {p0, v0}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->dimenDp(Landroid/view/View;Ljava/lang/String;)F

    move-result v0

    const/4 v2, 0x1

    goto :goto_25

    :cond_18
    const/4 v1, 0x2

    if-ne p2, v1, :cond_25

    const/4 v1, 0x4

    if-ne p1, v1, :cond_25

    const-string v0, "inv_media_2x4_card_corner_radius"

    invoke-static {p0, v0}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->dimenDp(Landroid/view/View;Ljava/lang/String;)F

    move-result v0

    const/4 v2, 0x1

    :cond_25
    :goto_25
    const-string v1, "media_art"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    move v4, v1

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    invoke-virtual {p0, v4, v3}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    if-eqz v2, :cond_47

    const-string v1, "media_body"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_44

    invoke-virtual {v1, v4, v3}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    :cond_44
    invoke-static {v1, v0}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClipRoundedRect(Landroid/view/View;F)V

    :cond_47
    const-string v1, "media_art_holder"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_56

    invoke-virtual {v1, v4, v3}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    :cond_56
    invoke-static {v1, v0}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClipRoundedRect(Landroid/view/View;F)V

    const-string v1, "media_art"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_68

    invoke-virtual {v1, v4, v3}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    :cond_68
    invoke-static {v1, v0}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClipRoundedRect(Landroid/view/View;F)V

    const-string v1, "media_blur_bg"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_7a

    invoke-virtual {v1, v4, v3}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    :cond_7a
    invoke-static {v1, v0}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClipRoundedRect(Landroid/view/View;F)V

    const-string v1, "media_scrim"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_8c

    invoke-virtual {v1, v4, v3}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    :cond_8c
    invoke-static {v1, v0}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClipRoundedRect(Landroid/view/View;F)V

    return-void
.end method

.method private static applyPlayPauseChrome(Landroid/widget/ImageView;Linv/exe/systemui/qs/controller/InvMediaSessionController;IIZ)V
    .registers 7

    if-eqz p0, :cond_36

    if-nez p4, :cond_17

    const/4 v0, 0x1

    if-ne p3, v0, :cond_11

    const/4 v0, 0x2

    if-eq p2, v0, :cond_17

    const/4 v0, 0x3

    if-eq p2, v0, :cond_17

    const/4 v0, 0x4

    if-ne p2, v0, :cond_32

    goto :goto_17

    :cond_11
    const/4 v0, 0x2

    if-ne p3, v0, :cond_32

    const/4 v0, 0x4

    if-ne p2, v0, :cond_32

    :cond_17
    :goto_17
    if-eqz p1, :cond_32

    invoke-virtual {p1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->hasSession()Z

    move-result v0

    if-eqz v0, :cond_32

    invoke-virtual {p1}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->isPlaying()Z

    move-result v0

    if-eqz v0, :cond_28

    const-string v0, "inv_bg_media_pause_button"

    goto :goto_2a

    :cond_28
    const-string v0, "inv_bg_media_play_button"

    :goto_2a
    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/widget/ImageView;->setBackgroundResource(I)V

    goto :goto_36

    :cond_32
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_36
    :goto_36
    return-void
.end method

.method private static applyPlayPauseVisual(Landroid/content/Context;Landroid/widget/ImageView;Linv/exe/systemui/qs/controller/InvMediaSessionController;)V
    .registers 7

    if-eqz p1, :cond_22

    invoke-virtual {p1}, Landroid/widget/ImageView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    if-eqz v1, :cond_22

    iget v2, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    if-lez v2, :cond_d

    goto :goto_1a

    :cond_d
    invoke-virtual {p1}, Landroid/widget/ImageView;->getHeight()I

    move-result v2

    if-lez v2, :cond_14

    goto :goto_1a

    :cond_14
    const-string v2, "inv_media_single_row_play_button_size"

    invoke-static {p0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    :goto_1a
    move v3, v2

    iput v3, v1, Landroid/view/ViewGroup$LayoutParams;->width:I

    iput v2, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    invoke-virtual {p1, v1}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_22
    return-void
.end method

.method private static applyResponsiveLayout(Landroid/content/Context;Landroid/widget/FrameLayout;Landroid/widget/LinearLayout;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/FrameLayout;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/FrameLayout;Landroid/widget/FrameLayout;Landroid/widget/TextView;Landroid/widget/TextView;II)V
    .registers 46

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v3, p3

    move-object/from16 v9, p4

    move-object/from16 v10, p5

    move-object/from16 v11, p7

    move-object/from16 v12, p8

    move-object/from16 v13, p9

    move-object/from16 v14, p10

    move-object/from16 v15, p11

    move-object/from16 v4, p13

    move-object/from16 v5, p14

    move/from16 v6, p15

    move/from16 v7, p16

    if-nez v1, :cond_20

    goto/16 :goto_5d4

    :cond_20
    invoke-virtual {v1}, Landroid/widget/FrameLayout;->getId()I

    move-result v2

    if-lez v2, :cond_5b

    move/from16 v17, v2

    move-object/from16 v28, v3

    mul-int/lit8 v8, v6, 0x10

    add-int/2addr v8, v7

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v3

    iget v3, v3, Landroid/content/res/Configuration;->orientation:I

    mul-int/lit8 v8, v8, 0x10

    add-int/2addr v8, v3

    move/from16 v2, v17

    invoke-virtual {v1, v2}, Landroid/widget/FrameLayout;->getTag(I)Ljava/lang/Object;

    move-result-object v3

    instance-of v2, v3, Ljava/lang/Integer;

    if-eqz v2, :cond_50

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v2

    if-ne v2, v8, :cond_50

    move-object/from16 v3, v28

    goto/16 :goto_5d4

    :cond_50
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move/from16 v2, v17

    invoke-virtual {v1, v2, v3}, Landroid/widget/FrameLayout;->setTag(ILjava/lang/Object;)V

    move-object/from16 v3, v28

    :cond_5b
    const/4 v8, 0x1

    if-gt v7, v8, :cond_61

    move/from16 v16, v8

    goto :goto_63

    :cond_61
    const/16 v16, 0x0

    :goto_63
    const/4 v8, 0x2

    const/4 v2, 0x3

    if-lt v7, v8, :cond_6c

    if-lt v6, v2, :cond_6c

    const/16 v19, 0x1

    goto :goto_6e

    :cond_6c
    const/16 v19, 0x0

    :goto_6e
    const/4 v2, 0x4

    if-lt v7, v8, :cond_75

    if-lt v6, v2, :cond_75

    const/4 v7, 0x1

    goto :goto_76

    :cond_75
    const/4 v7, 0x0

    .line 205
    :goto_76
    const-string v8, "inv_media_transport_button_icon_padding"

    invoke-static {v0, v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    invoke-static {v11, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->resetControlView(Landroid/widget/ImageView;I)V

    .line 206
    invoke-static {v0, v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    invoke-static {v12, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->resetControlView(Landroid/widget/ImageView;I)V

    .line 207
    invoke-static {v0, v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    invoke-static {v13, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->resetControlView(Landroid/widget/ImageView;I)V

    .line 208
    const-string v2, "inv_media_shuffle_button_icon_padding"

    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    invoke-static {v14, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->resetControlView(Landroid/widget/ImageView;I)V

    const/16 v2, 0x8

    if-eqz v14, :cond_9d

    .line 209
    invoke-virtual {v14, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_9d
    if-eqz v15, :cond_a2

    .line 210
    invoke-virtual {v15, v2}, Landroid/widget/FrameLayout;->setVisibility(I)V

    :cond_a2
    if-eqz v10, :cond_a7

    .line 211
    invoke-virtual {v10, v2}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_a7
    const/4 v8, 0x3

    if-eqz v9, :cond_b3

    if-eqz v16, :cond_af

    if-ge v6, v8, :cond_af

    goto :goto_b0

    :cond_af
    const/4 v2, 0x0

    .line 212
    :goto_b0
    invoke-virtual {v9, v2}, Landroid/view/View;->setVisibility(I)V

    .line 214
    :cond_b3
    const-string v2, "inv_media_single_row_side_action_button_size"

    if-eqz v16, :cond_227

    if-lt v6, v8, :cond_bb

    const/4 v14, 0x1

    goto :goto_bc

    :cond_bb
    const/4 v14, 0x0

    :goto_bc
    const/4 v7, 0x4

    if-lt v6, v7, :cond_c2

    const/16 v17, 0x1

    goto :goto_c4

    :cond_c2
    const/16 v17, 0x0

    .line 217
    :goto_c4
    const-string v6, "inv_media_content_padding"

    invoke-static {v0, v6}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v6

    const-string v7, "inv_media_content_padding"

    invoke-static {v0, v7}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v7

    const-string v8, "inv_media_content_padding"

    invoke-static {v0, v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v8

    const-string v15, "inv_media_content_padding"

    invoke-static {v0, v15}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v15

    invoke-virtual {v1, v6, v7, v8, v15}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    .line 218
    const-string v1, "inv_media_single_row_title_text_size"

    invoke-static {v4, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setTextSizeDimen(Landroid/widget/TextView;Ljava/lang/String;)V

    if-eqz v5, :cond_fc

    .line 220
    const-string v1, "inv_media_single_row_subtitle_text_size"

    invoke-static {v5, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setTextSizeDimen(Landroid/widget/TextView;Ljava/lang/String;)V

    .line 221
    invoke-virtual {v5}, Landroid/widget/TextView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 222
    const-string v4, "inv_media_single_row_subtitle_margin_top"

    invoke-static {v0, v4}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v4

    iput v4, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 223
    invoke-virtual {v5, v1}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_fc
    const/16 v1, 0x8

    if-eqz v9, :cond_103

    .line 227
    invoke-virtual {v9, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_103
    if-eqz v10, :cond_108

    .line 228
    invoke-virtual {v10, v1}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_108
    if-eqz v3, :cond_12c

    if-eqz v14, :cond_10e

    const/4 v1, 0x0

    goto :goto_110

    :cond_10e
    const/16 v1, 0x8

    .line 230
    :goto_110
    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    if-eqz v14, :cond_12c

    .line 232
    const-string v1, "inv_media_single_row_inline_album_art_size"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v4

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v5

    const/4 v9, 0x0

    const/4 v10, 0x0

    const v6, 0x800013

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object/from16 v1, p12

    invoke-static/range {v3 .. v10}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->frame(Landroid/view/View;IIIIIII)V

    goto :goto_12e

    :cond_12c
    move-object/from16 v1, p12

    :goto_12e
    if-eqz v11, :cond_139

    if-eqz v17, :cond_134

    const/4 v3, 0x0

    goto :goto_136

    :cond_134
    const/16 v3, 0x8

    .line 237
    :goto_136
    invoke-virtual {v11, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_139
    if-eqz v13, :cond_144

    if-eqz v17, :cond_13f

    const/4 v3, 0x0

    goto :goto_141

    :cond_13f
    const/16 v3, 0x8

    .line 238
    :goto_141
    invoke-virtual {v13, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_144
    if-eqz v17, :cond_149

    .line 240
    const-string v3, "inv_media_single_row_controls_width_full"

    goto :goto_14b

    :cond_149
    const-string v3, "inv_media_single_row_controls_width_basic"

    :goto_14b
    invoke-static {v0, v3}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    move/from16 v20, v3

    .line 241
    const-string v15, "inv_media_single_row_action_button_height"

    if-eqz p6, :cond_17a

    invoke-static {v0, v15}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v21

    if-eqz v17, :cond_15e

    const-string v3, "inv_media_1x4_controls_margin_top"

    goto :goto_165

    :cond_15e
    if-eqz v14, :cond_163

    const-string v3, "inv_media_1x3_controls_margin_top"

    goto :goto_165

    :cond_163
    const-string v3, "inv_media_1x2_controls_margin_top"

    :goto_165
    invoke-static {v0, v3}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v24

    move/from16 v3, v24

    neg-int v3, v3

    move/from16 v26, v3

    const/16 v25, 0x0

    const v22, 0x800015

    const/16 v23, 0x0

    move-object/from16 v19, p6

    invoke-static/range {v19 .. v26}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->frame(Landroid/view/View;IIIIIII)V

    .line 243
    :cond_17a
    const-string v3, "inv_media_single_row_play_button_size"

    if-eqz v17, :cond_1b5

    .line 244
    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v4

    invoke-static {v0, v15}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v5

    const/4 v9, 0x0

    const/4 v10, 0x0

    const v6, 0x800013

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object/from16 v28, v11

    move-object v11, v3

    move-object/from16 v3, v28

    invoke-static/range {v3 .. v10}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->controlFrame(Landroid/view/View;IIIIIII)V

    .line 246
    invoke-static {v0, v11}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v4

    invoke-static {v0, v15}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v5

    const/16 v6, 0x11

    move-object v3, v12

    invoke-static/range {v3 .. v10}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->controlFrame(Landroid/view/View;IIIIIII)V

    .line 248
    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v4

    invoke-static {v0, v15}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v5

    const v6, 0x800015

    move-object v3, v13

    invoke-static/range {v3 .. v10}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->controlFrame(Landroid/view/View;IIIIIII)V

    move-object/from16 v12, p8

    goto :goto_1ca

    :cond_1b5
    move-object v11, v3

    .line 251
    invoke-static {v0, v11}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v4

    invoke-static {v0, v15}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v5

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/16 v6, 0x11

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object/from16 v3, p8

    invoke-static/range {v3 .. v10}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->controlFrame(Landroid/view/View;IIIIIII)V

    move-object v12, v3

    :goto_1ca
    if-eqz v12, :cond_1e1

    .line 253
    const-string v2, "inv_media_single_row_play_icon_padding"

    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v4

    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v5

    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v12, v3, v4, v5, v2}, Landroid/widget/ImageView;->setPadding(IIII)V

    :cond_1e1
    if-eqz p2, :cond_21f

    const/16 v2, 0x10

    move-object/from16 v3, p2

    .line 256
    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    if-eqz v14, :cond_1f3

    .line 257
    const-string v2, "inv_media_single_row_metadata_margin_start_with_album_art"

    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    goto :goto_1f4

    :cond_1f3
    const/4 v2, 0x0

    :goto_1f4
    if-eqz v17, :cond_1ff

    .line 258
    const-string v4, "inv_spacing_small"

    invoke-static {v0, v4}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    add-int v20, v20, v0

    goto :goto_205

    :cond_1ff
    const-string v4, "inv_media_single_row_metadata_margin_end"

    invoke-static {v0, v4}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v20

    :goto_205
    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v5, -0x1

    const/4 v6, -0x2

    const v7, 0x800013

    move/from16 p8, v0

    move/from16 p7, v2

    move-object/from16 p3, v3

    move/from16 p10, v4

    move/from16 p4, v5

    move/from16 p5, v6

    move/from16 p6, v7

    move/from16 p9, v20

    .line 259
    invoke-static/range {p3 .. p10}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->frame(Landroid/view/View;IIIIIII)V

    :cond_21f
    if-eqz v1, :cond_5d4

    const/16 v3, 0x8

    .line 262
    invoke-virtual {v1, v3}, Landroid/widget/FrameLayout;->setVisibility(I)V

    return-void

    :cond_227
    move-object/from16 v11, p2

    move-object/from16 v13, p12

    move-object v6, v3

    const/16 v3, 0x8

    if-eqz v7, :cond_233

    .line 266
    const-string v8, "inv_media_content_padding"

    goto :goto_235

    :cond_233
    const-string v8, "inv_media_content_padding"

    :goto_235
    invoke-static {v0, v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v8

    if-eqz v7, :cond_23e

    .line 267
    const-string v16, "inv_media_content_padding"

    goto :goto_240

    :cond_23e
    const-string v16, "inv_media_content_padding"

    :goto_240
    move-object/from16 v3, v16

    invoke-static {v0, v3}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    if-eqz v7, :cond_24b

    .line 268
    const-string v16, "inv_media_content_padding"

    goto :goto_24d

    :cond_24b
    const-string v16, "inv_media_content_padding"

    :goto_24d
    move-object/from16 v17, v2

    move-object/from16 v2, v16

    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    if-eqz v7, :cond_25a

    .line 269
    const-string v16, "inv_media_content_padding"

    goto :goto_25c

    :cond_25a
    const-string v16, "inv_media_content_padding"

    :goto_25c
    move/from16 v20, v7

    move-object/from16 v7, v16

    invoke-static {v0, v7}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v7

    .line 266
    invoke-virtual {v1, v8, v3, v2, v7}, Landroid/widget/FrameLayout;->setPadding(IIII)V

    if-eqz v5, :cond_27f

    .line 271
    invoke-virtual {v5}, Landroid/widget/TextView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout$LayoutParams;

    if-eqz v20, :cond_274

    .line 272
    const-string v2, "inv_media_full_art_subtitle_margin_top"

    goto :goto_276

    :cond_274
    const-string v2, "inv_media_standard_subtitle_margin_top"

    :goto_276
    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 273
    invoke-virtual {v5, v1}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_27f
    const v1, 0x800003

    if-nez v19, :cond_353

    .line 277
    const-string v2, "inv_media_2x2_title_text_size"

    invoke-static {v4, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setTextSizeDimen(Landroid/widget/TextView;Ljava/lang/String;)V

    .line 278
    const-string v2, "inv_media_2x2_subtitle_text_size"

    invoke-static {v5, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setTextSizeDimen(Landroid/widget/TextView;Ljava/lang/String;)V

    if-eqz v6, :cond_2b3

    const/4 v2, 0x0

    .line 280
    invoke-virtual {v6, v2}, Landroid/view/View;->setVisibility(I)V

    .line 281
    const-string v2, "inv_media_2x2_album_art_size"

    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    const/4 v7, 0x0

    const/4 v8, 0x0

    const v4, 0x800033

    const/4 v5, 0x0

    const/4 v6, 0x0

    move v10, v3

    move v3, v2

    move v2, v10

    move v10, v1

    move-object/from16 v15, v17

    const/16 v14, 0x8

    move-object/from16 v1, p3

    invoke-static/range {v1 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->frame(Landroid/view/View;IIIIIII)V

    goto :goto_2b8

    :cond_2b3
    move v10, v1

    move-object/from16 v15, v17

    const/16 v14, 0x8

    :goto_2b8
    if-eqz v9, :cond_2cd

    .line 283
    invoke-static {v0, v15}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    invoke-static {v0, v15}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    const/4 v7, 0x0

    const/4 v8, 0x0

    const v4, 0x800035

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v1, v9

    invoke-static/range {v1 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->frame(Landroid/view/View;IIIIIII)V

    :cond_2cd
    if-eqz v11, :cond_2e4

    .line 286
    invoke-virtual {v11, v10}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 287
    const-string v1, "inv_media_2x2_metadata_margin_top"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v6

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v2, -0x1

    const/4 v3, -0x2

    const v4, 0x800033

    const/4 v5, 0x0

    move-object v1, v11

    invoke-static/range {v1 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->frame(Landroid/view/View;IIIIIII)V

    .line 289
    :cond_2e4
    const-string v9, "inv_media_2x2_transport_button_size"

    if-eqz p6, :cond_2fd

    invoke-static {v0, v9}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v22

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v21, -0x1

    const/16 v23, 0x50

    const/16 v24, 0x0

    const/16 v25, 0x0

    move-object/from16 v20, p6

    invoke-static/range {v20 .. v27}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->frame(Landroid/view/View;IIIIIII)V

    .line 290
    :cond_2fd
    const-string v1, "inv_media_2x2_controls_margin_top"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v6

    neg-int v8, v6

    invoke-static {v0, v9}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    invoke-static {v0, v9}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    const-string v10, "inv_media_2x2_transport_controls_vertical_offset"

    invoke-static {v0, v10}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v1

    neg-int v5, v1

    const/4 v7, 0x0

    const/16 v4, 0x11

    move-object/from16 v1, p7

    invoke-static/range {v1 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->controlFrame(Landroid/view/View;IIIIIII)V

    .line 291
    const-string v1, "inv_media_2x2_play_button_size"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    invoke-static {v0, v9}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    const/4 v5, 0x0

    move-object v1, v12

    invoke-static/range {v1 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->controlFrame(Landroid/view/View;IIIIIII)V

    .line 292
    invoke-static {v0, v9}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v1

    invoke-static {v0, v9}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    invoke-static {v0, v10}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    const/4 v3, 0x0

    move v4, v8

    const/16 v5, 0x11

    move-object/from16 p0, p9

    move/from16 p4, v0

    move/from16 p1, v1

    move/from16 p2, v2

    move/from16 p6, v3

    move/from16 p7, v4

    move/from16 p3, v5

    move/from16 p5, v6

    invoke-static/range {p0 .. p7}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->controlFrame(Landroid/view/View;IIIIIII)V

    if-eqz v13, :cond_5d4

    .line 293
    invoke-virtual {v13, v14}, Landroid/widget/FrameLayout;->setVisibility(I)V

    return-void

    :cond_353
    move v9, v1

    move-object v1, v6

    move-object/from16 v12, v17

    if-nez v20, :cond_477

    .line 298
    const-string v2, "inv_media_2x3_title_text_size"

    invoke-static {v4, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setTextSizeDimen(Landroid/widget/TextView;Ljava/lang/String;)V

    .line 299
    const-string v2, "inv_media_2x3_subtitle_text_size"

    invoke-static {v5, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setTextSizeDimen(Landroid/widget/TextView;Ljava/lang/String;)V

    if-eqz v1, :cond_382

    const/4 v2, 0x0

    .line 301
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 302
    const-string v3, "inv_media_2x3_album_art_size"

    move/from16 v18, v2

    invoke-static {v0, v3}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    invoke-static {v0, v3}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    const/4 v7, 0x0

    const/4 v8, 0x0

    const v4, 0x800033

    const/4 v5, 0x0

    const/4 v6, 0x0

    move/from16 v10, v18

    invoke-static/range {v1 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->frame(Landroid/view/View;IIIIIII)V

    goto :goto_383

    :cond_382
    const/4 v10, 0x0

    :goto_383
    if-eqz p4, :cond_399

    .line 304
    invoke-static {v0, v12}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    invoke-static {v0, v12}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    const/4 v7, 0x0

    const/4 v8, 0x0

    const v4, 0x800035

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object/from16 v1, p4

    invoke-static/range {v1 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->frame(Landroid/view/View;IIIIIII)V

    :cond_399
    if-eqz v11, :cond_3ba

    .line 307
    invoke-virtual {v11, v9}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 309
    const-string v1, "inv_media_2x3_metadata_margin_start"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v5

    const-string v1, "inv_media_2x3_metadata_margin_top"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v6

    const-string v1, "inv_media_2x3_metadata_margin_end"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v7

    const/4 v8, 0x0

    const/4 v2, -0x1

    const/4 v3, -0x2

    const v4, 0x800033

    move-object v1, v11

    .line 308
    invoke-static/range {v1 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->frame(Landroid/view/View;IIIIIII)V

    .line 311
    :cond_3ba
    const-string v9, "inv_media_2x3_transport_button_size"

    if-eqz p6, :cond_3d3

    invoke-static {v0, v9}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v22

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v21, -0x1

    const/16 v23, 0x50

    const/16 v24, 0x0

    const/16 v25, 0x0

    move-object/from16 v20, p6

    invoke-static/range {v20 .. v27}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->frame(Landroid/view/View;IIIIIII)V

    .line 312
    :cond_3d3
    const-string v1, "inv_media_2x3_controls_margin_top"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v18

    move/from16 v6, v18

    neg-int v8, v6

    invoke-static {v0, v9}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    invoke-static {v0, v9}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    const-string v11, "inv_media_2x3_transport_controls_vertical_offset"

    invoke-static {v0, v11}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v1

    neg-int v5, v1

    const/4 v7, 0x0

    const/16 v4, 0x11

    move-object/from16 v1, p7

    invoke-static/range {v1 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->controlFrame(Landroid/view/View;IIIIIII)V

    .line 313
    const-string v1, "inv_media_2x3_play_button_size"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    invoke-static {v0, v9}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    const/4 v5, 0x0

    move-object/from16 v1, p8

    invoke-static/range {v1 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->controlFrame(Landroid/view/View;IIIIIII)V

    .line 314
    invoke-static {v0, v9}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v1

    invoke-static {v0, v9}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    invoke-static {v0, v11}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    const/4 v4, 0x0

    const/16 v6, 0x11

    move-object/from16 p1, p9

    move/from16 p2, v1

    move/from16 p3, v2

    move/from16 p5, v3

    move/from16 p7, v4

    move/from16 p8, v8

    move/from16 p4, v6

    move/from16 p6, v18

    invoke-static/range {p1 .. p8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->controlFrame(Landroid/view/View;IIIIIII)V

    if-eqz v15, :cond_44f

    .line 316
    invoke-virtual {v15, v10}, Landroid/widget/FrameLayout;->setVisibility(I)V

    .line 317
    const-string v1, "inv_media_playback_time_row_height"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v1

    const-string v2, "inv_media_2x3_playback_time_margin_bottom"

    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    const/4 v3, -0x1

    const/16 v4, 0x50

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    move/from16 p3, v1

    move/from16 p8, v2

    move/from16 p2, v3

    move/from16 p4, v4

    move/from16 p5, v5

    move/from16 p6, v6

    move/from16 p7, v7

    move-object/from16 p1, v15

    invoke-static/range {p1 .. p8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->frame(Landroid/view/View;IIIIIII)V

    :cond_44f
    if-eqz v13, :cond_5d4

    .line 319
    const-string v1, "inv_media_seekbar_touch_area_height"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v1

    const-string v2, "inv_media_2x3_seekbar_margin_bottom"

    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    const/4 v2, -0x1

    const/16 v3, 0x50

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move/from16 p7, v0

    move/from16 p2, v1

    move/from16 p1, v2

    move/from16 p3, v3

    move/from16 p4, v4

    move/from16 p5, v5

    move/from16 p6, v6

    move-object/from16 p0, v13

    invoke-static/range {p0 .. p7}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->frame(Landroid/view/View;IIIIIII)V

    return-void

    :cond_477
    const/4 v13, 0x0

    .line 323
    const-string v2, "inv_media_2x4_title_text_size"

    invoke-static {v4, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setTextSizeDimen(Landroid/widget/TextView;Ljava/lang/String;)V

    .line 324
    const-string v2, "inv_media_2x4_subtitle_text_size"

    invoke-static {v5, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setTextSizeDimen(Landroid/widget/TextView;Ljava/lang/String;)V

    if-eqz v1, :cond_4a0

    .line 326
    invoke-virtual {v1, v13}, Landroid/view/View;->setVisibility(I)V

    .line 327
    const-string v2, "inv_media_2x4_app_icon_size"

    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    const/4 v7, 0x0

    const/4 v8, 0x0

    const v4, 0x800033

    const/4 v5, 0x0

    const/4 v6, 0x0

    move/from16 v28, v3

    move v3, v2

    move/from16 v2, v28

    invoke-static/range {v1 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->frame(Landroid/view/View;IIIIIII)V

    :cond_4a0
    if-eqz v10, :cond_4aa

    .line 330
    invoke-virtual {v10, v13}, Landroid/widget/TextView;->setVisibility(I)V

    .line 331
    const-string v1, "inv_media_2x4_output_label_text_size"

    invoke-static {v10, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setTextSizeDimen(Landroid/widget/TextView;Ljava/lang/String;)V

    :cond_4aa
    if-eqz p4, :cond_4c4

    .line 333
    const-string v1, "inv_media_2x4_output_button_width"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    const-string v1, "inv_media_2x4_output_button_height"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    const/4 v7, 0x0

    const/4 v8, 0x0

    const v4, 0x800035

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object/from16 v1, p4

    invoke-static/range {v1 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->frame(Landroid/view/View;IIIIIII)V

    :cond_4c4
    if-eqz v11, :cond_4e0

    .line 336
    invoke-virtual {v11, v9}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 338
    const-string v1, "inv_media_2x4_metadata_margin_top"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v6

    const-string v1, "inv_media_2x4_metadata_margin_end"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v7

    const/4 v8, 0x0

    const/4 v2, -0x1

    const/4 v3, -0x2

    const v4, 0x800033

    const/4 v5, 0x0

    move-object v1, v11

    .line 337
    invoke-static/range {v1 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->frame(Landroid/view/View;IIIIIII)V

    :cond_4e0
    if-eqz p6, :cond_4f5

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v21, -0x1

    const/16 v22, -0x1

    const/16 v23, 0x77

    const/16 v24, 0x0

    const/16 v25, 0x0

    move-object/from16 v20, p6

    .line 340
    invoke-static/range {v20 .. v27}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->frame(Landroid/view/View;IIIIIII)V

    .line 341
    :cond_4f5
    const-string v1, "inv_media_2x4_play_button_size"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    .line 342
    const-string v1, "inv_media_2x4_controls_margin_top"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v16

    const-string v1, "inv_media_2x4_play_button_margin_top"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v6

    move/from16 v5, v16

    add-int/2addr v6, v5

    const/4 v7, 0x0

    const/4 v8, 0x0

    const v4, 0x800035

    const/4 v5, 0x0

    move-object/from16 v1, p8

    .line 341
    invoke-static/range {v1 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->controlFrame(Landroid/view/View;IIIIIII)V

    if-eqz v1, :cond_545

    .line 344
    const-string v2, "inv_media_2x4_play_icon_padding"

    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v4

    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v5

    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v3, v4, v5, v2}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 345
    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 346
    const-string v2, "inv_media_full_art_control_foreground"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/content/Context;->getColor(I)I

    move-result v2

    invoke-static {v2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    .line 348
    :cond_545
    invoke-static {v0, v12}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    invoke-static {v0, v12}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    const/4 v7, 0x0

    const/4 v8, 0x0

    const v4, 0x800053

    const-string v5, "inv_media_2x4_prev_button_margin_start"

    invoke-static {v0, v5}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v5

    const/4 v6, 0x0

    move/from16 v8, v16

    neg-int v8, v8

    move-object/from16 v1, p7

    invoke-static/range {v1 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->controlFrame(Landroid/view/View;IIIIIII)V

    if-eqz v14, :cond_566

    .line 350
    invoke-virtual {v14, v13}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 351
    :cond_566
    invoke-static {v0, v12}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v1

    invoke-static {v0, v12}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    .line 352
    const-string v3, "inv_media_2x4_next_button_margin_end"

    invoke-static {v0, v3}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    move/from16 v4, v16

    neg-int v4, v4

    const v5, 0x800055

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object/from16 p1, p9

    move/from16 p2, v1

    move/from16 p3, v2

    move/from16 p7, v3

    move/from16 p8, v4

    move/from16 p4, v5

    move/from16 p5, v6

    move/from16 p6, v7

    .line 351
    invoke-static/range {p1 .. p8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->controlFrame(Landroid/view/View;IIIIIII)V

    .line 353
    invoke-static {v0, v12}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v1

    invoke-static {v0, v12}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    const/4 v3, 0x0

    move/from16 p2, v1

    move/from16 p3, v2

    move/from16 p7, v3

    move-object/from16 p1, v14

    invoke-static/range {p1 .. p8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->controlFrame(Landroid/view/View;IIIIIII)V

    if-eqz p12, :cond_5d4

    .line 355
    const-string v1, "inv_media_seekbar_touch_area_height"

    invoke-static {v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v1

    .line 356
    const-string v2, "inv_media_2x4_seekbar_margin_start"

    invoke-static {v0, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v2

    const-string v3, "inv_media_2x4_seekbar_margin_end"

    invoke-static {v0, v3}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v3

    const-string v4, "inv_media_2x4_seekbar_margin_bottom"

    invoke-static {v0, v4}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->d(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    const/4 v4, -0x1

    const/16 v5, 0x50

    const/4 v6, 0x0

    move-object/from16 p0, p12

    move/from16 p7, v0

    move/from16 p2, v1

    move/from16 p4, v2

    move/from16 p6, v3

    move/from16 p1, v4

    move/from16 p3, v5

    move/from16 p5, v6

    .line 355
    invoke-static/range {p0 .. p7}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->frame(Landroid/view/View;IIIIIII)V

    :cond_5d4
    :goto_5d4
    return-void
.end method

.method private static applySurface(Landroid/content/Context;Landroid/widget/FrameLayout;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/ImageView;Landroid/view/View;Landroid/widget/ImageView;Landroid/widget/TextView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;ZZZZ)V
    .registers 41

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    move-object/from16 v7, p7

    move-object/from16 v8, p8

    move-object/from16 v9, p9

    .line 141
    if-eqz p18, :cond_1d

    const-string v16, "inv_media_text_primary_on_art"

    const-string v17, "inv_media_text_secondary_on_art"

    const-string v18, "inv_media_full_art_control_foreground"

    goto :goto_2c

    :cond_1d
    if-eqz p21, :cond_26

    const-string v16, "inv_text_primary"

    const-string v17, "inv_text_primary"

    const-string v18, "inv_icon_primary"

    goto :goto_2c

    :cond_26
    const-string v16, "inv_text_secondary"

    const-string v17, "inv_text_secondary"

    const-string v18, "inv_icon_muted"

    :goto_2c
    invoke-static/range {v16 .. v16}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v15

    invoke-virtual {v0, v15}, Landroid/content/Context;->getColor(I)I

    move-result v15

    invoke-static/range {v17 .. v17}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v14

    invoke-virtual {v0, v14}, Landroid/content/Context;->getColor(I)I

    move-result v14

    invoke-static/range {v18 .. v18}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v0, v10}, Landroid/content/Context;->getColor(I)I

    move-result v10

    invoke-static {v10}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v13

    invoke-static {v10}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v12

    move v11, v15

    if-eqz v1, :cond_8c

    if-eqz p19, :cond_6f

    if-eqz p18, :cond_58

    if-eqz p21, :cond_58

    .line 155
    const-string v17, "inv_bg_media_pill"

    goto :goto_5a

    :cond_58
    const-string v17, "inv_bg_media_empty_pill"

    .line 154
    :goto_5a
    invoke-static/range {v17 .. v17}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v1, v10}, Landroid/widget/FrameLayout;->setBackgroundResource(I)V

    .line 156
    const-string v10, "inv_bg_media_border_pill"

    invoke-static {v10}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v0, v10}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v10

    invoke-virtual {v1, v10}, Landroid/widget/FrameLayout;->setForeground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_8c

    :cond_6f
    if-eqz p18, :cond_76

    if-eqz p21, :cond_76

    .line 159
    const-string v10, "inv_bg_media"

    goto :goto_78

    :cond_76
    const-string v10, "inv_bg_media_empty"

    .line 158
    :goto_78
    invoke-static {v10}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v1, v10}, Landroid/widget/FrameLayout;->setBackgroundResource(I)V

    .line 160
    const-string v10, "inv_bg_media_border"

    invoke-static {v10}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v0, v10}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v10

    invoke-virtual {v1, v10}, Landroid/widget/FrameLayout;->setForeground(Landroid/graphics/drawable/Drawable;)V

    :cond_8c
    :goto_8c
    if-eqz v2, :cond_a5

    if-eqz p20, :cond_97

    if-eqz p18, :cond_97

    const/4 v1, 0x0

    .line 166
    invoke-virtual {v2, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_a5

    :cond_97
    if-eqz p18, :cond_9c

    .line 169
    const-string v1, "inv_bg_media_art"

    goto :goto_9e

    :cond_9c
    const-string v1, "inv_bg_media_art_empty"

    :goto_9e
    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v1

    .line 168
    invoke-virtual {v2, v1}, Landroid/view/View;->setBackgroundResource(I)V

    :cond_a5
    :goto_a5
    if-eqz v3, :cond_b0

    if-eqz p18, :cond_ab

    const/4 v1, 0x0

    goto :goto_ad

    :cond_ab
    const/16 v1, 0x8

    .line 172
    :goto_ad
    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_b0
    if-eqz v4, :cond_b5

    .line 173
    invoke-virtual {v4, v15}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_b5
    if-eqz v5, :cond_ba

    .line 174
    invoke-virtual {v5, v14}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_ba
    if-eqz v6, :cond_c3

    .line 175
    const/4 v10, 0x0

    invoke-virtual {v6, v10}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    invoke-virtual {v6, v10}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 176
    :cond_c3
    if-eqz v7, :cond_c9

    const/4 v3, 0x0

    invoke-virtual {v7, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_c9
    if-eqz v8, :cond_ce

    .line 178
    invoke-virtual {v8, v12}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    :cond_ce
    if-eqz v9, :cond_d3

    .line 179
    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_d3
    if-eqz p10, :cond_da

    move-object/from16 v10, p10

    .line 180
    invoke-virtual {v10, v13}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    :cond_da
    const/4 v3, 0x0

    if-eqz p10, :cond_e2

    move-object/from16 v10, p10

    invoke-virtual {v10, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_e2
    if-eqz p12, :cond_e9

    move-object/from16 v10, p12

    invoke-virtual {v10, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_e9
    if-eqz p13, :cond_f0

    move-object/from16 v10, p13

    invoke-virtual {v10, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_f0
    if-eqz p11, :cond_fc

    .line 182
    move-object v3, v13

    move-object/from16 v11, p11

    invoke-virtual {v11, v3}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    const/4 v1, 0x0

    invoke-virtual {v11, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_fc
    if-eqz p12, :cond_103

    move-object/from16 v12, p12

    .line 186
    invoke-virtual {v12, v13}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    :cond_103
    if-eqz p13, :cond_10a

    move-object/from16 v1, p13

    .line 187
    invoke-virtual {v1, v13}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    :cond_10a
    if-eqz p14, :cond_120

    if-eqz p18, :cond_111

    .line 189
    const-string v1, "inv_media_full_art_seekbar_track"

    goto :goto_113

    :cond_111
    const-string v1, "inv_component_outline"

    :goto_113
    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getColor(I)I

    move-result v1

    move-object/from16 v2, p14

    .line 188
    invoke-static {v2, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setPillBackground(Landroid/view/View;I)V

    :cond_120
    if-eqz p15, :cond_13b

    if-eqz p18, :cond_127

    .line 191
    const-string v1, "inv_media_full_art_seekbar_fill"

    goto :goto_12e

    :cond_127
    if-eqz p21, :cond_12c

    const-string v1, "inv_icon_primary"

    goto :goto_12e

    :cond_12c
    const-string v1, "inv_component_outline"

    :goto_12e
    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getColor(I)I

    move-result v0

    move-object/from16 v15, p15

    .line 190
    invoke-static {v15, v0}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setPillBackground(Landroid/view/View;I)V

    :cond_13b
    move-object/from16 v0, p16

    if-eqz v0, :cond_142

    .line 192
    invoke-virtual {v0, v14}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_142
    move-object/from16 v0, p17

    if-eqz v0, :cond_149

    .line 193
    invoke-virtual {v0, v14}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_149
    return-void
.end method

.method private static bindArtwork(Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/graphics/Bitmap;Landroid/graphics/drawable/Drawable;ZZZLjava/lang/CharSequence;)V
    .registers 13

    const/16 v0, 0x8

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz p7, :cond_16

    if-eqz p3, :cond_16

    if-eqz p1, :cond_16

    .line 472
    invoke-virtual {p1, p3}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    const/high16 v3, 0x3f800000  # 1.0f

    .line 473
    invoke-virtual {p1, v3}, Landroid/widget/ImageView;->setAlpha(F)V

    .line 474
    invoke-virtual {p1, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    goto :goto_1e

    :cond_16
    if-eqz p1, :cond_1e

    .line 478
    invoke-virtual {p1, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 480
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    :cond_1e
    :goto_1e
    if-eqz p6, :cond_70

    if-eqz p7, :cond_70

    if-eqz p0, :cond_33

    .line 485
    invoke-virtual {p0, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 486
    invoke-virtual {p0, v1}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    .line 487
    invoke-virtual {p0, v2, v2, v2, v2}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 488
    invoke-virtual {p0, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 489
    invoke-virtual {p0, p8}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    :cond_33
    if-eqz p2, :cond_fa

    if-eqz p4, :cond_69

    sget-object p1, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {p2, p1}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    invoke-virtual {p2, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p2, v2, v2, v2, v2}, Landroid/widget/ImageView;->setPadding(IIII)V

    invoke-static {p4}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->monochromeAppIcon(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    if-eqz p1, :cond_4c

    invoke-virtual {p2, p1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_55

    :cond_4c
    const-string p1, "inv_ic_music"

    invoke-static {p1}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result p1

    invoke-virtual {p2, p1}, Landroid/widget/ImageView;->setImageResource(I)V

    :goto_55
    const/4 v3, -0x1

    invoke-static {v3}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v1

    invoke-virtual {p2, v1}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    const/high16 v3, 0x3f800000  # 1.0f

    invoke-virtual {p2, v3}, Landroid/widget/ImageView;->setAlpha(F)V

    invoke-virtual {p2, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    invoke-virtual {p2, p8}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    return-void

    :cond_69
    invoke-virtual {p2, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    invoke-virtual {p2, p8}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    return-void

    :cond_70
    if-eqz p5, :cond_bb

    if-eqz p0, :cond_b2

    .line 500
    sget-object p1, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {p0, p1}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    invoke-virtual {p0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 502
    invoke-virtual {p0, v2, v2, v2, v2}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 503
    if-eqz p4, :cond_a2

    invoke-static {p4}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->monochromeAppIcon(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    if-eqz p1, :cond_8b

    invoke-virtual {p0, p1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_94

    :cond_8b
    const-string p1, "inv_ic_music"

    invoke-static {p1}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result p1

    invoke-virtual {p0, p1}, Landroid/widget/ImageView;->setImageResource(I)V

    :goto_94
    const/4 v3, -0x1

    invoke-static {v3}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v3

    invoke-virtual {p0, v3}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    const/high16 v3, 0x3f800000  # 1.0f

    invoke-virtual {p0, v3}, Landroid/widget/ImageView;->setAlpha(F)V

    goto :goto_ac

    .line 505
    :cond_a2
    invoke-virtual {p0, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p0, v1}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    invoke-virtual {p0, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    goto :goto_b2

    .line 507
    :goto_ac
    invoke-virtual {p0, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 508
    invoke-virtual {p0, p8}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    :cond_b2
    :goto_b2
    if-eqz p2, :cond_fa

    .line 511
    invoke-virtual {p2, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 512
    invoke-virtual {p2, p8}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    return-void

    :cond_bb
    if-eqz p3, :cond_dc

    if-eqz p0, :cond_d3

    .line 519
    sget-object p1, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {p0, p1}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 520
    invoke-virtual {p0, v2, v2, v2, v2}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 521
    invoke-virtual {p0, v1}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    .line 522
    invoke-virtual {p0, p3}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 523
    invoke-virtual {p0, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 524
    invoke-virtual {p0, p8}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    :cond_d3
    if-eqz p2, :cond_fa

    .line 527
    invoke-virtual {p2, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 528
    invoke-virtual {p2, p8}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    return-void

    :cond_dc
    if-eqz p0, :cond_f2

    .line 532
    sget-object p1, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {p0, p1}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 533
    invoke-virtual {p0, v2, v2, v2, v2}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 534
    invoke-virtual {p0, v1}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    .line 535
    invoke-virtual {p0, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 536
    invoke-virtual {p0, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 537
    invoke-virtual {p0, p8}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    :cond_f2
    if-eqz p2, :cond_fa

    .line 540
    invoke-virtual {p2, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 541
    invoke-virtual {p2, p8}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    :cond_fa
    return-void
.end method

.method private static bindOutputRoute(Landroid/content/Context;Landroid/widget/ImageView;Landroid/widget/TextView;Linv/exe/systemui/qs/controller/InvMediaSessionController;)V
    .registers 5

    if-nez p1, :cond_5

    if-nez p2, :cond_5

    return-void

    :cond_5
    if-nez p3, :cond_9

    const/4 p3, 0x0

    goto :goto_d

    :cond_9
    invoke-virtual {p3}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->getOutputRoute()I

    move-result p3

    :goto_d
    const/4 v0, 0x1

    if-eq p3, v0, :cond_1b

    const/4 v0, 0x2

    if-eq p3, v0, :cond_20

    const/4 v0, 0x3

    if-eq p3, v0, :cond_25

    const-string p3, "inv_ic_speaker"

    const-string v0, "Speaker"

    goto :goto_29

    :cond_1b
    const-string p3, "inv_ic_headphones"

    const-string v0, "Headset"

    goto :goto_29

    :cond_20
    const-string p3, "inv_ic_bluetooth"

    const-string v0, "Bluetooth"

    goto :goto_29

    :cond_25
    const-string p3, "inv_ic_cast"

    const-string v0, "Cast"

    :goto_29
    invoke-static {p3}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result p3

    if-eqz p1, :cond_35

    invoke-virtual {p1, p3}, Landroid/widget/ImageView;->setImageResource(I)V

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    :cond_35
    if-eqz p2, :cond_3d

    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setContentDescription(Ljava/lang/CharSequence;)V

    :cond_3d
    return-void
.end method

.method private static bindProgress(Landroid/widget/FrameLayout;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;Linv/exe/systemui/qs/controller/InvMediaSessionController;II)V
    .registers 21

    move/from16 v2, p7

    if-eqz p0, :cond_b1

    if-eqz p1, :cond_b1

    if-nez p2, :cond_a

    goto/16 :goto_b1

    .line 363
    :cond_a
    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->cancelProgressTicker(Landroid/view/View;)V

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v10, 0x0

    move/from16 v6, p8

    if-lt v6, v3, :cond_19

    if-lt v2, v4, :cond_19

    move v3, v5

    goto :goto_1a

    :cond_19
    move v3, v10

    :goto_1a
    if-eqz v3, :cond_20

    if-ne v2, v4, :cond_20

    move v6, v5

    goto :goto_21

    :cond_20
    move v6, v10

    :goto_21
    const/16 v2, 0x8

    if-eqz v3, :cond_27

    move v4, v10

    goto :goto_28

    :cond_27
    move v4, v2

    .line 366
    :goto_28
    invoke-virtual {p0, v4}, Landroid/widget/FrameLayout;->setVisibility(I)V

    if-eqz p3, :cond_33

    if-eqz v6, :cond_30

    move v2, v10

    .line 367
    :cond_30
    invoke-virtual {p3, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_33
    const/4 v11, 0x0

    if-nez v3, :cond_3a

    .line 369
    invoke-virtual {p0, v11}, Landroid/widget/FrameLayout;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    return-void

    .line 373
    :cond_3a
    new-array v8, v5, [Z

    .line 374
    new-array v9, v5, [J

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object/from16 v3, p4

    move-object/from16 v4, p5

    move v5, v6

    move-object v7, v8

    move-object v8, v9

    move-object/from16 v6, p6

    .line 375
    invoke-static/range {v0 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->updateProgressNow(Landroid/widget/FrameLayout;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;ZLinv/exe/systemui/qs/controller/InvMediaSessionController;[Z[J)V

    move-object v8, v7

    .line 376
    new-instance v0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object/from16 v4, p4

    move-object/from16 v7, p6

    move v6, v5

    move-object/from16 v5, p5

    invoke-direct/range {v0 .. v9}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$1;-><init>(Landroid/widget/FrameLayout;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;ZLinv/exe/systemui/qs/controller/InvMediaSessionController;[Z[J)V

    move-object v5, v9

    move-object v9, v8

    move-object v8, v5

    move v5, v6

    invoke-virtual {p0, v0}, Landroid/widget/FrameLayout;->post(Ljava/lang/Runnable;)Z

    .line 382
    aget-boolean v0, v9, v10

    if-eqz v0, :cond_84

    if-eqz p6, :cond_84

    invoke-virtual/range {p6 .. p6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->canSeek()Z

    move-result v0

    if-eqz v0, :cond_84

    .line 383
    new-instance v0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;

    move-object v2, p0

    move-object v1, p1

    move-object v4, p2

    move-object/from16 v6, p4

    move-object/from16 v7, p5

    move-object v3, v8

    move-object/from16 v8, p6

    invoke-direct/range {v0 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$2;-><init>(Landroid/view/View;Landroid/widget/FrameLayout;[JLandroid/view/View;ZLandroid/widget/TextView;Landroid/widget/TextView;Linv/exe/systemui/qs/controller/InvMediaSessionController;)V

    move-object v8, v3

    invoke-virtual {p0, v0}, Landroid/widget/FrameLayout;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    goto :goto_87

    .line 399
    :cond_84
    invoke-virtual {p0, v11}, Landroid/widget/FrameLayout;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    :goto_87
    if-eqz p6, :cond_b1

    .line 402
    invoke-virtual/range {p6 .. p6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->hasSession()Z

    move-result v0

    if-eqz v0, :cond_b1

    invoke-virtual/range {p6 .. p6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->isPlaying()Z

    move-result v0

    if-eqz v0, :cond_b1

    .line 403
    new-instance v0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;

    move-object v1, v9

    move-object v9, v8

    move-object v8, v1

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object/from16 v4, p4

    move-object/from16 v7, p6

    move v6, v5

    move-object/from16 v5, p5

    invoke-direct/range {v0 .. v9}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer$3;-><init>(Landroid/widget/FrameLayout;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;ZLinv/exe/systemui/qs/controller/InvMediaSessionController;[Z[J)V

    .line 414
    sget-object v2, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->PROGRESS_TICKERS:Ljava/util/Map;

    invoke-interface {v2, p0, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-wide/16 v2, 0x3e8

    .line 415
    invoke-virtual {p0, v0, v2, v3}, Landroid/widget/FrameLayout;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_b1
    :goto_b1
    return-void
.end method

.method private static cancelProgressTicker(Landroid/view/View;)V
    .registers 2

    .line 420
    sget-object v0, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->PROGRESS_TICKERS:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Runnable;

    if-eqz v0, :cond_d

    .line 421
    invoke-virtual {p0, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    :cond_d
    return-void
.end method

.method private static cloneDrawable(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    .registers 2

    if-nez p0, :cond_4

    const/4 p0, 0x0

    return-object p0

    .line 564
    :cond_4
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v0

    if-eqz v0, :cond_e

    .line 565
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p0

    .line 566
    :cond_e
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0
.end method

.method private static controlFrame(Landroid/view/View;IIIIIII)V
    .registers 12

    if-nez p0, :cond_3

    return-void

    :cond_3
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    instance-of v1, v0, Landroid/widget/FrameLayout$LayoutParams;

    if-eqz v1, :cond_2a

    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->width:I

    if-ne v1, p1, :cond_2a

    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->height:I

    if-ne v1, p2, :cond_2a

    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    if-ne v1, p3, :cond_2a

    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    if-ne v1, p4, :cond_2a

    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    if-ne v1, p5, :cond_2a

    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    if-ne v1, p6, :cond_2a

    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    if-ne v1, p7, :cond_2a

    return-void

    .line 642
    :cond_2a
    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v0, p1, p2, p3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    .line 643
    iput p4, v0, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 644
    iput p5, v0, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    .line 645
    iput p6, v0, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    .line 646
    iput p7, v0, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    .line 647
    invoke-virtual {p0, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private static d(Landroid/content/Context;Ljava/lang/String;)I
    .registers 2

    .line 651
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-static {p1}, Linv/exe/systemui/qs/core/InvRes;->dimen(Ljava/lang/String;)I

    move-result p1

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p0

    return p0
.end method

.method private static dimenDp(Landroid/view/View;Ljava/lang/String;)F
    .registers 5

    if-eqz p0, :cond_18

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-static {p1}, Linv/exe/systemui/qs/core/InvRes;->dimen(Ljava/lang/String;)I

    move-result v1

    if-lez v1, :cond_18

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    div-float/2addr p0, v0

    return p0

    :cond_18
    const/high16 p0, 0x41c00000  # 24.0f

    return p0
.end method

.method private static dp(Landroid/content/Context;I)I
    .registers 2

    int-to-float p1, p1

    .line 660
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, p0

    const/high16 p0, 0x3f000000  # 0.5f

    add-float/2addr p1, p0

    float-to-int p0, p1

    return p0
.end method

.method private static enableMarquee(Landroid/widget/TextView;)V
    .registers 3

    if-nez p0, :cond_3

    goto :goto_1f

    :cond_3
    const/4 v0, 0x1

    .line 608
    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 609
    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 610
    sget-object v1, Landroid/text/TextUtils$TruncateAt;->MARQUEE:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {p0, v1}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    const/4 v1, -0x1

    .line 611
    invoke-virtual {p0, v1}, Landroid/widget/TextView;->setMarqueeRepeatLimit(I)V

    .line 612
    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setHorizontallyScrolling(Z)V

    .line 613
    invoke-virtual {p0}, Landroid/widget/TextView;->isSelected()Z

    move-result v1

    if-nez v1, :cond_1f

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setSelected(Z)V

    :cond_1f
    :goto_1f
    return-void
.end method

.method private static enforceOutputPolicy(Landroid/view/View;Landroid/widget/TextView;II)V
    .registers 6

    const/4 v0, 0x1

    if-gt p3, v0, :cond_10

    const/16 v0, 0x8

    if-eqz p0, :cond_a

    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    :cond_a
    if-eqz p1, :cond_31

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_31

    :cond_10
    if-eqz p0, :cond_16

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    :cond_16
    const/4 v0, 0x4

    if-ge p2, v0, :cond_31

    if-eqz p1, :cond_20

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setVisibility(I)V

    :cond_20
    if-eqz p0, :cond_31

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    if-eqz v0, :cond_31

    iget v1, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    if-lez v1, :cond_31

    iput v1, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    invoke-virtual {p0, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_31
    :goto_31
    return-void
.end method

.method private static formatMediaTime(J)Ljava/lang/String;
    .registers 10

    const-wide/16 v0, 0x3e8

    .line 444
    div-long/2addr p0, v0

    const-wide/16 v0, 0x0

    invoke-static {v0, v1, p0, p1}, Ljava/lang/Math;->max(JJ)J

    move-result-wide p0

    const-wide/16 v2, 0x3c

    .line 445
    rem-long v4, p0, v2

    .line 446
    div-long/2addr p0, v2

    .line 447
    rem-long v6, p0, v2

    .line 448
    div-long/2addr p0, v2

    cmp-long v0, p0, v0

    .line 449
    const-string v1, ":"

    if-lez v0, :cond_39

    .line 450
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-static {p0, p1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v6, v7}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->twoDigits(J)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v4, v5}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->twoDigits(J)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 452
    :cond_39
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-static {v6, v7}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v4, v5}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->twoDigits(J)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private static frame(Landroid/view/View;IIIIIII)V
    .registers 12

    if-nez p0, :cond_3

    return-void

    :cond_3
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    instance-of v1, v0, Landroid/widget/FrameLayout$LayoutParams;

    if-eqz v1, :cond_2a

    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->width:I

    if-ne v1, p1, :cond_2a

    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->height:I

    if-ne v1, p2, :cond_2a

    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    if-ne v1, p3, :cond_2a

    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    if-ne v1, p4, :cond_2a

    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    if-ne v1, p5, :cond_2a

    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    if-ne v1, p6, :cond_2a

    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    if-ne v1, p7, :cond_2a

    return-void

    .line 631
    :cond_2a
    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v0, p1, p2, p3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    .line 632
    iput p4, v0, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 633
    iput p5, v0, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    .line 634
    iput p6, v0, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    .line 635
    iput p7, v0, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    .line 636
    invoke-virtual {p0, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public static lockMediaArtClipForEditHold(Landroid/view/View;)V
    .registers 8

    if-eqz p0, :cond_6a

    const/high16 v3, 0x41800000  # 16.0f

    const-string v0, "media_art"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object v1

    instance-of v2, v1, Ljava/lang/Float;

    if-eqz v2, :cond_19

    check-cast v1, Ljava/lang/Float;

    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    move-result v3

    goto :goto_1f

    :cond_19
    const-string v4, "inv_media_standard_album_art_corner_radius"

    invoke-static {p0, v4}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->dimenDp(Landroid/view/View;Ljava/lang/String;)F

    move-result v3

    :goto_1f
    const/high16 v5, 0x41a00000  # 20.0f

    cmpg-float v2, v3, v5

    if-gez v2, :cond_33

    goto :goto_26

    :goto_26
    const-string v0, "media_body"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    invoke-static {v4, v3}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClipRoundedRect(Landroid/view/View;F)V

    :cond_33
    const-string v0, "media_art_holder"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    invoke-static {v4, v3}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClipRoundedRect(Landroid/view/View;F)V

    const-string v0, "media_art"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    invoke-static {v4, v3}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClipRoundedRect(Landroid/view/View;F)V

    const-string v0, "media_blur_bg"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    invoke-static {v4, v3}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClipRoundedRect(Landroid/view/View;F)V

    const-string v0, "media_scrim"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    invoke-static {v4, v3}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClipRoundedRect(Landroid/view/View;F)V

    invoke-virtual {p0}, Landroid/view/View;->invalidateOutline()V

    :cond_6a
    return-void
.end method

.method private static monochromeAppIcon(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    .registers 4

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 548
    :cond_4
    instance-of v1, p0, Landroid/graphics/drawable/AdaptiveIconDrawable;

    if-eqz v1, :cond_20

    .line 549
    move-object v1, p0

    check-cast v1, Landroid/graphics/drawable/AdaptiveIconDrawable;

    .line 551
    :try_start_b
    invoke-virtual {v1}, Landroid/graphics/drawable/AdaptiveIconDrawable;->getMonochrome()Landroid/graphics/drawable/Drawable;

    move-result-object v2
    :try_end_f
    .catchall {:try_start_b .. :try_end_f} :catchall_10

    goto :goto_11

    :catchall_10
    move-object v2, v0

    :goto_11
    if-nez v2, :cond_18

    .line 554
    :try_start_13
    invoke-virtual {v1}, Landroid/graphics/drawable/AdaptiveIconDrawable;->getForeground()Landroid/graphics/drawable/Drawable;

    move-result-object v0
    :try_end_17
    .catchall {:try_start_13 .. :try_end_17} :catchall_19

    goto :goto_19

    :cond_18
    move-object v0, v2

    :catchall_19
    :goto_19
    if-eqz v0, :cond_20

    .line 557
    invoke-static {v0}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->cloneDrawable(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0

    .line 559
    :cond_20
    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->cloneDrawable(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0
.end method

.method public static render(Landroid/view/View;Linv/exe/systemui/qs/controller/InvMediaSessionController;)V
    .registers 3

    const/4 v0, 0x2

    .line 34
    invoke-static {p0, p1, v0, v0}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->render(Landroid/view/View;Linv/exe/systemui/qs/controller/InvMediaSessionController;II)V

    return-void
.end method

.method public static render(Landroid/view/View;Linv/exe/systemui/qs/controller/InvMediaSessionController;II)V
    .registers 41

    move-object/from16 v0, p0

    move-object/from16 v6, p1

    if-nez v0, :cond_7

    return-void

    .line 39
    :cond_7
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    .line 40
    const-string v1, "media_body"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    move-object v8, v1

    check-cast v8, Landroid/widget/FrameLayout;

    const-string v2, "inv_media_card_corner_radius"

    invoke-static {v8, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->dimenDp(Landroid/view/View;Ljava/lang/String;)F

    move-result v2

    invoke-static {v8, v2}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClipRoundedRect(Landroid/view/View;F)V

    .line 41
    const-string v1, "media_content"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/FrameLayout;

    .line 42
    const-string v2, "media_title"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    move-object v11, v2

    check-cast v11, Landroid/widget/TextView;

    .line 43
    const-string v2, "media_artist"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    move-object v12, v2

    check-cast v12, Landroid/widget/TextView;

    .line 44
    const-string v2, "media_info"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout;

    .line 45
    const-string v3, "media_art_holder"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v9

    const-string v3, "inv_media_card_corner_radius"

    invoke-static {v9, v3}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->dimenDp(Landroid/view/View;Ljava/lang/String;)F

    move-result v3

    invoke-static {v9, v3}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClipRoundedRect(Landroid/view/View;F)V

    .line 46
    const-string v3, "media_art"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ImageView;

    const-string v4, "inv_media_card_corner_radius"

    invoke-static {v3, v4}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->dimenDp(Landroid/view/View;Ljava/lang/String;)F

    move-result v4

    invoke-static {v3, v4}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClipRoundedRect(Landroid/view/View;F)V

    .line 47
    const-string v4, "media_blur_bg"

    invoke-static {v4}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v0, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/ImageView;

    const-string v5, "inv_media_card_corner_radius"

    invoke-static {v4, v5}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->dimenDp(Landroid/view/View;Ljava/lang/String;)F

    move-result v5

    invoke-static {v4, v5}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClipRoundedRect(Landroid/view/View;F)V

    .line 48
    const-string v5, "media_scrim"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v0, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v10

    .line 49
    const-string v5, "media_placeholder_icon"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v0, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    move-object v13, v5

    check-cast v13, Landroid/widget/ImageView;

    const-string v5, "media_app_button"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v0, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v14

    if-nez v14, :cond_b4

    move-object v14, v13

    :cond_b4
    if-eqz v14, :cond_d2

    new-instance v5, Linv/exe/systemui/qs/helper/InvMediaAppClickListener;

    invoke-direct {v5, v6, v8}, Linv/exe/systemui/qs/helper/InvMediaAppClickListener;-><init>(Linv/exe/systemui/qs/controller/InvMediaSessionController;Landroid/view/View;)V

    invoke-virtual {v14, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    if-eqz v8, :cond_c3

    invoke-virtual {v8, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_c3
    const/4 v5, 0x1

    invoke-virtual {v14, v5}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {v14, v5}, Landroid/view/View;->setFocusable(Z)V

    if-eqz v8, :cond_d2

    invoke-virtual {v8, v5}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {v8, v5}, Landroid/view/View;->setFocusable(Z)V

    .line 50
    :cond_d2
    const-string v5, "media_output_button"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v0, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v14

    .line 51
    const-string v5, "media_output"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v0, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    move-object v15, v5

    check-cast v15, Landroid/widget/ImageView;

    .line 52
    const-string v5, "media_output_label"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v0, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    move-object/from16 v16, v5

    check-cast v16, Landroid/widget/TextView;

    .line 53
    const-string v5, "media_controls"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v0, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/FrameLayout;

    .line 54
    const-string v17, "media_prev"

    move-object/from16 v28, v1

    invoke-static/range {v17 .. v17}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    move-object/from16 v17, v1

    check-cast v17, Landroid/widget/ImageView;

    .line 55
    const-string v1, "media_play"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    move-object/from16 v18, v1

    check-cast v18, Landroid/widget/ImageView;

    .line 56
    const-string v1, "media_next"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    move-object/from16 v19, v1

    check-cast v19, Landroid/widget/ImageView;

    .line 57
    const-string v1, "media_shuffle"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    move-object/from16 v20, v1

    check-cast v20, Landroid/widget/ImageView;

    .line 58
    const-string v1, "media_time_row"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/FrameLayout;

    .line 59
    const-string v21, "media_time_start"

    move-object/from16 v29, v1

    invoke-static/range {v21 .. v21}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    move-object/from16 v23, v1

    check-cast v23, Landroid/widget/TextView;

    .line 60
    const-string v1, "media_time_end"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    move-object/from16 v24, v1

    check-cast v24, Landroid/widget/TextView;

    .line 61
    const-string v1, "media_seek_container"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/FrameLayout;

    .line 62
    const-string v21, "media_seek_track"

    move-object/from16 v30, v1

    invoke-static/range {v21 .. v21}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    .line 63
    const-string v21, "media_seek_fill"

    move-object/from16 v22, v1

    invoke-static/range {v21 .. v21}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v6, :cond_196

    .line 65
    invoke-virtual {v6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->hasAccess()Z

    move-result v21

    if-eqz v21, :cond_196

    const/16 v31, 0x1

    goto :goto_198

    :cond_196
    const/16 v31, 0x0

    :goto_198
    if-eqz v6, :cond_1a3

    .line 66
    invoke-virtual {v6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->hasSession()Z

    move-result v21

    if-eqz v21, :cond_1a3

    const/16 v32, 0x1

    goto :goto_1a5

    :cond_1a3
    const/16 v32, 0x0

    :goto_1a5
    const/16 v21, 0x0

    if-eqz v32, :cond_1ae

    .line 67
    invoke-virtual {v6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->getTitle()Ljava/lang/CharSequence;

    move-result-object v25

    goto :goto_1b0

    :cond_1ae
    move-object/from16 v25, v21

    :goto_1b0
    if-eqz v32, :cond_1b7

    .line 68
    invoke-virtual {v6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->getSubtitle()Ljava/lang/CharSequence;

    move-result-object v26

    goto :goto_1b9

    :cond_1b7
    move-object/from16 v26, v21

    :goto_1b9
    if-eqz v11, :cond_1d5

    if-nez v31, :cond_1c0

    .line 73
    const-string v1, "Media access required"

    goto :goto_1cf

    .line 74
    :cond_1c0
    const-string v1, "Not Playing"

    if-nez v32, :cond_1c5

    goto :goto_1cf

    .line 77
    :cond_1c5
    invoke-static/range {v25 .. v25}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v27

    if-eqz v27, :cond_1cd

    .line 78
    const-string v25, "Not Playing"

    :cond_1cd
    move-object/from16 v1, v25

    .line 80
    :goto_1cf
    invoke-static {v11, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setTextIfChanged(Landroid/widget/TextView;Ljava/lang/CharSequence;)V

    .line 81
    invoke-static {v11}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->enableMarquee(Landroid/widget/TextView;)V

    :cond_1d5
    if-eqz v12, :cond_1f1

    if-nez v31, :cond_1dc

    .line 86
    const-string v1, "Tap media card to enable sessions"

    goto :goto_1eb

    .line 87
    :cond_1dc
    const-string v1, "Unknown Artist"

    if-nez v32, :cond_1e1

    goto :goto_1eb

    .line 90
    :cond_1e1
    invoke-static/range {v26 .. v26}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v25

    if-eqz v25, :cond_1e9

    .line 91
    const-string v26, "Unknown Artist"

    :cond_1e9
    move-object/from16 v1, v26

    .line 93
    :goto_1eb
    invoke-static {v12, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setTextIfChanged(Landroid/widget/TextView;Ljava/lang/CharSequence;)V

    .line 94
    invoke-static {v12}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->enableMarquee(Landroid/widget/TextView;)V

    :cond_1f1
    const/4 v1, 0x4

    move-object/from16 v25, v0

    move/from16 v0, p2

    .line 97
    invoke-static {v1, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v1, 0x2

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    move-object/from16 v33, v2

    move/from16 v2, p3

    .line 98
    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/4 v1, 0x1

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    if-gt v2, v1, :cond_211

    const/16 p2, 0x1

    goto :goto_213

    :cond_211
    const/16 p2, 0x0

    :goto_213
    const/4 v1, 0x2

    if-lt v2, v1, :cond_21b

    const/4 v1, 0x4

    if-lt v0, v1, :cond_21b

    const/4 v1, 0x1

    goto :goto_21c

    :cond_21b
    const/4 v1, 0x0

    :goto_21c
    move/from16 p3, v1

    if-eqz p2, :cond_225

    const/4 v1, 0x2

    if-gt v0, v1, :cond_225

    const/4 v1, 0x1

    goto :goto_226

    :cond_225
    const/4 v1, 0x0

    :goto_226
    if-eqz v32, :cond_22f

    .line 102
    invoke-virtual {v6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->getArtwork()Landroid/graphics/Bitmap;

    move-result-object v26

    move-object/from16 v34, v26

    goto :goto_231

    :cond_22f
    move-object/from16 v34, v21

    :goto_231
    if-eqz v32, :cond_239

    if-eqz v6, :cond_239

    .line 103
    invoke-virtual {v6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->getAppIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v21

    :cond_239
    move-object/from16 v35, v21

    if-eqz v34, :cond_248

    if-nez v1, :cond_241

    if-eqz p3, :cond_248

    :cond_241
    move-object/from16 v21, v22

    move-object/from16 v22, v25

    const/16 v25, 0x1

    goto :goto_24e

    :cond_248
    move-object/from16 v21, v22

    move-object/from16 v22, v25

    const/16 v25, 0x0

    :goto_24e
    move/from16 v26, p2

    move/from16 v27, p3

    move-object/from16 v36, v28

    move/from16 v28, v32

    .line 108
    invoke-static/range {v7 .. v28}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->applySurface(Landroid/content/Context;Landroid/widget/FrameLayout;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/ImageView;Landroid/view/View;Landroid/widget/ImageView;Landroid/widget/TextView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;ZZZZ)V

    move-object/from16 v28, v36

    move/from16 v36, v25

    move-object/from16 v1, v22

    move/from16 v22, v0

    move-object/from16 v0, v19

    move/from16 v19, v26

    move-object/from16 v26, v1

    move-object v1, v14

    move-object v8, v15

    move-object/from16 v10, v16

    move-object/from16 v14, v17

    move-object/from16 v15, v18

    move/from16 v18, v27

    move-object/from16 v16, v4

    move-object/from16 v4, v23

    move/from16 v23, v2

    move-object/from16 v2, v20

    move/from16 v20, v25

    move-object/from16 v25, v21

    if-nez v11, :cond_286

    .line 112
    const-string v17, "Media player"

    move-object/from16 v21, v3

    move-object/from16 v3, v17

    goto :goto_28c

    :cond_286
    move-object/from16 v21, v3

    invoke-virtual {v11}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v3

    :goto_28c
    move-object/from16 p2, v4

    move-object v4, v15

    move-object/from16 v17, v35

    move-object v15, v13

    move-object/from16 v13, v21

    move-object/from16 v21, v3

    move-object v3, v14

    move-object/from16 v14, v16

    move-object/from16 v16, v34

    .line 111
    invoke-static/range {v13 .. v21}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->bindArtwork(Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/graphics/Bitmap;Landroid/graphics/drawable/Drawable;ZZZLjava/lang/CharSequence;)V

    move-object/from16 v13, p0

    move/from16 v14, v18

    invoke-static {v13, v6, v14}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->applyAppIconChrome(Landroid/view/View;Linv/exe/systemui/qs/controller/InvMediaSessionController;Z)V

    .line 113
    invoke-static {v7, v8, v10, v6}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->bindOutputRoute(Landroid/content/Context;Landroid/widget/ImageView;Landroid/widget/TextView;Linv/exe/systemui/qs/controller/InvMediaSessionController;)V

    if-eqz v32, :cond_2b2

    .line 115
    invoke-virtual {v6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->isPlaying()Z

    move-result v8

    if-eqz v8, :cond_2b2

    const/4 v8, 0x1

    goto :goto_2b3

    :cond_2b2
    const/4 v8, 0x0

    :goto_2b3
    move-object/from16 v13, p0

    move-object/from16 v14, v16

    move/from16 v15, v36

    invoke-static {v13, v14, v15, v8}, Linv/exe/systemui/qs/ui/InvMediaEffects;->apply(Landroid/view/View;Landroid/graphics/Bitmap;ZZ)V

    if-eqz v4, :cond_2d6

    if-eqz v8, :cond_2c3

    .line 117
    const-string v13, "inv_ic_pause"

    goto :goto_2c5

    :cond_2c3
    const-string v13, "inv_ic_play"

    :goto_2c5
    invoke-static {v13}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v13

    invoke-virtual {v4, v13}, Landroid/widget/ImageView;->setImageResource(I)V

    if-eqz v8, :cond_2d1

    .line 119
    const-string v8, "Pause"

    goto :goto_2d3

    :cond_2d1
    const-string v8, "Play"

    :goto_2d3
    invoke-virtual {v4, v8}, Landroid/widget/ImageView;->setContentDescription(Ljava/lang/CharSequence;)V

    :cond_2d6
    if-eqz v32, :cond_2e0

    .line 122
    invoke-virtual {v6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->canPrevious()Z

    move-result v8

    if-eqz v8, :cond_2e0

    const/4 v8, 0x1

    goto :goto_2e1

    :cond_2e0
    const/4 v8, 0x0

    :goto_2e1
    invoke-static {v3, v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setEnabled(Landroid/widget/ImageView;Z)V

    if-eqz v32, :cond_2ee

    .line 123
    invoke-virtual {v6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->canPlayPause()Z

    move-result v8

    if-eqz v8, :cond_2ee

    const/4 v8, 0x1

    goto :goto_2ef

    :cond_2ee
    const/4 v8, 0x0

    :goto_2ef
    invoke-static {v4, v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setEnabled(Landroid/widget/ImageView;Z)V

    if-eqz v32, :cond_2fc

    .line 124
    invoke-virtual {v6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->canNext()Z

    move-result v8

    if-eqz v8, :cond_2fc

    const/4 v8, 0x1

    goto :goto_2fd

    :cond_2fc
    const/4 v8, 0x0

    :goto_2fd
    invoke-static {v0, v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setEnabled(Landroid/widget/ImageView;Z)V

    if-eqz v32, :cond_30a

    .line 125
    invoke-virtual {v6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->canShuffle()Z

    move-result v8

    if-eqz v8, :cond_30a

    const/4 v8, 0x1

    goto :goto_30b

    :cond_30a
    const/4 v8, 0x0

    :goto_30b
    invoke-static {v2, v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setEnabled(Landroid/widget/ImageView;Z)V

    if-eqz v2, :cond_32b

    invoke-virtual {v6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->isShuffleEnabled()Z

    move-result v8

    invoke-virtual {v2, v8}, Landroid/widget/ImageView;->setActivated(Z)V

    if-eqz v8, :cond_31f

    const/high16 v8, 0x3f800000  # 1.0f

    invoke-virtual {v2, v8}, Landroid/widget/ImageView;->setAlpha(F)V

    goto :goto_32b

    :cond_31f
    invoke-virtual {v6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->canShuffle()Z

    move-result v8

    if-eqz v8, :cond_32b

    const v8, 0x3f400000  # 0.75f

    invoke-virtual {v2, v8}, Landroid/widget/ImageView;->setAlpha(F)V

    :cond_32b
    :goto_32b
    if-eqz v1, :cond_33c

    const/4 v8, 0x1

    .line 127
    invoke-virtual {v1, v8}, Landroid/view/View;->setEnabled(Z)V

    if-eqz v31, :cond_336

    const/high16 v8, 0x3f800000  # 1.0f

    goto :goto_339

    :cond_336
    const v8, 0x3f000000  # 0.5f

    .line 128
    :goto_339
    invoke-virtual {v1, v8}, Landroid/view/View;->setAlpha(F)V

    :cond_33c
    move-object/from16 v16, v0

    move-object/from16 v17, v2

    move-object v14, v3

    move-object v15, v4

    move-object v13, v5

    move-object/from16 v20, v11

    move-object/from16 v21, v12

    move-object/from16 v8, v28

    move-object/from16 v18, v29

    move-object/from16 v19, v30

    move-object v11, v1

    move-object v12, v10

    move-object v10, v9

    move-object/from16 v9, v33

    .line 131
    invoke-static/range {v7 .. v23}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->applyResponsiveLayout(Landroid/content/Context;Landroid/widget/FrameLayout;Landroid/widget/LinearLayout;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/FrameLayout;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/FrameLayout;Landroid/widget/FrameLayout;Landroid/widget/TextView;Landroid/widget/TextView;II)V

    move-object/from16 v0, p0

    move/from16 v1, v22

    move/from16 v2, v23

    invoke-static {v0, v1, v2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->applyMediaArtClip(Landroid/view/View;II)V

    invoke-static {v7, v15, v6}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->applyPlayPauseVisual(Landroid/content/Context;Landroid/widget/ImageView;Linv/exe/systemui/qs/controller/InvMediaSessionController;)V

    move/from16 v1, v36

    invoke-static {v11, v12, v15, v6, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->applyFullArtChrome(Landroid/view/View;Landroid/widget/TextView;Landroid/widget/ImageView;Linv/exe/systemui/qs/controller/InvMediaSessionController;Z)V

    move/from16 v0, v22

    move/from16 v1, v23

    invoke-static {v11, v12, v0, v1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->enforceOutputPolicy(Landroid/view/View;Landroid/widget/TextView;II)V

    move-object v0, v15

    move-object v1, v6

    move/from16 v2, v22

    move/from16 v3, v23

    move/from16 v4, v36

    invoke-static {v0, v1, v2, v3, v4}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->applyPlayPauseChrome(Landroid/widget/ImageView;Linv/exe/systemui/qs/controller/InvMediaSessionController;IIZ)V

    move-object/from16 v4, p2

    move-object/from16 v3, v18

    move-object/from16 v0, v19

    move/from16 v7, v22

    move/from16 v8, v23

    move-object/from16 v5, v24

    move-object/from16 v1, v25

    move-object/from16 v2, v26

    .line 133
    invoke-static/range {v0 .. v8}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->bindProgress(Landroid/widget/FrameLayout;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;Linv/exe/systemui/qs/controller/InvMediaSessionController;II)V

    return-void
.end method

.method private static resetControlView(Landroid/widget/ImageView;I)V
    .registers 4

    if-nez p0, :cond_3

    return-void

    :cond_3
    const/4 v0, 0x0

    .line 624
    invoke-virtual {p0}, Landroid/widget/ImageView;->getVisibility()I

    move-result v1

    if-eq v1, v0, :cond_d

    invoke-virtual {p0, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 625
    :cond_d
    invoke-virtual {p0}, Landroid/widget/ImageView;->getPaddingLeft()I

    move-result v1

    if-ne v1, p1, :cond_26

    invoke-virtual {p0}, Landroid/widget/ImageView;->getPaddingTop()I

    move-result v1

    if-ne v1, p1, :cond_26

    invoke-virtual {p0}, Landroid/widget/ImageView;->getPaddingRight()I

    move-result v1

    if-ne v1, p1, :cond_26

    invoke-virtual {p0}, Landroid/widget/ImageView;->getPaddingBottom()I

    move-result v1

    if-ne v1, p1, :cond_26

    return-void

    :cond_26
    invoke-virtual {p0, p1, p1, p1, p1}, Landroid/widget/ImageView;->setPadding(IIII)V

    return-void
.end method

.method private static setEnabled(Landroid/widget/ImageView;Z)V
    .registers 2

    if-nez p0, :cond_3

    return-void

    .line 618
    :cond_3
    invoke-virtual {p0, p1}, Landroid/widget/ImageView;->setEnabled(Z)V

    if-eqz p1, :cond_b

    const/high16 p1, 0x3f800000  # 1.0f

    goto :goto_d

    :cond_b
    const/high16 p1, 0x3f000000  # 0.5f

    .line 619
    :goto_d
    invoke-virtual {p0, p1}, Landroid/widget/ImageView;->setAlpha(F)V

    return-void
.end method

.method private static setPillBackground(Landroid/view/View;I)V
    .registers 4

    .line 664
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v1, 0x0

    .line 665
    invoke-virtual {v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 666
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 667
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const-string v1, "inv_component_pill_corner_radius"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->dimen(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 668
    invoke-virtual {p0, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method private static setTextIfChanged(Landroid/widget/TextView;Ljava/lang/CharSequence;)V
    .registers 3

    if-nez p0, :cond_3

    goto :goto_10

    .line 602
    :cond_3
    invoke-virtual {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    .line 603
    invoke-static {v0, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_10

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_10
    :goto_10
    return-void
.end method

.method private static setTextSizeDimen(Landroid/widget/TextView;Ljava/lang/String;)V
    .registers 4

    if-nez p0, :cond_3

    return-void

    .line 656
    :cond_3
    invoke-virtual {p0}, Landroid/widget/TextView;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-static {p1}, Linv/exe/systemui/qs/core/InvRes;->dimen(Ljava/lang/String;)I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    invoke-virtual {p0}, Landroid/widget/TextView;->getTextSize()F

    move-result v0

    cmpl-float v0, v0, p1

    if-eqz v0, :cond_1b

    const/4 v0, 0x0

    invoke-virtual {p0, v0, p1}, Landroid/widget/TextView;->setTextSize(IF)V

    :cond_1b
    return-void
.end method

.method private static twoDigits(J)Ljava/lang/String;
    .registers 4

    const-wide/16 v0, 0xa

    cmp-long v0, p0, v0

    if-gez v0, :cond_15

    .line 456
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "0"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_15
    invoke-static {p0, p1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private static updateFill(Landroid/view/View;Landroid/view/View;F)V
    .registers 5

    .line 460
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v0

    if-gtz v0, :cond_18

    .line 461
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    instance-of v1, v1, Landroid/view/View;

    if-eqz v1, :cond_18

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v0

    :cond_18
    if-gtz v0, :cond_1b

    return-void

    .line 463
    :cond_1b
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Landroid/widget/FrameLayout$LayoutParams;

    int-to-float v1, v0

    mul-float/2addr v1, p2

    .line 464
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result p2

    invoke-static {v0, p2}, Ljava/lang/Math;->min(II)I

    move-result p2

    const/4 v0, 0x0

    invoke-static {v0, p2}, Ljava/lang/Math;->max(II)I

    move-result p2

    iput p2, p0, Landroid/widget/FrameLayout$LayoutParams;->width:I

    .line 465
    invoke-virtual {p1, p0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private static updateProgressNow(Landroid/widget/FrameLayout;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;ZLinv/exe/systemui/qs/controller/InvMediaSessionController;[Z[J)V
    .registers 16

    const/4 p0, 0x0

    const-wide/16 v0, 0x0

    if-eqz p6, :cond_15

    .line 427
    invoke-virtual {p6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->hasSession()Z

    move-result v2

    if-eqz v2, :cond_15

    .line 428
    invoke-virtual {p6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->getDurationMillis()J

    move-result-wide v2

    cmp-long v2, v2, v0

    if-lez v2, :cond_15

    const/4 v2, 0x1

    goto :goto_16

    :cond_15
    move v2, p0

    :goto_16
    if-eqz v2, :cond_1d

    .line 429
    invoke-virtual {p6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->getDurationMillis()J

    move-result-wide v3

    goto :goto_1e

    :cond_1d
    move-wide v3, v0

    :goto_1e
    if-eqz v2, :cond_25

    .line 430
    invoke-virtual {p6}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->getPositionMillis()J

    move-result-wide v5

    goto :goto_26

    :cond_25
    move-wide v5, v0

    :goto_26
    cmp-long p6, v3, v0

    const/4 v0, 0x0

    if-gtz p6, :cond_2c

    goto :goto_39

    :cond_2c
    long-to-float p6, v5

    long-to-float v1, v3

    div-float/2addr p6, v1

    const/high16 v1, 0x3f800000  # 1.0f

    .line 431
    invoke-static {v1, p6}, Ljava/lang/Math;->min(FF)F

    move-result p6

    invoke-static {v0, p6}, Ljava/lang/Math;->max(FF)F

    move-result v0

    .line 432
    :goto_39
    aput-boolean v2, p7, p0

    .line 433
    aput-wide v3, p8, p0

    .line 434
    invoke-static {p1, p2, v0}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->updateFill(Landroid/view/View;Landroid/view/View;F)V

    if-eqz p5, :cond_49

    move-object p1, p3

    move-object p2, p4

    move-wide p5, v3

    move-wide p3, v5

    .line 435
    invoke-static/range {p1 .. p6}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->updateTimeLabels(Landroid/widget/TextView;Landroid/widget/TextView;JJ)V

    :cond_49
    return-void
.end method

.method private static updateTimeLabels(Landroid/widget/TextView;Landroid/widget/TextView;JJ)V
    .registers 6

    if-eqz p0, :cond_9

    .line 439
    invoke-static {p2, p3}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->formatMediaTime(J)Ljava/lang/String;

    move-result-object p2

    invoke-static {p0, p2}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setTextIfChanged(Landroid/widget/TextView;Ljava/lang/CharSequence;)V

    :cond_9
    if-eqz p1, :cond_12

    .line 440
    invoke-static {p4, p5}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->formatMediaTime(J)Ljava/lang/String;

    move-result-object p0

    invoke-static {p1, p0}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->setTextIfChanged(Landroid/widget/TextView;Ljava/lang/CharSequence;)V

    :cond_12
    return-void
.end method
