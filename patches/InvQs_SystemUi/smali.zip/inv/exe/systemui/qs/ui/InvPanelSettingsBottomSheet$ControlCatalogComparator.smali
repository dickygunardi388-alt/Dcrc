.class final Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$ControlCatalogComparator;
.super Ljava/lang/Object;
.source "PanelSettingsBottomSheet.java"

# interfaces
.implements Ljava/util/Comparator;


# direct methods
.method constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static bucket(Linv/exe/systemui/qs/model/InvControlId;)I
    .registers 5

    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$ControlCatalogComparator;->previewSpanW(Linv/exe/systemui/qs/model/InvControlId;)I

    move-result v0

    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$ControlCatalogComparator;->previewSpanH(Linv/exe/systemui/qs/model/InvControlId;)I

    move-result p0

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-ne v0, v1, :cond_10

    if-ne p0, v1, :cond_10

    const/4 p0, 0x0

    return p0

    :cond_10
    if-ne v0, v2, :cond_15

    if-ne p0, v1, :cond_15

    return v2

    :cond_15
    if-ne v0, v1, :cond_1a

    if-ne p0, v2, :cond_1a

    return v1

    :cond_1a
    if-ne v0, v2, :cond_20

    if-ne p0, v2, :cond_20

    const/4 p0, 0x3

    return p0

    :cond_20
    const/4 p0, 0x4

    return p0
.end method

.method public static previewSpanH(Linv/exe/systemui/qs/model/InvControlId;)I
    .registers 2

    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->MEDIA:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_6

    const/4 p0, 0x2

    return p0

    :cond_6
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->CUSTOM_IMAGE:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_c

    const/4 p0, 0x2

    return p0

    :cond_c
    iget p0, p0, Linv/exe/systemui/qs/model/InvControlId;->spanH:I

    return p0
.end method

.method public static previewSpanW(Linv/exe/systemui/qs/model/InvControlId;)I
    .registers 2

    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->MEDIA:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_6

    const/4 p0, 0x2

    return p0

    :cond_6
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->CUSTOM_IMAGE:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_c

    const/4 p0, 0x2

    return p0

    :cond_c
    iget p0, p0, Linv/exe/systemui/qs/model/InvControlId;->spanW:I

    return p0
.end method


# virtual methods
.method public compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 5

    check-cast p1, Linv/exe/systemui/qs/model/InvControlId;

    check-cast p2, Linv/exe/systemui/qs/model/InvControlId;

    invoke-static {p1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$ControlCatalogComparator;->bucket(Linv/exe/systemui/qs/model/InvControlId;)I

    move-result p0

    invoke-static {p2}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$ControlCatalogComparator;->bucket(Linv/exe/systemui/qs/model/InvControlId;)I

    move-result v0

    sub-int v1, p0, v0

    if-nez v1, :cond_1a

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    sub-int v1, p0, v0

    :cond_1a
    return v1
.end method
