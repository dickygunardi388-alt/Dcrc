.class public Linv/exe/systemui/qs/ui/InvQsPanelView$6;
.super Ljava/lang/Object;
.source "QsPanelView.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Linv/exe/systemui/qs/ui/InvQsPanelView;->scheduleOrientationLayoutRebuild()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field public final synthetic this$0:Linv/exe/systemui/qs/ui/InvQsPanelView;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/ui/InvQsPanelView;)V
    .registers 2

    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvQsPanelView$6;->this$0:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 2

    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView$6;->this$0:Linv/exe/systemui/qs/ui/InvQsPanelView;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->forceResponsiveLayoutNow()V

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isShown()Z

    move-result v0

    if-eqz v0, :cond_14

    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->access$0(Linv/exe/systemui/qs/ui/InvQsPanelView;)Linv/exe/systemui/qs/controller/InvQsPanelController;

    move-result-object v0

    if-eqz v0, :cond_14

    invoke-virtual {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->rebuildUi()V

    :cond_14
    return-void
.end method
