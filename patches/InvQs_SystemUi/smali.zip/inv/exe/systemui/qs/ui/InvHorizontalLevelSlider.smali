.class public Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;
.super Ljava/lang/Object;
.source "HorizontalLevelSlider.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider$Listener;
    }
.end annotation


# instance fields
.field private final box:Landroid/view/View;

.field private final fill:Landroid/view/View;

.field private final icon:Landroid/widget/ImageView;

.field private final listener:Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider$Listener;

.field private final max:I

.field private onFill:I

.field private onTrack:I

.field private progress:I

.field private tracking:Z


# direct methods
.method public constructor <init>(Landroid/view/View;Landroid/view/View;ILinv/exe/systemui/qs/ui/InvHorizontalLevelSlider$Listener;Landroid/widget/ImageView;II)V
    .registers 8

    .line 19
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 21
    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->box:Landroid/view/View;

    .line 22
    iput-object p2, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->fill:Landroid/view/View;

    .line 23
    iput p3, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->max:I

    .line 24
    iput-object p4, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->listener:Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider$Listener;

    .line 25
    iput-object p5, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->icon:Landroid/widget/ImageView;

    .line 26
    iput p6, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->onTrack:I

    .line 27
    iput p7, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->onFill:I

    .line 28
    invoke-virtual {p1, p0}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    const/4 p2, 0x1

    .line 29
    invoke-virtual {p1, p2}, Landroid/view/View;->setClickable(Z)V

    .line 30
    invoke-static {p1}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClipToRounded(Landroid/view/View;)V

    .line 31
    new-instance p2, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider$$ExternalSyntheticLambda2;

    invoke-direct {p2, p0}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider$$ExternalSyntheticLambda2;-><init>(Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;)V

    invoke-virtual {p1, p2}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    return-void
.end method

.method public static applyAdaptiveUi(Landroid/view/View;IILandroid/widget/ImageView;)V
    .registers 16

    if-eqz p0, :cond_16a

    const/4 v0, 0x1

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result v1

    mul-int/lit8 v2, p2, 0x64

    div-int/2addr v2, v1

    const/4 v1, 0x0

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    const/16 v3, 0x64

    invoke-static {v3, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    goto :goto_47

    const-string v3, "slider_fill"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {p0, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    if-eqz v3, :cond_47

    invoke-virtual {v3}, Landroid/view/View;->getWidth()I

    move-result v5

    if-gtz v5, :cond_33

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    if-eqz v4, :cond_47

    iget v5, v4, Landroid/view/ViewGroup$LayoutParams;->width:I

    if-gtz v5, :cond_33

    goto :goto_47

    :cond_33
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v6

    if-gtz v6, :cond_3a

    goto :goto_47

    :cond_3a
    mul-int/lit8 v5, v5, 0x64

    div-int/2addr v5, v6

    invoke-static {v1, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    const/16 v6, 0x64

    invoke-static {v6, v5}, Ljava/lang/Math;->min(II)I

    move-result v2

    :cond_47
    :goto_47
    const-string v3, "slider_title"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {p0, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    const-string v4, "slider_summary"

    invoke-static {v4}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {p0, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    const/4 v5, 0x0

    const-string v6, "slider_body"

    invoke-static {v6}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {p0, v6}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    move-result-object v6

    instance-of v7, v6, Ljava/lang/String;

    if-eqz v7, :cond_78

    check-cast v6, Ljava/lang/String;

    const-string v7, "volume"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_a5

    :cond_78
    invoke-virtual {p0}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v6

    instance-of v7, v6, Ljava/lang/String;

    if-eqz v7, :cond_8b

    check-cast v6, Ljava/lang/String;

    const-string v7, "volume"

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_a5

    goto :goto_99

    :cond_8b
    if-eqz v6, :cond_99

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    const-string v7, "VOLUME"

    invoke-virtual {v6, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_a5

    :cond_99
    :goto_99
    if-eqz v3, :cond_a5

    invoke-virtual {v3}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v6

    const-string v7, "Volume"

    invoke-static {v6, v7}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v5

    :cond_a5
    if-eqz v4, :cond_c8

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v7, "%"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v7

    invoke-static {v7, v6}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_c5

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_c5
    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setSelected(Z)V

    :cond_c8
    const/4 v6, 0x0

    const-string v7, "slider_fill"

    invoke-static {v7}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {p0, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v8, 0x0

    if-eqz v7, :cond_105

    invoke-virtual {v7}, Landroid/view/View;->getWidth()I

    move-result v8

    invoke-virtual {v7}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v7

    if-eqz v7, :cond_e6

    iget v10, v7, Landroid/view/ViewGroup$LayoutParams;->width:I

    invoke-static {v8, v10}, Ljava/lang/Math;->max(II)I

    move-result v8

    :cond_e6
    const-string v9, "slider_text_stack"

    invoke-static {v9}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v9

    invoke-virtual {p0, v9}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v9

    const/4 v10, 0x0

    if-eqz v9, :cond_fa

    invoke-virtual {v9}, Landroid/view/View;->getLeft()I

    move-result v10

    if-lez v10, :cond_fa

    goto :goto_102

    :cond_fa
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v10

    mul-int/lit8 v10, v10, 0x20

    div-int/lit8 v10, v10, 0x64

    :goto_102
    if-lt v8, v10, :cond_105

    const/4 v6, 0x1

    :cond_105
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    const-string v8, "inv_text_on_accent"

    invoke-static {v8}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v8

    invoke-virtual {v7, v8}, Landroid/content/Context;->getColor(I)I

    move-result v8

    const-string v9, "inv_text_primary"

    invoke-static {v9}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v9

    invoke-virtual {v7, v9}, Landroid/content/Context;->getColor(I)I

    move-result v9

    const-string v10, "inv_text_secondary"

    invoke-static {v10}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v7, v10}, Landroid/content/Context;->getColor(I)I

    move-result v10

    if-eqz v3, :cond_131

    if-eqz v6, :cond_12d

    move v11, v8

    goto :goto_12e

    :cond_12d
    move v11, v9

    :goto_12e
    invoke-virtual {v3, v11}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_131
    if-eqz v4, :cond_13b

    if-eqz v6, :cond_137

    move v11, v8

    goto :goto_138

    :cond_137
    move v11, v10

    :goto_138
    invoke-virtual {v4, v11}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_13b
    if-eqz p3, :cond_16a

    if-eqz v5, :cond_147

    if-lez v2, :cond_144

    const-string v11, "inv_ic_volume"

    goto :goto_157

    :cond_144
    const-string v11, "inv_ic_volume_off"

    goto :goto_157

    :cond_147
    const/16 v11, 0x21

    if-gt v2, v11, :cond_14e

    const-string v11, "inv_ic_brightness_low"

    goto :goto_157

    :cond_14e
    const/16 v11, 0x42

    if-gt v2, v11, :cond_155

    const-string v11, "inv_ic_brightness_medium"

    goto :goto_157

    :cond_155
    const-string v11, "inv_ic_brightness_full"

    :goto_157
    invoke-static {v11}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {p3, v11}, Landroid/widget/ImageView;->setImageResource(I)V

    if-eqz v6, :cond_162

    move v11, v8

    goto :goto_163

    :cond_162
    move v11, v9

    :goto_163
    invoke-static {v11}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v11

    invoke-virtual {p3, v11}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    :cond_16a
    return-void
.end method

.method public static applyStaticProgress(Landroid/view/View;Landroid/view/View;IILandroid/widget/ImageView;II)V
    .registers 15

    .line 63
    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvVerticalLevelSlider;->enableClipToRounded(Landroid/view/View;)V

    .line 64
    new-instance v0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider$$ExternalSyntheticLambda1;

    move-object v1, p0

    move-object v4, p1

    move v2, p2

    move v3, p3

    move-object v5, p4

    move v7, p5

    move v6, p6

    invoke-direct/range {v0 .. v7}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider$$ExternalSyntheticLambda1;-><init>(Landroid/view/View;IILandroid/view/View;Landroid/widget/ImageView;II)V

    .line 93
    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result p0

    if-lez p0, :cond_19

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    return-void

    :cond_19
    invoke-virtual {v1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public static synthetic lambda$2(Landroid/view/View;IILandroid/view/View;Landroid/widget/ImageView;II)V
    .registers 16

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v0

    if-gtz v0, :cond_8

    goto/16 :goto_5f

    :cond_8
    const/4 v3, 0x0

    invoke-virtual {p3, v3}, Landroid/view/View;->setVisibility(I)V

    const/4 v1, 0x1

    invoke-static {v1, p1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-static {p1, p2}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/4 v3, 0x0

    invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    nop

    int-to-float v4, v0

    int-to-float v5, v2

    int-to-float v6, v1

    div-float/2addr v5, v6

    mul-float v6, v4, v5

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    invoke-virtual {p3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v7

    iget v8, v7, Landroid/view/ViewGroup$LayoutParams;->width:I

    if-eq v8, v6, :cond_32

    iput v6, v7, Landroid/view/ViewGroup$LayoutParams;->width:I

    invoke-virtual {p3, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_32
    invoke-static {p0, v1, v2, p4}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->applyAdaptiveUi(Landroid/view/View;IILandroid/widget/ImageView;)V

    if-eqz p4, :cond_5f

    invoke-virtual {p4}, Landroid/widget/ImageView;->getRight()I

    move-result v7

    if-gtz v7, :cond_54

    invoke-virtual {p4}, Landroid/widget/ImageView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v7

    instance-of v8, v7, Landroid/view/ViewGroup$MarginLayoutParams;

    if-eqz v8, :cond_4c

    check-cast v7, Landroid/view/ViewGroup$MarginLayoutParams;

    invoke-virtual {v7}, Landroid/view/ViewGroup$MarginLayoutParams;->getMarginEnd()I

    move-result v7

    goto :goto_4d

    :cond_4c
    const/4 v7, 0x0

    :goto_4d
    const/4 v8, 0x0

    invoke-static {v8, v7}, Ljava/lang/Math;->max(II)I

    move-result v8

    sub-int v7, v0, v8

    :cond_54
    if-le v6, v7, :cond_57

    goto :goto_58

    :cond_57
    move p5, p6

    :goto_58
    invoke-static {p5}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v8

    invoke-virtual {p4, v8}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    :cond_5f
    :goto_5f
    return-void
.end method

.method private update()V
    .registers 8

    .line 58
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->box:Landroid/view/View;

    iget-object v1, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->fill:Landroid/view/View;

    iget v2, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->max:I

    iget v3, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->progress:I

    iget-object v4, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->icon:Landroid/widget/ImageView;

    iget v5, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->onTrack:I

    iget v6, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->onFill:I

    invoke-static/range {v0 .. v6}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->applyStaticProgress(Landroid/view/View;Landroid/view/View;IILandroid/widget/ImageView;II)V

    return-void
.end method


# virtual methods
.method public getProgress()I
    .registers 1

    .line 39
    iget p0, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->progress:I

    return p0
.end method

.method public synthetic lambda$1$inv-exe-systemui-qs-HorizontalLevelSlider(Landroid/view/View;IIIIIIII)V
    .registers 10

    .line 31
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->update()V

    return-void
.end method

.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .registers 7

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_26

    const/4 v2, 0x0

    if-eq v0, v1, :cond_16

    const/4 v3, 0x2

    if-eq v0, v3, :cond_11

    const/4 v3, 0x3

    if-eq v0, v3, :cond_16

    return v2

    :cond_11
    iget-boolean v0, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->tracking:Z

    if-eqz v0, :cond_65

    goto :goto_31

    :cond_16
    iget-boolean v0, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->tracking:Z

    if-eqz v0, :cond_65

    iput-boolean v2, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->tracking:Z

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    if-eqz v0, :cond_31

    invoke-interface {v0, v2}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    goto :goto_31

    :cond_26
    iput-boolean v1, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->tracking:Z

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    if-eqz v0, :cond_31

    invoke-interface {v0, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_31
    :goto_31
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result p2

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p1

    invoke-static {v1, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    int-to-float p1, p1

    div-float/2addr p2, p1

    iget p1, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->max:I

    int-to-float p1, p1

    mul-float/2addr p2, p1

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p1

    iget p2, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->max:I

    invoke-static {p2, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 p2, 0x0

    invoke-static {p2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    iget p2, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->progress:I

    if-eq p1, p2, :cond_61

    iput p1, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->progress:I

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->update()V

    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->listener:Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider$Listener;

    invoke-interface {p0, p1}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider$Listener;->onChanged(I)V

    return v1

    :cond_61
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->update()V

    return v1

    :cond_65
    return v2
.end method

.method public refreshTheme()V
    .registers 4

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->box:Landroid/view/View;

    if-eqz v0, :cond_3d

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_3d

    const-string v1, "inv_icon_primary"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getColor(I)I

    move-result v1

    iput v1, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->onTrack:I

    const-string v1, "inv_text_on_accent"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getColor(I)I

    move-result v1

    iput v1, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->onFill:I

    iget-object v1, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->box:Landroid/view/View;

    const-string v2, "inv_bg_slider_track"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackgroundResource(I)V

    iget-object v1, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->fill:Landroid/view/View;

    if-eqz v1, :cond_3a

    const-string v2, "inv_bg_slider_fill"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackgroundResource(I)V

    :cond_3a
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->update()V

    :cond_3d
    return-void
.end method

.method public setProgress(I)V
    .registers 3

    .line 35
    iget v0, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->max:I

    invoke-static {v0, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v0, 0x0

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    iput p1, p0, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->progress:I

    .line 36
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvHorizontalLevelSlider;->update()V

    return-void
.end method
