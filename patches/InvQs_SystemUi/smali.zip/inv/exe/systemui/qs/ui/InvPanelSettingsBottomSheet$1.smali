.class public Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$1;
.super Ljava/lang/Object;
.source "PanelSettingsBottomSheet.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->show(Landroid/view/View;Ljava/lang/Runnable;)Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final synthetic val$sheet:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V
    .registers 2

    .line 77
    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$1;->val$sheet:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 1

    .line 77
    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$1;->val$sheet:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->access$0(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V

    return-void
.end method
