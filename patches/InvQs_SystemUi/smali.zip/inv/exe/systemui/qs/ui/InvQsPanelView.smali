.class public Linv/exe/systemui/qs/ui/InvQsPanelView;
.super Landroid/widget/LinearLayout;
.source "QsPanelView.java"

# interfaces
.implements Lcom/android/systemui/animation/LaunchableView;
.implements Lcom/android/systemui/statusbar/policy/ConfigurationController$ConfigurationListener;


# instance fields
.field private blockVisibilityChanges:Z

.field private bound:Z

.field private final controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

.field private initialLandscapeRebuildDone:Z

.field private lastOrientation:I

.field private mConfigurationController:Lcom/android/systemui/statusbar/policy/ConfigurationController;

.field private final orientationRelayoutRunnable:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 23
    invoke-direct {p0, p1, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4

    const/4 v0, 0x0

    .line 24
    invoke-direct {p0, p1, p2, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 5

    .line 27
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 28
    invoke-static {p1}, Linv/exe/systemui/qs/core/InvRes;->init(Landroid/content/Context;)V

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    iget v0, v0, Landroid/content/res/Configuration;->orientation:I

    iput v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->lastOrientation:I

    const-class v0, Lcom/android/systemui/statusbar/policy/ConfigurationController;

    invoke-static {v0}, Lcom/android/systemui/Dependency;->get(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/systemui/statusbar/policy/ConfigurationController;

    iput-object v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->mConfigurationController:Lcom/android/systemui/statusbar/policy/ConfigurationController;

    const/4 p2, 0x1

    .line 29
    invoke-virtual {p0, p2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->setOrientation(I)V

    const/4 p3, 0x0

    .line 30
    invoke-virtual {p0, p3}, Linv/exe/systemui/qs/ui/InvQsPanelView;->setClipChildren(Z)V

    .line 31
    invoke-virtual {p0, p3}, Linv/exe/systemui/qs/ui/InvQsPanelView;->setClipToPadding(Z)V

    .line 32
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    const-string p3, "inv_view_qs_panel"

    invoke-static {p3}, Linv/exe/systemui/qs/core/InvRes;->layout(Ljava/lang/String;)I

    move-result p3

    invoke-virtual {p1, p3, p0, p2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 33
    new-instance p1, Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-direct {p1, p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;-><init>(Linv/exe/systemui/qs/ui/InvQsPanelView;)V

    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    new-instance p1, Linv/exe/systemui/qs/ui/InvQsPanelView$6;

    invoke-direct {p1, p0}, Linv/exe/systemui/qs/ui/InvQsPanelView$6;-><init>(Linv/exe/systemui/qs/ui/InvQsPanelView;)V

    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->orientationRelayoutRunnable:Ljava/lang/Runnable;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->scheduleResponsiveLayoutRefresh()V

    return-void
.end method

.method public static synthetic access$0(Linv/exe/systemui/qs/ui/InvQsPanelView;)Linv/exe/systemui/qs/controller/InvQsPanelController;
    .registers 1

    .line 20
    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    return-object p0
.end method

.method private applyExpansionByName(Ljava/lang/String;FIF)V
    .registers 7

    invoke-static {p1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-direct {p0, v0, p2, p3, p4}, Linv/exe/systemui/qs/ui/InvQsPanelView;->applyExpansionToView(Landroid/view/View;FIF)V

    return-void
.end method

.method private applyExpansionToView(Landroid/view/View;FIF)V
    .registers 10

    if-eqz p1, :cond_31

    const/4 v0, 0x0

    cmpg-float v1, p2, v0

    if-ltz v1, :cond_f

    const/high16 v1, 0x3f800000  # 1.0f

    cmpl-float v2, p2, v1

    if-lez v2, :cond_10

    move p2, v1

    goto :goto_12

    :cond_f
    move p2, v0

    :cond_10
    const/high16 v1, 0x3f800000  # 1.0f

    :goto_12
    sub-float v2, v1, p2

    mul-float v3, v2, v2

    mul-float/2addr v3, v2

    sub-float p2, v1, v3

    sub-float v2, v1, p2

    invoke-direct {p0, p3}, Linv/exe/systemui/qs/ui/InvQsPanelView;->dp(I)I

    move-result p3

    int-to-float p3, p3

    mul-float/2addr p3, v2

    sub-float v2, v1, p4

    mul-float/2addr v2, p2

    add-float/2addr v2, p4

    invoke-virtual {p1, p2}, Landroid/view/View;->setAlpha(F)V

    invoke-virtual {p1, p3}, Landroid/view/View;->setTranslationY(F)V

    invoke-virtual {p1, v2}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {p1, v2}, Landroid/view/View;->setScaleY(F)V

    :cond_31
    return-void
.end method

.method private applyLandscapeHeaderPlacement()V
    .registers 7

    const-string v0, "header_normal"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_33

    const-string v1, "tiles_column"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v1

    instance-of v2, v1, Landroid/widget/LinearLayout;

    if-eqz v2, :cond_33

    check-cast v1, Landroid/widget/LinearLayout;

    invoke-static {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->detachFromParent(Landroid/view/View;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x1

    const/4 v4, -0x2

    invoke-direct {v2, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v3, 0x8

    invoke-direct {p0, v3}, Linv/exe/systemui/qs/ui/InvQsPanelView;->dp(I)I

    move-result p0

    const/4 v3, 0x0

    invoke-virtual {v2, v3, p0, v3, v3}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    invoke-virtual {v1, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_33
    return-void
.end method

.method private applyPortraitChildOrder()V
    .registers 7

    const-string v0, "header_normal"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const-string v1, "header_edit"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v1

    const-string v2, "txt_edit_hint"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p0, v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v2

    const-string v3, "body_host"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {p0, v3}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v3

    if-eqz v0, :cond_2d

    invoke-static {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->detachFromParent(Landroid/view/View;)V

    :cond_2d
    if-eqz v1, :cond_32

    invoke-static {v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->detachFromParent(Landroid/view/View;)V

    :cond_32
    if-eqz v2, :cond_37

    invoke-static {v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->detachFromParent(Landroid/view/View;)V

    :cond_37
    if-eqz v3, :cond_3c

    invoke-static {v3}, Linv/exe/systemui/qs/ui/InvQsPanelView;->detachFromParent(Landroid/view/View;)V

    :cond_3c
    const/4 v4, 0x0

    if-eqz v0, :cond_44

    invoke-virtual {p0, v0, v4}, Linv/exe/systemui/qs/ui/InvQsPanelView;->addView(Landroid/view/View;I)V

    add-int/lit8 v4, v4, 0x1

    :cond_44
    if-eqz v1, :cond_4b

    invoke-virtual {p0, v1, v4}, Linv/exe/systemui/qs/ui/InvQsPanelView;->addView(Landroid/view/View;I)V

    add-int/lit8 v4, v4, 0x1

    :cond_4b
    if-eqz v2, :cond_52

    invoke-virtual {p0, v2, v4}, Linv/exe/systemui/qs/ui/InvQsPanelView;->addView(Landroid/view/View;I)V

    add-int/lit8 v4, v4, 0x1

    :cond_52
    if-eqz v3, :cond_57

    invoke-virtual {p0, v3, v4}, Linv/exe/systemui/qs/ui/InvQsPanelView;->addView(Landroid/view/View;I)V

    :cond_57
    return-void
.end method

.method private applyResponsiveLayout()V
    .registers 13

    const-string v0, "body_host"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    instance-of v1, v0, Landroid/widget/LinearLayout;

    if-eqz v1, :cond_ae

    check-cast v0, Landroid/widget/LinearLayout;

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->applyPortraitChildOrder()V

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v1

    iget v1, v1, Landroid/content/res/Configuration;->orientation:I

    const/4 v2, 0x2

    if-ne v1, v2, :cond_6d

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isSplitShadeEnabled()Z

    move-result v1

    if-eqz v1, :cond_27

    goto :goto_6d

    :cond_27
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/4 v2, -0x1

    const/4 v3, -0x2

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v4, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const-string v4, "controls_column"

    invoke-static {v4}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {p0, v4}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v4

    const-string v5, "tiles_column"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {p0, v5}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v5

    const/high16 v6, 0x3f800000  # 1.0f

    if-eqz v4, :cond_58

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v7, v1, v3, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v7, v1, v1, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    invoke-virtual {v4, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_58
    if-eqz v5, :cond_69

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v7, v1, v3, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->landscapeColumnGapPx()I

    move-result v8

    invoke-virtual {v7, v8, v1, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    invoke-virtual {v5, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_69
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->applyLandscapeHeaderPlacement()V

    goto :goto_ae

    :cond_6d
    :goto_6d
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/4 v1, -0x1

    const/4 v2, -0x2

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v3, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const-string v4, "controls_column"

    invoke-static {v4}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {p0, v4}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v4

    const-string v5, "tiles_column"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {p0, v5}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v5

    const/4 v6, 0x0

    if-eqz v4, :cond_9d

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v7, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v6, v6, v6, v6}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    invoke-virtual {v4, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_9d
    if-eqz v5, :cond_ae

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v7, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->portraitTilesGapPx()I

    move-result v8

    invoke-virtual {v7, v6, v8, v6, v6}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    invoke-virtual {v5, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_ae
    :goto_ae
    return-void
.end method

.method private click(Ljava/lang/String;Landroid/view/View$OnClickListener;)V
    .registers 3

    .line 59
    invoke-static {p1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result p1

    invoke-virtual {p0, p1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object p0

    if-eqz p0, :cond_d

    .line 60
    invoke-virtual {p0, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_d
    return-void
.end method

.method private static detachFromParent(Landroid/view/View;)V
    .registers 3

    if-eqz p0, :cond_f

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v1, v0, Landroid/view/ViewGroup;

    if-eqz v1, :cond_f

    check-cast v0, Landroid/view/ViewGroup;

    invoke-virtual {v0, p0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_f
    return-void
.end method

.method private dp(I)I
    .registers 7

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-static {p1}, Linv/exe/systemui/qs/core/InvRes;->dimenNameForDp(I)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_1f

    const-string v2, "dimen"

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    if-lez v1, :cond_1f

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p0

    return p0

    :cond_1f
    int-to-float p1, p1

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, p0

    const/high16 p0, 0x3f000000  # 0.5f

    add-float/2addr p1, p0

    float-to-int p0, p1

    return p0
.end method

.method private ensureInitialLandscapeLayout()V
    .registers 4

    iget-boolean v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->initialLandscapeRebuildDone:Z

    if-nez v0, :cond_2d

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_2d

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isShown()Z

    move-result v0

    if-eqz v0, :cond_2d

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    iget v0, v0, Landroid/content/res/Configuration;->orientation:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_2a

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isSplitShadeEnabled()Z

    move-result v0

    if-nez v0, :cond_2a

    const/4 v0, 0x1

    iput-boolean v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->initialLandscapeRebuildDone:Z

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->scheduleOrientationLayoutRebuild()V

    return-void

    :cond_2a
    const/4 v0, 0x1

    iput-boolean v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->initialLandscapeRebuildDone:Z

    :cond_2d
    return-void
.end method

.method private exitEditIfHidden()V
    .registers 2

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getVisibility()I

    move-result v0

    if-nez v0, :cond_c

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isShown()Z

    move-result v0

    if-nez v0, :cond_18

    :cond_c
    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dismissIfShowing(Landroid/view/View;)V

    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->onHostHidden()V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->setEditMode(Z)V

    :cond_18
    return-void
.end method

.method private isSplitShadeEnabled()Z
    .registers 7

    :try_start_0
    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string v1, "bool"

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const-string v3, "config_use_split_notification_shade"

    invoke-virtual {v0, v3, v1, v2}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v4

    if-gtz v4, :cond_38

    const-string v2, "com.android.systemui"

    invoke-virtual {v0, v3, v1, v2}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v4

    if-gtz v4, :cond_38

    const-string v3, "config_use_split_shade"

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, v3, v1, p0}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v4

    if-gtz v4, :cond_38

    const-string p0, "com.android.systemui"

    invoke-virtual {v0, v3, v1, p0}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v4

    if-gtz v4, :cond_38

    const/4 v0, 0x0

    return v0

    :cond_38
    invoke-virtual {v0, v4}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result v0

    return v0
    :try_end_3d
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_3d} :catch_3d

    :catch_3d
    const/4 v0, 0x0

    return v0
.end method

.method private landscapeColumnGapPx()I
    .registers 3

    const/16 v0, 0xc

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->dp(I)I

    move-result v0

    const/4 v1, 0x1

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    return v0
.end method

.method private maybeScheduleOrientationLayoutRebuild(Landroid/content/res/Configuration;)V
    .registers 4

    if-eqz p1, :cond_d

    iget v0, p1, Landroid/content/res/Configuration;->orientation:I

    iget v1, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->lastOrientation:I

    if-eq v0, v1, :cond_d

    iput v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->lastOrientation:I

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->scheduleOrientationLayoutRebuild()V

    :cond_d
    return-void
.end method

.method private navigationBarHeight()I
    .registers 6

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string v1, "navigation_bar_height"

    const-string v2, "dimen"

    const-string v3, "android"

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    const/4 v2, 0x0

    if-lez v1, :cond_15

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v2

    :cond_15
    if-lez v2, :cond_18

    return v2

    :cond_18
    const/16 v0, 0x18

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->dp(I)I

    move-result p0

    return p0
.end method

.method private portraitTilesGapPx()I
    .registers 4

    const-string v0, "inv_qs_tiles_section_margin_top"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->dimen(Ljava/lang/String;)I

    move-result v0

    const/4 v1, 0x0

    if-lez v0, :cond_12

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v1

    return v1

    :cond_12
    const/16 v0, 0x10

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->dp(I)I

    move-result v1

    return v1
.end method

.method private refreshStaticThemeResources()V
    .registers 7

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_114

    const-string v1, "inv_bg_header_btn"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v3

    const-string v1, "inv_icon_primary"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getColor(I)I

    move-result v1

    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v4

    const-string v2, "btn_edit"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p0, v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v2

    instance-of v5, v2, Landroid/widget/ImageView;

    if-eqz v5, :cond_30

    invoke-virtual {v2, v3}, Landroid/view/View;->setBackgroundResource(I)V

    check-cast v2, Landroid/widget/ImageView;

    invoke-virtual {v2, v4}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    :cond_30
    const-string v2, "btn_more"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p0, v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v2

    instance-of v5, v2, Landroid/widget/ImageView;

    if-eqz v5, :cond_46

    invoke-virtual {v2, v3}, Landroid/view/View;->setBackgroundResource(I)V

    check-cast v2, Landroid/widget/ImageView;

    invoke-virtual {v2, v4}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    :cond_46
    const-string v2, "btn_reset"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p0, v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v2

    instance-of v5, v2, Landroid/widget/ImageView;

    if-eqz v5, :cond_5c

    invoke-virtual {v2, v3}, Landroid/view/View;->setBackgroundResource(I)V

    check-cast v2, Landroid/widget/ImageView;

    invoke-virtual {v2, v4}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    :cond_5c
    const-string v2, "btn_settings"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p0, v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v2

    if-eqz v2, :cond_85

    invoke-virtual {v2, v3}, Landroid/view/View;->setBackgroundResource(I)V

    instance-of v5, v2, Landroid/view/ViewGroup;

    if-eqz v5, :cond_85

    check-cast v2, Landroid/view/ViewGroup;

    invoke-virtual {v2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v5

    if-lez v5, :cond_85

    const/4 v5, 0x0

    invoke-virtual {v2, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    instance-of v5, v2, Landroid/widget/ImageView;

    if-eqz v5, :cond_85

    check-cast v2, Landroid/widget/ImageView;

    invoke-virtual {v2, v4}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    :cond_85
    const-string v1, "inv_icon_on_accent"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getColor(I)I

    move-result v5

    const-string v2, "btn_panel_settings"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p0, v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v2

    instance-of v1, v2, Landroid/widget/TextView;

    if-eqz v1, :cond_ab

    const-string v1, "inv_bg_btn_secondary_pill"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v2, v1}, Landroid/view/View;->setBackgroundResource(I)V

    check-cast v2, Landroid/widget/TextView;

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_ab
    const-string v2, "btn_done"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p0, v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v2

    instance-of v1, v2, Landroid/widget/TextView;

    if-eqz v1, :cond_c7

    const-string v1, "inv_bg_btn_done"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v2, v1}, Landroid/view/View;->setBackgroundResource(I)V

    check-cast v2, Landroid/widget/TextView;

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_c7
    const-string v1, "inv_text_secondary"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getColor(I)I

    move-result v5

    const-string v2, "txt_edit_hint"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p0, v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v2

    instance-of v1, v2, Landroid/widget/TextView;

    if-eqz v1, :cond_e4

    check-cast v2, Landroid/widget/TextView;

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_e4
    const-string v1, "inv_text_primary"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getColor(I)I

    move-result v5

    const-string v2, "label_controls"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p0, v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v2

    instance-of v1, v2, Landroid/widget/TextView;

    if-eqz v1, :cond_101

    check-cast v2, Landroid/widget/TextView;

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_101
    const-string v2, "label_tiles"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {p0, v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v2

    instance-of v1, v2, Landroid/widget/TextView;

    if-eqz v1, :cond_114

    check-cast v2, Landroid/widget/TextView;

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_114
    return-void
.end method

.method private setTextSizeDimen(Landroid/widget/TextView;Ljava/lang/String;)V
    .registers 5

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-static {p2}, Linv/exe/systemui/qs/core/InvRes;->dimen(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result v0

    const/4 v1, 0x0

    invoke-virtual {p1, v1, v0}, Landroid/widget/TextView;->setTextSize(IF)V

    return-void
.end method


# virtual methods
.method public bind()V
    .registers 5

    .line 37
    iget-boolean v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->bound:Z

    if-eqz v0, :cond_5

    return-void

    .line 39
    :cond_5
    :try_start_5
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-virtual {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->bind()V

    const/4 v0, 0x1

    .line 40
    iput-boolean v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->bound:Z

    .line 41
    const-string v0, "txt_date"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    if-eqz v0, :cond_32

    .line 43
    new-instance v1, Ljava/text/SimpleDateFormat;

    const-string v2, "EEE, MMM d"

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v2, Ljava/util/Date;

    invoke-direct {v2}, Ljava/util/Date;-><init>()V

    invoke-virtual {v1, v2}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 45
    :cond_32
    const-string v0, "btn_edit"

    new-instance v1, Linv/exe/systemui/qs/ui/InvQsPanelView$1;

    invoke-direct {v1, p0}, Linv/exe/systemui/qs/ui/InvQsPanelView$1;-><init>(Linv/exe/systemui/qs/ui/InvQsPanelView;)V

    invoke-direct {p0, v0, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->click(Ljava/lang/String;Landroid/view/View$OnClickListener;)V

    .line 46
    const-string v0, "btn_done"

    new-instance v1, Linv/exe/systemui/qs/ui/InvQsPanelView$2;

    invoke-direct {v1, p0}, Linv/exe/systemui/qs/ui/InvQsPanelView$2;-><init>(Linv/exe/systemui/qs/ui/InvQsPanelView;)V

    invoke-direct {p0, v0, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->click(Ljava/lang/String;Landroid/view/View$OnClickListener;)V

    .line 47
    const-string v0, "btn_reset"

    new-instance v1, Linv/exe/systemui/qs/ui/InvQsPanelView$3;

    invoke-direct {v1, p0}, Linv/exe/systemui/qs/ui/InvQsPanelView$3;-><init>(Linv/exe/systemui/qs/ui/InvQsPanelView;)V

    invoke-direct {p0, v0, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->click(Ljava/lang/String;Landroid/view/View$OnClickListener;)V

    .line 48
    new-instance v0, Linv/exe/systemui/qs/ui/InvQsPanelView$4;

    invoke-direct {v0, p0}, Linv/exe/systemui/qs/ui/InvQsPanelView$4;-><init>(Linv/exe/systemui/qs/ui/InvQsPanelView;)V

    new-instance v2, Linv/exe/systemui/qs/helper/InvSettingsButtonClickListener;

    invoke-direct {v2}, Linv/exe/systemui/qs/helper/InvSettingsButtonClickListener;-><init>()V

    .line 49
    const-string v1, "btn_settings"

    invoke-direct {p0, v1, v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->click(Ljava/lang/String;Landroid/view/View$OnClickListener;)V

    .line 50
    const-string v1, "btn_panel_settings"

    invoke-direct {p0, v1, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->click(Ljava/lang/String;Landroid/view/View$OnClickListener;)V

    .line 51
    new-instance v1, Linv/exe/systemui/qs/helper/InvPowerMenuButtonClickListener;

    invoke-direct {v1}, Linv/exe/systemui/qs/helper/InvPowerMenuButtonClickListener;-><init>()V

    const-string v2, "btn_more"

    invoke-direct {p0, v2, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->click(Ljava/lang/String;Landroid/view/View$OnClickListener;)V
    :try_end_6e
    .catchall {:try_start_5 .. :try_end_6e} :catchall_6f

    return-void

    :catchall_6f
    const/4 v0, 0x0

    .line 53
    iput-boolean v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->bound:Z

    .line 54
    const-string v1, "Panel settings tidak tersedia"

    invoke-virtual {p0, v1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->showPanelToastText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public forceResponsiveLayoutNow()V
    .registers 2

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->applyResponsiveLayout()V

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_f

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->requestLayout()V

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->invalidate()V

    :cond_f
    return-void
.end method

.method public isEditMode()Z
    .registers 1

    .line 79
    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->isEditMode()Z

    move-result p0

    return p0
.end method

.method public isFullLandscapeMode()Z
    .registers 3

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    iget v0, v0, Landroid/content/res/Configuration;->orientation:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_13

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isSplitShadeEnabled()Z

    move-result v0

    if-eqz v0, :cond_15

    :cond_13
    const/4 v0, 0x0

    return v0

    :cond_15
    const/4 v0, 0x1

    return v0
.end method

.method protected onAttachedToWindow()V
    .registers 2

    invoke-super {p0}, Landroid/widget/LinearLayout;->onAttachedToWindow()V

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->mConfigurationController:Lcom/android/systemui/statusbar/policy/ConfigurationController;

    if-eqz v0, :cond_a

    invoke-interface {v0, p0}, Lcom/android/systemui/statusbar/policy/ConfigurationController;->addCallback(Ljava/lang/Object;)V

    :cond_a
    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->bind()V

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->onHostResume()V

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->scheduleResponsiveLayoutRefresh()V

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->ensureInitialLandscapeLayout()V

    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvFooterActionsHider;->hide(Landroid/view/View;)V

    return-void
.end method

.method public onConfigChanged(Landroid/content/res/Configuration;)V
    .registers 2

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->updateResources()V

    invoke-direct {p0, p1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->maybeScheduleOrientationLayoutRebuild(Landroid/content/res/Configuration;)V

    return-void
.end method

.method protected onConfigurationChanged(Landroid/content/res/Configuration;)V
    .registers 2

    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->updateResources()V

    invoke-direct {p0, p1}, Linv/exe/systemui/qs/ui/InvQsPanelView;->maybeScheduleOrientationLayoutRebuild(Landroid/content/res/Configuration;)V

    return-void
.end method

.method protected onDetachedFromWindow()V
    .registers 2

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->orientationRelayoutRunnable:Ljava/lang/Runnable;

    if-eqz v0, :cond_7

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->removeCallbacks(Ljava/lang/Runnable;)Z

    :cond_7
    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->mConfigurationController:Lcom/android/systemui/statusbar/policy/ConfigurationController;

    if-eqz v0, :cond_e

    invoke-interface {v0, p0}, Lcom/android/systemui/statusbar/policy/ConfigurationController;->removeCallback(Ljava/lang/Object;)V

    :cond_e
    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->dismissIfShowing(Landroid/view/View;)V

    .line 70
    :try_start_11
    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->onHostDestroy()V
    :try_end_14
    .catchall {:try_start_11 .. :try_end_14} :catchall_14

    :catchall_14
    const/4 v0, 0x0

    .line 72
    iput-boolean v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->bound:Z

    .line 73
    invoke-super {p0}, Landroid/widget/LinearLayout;->onDetachedFromWindow()V

    return-void
.end method

.method public onHostDestroy()V
    .registers 2

    .line 77
    iget-boolean v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->bound:Z

    if-eqz v0, :cond_9

    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->onDestroy()V

    :cond_9
    return-void
.end method

.method public onHostResume()V
    .registers 2

    .line 76
    iget-boolean v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->bound:Z

    if-eqz v0, :cond_9

    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->onResume()V

    :cond_9
    return-void
.end method

.method public onNativeQsExpansion(FFFF)V
    .registers 16

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isEditMode()Z

    move-result v0

    if-eqz v0, :cond_7

    return-void

    :cond_7
    const/4 v0, 0x0

    cmpg-float v1, p1, v0

    if-ltz v1, :cond_14

    const/high16 v1, 0x3f800000  # 1.0f

    cmpl-float v2, p1, v1

    if-lez v2, :cond_15

    move p1, v1

    goto :goto_17

    :cond_14
    move p1, v0

    :cond_15
    const/high16 v1, 0x3f800000  # 1.0f

    :goto_17
    const-string v2, "body_host"

    const/4 v3, 0x0

    const/high16 v4, 0x3f800000  # 1.0f

    invoke-direct {p0, v2, v4, v3, v4}, Linv/exe/systemui/qs/ui/InvQsPanelView;->applyExpansionByName(Ljava/lang/String;FIF)V

    const-string v2, "header_normal"

    const/16 v3, 0xa

    invoke-direct {p0, v2, p1, v3, v4}, Linv/exe/systemui/qs/ui/InvQsPanelView;->applyExpansionByName(Ljava/lang/String;FIF)V

    const-string v2, "header_edit"

    invoke-direct {p0, v2, p1, v3, v4}, Linv/exe/systemui/qs/ui/InvQsPanelView;->applyExpansionByName(Ljava/lang/String;FIF)V

    const v5, 0x3d23d70a  # 0.04f

    sub-float v5, p1, v5

    const v6, 0x3ed70a3d  # 0.42f

    div-float/2addr v5, v6

    const-string v2, "controls_column"

    const/16 v3, 0x16

    const v6, 0x3f7851ec  # 0.97f

    invoke-direct {p0, v2, v5, v3, v6}, Linv/exe/systemui/qs/ui/InvQsPanelView;->applyExpansionByName(Ljava/lang/String;FIF)V

    const v5, 0x3dcccccd  # 0.1f

    sub-float v5, p1, v5

    const v6, 0x3f0ccccd  # 0.55f

    div-float/2addr v5, v6

    const-string v2, "tiles_column"

    const/16 v3, 0x1c

    const v6, 0x3f770a3d  # 0.965f

    invoke-direct {p0, v2, v5, v3, v6}, Linv/exe/systemui/qs/ui/InvQsPanelView;->applyExpansionByName(Ljava/lang/String;FIF)V

    return-void
.end method

.method protected onSizeChanged(IIII)V
    .registers 5

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/LinearLayout;->onSizeChanged(IIII)V

    if-ne p1, p3, :cond_6

    return-void

    :cond_6
    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->scheduleResponsiveLayoutRefresh()V

    return-void
.end method

.method public onThemeChanged()V
    .registers 1

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->updateResources()V

    return-void
.end method

.method public onUiModeChanged()V
    .registers 1

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->updateResources()V

    return-void
.end method

.method protected onVisibilityChanged(Landroid/view/View;I)V
    .registers 3

    invoke-super {p0, p1, p2}, Landroid/widget/LinearLayout;->onVisibilityChanged(Landroid/view/View;I)V

    if-nez p2, :cond_12

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->bind()V

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->onHostResume()V

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->scheduleResponsiveLayoutRefresh()V

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->ensureInitialLandscapeLayout()V

    goto :goto_15

    :cond_12
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->exitEditIfHidden()V

    :goto_15
    return-void
.end method

.method protected onWindowVisibilityChanged(I)V
    .registers 2

    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->onWindowVisibilityChanged(I)V

    if-nez p1, :cond_f

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->onHostResume()V

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->scheduleResponsiveLayoutRefresh()V

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->ensureInitialLandscapeLayout()V

    goto :goto_12

    :cond_f
    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->exitEditIfHidden()V

    :goto_12
    return-void
.end method

.method public rebuild()V
    .registers 1

    .line 78
    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-virtual {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->rebuildUi()V

    return-void
.end method

.method public scheduleOrientationLayoutRebuild()V
    .registers 4

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->orientationRelayoutRunnable:Ljava/lang/Runnable;

    if-eqz v0, :cond_18

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->removeCallbacks(Ljava/lang/Runnable;)Z

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isAttachedToWindow()Z

    move-result v1

    if-eqz v1, :cond_18

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isShown()Z

    move-result v1

    if-eqz v1, :cond_18

    const-wide/16 v1, 0x90

    invoke-virtual {p0, v0, v1, v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_18
    return-void
.end method

.method public scheduleResponsiveLayoutRefresh()V
    .registers 6

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->forceResponsiveLayoutNow()V

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_13

    new-instance v0, Linv/exe/systemui/qs/ui/InvQsPanelView$5;

    invoke-direct {v0, p0}, Linv/exe/systemui/qs/ui/InvQsPanelView$5;-><init>(Linv/exe/systemui/qs/ui/InvQsPanelView;)V

    const-wide/16 v1, 0x40

    invoke-virtual {p0, v0, v1, v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_13
    return-void
.end method

.method public setShouldBlockVisibilityChanges(Z)V
    .registers 3

    iput-boolean p1, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->blockVisibilityChanges:Z

    if-nez p1, :cond_8

    const/4 v0, 0x0

    invoke-super {p0, v0}, Landroid/widget/LinearLayout;->setVisibility(I)V

    :cond_8
    return-void
.end method

.method public setVisibility(I)V
    .registers 3

    iget-boolean v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->blockVisibilityChanges:Z

    if-eqz v0, :cond_6

    if-nez p1, :cond_9

    :cond_6
    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    :cond_9
    return-void
.end method

.method public showPanelToast(I)V
    .registers 12

    const-string v0, "inv_qs_toast"

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getRootView()Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_be

    instance-of v2, v1, Landroid/widget/FrameLayout;

    if-eqz v2, :cond_be

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    move-result-object v2

    check-cast v1, Landroid/widget/FrameLayout;

    if-eqz v2, :cond_17

    invoke-virtual {v1, v2}, Landroid/widget/FrameLayout;->removeView(Landroid/view/View;)V

    :cond_17
    new-instance v2, Landroid/widget/TextView;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setText(I)V

    const-string v0, "inv_panel_settings_toast_text_size"

    invoke-direct {p0, v2, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->setTextSizeDimen(Landroid/widget/TextView;Ljava/lang/String;)V

    const/16 v0, 0x11

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setGravity(I)V

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v3, "inv_icon_on_accent"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v3}, Landroid/content/Context;->getColor(I)I

    move-result v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setTextColor(I)V

    const-string v0, "google-sans-medium"

    const/4 v3, 0x0

    invoke-static {v0, v3}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const/16 v0, 0x10

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->dp(I)I

    move-result v0

    const/16 v4, 0xa

    invoke-direct {p0, v4}, Linv/exe/systemui/qs/ui/InvQsPanelView;->dp(I)I

    move-result v4

    invoke-virtual {v2, v0, v4, v0, v4}, Landroid/widget/TextView;->setPadding(IIII)V

    const-string v0, "inv_bg_btn_done"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setBackgroundResource(I)V

    const/16 v0, 0x20

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->dp(I)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setElevation(F)V

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setTranslationZ(F)V

    const/4 v0, -0x1

    const/4 v4, -0x2

    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v6, 0x51

    invoke-direct {v5, v0, v4, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    const/16 v0, 0x14

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->dp(I)I

    move-result v0

    iput v0, v5, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    iput v0, v5, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->navigationBarHeight()I

    move-result v0

    iput v0, v5, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    invoke-virtual {v1, v2, v5}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v2}, Landroid/widget/TextView;->bringToFront()V

    const/4 v0, 0x0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setAlpha(F)V

    const/16 v4, 0x8

    invoke-direct {p0, v4}, Linv/exe/systemui/qs/ui/InvQsPanelView;->dp(I)I

    move-result v4

    int-to-float v4, v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTranslationY(F)V

    invoke-virtual {v2}, Landroid/widget/TextView;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v4

    const/high16 v5, 0x3f800000  # 1.0f

    invoke-virtual {v4, v5}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v4

    invoke-virtual {v4, v0}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v4

    const-wide/16 v5, 0x8c

    invoke-virtual {v4, v5, v6}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/ViewPropertyAnimator;->start()V

    new-instance v4, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$SheetToastRemoveRunnable;

    invoke-direct {v4, v1, v2}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$SheetToastRemoveRunnable;-><init>(Landroid/view/ViewGroup;Landroid/view/View;)V

    const-wide/16 v5, 0x6a4

    invoke-virtual {v2, v4, v5, v6}, Landroid/widget/TextView;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_be
    return-void
.end method

.method public showPanelToastText(Ljava/lang/CharSequence;)V
    .registers 12

    const-string v0, "inv_qs_toast"

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getRootView()Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_be

    instance-of v2, v1, Landroid/widget/FrameLayout;

    if-eqz v2, :cond_be

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    move-result-object v2

    check-cast v1, Landroid/widget/FrameLayout;

    if-eqz v2, :cond_17

    invoke-virtual {v1, v2}, Landroid/widget/FrameLayout;->removeView(Landroid/view/View;)V

    :cond_17
    new-instance v2, Landroid/widget/TextView;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "inv_panel_settings_toast_text_size"

    invoke-direct {p0, v2, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->setTextSizeDimen(Landroid/widget/TextView;Ljava/lang/String;)V

    const/16 v0, 0x11

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setGravity(I)V

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v3, "inv_icon_on_accent"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v3}, Landroid/content/Context;->getColor(I)I

    move-result v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setTextColor(I)V

    const-string v0, "google-sans-medium"

    const/4 v3, 0x0

    invoke-static {v0, v3}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const/16 v0, 0x10

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->dp(I)I

    move-result v0

    const/16 v4, 0xa

    invoke-direct {p0, v4}, Linv/exe/systemui/qs/ui/InvQsPanelView;->dp(I)I

    move-result v4

    invoke-virtual {v2, v0, v4, v0, v4}, Landroid/widget/TextView;->setPadding(IIII)V

    const-string v0, "inv_bg_btn_done"

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setBackgroundResource(I)V

    const/16 v0, 0x20

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->dp(I)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setElevation(F)V

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setTranslationZ(F)V

    const/4 v0, -0x1

    const/4 v4, -0x2

    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v6, 0x51

    invoke-direct {v5, v0, v4, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    const/16 v0, 0x14

    invoke-direct {p0, v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->dp(I)I

    move-result v0

    iput v0, v5, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    iput v0, v5, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->navigationBarHeight()I

    move-result v0

    iput v0, v5, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    invoke-virtual {v1, v2, v5}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v2}, Landroid/widget/TextView;->bringToFront()V

    const/4 v0, 0x0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setAlpha(F)V

    const/16 v4, 0x8

    invoke-direct {p0, v4}, Linv/exe/systemui/qs/ui/InvQsPanelView;->dp(I)I

    move-result v4

    int-to-float v4, v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTranslationY(F)V

    invoke-virtual {v2}, Landroid/widget/TextView;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v4

    const/high16 v5, 0x3f800000  # 1.0f

    invoke-virtual {v4, v5}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v4

    invoke-virtual {v4, v0}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v4

    const-wide/16 v5, 0x8c

    invoke-virtual {v4, v5, v6}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/ViewPropertyAnimator;->start()V

    new-instance v4, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$SheetToastRemoveRunnable;

    invoke-direct {v4, v1, v2}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$SheetToastRemoveRunnable;-><init>(Landroid/view/ViewGroup;Landroid/view/View;)V

    const-wide/16 v5, 0x6a4

    invoke-virtual {v2, v4, v5, v6}, Landroid/widget/TextView;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_be
    return-void
.end method

.method public updateResources()V
    .registers 3

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Linv/exe/systemui/qs/core/InvRes;->init(Landroid/content/Context;)V

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->refreshStaticThemeResources()V

    invoke-direct {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->applyResponsiveLayout()V

    const/4 v1, 0x0

    iput-boolean v1, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->blockVisibilityChanges:Z

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvQsPanelView;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    if-eqz v0, :cond_17

    invoke-virtual {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->updateResources()V

    :cond_17
    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->scheduleResponsiveLayoutRefresh()V

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->invalidate()V

    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvFooterActionsHider;->hide(Landroid/view/View;)V

    return-void
.end method
