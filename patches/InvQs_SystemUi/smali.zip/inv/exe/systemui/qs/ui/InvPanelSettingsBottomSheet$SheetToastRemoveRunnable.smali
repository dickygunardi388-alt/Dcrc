.class public Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$SheetToastRemoveRunnable;
.super Ljava/lang/Object;
.source "PanelSettingsBottomSheet.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final child:Landroid/view/View;

.field private final parent:Landroid/view/ViewGroup;


# direct methods
.method public constructor <init>(Landroid/view/ViewGroup;Landroid/view/View;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$SheetToastRemoveRunnable;->parent:Landroid/view/ViewGroup;

    iput-object p2, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$SheetToastRemoveRunnable;->child:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    iget-object v0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$SheetToastRemoveRunnable;->parent:Landroid/view/ViewGroup;

    if-eqz v0, :cond_b

    iget-object v1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$SheetToastRemoveRunnable;->child:Landroid/view/View;

    if-eqz v1, :cond_b

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_b
    return-void
.end method
