.class public final synthetic Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "b849e8a9f6cceff267251a73644faacc801ad726cc8f22a9c323c56a203f5446"
.end annotation


# instance fields
.field public final synthetic f$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;


# direct methods
.method public synthetic constructor <init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda4;->f$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .registers 3

    .line 0
    iget-object p0, p0, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$$ExternalSyntheticLambda4;->f$0:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    invoke-virtual {p0, p1, p2}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->lambda$1$inv-exe-systemui-qs-PanelSettingsBottomSheet(Landroid/widget/CompoundButton;Z)V

    return-void
.end method
