.class public interface abstract Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet$Change;
.super Ljava/lang/Object;
.source "PanelSettingsBottomSheet.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x60a
    name = "Change"
.end annotation


# virtual methods
.method public abstract value(I)V
.end method
