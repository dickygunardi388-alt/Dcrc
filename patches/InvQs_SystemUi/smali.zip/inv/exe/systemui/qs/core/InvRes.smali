.class public final Linv/exe/systemui/qs/core/InvRes;
.super Ljava/lang/Object;
.source "Res.java"


# static fields
.field private static appContext:Landroid/content/Context;


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static color(Ljava/lang/String;)I
    .registers 2

    .line 18
    const-string v0, "color"

    invoke-static {v0, p0}, Linv/exe/systemui/qs/core/InvRes;->get(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static dimen(Ljava/lang/String;)I
    .registers 2

    .line 19
    const-string v0, "dimen"

    invoke-static {v0, p0}, Linv/exe/systemui/qs/core/InvRes;->get(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static dimenNameForDp(I)Ljava/lang/String;
    .registers 2

    if-eqz p0, :cond_46

    const/4 v0, 0x3

    if-eq p0, v0, :cond_49

    const/4 v0, 0x4

    if-eq p0, v0, :cond_4c

    const/16 v0, 0x8

    if-eq p0, v0, :cond_4f

    const/16 v0, 0xa

    if-eq p0, v0, :cond_52

    const/16 v0, 0xe

    if-eq p0, v0, :cond_55

    const/16 v0, 0x10

    if-eq p0, v0, :cond_58

    const/16 v0, 0x12

    if-eq p0, v0, :cond_5b

    const/16 v0, 0x14

    if-eq p0, v0, :cond_5e

    const/16 v0, 0x16

    if-eq p0, v0, :cond_61

    const/16 v0, 0x18

    if-eq p0, v0, :cond_64

    const/16 v0, 0x20

    if-eq p0, v0, :cond_67

    const/16 v0, 0x28

    if-eq p0, v0, :cond_6a

    const/16 v0, 0x2e

    if-eq p0, v0, :cond_6d

    const/16 v0, 0x30

    if-eq p0, v0, :cond_70

    const/16 v0, 0x51

    if-eq p0, v0, :cond_73

    const/16 v0, 0x5c

    if-eq p0, v0, :cond_76

    const/16 v0, 0x168

    if-eq p0, v0, :cond_79

    const/4 v0, 0x0

    return-object v0

    :cond_46
    const-string v0, "inv_spacing_zero"

    return-object v0

    :cond_49
    const-string v0, "inv_edit_badge_icon_padding"

    return-object v0

    :cond_4c
    const-string v0, "inv_spacing_extra_small"

    return-object v0

    :cond_4f
    const-string v0, "inv_spacing_small"

    return-object v0

    :cond_52
    const-string v0, "inv_spacing_medium"

    return-object v0

    :cond_55
    const-string v0, "inv_spacing_large"

    return-object v0

    :cond_58
    const-string v0, "inv_spacing_extra_large"

    return-object v0

    :cond_5b
    const-string v0, "inv_component_size_medium"

    return-object v0

    :cond_5e
    const-string v0, "inv_icon_size_small"

    return-object v0

    :cond_61
    const-string v0, "inv_icon_size_medium"

    return-object v0

    :cond_64
    const-string v0, "inv_icon_size_standard"

    return-object v0

    :cond_67
    const-string v0, "inv_panel_settings_sheet_corner_radius"

    return-object v0

    :cond_6a
    const-string v0, "inv_qs_header_button_size"

    return-object v0

    :cond_6d
    const-string v0, "inv_media_default_album_art_size"

    return-object v0

    :cond_70
    const-string v0, "inv_panel_settings_tile_preview_min_height"

    return-object v0

    :cond_73
    const-string v0, "inv_panel_settings_control_preview_cell_size"

    return-object v0

    :cond_76
    const-string v0, "inv_panel_settings_sheet_margin_top"

    return-object v0

    :cond_79
    const-string v0, "inv_panel_settings_sheet_width_landscape"

    return-object v0
.end method

.method public static drawable(Ljava/lang/String;)I
    .registers 2

    .line 16
    const-string v0, "drawable"

    invoke-static {v0, p0}, Linv/exe/systemui/qs/core/InvRes;->get(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method private static get(Ljava/lang/String;Ljava/lang/String;)I
    .registers 6

    .line 11
    sget-object v0, Linv/exe/systemui/qs/core/InvRes;->appContext:Landroid/content/Context;

    if-eqz v0, :cond_13

    .line 12
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    sget-object v0, Linv/exe/systemui/qs/core/InvRes;->appContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, p1, p0, v2}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v3

    return v3

    .line 11
    :cond_13
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Res.init(context) must run before resource lookup"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static id(Ljava/lang/String;)I
    .registers 2

    .line 14
    const-string v0, "id"

    invoke-static {v0, p0}, Linv/exe/systemui/qs/core/InvRes;->get(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static init(Landroid/content/Context;)V
    .registers 1

    sput-object p0, Linv/exe/systemui/qs/core/InvRes;->appContext:Landroid/content/Context;

    return-void
.end method

.method public static integer(Ljava/lang/String;)I
    .registers 2

    const-string v0, "integer"

    invoke-static {v0, p0}, Linv/exe/systemui/qs/core/InvRes;->get(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static integerValue(Ljava/lang/String;I)I
    .registers 3

    sget-object v0, Linv/exe/systemui/qs/core/InvRes;->appContext:Landroid/content/Context;

    if-eqz v0, :cond_13

    invoke-static {p0}, Linv/exe/systemui/qs/core/InvRes;->integer(Ljava/lang/String;)I

    move-result p0

    if-eqz p0, :cond_13

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/content/res/Resources;->getInteger(I)I

    move-result p1

    return p1

    :cond_13
    return p1
.end method

.method public static layout(Ljava/lang/String;)I
    .registers 2

    .line 15
    const-string v0, "layout"

    invoke-static {v0, p0}, Linv/exe/systemui/qs/core/InvRes;->get(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method
