.class public final Linv/exe/systemui/qs/nativeqs/InvNativeTileDropListener;
.super Ljava/lang/Object;
.source "NativeTileDropListener.java"

# interfaces
.implements Landroid/view/View$OnDragListener;


# instance fields
.field private final controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

.field private final targetSpec:Ljava/lang/String;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileDropListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iput-object p2, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileDropListener;->targetSpec:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public onDrag(Landroid/view/View;Landroid/view/DragEvent;)Z
    .registers 10

    invoke-virtual {p2}, Landroid/view/DragEvent;->getLocalState()Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Ljava/lang/String;

    if-eqz v1, :cond_b

    check-cast v0, Ljava/lang/String;

    goto :goto_28

    :cond_b
    invoke-virtual {p2}, Landroid/view/DragEvent;->getClipData()Landroid/content/ClipData;

    move-result-object v1

    if-eqz v1, :cond_7e

    invoke-virtual {v1}, Landroid/content/ClipData;->getItemCount()I

    move-result v2

    if-lez v2, :cond_7e

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/content/ClipData;->getItemAt(I)Landroid/content/ClipData$Item;

    move-result-object v1

    if-eqz v1, :cond_7e

    invoke-virtual {v1}, Landroid/content/ClipData$Item;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    if-eqz v1, :cond_7e

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_28
    iget-object v1, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileDropListener;->targetSpec:Ljava/lang/String;

    invoke-virtual {p2}, Landroid/view/DragEvent;->getAction()I

    move-result v2

    const/4 v3, 0x5

    if-ne v2, v3, :cond_42

    if-eqz v1, :cond_7c

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3a

    goto :goto_7c

    :cond_3a
    invoke-static {p1}, Linv/exe/systemui/qs/drag/InvNativeDragVisual;->unclipParents(Landroid/view/View;)V

    const/4 v3, 0x1

    invoke-static {p1, v3}, Linv/exe/systemui/qs/drag/InvNativeDragVisual;->hover(Landroid/view/View;Z)V

    return v3

    :cond_42
    const/4 v3, 0x6

    if-ne v2, v3, :cond_4b

    const/4 v3, 0x0

    invoke-static {p1, v3}, Linv/exe/systemui/qs/drag/InvNativeDragVisual;->hover(Landroid/view/View;Z)V

    const/4 p0, 0x1

    return p0

    :cond_4b
    const/4 v3, 0x4

    if-ne v2, v3, :cond_53

    invoke-static {p1}, Linv/exe/systemui/qs/drag/InvNativeDragVisual;->reset(Landroid/view/View;)V

    const/4 p0, 0x1

    return p0

    :cond_53
    const/4 v3, 0x3

    if-ne v2, v3, :cond_7c

    invoke-static {p1}, Linv/exe/systemui/qs/drag/InvNativeDragVisual;->reset(Landroid/view/View;)V

    if-eqz v1, :cond_7c

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_62

    goto :goto_7c

    :cond_62
    iget-object v3, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileDropListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {v3, v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$13(Linv/exe/systemui/qs/controller/InvQsPanelController;Ljava/lang/String;)Landroid/view/View;

    move-result-object v3

    if-eqz v3, :cond_78

    invoke-static {v3, p1}, Linv/exe/systemui/qs/drag/InvDragSupport;->swapViews(Landroid/view/View;Landroid/view/View;)V

    new-instance v4, Linv/exe/systemui/qs/nativeqs/InvNativeTileDropCommitRunnable;

    invoke-direct {v4, p1, v0, v1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileDropCommitRunnable;-><init>(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;)V

    const-wide/16 v5, 0x140

    invoke-virtual {p1, v4, v5, v6}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_7c

    :cond_78
    invoke-static {p1, v0, v1}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->moveBefore(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    :cond_7c
    :goto_7c
    const/4 p0, 0x1

    return p0

    :cond_7e
    const/4 p0, 0x0

    return p0
.end method
