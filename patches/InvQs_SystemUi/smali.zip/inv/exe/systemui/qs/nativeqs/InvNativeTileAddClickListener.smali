.class public final Linv/exe/systemui/qs/nativeqs/InvNativeTileAddClickListener;
.super Ljava/lang/Object;
.source "NativeTileAddClickListener.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field private final sheet:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

.field private final spec:Ljava/lang/String;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileAddClickListener;->sheet:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    iput-object p2, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileAddClickListener;->spec:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 3

    iget-object v0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileAddClickListener;->sheet:Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;

    iget-object p0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileAddClickListener;->spec:Ljava/lang/String;

    invoke-virtual {v0, p0, p1}, Linv/exe/systemui/qs/ui/InvPanelSettingsBottomSheet;->addNativeSpec(Ljava/lang/String;Landroid/view/View;)V

    return-void
.end method
