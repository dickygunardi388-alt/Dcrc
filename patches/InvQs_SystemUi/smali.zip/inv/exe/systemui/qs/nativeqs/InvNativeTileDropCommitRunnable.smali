.class public final Linv/exe/systemui/qs/nativeqs/InvNativeTileDropCommitRunnable;
.super Ljava/lang/Object;
.source "NativeTileDropCommitRunnable.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final sourceSpec:Ljava/lang/String;

.field private final targetSpec:Ljava/lang/String;

.field private final view:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileDropCommitRunnable;->view:Landroid/view/View;

    iput-object p2, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileDropCommitRunnable;->sourceSpec:Ljava/lang/String;

    iput-object p3, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileDropCommitRunnable;->targetSpec:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    iget-object v0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileDropCommitRunnable;->view:Landroid/view/View;

    iget-object v1, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileDropCommitRunnable;->sourceSpec:Ljava/lang/String;

    iget-object v2, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileDropCommitRunnable;->targetSpec:Ljava/lang/String;

    invoke-static {v0, v1, v2}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->moveBefore(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;)Z

    return-void
.end method
