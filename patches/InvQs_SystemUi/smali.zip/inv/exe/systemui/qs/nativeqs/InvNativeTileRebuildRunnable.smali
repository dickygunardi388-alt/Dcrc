.class public final Linv/exe/systemui/qs/nativeqs/InvNativeTileRebuildRunnable;
.super Ljava/lang/Object;
.source "NativeTileRebuildRunnable.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final controller:Linv/exe/systemui/qs/controller/InvQsPanelController;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileRebuildRunnable;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    return-void
.end method


# virtual methods
.method public run()V
    .registers 1

    iget-object p0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileRebuildRunnable;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    if-eqz p0, :cond_7

    invoke-static {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$12(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    :cond_7
    return-void
.end method
