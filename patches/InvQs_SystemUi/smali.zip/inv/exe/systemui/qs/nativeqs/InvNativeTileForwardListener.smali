.class public final Linv/exe/systemui/qs/nativeqs/InvNativeTileForwardListener;
.super Ljava/lang/Object;
.source "NativeTileForwardListener.java"

# interfaces
.implements Landroid/view/View$OnClickListener;
.implements Landroid/view/View$OnLongClickListener;


# instance fields
.field private final target:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileForwardListener;->target:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 2

    iget-object p0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileForwardListener;->target:Landroid/view/View;

    if-eqz p0, :cond_7

    invoke-virtual {p0}, Landroid/view/View;->performClick()Z

    :cond_7
    return-void
.end method

.method public onLongClick(Landroid/view/View;)Z
    .registers 2

    iget-object p0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileForwardListener;->target:Landroid/view/View;

    if-eqz p0, :cond_9

    invoke-virtual {p0}, Landroid/view/View;->performLongClick()Z

    move-result p0

    return p0

    :cond_9
    const/4 p0, 0x0

    return p0
.end method
