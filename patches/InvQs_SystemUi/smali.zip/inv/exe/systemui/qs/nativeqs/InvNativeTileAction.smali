.class public final Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;
.super Ljava/lang/Object;
.source "NativeTileAction.java"


# static fields
.field private static sHost:Lcom/android/systemui/qs/QSTileHost;


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static add(Landroid/view/View;Ljava/lang/String;)Z
    .registers 5

    if-eqz p0, :cond_28

    invoke-static {p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->canonicalSpec(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_28

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_28

    invoke-static {p0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->findHost(Landroid/view/View;)Lcom/android/systemui/qs/QSTileHost;

    move-result-object v0

    if-eqz v0, :cond_28

    :try_start_14
    invoke-static {p0, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->freshSpecs(Landroid/view/View;Lcom/android/systemui/qs/QSTileHost;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-static {v1, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->listContainsSpec(Ljava/util/ArrayList;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_20

    const/4 p0, 0x1

    return p0

    :cond_20
    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-static {p0, v0, v1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->writeSpecs(Landroid/view/View;Lcom/android/systemui/qs/QSTileHost;Ljava/util/ArrayList;)Z

    move-result p0

    return p0
    :try_end_28
    .catch Ljava/lang/Throwable; {:try_start_14 .. :try_end_28} :catch_28

    :catch_28
    :cond_28
    const/4 p0, 0x0

    return p0
.end method

.method private static addDefault(Ljava/util/ArrayList;ILjava/lang/String;)V
    .registers 4

    invoke-static {p2}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->canonicalSpec(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    if-eqz p2, :cond_1e

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_1e

    invoke-static {p0, p2}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->listContainsSpec(Ljava/util/ArrayList;Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1e

    if-lez p1, :cond_1b

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lt v0, p1, :cond_1b

    goto :goto_1e

    :cond_1b
    invoke-virtual {p0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1e
    :goto_1e
    return-void
.end method

.method private static addRomResourceSpecs(Ljava/util/ArrayList;ILandroid/view/View;)V
    .registers 5

    if-eqz p2, :cond_c

    :try_start_2
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "quick_settings_tiles_stock"

    invoke-static {p0, p1, v0, v1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->addSpecsFromStringResource(Ljava/util/ArrayList;ILandroid/content/Context;Ljava/lang/String;)V
    :try_end_b
    .catch Ljava/lang/Throwable; {:try_start_2 .. :try_end_b} :catch_c

    goto :goto_c

    :catch_c
    :cond_c
    :goto_c
    return-void
.end method

.method private static addSpecsFromCsv(Ljava/util/ArrayList;ILjava/lang/String;)V
    .registers 7

    if-eqz p2, :cond_2a

    const-string v0, ","

    invoke-virtual {p2, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    :goto_9
    array-length v2, v0

    if-lt v1, v2, :cond_d

    goto :goto_2a

    :cond_d
    aget-object v2, v0, v1

    if-eqz v2, :cond_27

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    if-lez v3, :cond_27

    const-string v3, "default"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_24

    goto :goto_27

    :cond_24
    invoke-static {p0, p1, v2}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->addDefault(Ljava/util/ArrayList;ILjava/lang/String;)V

    :cond_27
    :goto_27
    add-int/lit8 v1, v1, 0x1

    goto :goto_9

    :cond_2a
    :goto_2a
    return-void
.end method

.method private static addSpecsFromStringResource(Ljava/util/ArrayList;ILandroid/content/Context;Ljava/lang/String;)V
    .registers 7

    if-eqz p2, :cond_1c

    if-eqz p3, :cond_1c

    :try_start_4
    invoke-virtual {p2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string v1, "string"

    invoke-virtual {p2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, p3, v1, v2}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    if-lez v1, :cond_1c

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, p1, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->addSpecsFromCsv(Ljava/util/ArrayList;ILjava/lang/String;)V
    :try_end_1b
    .catch Ljava/lang/Throwable; {:try_start_4 .. :try_end_1b} :catch_1c

    goto :goto_1c

    :catch_1c
    :cond_1c
    :goto_1c
    return-void
.end method

.method public static allSpecs(Landroid/view/View;I)Ljava/util/ArrayList;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "I)",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->visibleSpecs(Landroid/view/View;I)Ljava/util/ArrayList;

    move-result-object v1

    if-eqz v1, :cond_1f

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_f
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1f

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v0, p1, v2}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->addDefault(Ljava/util/ArrayList;ILjava/lang/String;)V

    goto :goto_f

    :cond_1f
    invoke-static {v0, p1, p0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->addRomResourceSpecs(Ljava/util/ArrayList;ILandroid/view/View;)V

    return-object v0
.end method

.method private static canonicalSpec(Ljava/lang/String;)Ljava/lang/String;
    .registers 1

    if-eqz p0, :cond_6

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    :cond_6
    return-object p0
.end method

.method public static click(Landroid/view/View;Ljava/lang/String;)Z
    .registers 5

    if-eqz p0, :cond_16

    if-eqz p1, :cond_16

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->findTile(Landroid/view/View;Ljava/lang/String;)Lcom/android/systemui/plugins/qs/QSTile;

    move-result-object v0

    if-eqz v0, :cond_16

    :try_start_a
    const/4 v1, 0x1

    invoke-interface {v0, p0, v1}, Lcom/android/systemui/plugins/qs/QSTile;->setListening(Ljava/lang/Object;Z)V

    invoke-interface {v0, p0}, Lcom/android/systemui/plugins/qs/QSTile;->click(Landroid/view/View;)V

    invoke-interface {v0}, Lcom/android/systemui/plugins/qs/QSTile;->refreshState()V

    const/4 p0, 0x1

    return p0
    :try_end_16
    .catch Ljava/lang/Throwable; {:try_start_a .. :try_end_16} :catch_16

    :catch_16
    :cond_16
    const/4 p0, 0x0

    return p0
.end method

.method private static findHost(Landroid/view/View;)Lcom/android/systemui/qs/QSTileHost;
    .registers 3

    sget-object v0, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->sHost:Lcom/android/systemui/qs/QSTileHost;

    if-eqz v0, :cond_5

    return-object v0

    :cond_5
    const/4 v0, 0x0

    :try_start_6
    const-class p0, Lcom/android/systemui/qs/QSTileHost;

    invoke-static {p0}, Lcom/android/systemui/Dependency;->get(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    instance-of v1, p0, Lcom/android/systemui/qs/QSTileHost;

    if-eqz v1, :cond_15

    check-cast p0, Lcom/android/systemui/qs/QSTileHost;

    sput-object p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->sHost:Lcom/android/systemui/qs/QSTileHost;

    return-object p0
    :try_end_15
    .catch Ljava/lang/Throwable; {:try_start_6 .. :try_end_15} :catch_15

    :catch_15
    :cond_15
    return-object v0
.end method

.method private static findTile(Landroid/view/View;Ljava/lang/String;)Lcom/android/systemui/plugins/qs/QSTile;
    .registers 6

    const/4 v0, 0x0

    invoke-static {p0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->findHost(Landroid/view/View;)Lcom/android/systemui/qs/QSTileHost;

    move-result-object p0

    if-eqz p0, :cond_28

    :try_start_7
    invoke-virtual {p0}, Lcom/android/systemui/qs/QSTileHost;->getTiles()Ljava/util/Collection;

    move-result-object p0

    if-eqz p0, :cond_28

    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_11
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_28

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/android/systemui/plugins/qs/QSTile;

    invoke-interface {v1}, Lcom/android/systemui/plugins/qs/QSTile;->getTileSpec()Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v2}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->specMatches(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_11

    return-object v1
    :try_end_28
    .catch Ljava/lang/Throwable; {:try_start_7 .. :try_end_28} :catch_28

    :catch_28
    :cond_28
    return-object v0
.end method

.method private static freshSpecs(Landroid/view/View;Lcom/android/systemui/qs/QSTileHost;)Ljava/util/ArrayList;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "Lcom/android/systemui/qs/QSTileHost;",
            ")",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v0, 0x0

    invoke-static {p0, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->specsFromSettings(Landroid/view/View;I)Ljava/util/ArrayList;

    move-result-object v1

    if-eqz v1, :cond_d

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_21

    :cond_d
    const/4 v3, 0x0

    if-eqz p1, :cond_1f

    :try_start_10
    invoke-virtual {p1}, Lcom/android/systemui/qs/QSTileHost;->getSpecs()Ljava/util/ArrayList;

    move-result-object v3
    :try_end_14
    .catch Ljava/lang/Throwable; {:try_start_10 .. :try_end_14} :catch_15

    goto :goto_17

    :catch_15
    move-exception v4

    const/4 v3, 0x0

    :goto_17
    if-eqz v3, :cond_1f

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    return-object v1

    :cond_1f
    if-eqz v1, :cond_22

    :cond_21
    return-object v1

    :cond_22
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    return-object v1
.end method

.method public static groupRank(Ljava/lang/String;)I
    .registers 3

    if-eqz p0, :cond_88

    const-string v0, "internet"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_32

    const-string v0, "wifi"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_32

    const-string v0, "cell"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_32

    const-string v0, "bt"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_32

    const-string v0, "bluetooth"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_32

    const-string v0, "hotspot"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_34

    :cond_32
    const/4 p0, 0x0

    return p0

    :cond_34
    const-string v0, "rotation"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_74

    const-string v0, "dark"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_74

    const-string v0, "night"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_74

    const-string v0, "flashlight"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_74

    const-string v0, "brightness"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_74

    const-string v0, "color"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_74

    const-string v0, "inversion"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_74

    const-string v0, "font"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_76

    :cond_74
    const/4 p0, 0x1

    return p0

    :cond_76
    const-string v0, "dnd"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_86

    const-string v0, "alarm"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_88

    :cond_86
    const/4 p0, 0x2

    return p0

    :cond_88
    const/4 p0, 0x3

    return p0
.end method

.method public static icon(Landroid/view/View;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    .registers 8

    const/4 v0, 0x0

    if-eqz p0, :cond_60

    if-eqz p1, :cond_60

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->state(Landroid/view/View;Ljava/lang/String;)Lcom/android/systemui/plugins/qs/QSTile$State;

    move-result-object v1

    if-eqz v1, :cond_1b

    iget-object v2, v1, Lcom/android/systemui/plugins/qs/QSTile$State;->icon:Lcom/android/systemui/plugins/qs/QSTile$Icon;

    if-eqz v2, :cond_1b

    :try_start_f
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/systemui/plugins/qs/QSTile$Icon;->getDrawable(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    if-eqz v4, :cond_1b

    return-object v4
    :try_end_1a
    .catch Ljava/lang/Throwable; {:try_start_f .. :try_end_1a} :catch_1a

    :catch_1a
    move-exception v1

    :cond_1b
    invoke-static {p0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->findHost(Landroid/view/View;)Lcom/android/systemui/qs/QSTileHost;

    move-result-object v1

    if-eqz v1, :cond_59

    const/4 v5, 0x0

    :try_start_22
    invoke-virtual {v1, p1}, Lcom/android/systemui/qs/QSTileHost;->createTile(Ljava/lang/String;)Lcom/android/systemui/plugins/qs/QSTile;

    move-result-object v5

    if-eqz v5, :cond_4a

    invoke-interface {v5, p1}, Lcom/android/systemui/plugins/qs/QSTile;->setTileSpec(Ljava/lang/String;)V

    const/4 v4, 0x1

    invoke-interface {v5, p0, v4}, Lcom/android/systemui/plugins/qs/QSTile;->setListening(Ljava/lang/Object;Z)V

    invoke-interface {v5}, Lcom/android/systemui/plugins/qs/QSTile;->refreshState()V

    invoke-interface {v5}, Lcom/android/systemui/plugins/qs/QSTile;->getState()Lcom/android/systemui/plugins/qs/QSTile$State;

    move-result-object v1

    if-eqz v1, :cond_4a

    iget-object v2, v1, Lcom/android/systemui/plugins/qs/QSTile$State;->icon:Lcom/android/systemui/plugins/qs/QSTile$Icon;

    if-eqz v2, :cond_4a

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/android/systemui/plugins/qs/QSTile$Icon;->getDrawable(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    if-eqz v4, :cond_4a

    invoke-interface {v5}, Lcom/android/systemui/plugins/qs/QSTile;->destroy()V

    return-object v4

    :cond_4a
    if-eqz v5, :cond_59

    invoke-interface {v5}, Lcom/android/systemui/plugins/qs/QSTile;->destroy()V
    :try_end_4f
    .catch Ljava/lang/Throwable; {:try_start_22 .. :try_end_4f} :catch_50

    goto :goto_59

    :catch_50
    move-exception v1

    if-eqz v5, :cond_59

    :try_start_53
    invoke-interface {v5}, Lcom/android/systemui/plugins/qs/QSTile;->destroy()V
    :try_end_56
    .catch Ljava/lang/Throwable; {:try_start_53 .. :try_end_56} :catch_57

    goto :goto_59

    :catch_57
    move-exception v1

    goto :goto_59

    :cond_59
    :goto_59
    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileResourceIcon;->drawable(Landroid/view/View;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    if-eqz v1, :cond_60

    return-object v1

    :cond_60
    return-object v0
.end method

.method private static indexOfSpec(Ljava/util/ArrayList;Ljava/lang/String;)I
    .registers 6

    const/4 v0, -0x1

    if-eqz p0, :cond_1d

    if-eqz p1, :cond_1d

    const/4 v1, 0x0

    :goto_6
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lt v1, v2, :cond_d

    goto :goto_1d

    :cond_d
    invoke-virtual {p0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1a

    return v1

    :cond_1a
    add-int/lit8 v1, v1, 0x1

    goto :goto_6

    :cond_1d
    :goto_1d
    return v0
.end method

.method public static isActive(Landroid/view/View;Ljava/lang/String;)Z
    .registers 3

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->stateValue(Landroid/view/View;Ljava/lang/String;)I

    move-result p0

    const/4 p1, 0x2

    if-ne p0, p1, :cond_9

    const/4 p0, 0x1

    return p0

    :cond_9
    const/4 p0, 0x0

    return p0
.end method

.method private static isBluetoothSpec(Ljava/lang/String;)Z
    .registers 2

    const-string v0, "bt"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_10

    const-string v0, "bluetooth"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_12

    :cond_10
    const/4 p0, 0x1

    return p0

    :cond_12
    const/4 p0, 0x0

    return p0
.end method

.method private static isInternetSpec(Ljava/lang/String;)Z
    .registers 2

    const-string v0, "internet"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_18

    const-string v0, "wifi"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_18

    const-string v0, "cell"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1a

    :cond_18
    const/4 p0, 0x1

    return p0

    :cond_1a
    const/4 p0, 0x0

    return p0
.end method

.method public static label(Landroid/view/View;Ljava/lang/String;)Ljava/lang/CharSequence;
    .registers 5

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->state(Landroid/view/View;Ljava/lang/String;)Lcom/android/systemui/plugins/qs/QSTile$State;

    move-result-object v0

    if-eqz v0, :cond_f

    iget-object v1, v0, Lcom/android/systemui/plugins/qs/QSTile$State;->label:Ljava/lang/CharSequence;

    invoke-static {v1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->notBlank(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_f

    return-object v1

    :cond_f
    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->findTile(Landroid/view/View;Ljava/lang/String;)Lcom/android/systemui/plugins/qs/QSTile;

    move-result-object v0

    if-eqz v0, :cond_20

    :try_start_15
    invoke-interface {v0}, Lcom/android/systemui/plugins/qs/QSTile;->getTileLabel()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-static {v1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->notBlank(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_20

    return-object v1
    :try_end_20
    .catch Ljava/lang/Throwable; {:try_start_15 .. :try_end_20} :catch_20

    :catch_20
    :cond_20
    if-eqz p0, :cond_41

    if-eqz p1, :cond_41

    invoke-static {p0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->findHost(Landroid/view/View;)Lcom/android/systemui/qs/QSTileHost;

    move-result-object v0

    if-eqz v0, :cond_41

    :try_start_2a
    invoke-virtual {v0, p1}, Lcom/android/systemui/qs/QSTileHost;->createTile(Ljava/lang/String;)Lcom/android/systemui/plugins/qs/QSTile;

    move-result-object v0

    if-eqz v0, :cond_41

    invoke-interface {v0, p1}, Lcom/android/systemui/plugins/qs/QSTile;->setTileSpec(Ljava/lang/String;)V

    invoke-interface {v0}, Lcom/android/systemui/plugins/qs/QSTile;->getTileLabel()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-static {v1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->notBlank(Ljava/lang/CharSequence;)Z

    move-result v2

    invoke-interface {v0}, Lcom/android/systemui/plugins/qs/QSTile;->destroy()V

    if-eqz v2, :cond_41

    return-object v1
    :try_end_41
    .catch Ljava/lang/Throwable; {:try_start_2a .. :try_end_41} :catch_41

    :catch_41
    :cond_41
    if-eqz p1, :cond_44

    return-object p1

    :cond_44
    const-string p0, ""

    return-object p0
.end method

.method public static listContainsSpec(Ljava/util/ArrayList;Ljava/lang/String;)Z
    .registers 5

    if-eqz p0, :cond_1c

    if-eqz p1, :cond_1c

    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1c

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->specMatches(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_8

    const/4 p0, 0x1

    return p0

    :cond_1c
    const/4 p0, 0x0

    return p0
.end method

.method public static longClick(Landroid/view/View;Ljava/lang/String;)Z
    .registers 5

    if-eqz p0, :cond_16

    if-eqz p1, :cond_16

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->findTile(Landroid/view/View;Ljava/lang/String;)Lcom/android/systemui/plugins/qs/QSTile;

    move-result-object v0

    if-eqz v0, :cond_16

    :try_start_a
    const/4 v1, 0x1

    invoke-interface {v0, p0, v1}, Lcom/android/systemui/plugins/qs/QSTile;->setListening(Ljava/lang/Object;Z)V

    invoke-interface {v0, p0}, Lcom/android/systemui/plugins/qs/QSTile;->longClick(Landroid/view/View;)V

    invoke-interface {v0}, Lcom/android/systemui/plugins/qs/QSTile;->refreshState()V

    const/4 p0, 0x1

    return p0
    :try_end_16
    .catch Ljava/lang/Throwable; {:try_start_a .. :try_end_16} :catch_16

    :catch_16
    :cond_16
    const/4 p0, 0x0

    return p0
.end method

.method public static moveAfter(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;)Z
    .registers 3

    invoke-static {p0, p1, p2}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->moveBefore(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method public static moveBefore(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;)Z
    .registers 9

    if-eqz p0, :cond_37

    if-eqz p1, :cond_37

    if-eqz p2, :cond_37

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_e

    const/4 p0, 0x1

    return p0

    :cond_e
    invoke-static {p0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->findHost(Landroid/view/View;)Lcom/android/systemui/qs/QSTileHost;

    move-result-object v0

    if-eqz v0, :cond_37

    :try_start_14
    invoke-static {p0, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->freshSpecs(Landroid/view/View;Lcom/android/systemui/qs/QSTileHost;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-static {v1, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->indexOfSpec(Ljava/util/ArrayList;Ljava/lang/String;)I

    move-result v2

    if-ltz v2, :cond_37

    invoke-static {v1, p2}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->indexOfSpec(Ljava/util/ArrayList;Ljava/lang/String;)I

    move-result v3

    if-ltz v3, :cond_37

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v1, v2, v5}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v1, v3, v4}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    invoke-static {p0, v0, v1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->writeSpecs(Landroid/view/View;Lcom/android/systemui/qs/QSTileHost;Ljava/util/ArrayList;)Z

    move-result p0

    return p0
    :try_end_37
    .catch Ljava/lang/Throwable; {:try_start_14 .. :try_end_37} :catch_37

    :catch_37
    :cond_37
    const/4 p0, 0x0

    return p0
.end method

.method private static notBlank(Ljava/lang/CharSequence;)Z
    .registers 1

    if-eqz p0, :cond_a

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result p0

    if-lez p0, :cond_a

    const/4 p0, 0x1

    return p0

    :cond_a
    const/4 p0, 0x0

    return p0
.end method

.method public static openDetails(Landroid/view/View;Ljava/lang/String;)Z
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->longClick(Landroid/view/View;Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method public static pruneToCapacity(Landroid/view/View;I)Z
    .registers 7

    if-eqz p0, :cond_25

    if-lez p1, :cond_25

    invoke-static {p0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->findHost(Landroid/view/View;)Lcom/android/systemui/qs/QSTileHost;

    move-result-object v0

    if-eqz v0, :cond_25

    invoke-static {p0, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->freshSpecs(Landroid/view/View;Lcom/android/systemui/qs/QSTileHost;)Ljava/util/ArrayList;

    move-result-object v1

    if-eqz v1, :cond_25

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-le v2, p1, :cond_25

    new-instance v3, Ljava/util/ArrayList;

    const/4 v4, 0x0

    invoke-virtual {v1, v4, p1}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;

    move-result-object v1

    invoke-direct {v3, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {p0, v0, v3}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->writeSpecs(Landroid/view/View;Lcom/android/systemui/qs/QSTileHost;Ljava/util/ArrayList;)Z

    move-result p0

    return p0

    :cond_25
    const/4 p0, 0x0

    return p0
.end method

.method public static refresh(Landroid/view/View;Ljava/lang/String;)Z
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->findTile(Landroid/view/View;Ljava/lang/String;)Lcom/android/systemui/plugins/qs/QSTile;

    move-result-object p0

    if-eqz p0, :cond_b

    :try_start_6
    invoke-interface {p0}, Lcom/android/systemui/plugins/qs/QSTile;->refreshState()V

    const/4 p0, 0x1

    return p0
    :try_end_b
    .catch Ljava/lang/Throwable; {:try_start_6 .. :try_end_b} :catch_b

    :catch_b
    :cond_b
    const/4 p0, 0x0

    return p0
.end method

.method public static remove(Landroid/view/View;Ljava/lang/String;)Z
    .registers 5

    if-eqz p0, :cond_1f

    invoke-static {p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->canonicalSpec(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_1f

    invoke-static {p0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->findHost(Landroid/view/View;)Lcom/android/systemui/qs/QSTileHost;

    move-result-object v0

    if-eqz v0, :cond_1f

    :try_start_e
    invoke-static {p0, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->freshSpecs(Landroid/view/View;Lcom/android/systemui/qs/QSTileHost;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-static {v1, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->removeMatching(Ljava/util/ArrayList;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1d

    invoke-static {p0, v0, v1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->writeSpecs(Landroid/view/View;Lcom/android/systemui/qs/QSTileHost;Ljava/util/ArrayList;)Z

    move-result p0

    return p0

    :cond_1d
    const/4 p0, 0x1

    return p0
    :try_end_1f
    .catch Ljava/lang/Throwable; {:try_start_e .. :try_end_1f} :catch_1f

    :catch_1f
    :cond_1f
    const/4 p0, 0x0

    return p0
.end method

.method private static removeMatching(Ljava/util/ArrayList;Ljava/lang/String;)Z
    .registers 6

    const/4 v0, 0x0

    if-eqz p0, :cond_20

    if-eqz p1, :cond_20

    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_9
    :goto_9
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_20

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_9

    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    const/4 v0, 0x1

    goto :goto_9

    :cond_20
    return v0
.end method

.method public static resetToDefault(Landroid/view/View;)Z
    .registers 3

    const/4 v0, 0x0

    invoke-static {p0, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->resetToDefault(Landroid/view/View;I)Z

    move-result p0

    return p0
.end method

.method public static resetToDefault(Landroid/view/View;I)Z
    .registers 8

    if-eqz p0, :cond_42

    invoke-static {p0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->findHost(Landroid/view/View;)Lcom/android/systemui/qs/QSTileHost;

    move-result-object v0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    if-eqz v1, :cond_42

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const-string v3, "quick_settings_tiles_default"

    invoke-static {v2, p1, v1, v3}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->addSpecsFromStringResource(Ljava/util/ArrayList;ILandroid/content/Context;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_37

    :try_start_1c
    invoke-static {v1}, Lcom/android/systemui/qs/QSHost;->getDefaultSpecs(Landroid/content/Context;)Ljava/util/ArrayList;

    move-result-object v3

    if-eqz v3, :cond_37

    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_26
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_37

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v2, p1, v4}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->addDefault(Ljava/util/ArrayList;ILjava/lang/String;)V

    goto :goto_26
    :try_end_36
    .catch Ljava/lang/Throwable; {:try_start_1c .. :try_end_36} :catch_36

    :catch_36
    move-exception v5

    :cond_37
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_42

    invoke-static {p0, v0, v2}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->writeSpecs(Landroid/view/View;Lcom/android/systemui/qs/QSTileHost;Ljava/util/ArrayList;)Z

    move-result p0

    return p0

    :cond_42
    const/4 p0, 0x0

    return p0
.end method

.method public static secondaryLabel(Landroid/view/View;Ljava/lang/String;)Ljava/lang/CharSequence;
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->state(Landroid/view/View;Ljava/lang/String;)Lcom/android/systemui/plugins/qs/QSTile$State;

    move-result-object p0

    if-eqz p0, :cond_f

    iget-object p0, p0, Lcom/android/systemui/plugins/qs/QSTile$State;->secondaryLabel:Ljava/lang/CharSequence;

    invoke-static {p0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->notBlank(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_f

    return-object p0

    :cond_f
    const-string p0, ""

    return-object p0
.end method

.method public static setHost(Lcom/android/systemui/qs/QSTileHost;)V
    .registers 1

    sput-object p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->sHost:Lcom/android/systemui/qs/QSTileHost;

    return-void
.end method

.method private static specMatches(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 3

    if-eqz p0, :cond_24

    if-eqz p1, :cond_24

    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_22

    invoke-static {p0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->isBluetoothSpec(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_16

    invoke-static {p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->isBluetoothSpec(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_22

    :cond_16
    invoke-static {p0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->isInternetSpec(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_24

    invoke-static {p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->isInternetSpec(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_24

    :cond_22
    const/4 p0, 0x1

    return p0

    :cond_24
    const/4 p0, 0x0

    return p0
.end method

.method private static specsFromSettings(Landroid/view/View;I)Ljava/util/ArrayList;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "I)",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    if-eqz p0, :cond_4c

    :try_start_7
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const-string v1, "sysui_qs_tiles"

    const/4 v2, -0x2

    invoke-static {p0, v1, v2}, Landroid/provider/Settings$Secure;->getStringForUser(Landroid/content/ContentResolver;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_4c

    const-string v1, ","

    invoke-virtual {p0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    array-length v1, p0

    const/4 v2, 0x0

    :goto_20
    if-ge v2, v1, :cond_4c

    aget-object v3, p0, v2

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v4

    if-lez v4, :cond_49

    const-string v4, "default"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_37

    goto :goto_49

    :cond_37
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_49

    if-lez p1, :cond_46

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-lt v4, p1, :cond_46

    goto :goto_4c

    :cond_46
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_49
    :goto_49
    add-int/lit8 v2, v2, 0x1

    goto :goto_20
    :try_end_4c
    .catch Ljava/lang/Throwable; {:try_start_7 .. :try_end_4c} :catch_4c

    :catch_4c
    :cond_4c
    :goto_4c
    return-object v0
.end method

.method public static state(Landroid/view/View;Ljava/lang/String;)Lcom/android/systemui/plugins/qs/QSTile$State;
    .registers 6

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->findTile(Landroid/view/View;Ljava/lang/String;)Lcom/android/systemui/plugins/qs/QSTile;

    move-result-object v0

    if-eqz v0, :cond_e

    :try_start_6
    invoke-interface {v0}, Lcom/android/systemui/plugins/qs/QSTile;->refreshState()V

    invoke-interface {v0}, Lcom/android/systemui/plugins/qs/QSTile;->getState()Lcom/android/systemui/plugins/qs/QSTile$State;

    move-result-object v0
    :try_end_d
    .catch Ljava/lang/Throwable; {:try_start_6 .. :try_end_d} :catch_e

    return-object v0

    :catch_e
    :cond_e
    if-eqz p0, :cond_34

    if-eqz p1, :cond_34

    invoke-static {p0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->findHost(Landroid/view/View;)Lcom/android/systemui/qs/QSTileHost;

    move-result-object v0

    if-eqz v0, :cond_34

    :try_start_18
    invoke-virtual {v0, p1}, Lcom/android/systemui/qs/QSTileHost;->createTile(Ljava/lang/String;)Lcom/android/systemui/plugins/qs/QSTile;

    move-result-object v0

    if-eqz v0, :cond_34

    invoke-interface {v0, p1}, Lcom/android/systemui/plugins/qs/QSTile;->setTileSpec(Ljava/lang/String;)V

    const/4 v1, 0x1

    invoke-interface {v0, p0, v1}, Lcom/android/systemui/plugins/qs/QSTile;->setListening(Ljava/lang/Object;Z)V

    invoke-interface {v0}, Lcom/android/systemui/plugins/qs/QSTile;->refreshState()V

    invoke-interface {v0}, Lcom/android/systemui/plugins/qs/QSTile;->getState()Lcom/android/systemui/plugins/qs/QSTile$State;

    move-result-object v2

    const/4 v3, 0x0

    invoke-interface {v0, p0, v3}, Lcom/android/systemui/plugins/qs/QSTile;->setListening(Ljava/lang/Object;Z)V

    invoke-interface {v0}, Lcom/android/systemui/plugins/qs/QSTile;->destroy()V
    :try_end_33
    .catch Ljava/lang/Throwable; {:try_start_18 .. :try_end_33} :catch_34

    return-object v2

    :catch_34
    :cond_34
    const/4 p0, 0x0

    return-object p0
.end method

.method public static stateValue(Landroid/view/View;Ljava/lang/String;)I
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->state(Landroid/view/View;Ljava/lang/String;)Lcom/android/systemui/plugins/qs/QSTile$State;

    move-result-object p0

    if-eqz p0, :cond_9

    iget p0, p0, Lcom/android/systemui/plugins/qs/QSTile$State;->state:I

    return p0

    :cond_9
    const/4 p0, 0x1

    return p0
.end method

.method public static visibleSpecs(Landroid/view/View;I)Ljava/util/ArrayList;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "I)",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    if-eqz p0, :cond_57

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->specsFromSettings(Landroid/view/View;I)Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_12

    return-object v1

    :cond_12
    invoke-static {p0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->findHost(Landroid/view/View;)Lcom/android/systemui/qs/QSTileHost;

    move-result-object v1

    if-eqz v1, :cond_39

    :try_start_18
    invoke-virtual {v1}, Lcom/android/systemui/qs/QSTileHost;->getSpecs()Ljava/util/ArrayList;

    move-result-object v1

    if-eqz v1, :cond_39

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_22
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_32

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-static {v0, p1, v2}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->addDefault(Ljava/util/ArrayList;ILjava/lang/String;)V

    goto :goto_22

    :cond_32
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_39

    return-object v0
    :try_end_39
    .catch Ljava/lang/Throwable; {:try_start_18 .. :try_end_39} :catch_39

    :catch_39
    :cond_39
    :try_start_39
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-static {p0}, Lcom/android/systemui/qs/QSHost;->getDefaultSpecs(Landroid/content/Context;)Ljava/util/ArrayList;

    move-result-object p0

    if-eqz p0, :cond_57

    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_47
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_57

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v0, p1, v1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->addDefault(Ljava/util/ArrayList;ILjava/lang/String;)V
    :try_end_56
    .catch Ljava/lang/Throwable; {:try_start_39 .. :try_end_56} :catch_57

    goto :goto_47

    :catch_57
    :cond_57
    return-object v0
.end method

.method private static writeSpecs(Landroid/view/View;Lcom/android/systemui/qs/QSTileHost;Ljava/util/ArrayList;)Z
    .registers 6

    if-eqz p0, :cond_1e

    if-eqz p2, :cond_1e

    :try_start_4
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const-string v0, ","

    invoke-static {v0, p2}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object p2

    const-string v0, "sysui_qs_tiles"

    invoke-static {p0, v0, p2}, Landroid/provider/Settings$Secure;->putString(Landroid/content/ContentResolver;Ljava/lang/String;Ljava/lang/String;)Z

    if-eqz p1, :cond_1c

    invoke-virtual {p1, v0, p2}, Lcom/android/systemui/qs/QSTileHost;->onTuningChanged(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1c
    const/4 p0, 0x1

    return p0
    :try_end_1e
    .catch Ljava/lang/Throwable; {:try_start_4 .. :try_end_1e} :catch_1e

    :catch_1e
    :cond_1e
    const/4 p0, 0x0

    return p0
.end method
