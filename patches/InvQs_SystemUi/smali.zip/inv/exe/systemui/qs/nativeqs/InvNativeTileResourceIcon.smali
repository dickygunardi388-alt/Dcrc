.class public final Linv/exe/systemui/qs/nativeqs/InvNativeTileResourceIcon;
.super Ljava/lang/Object;
.source "NativeTileResourceIcon.java"


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static drawable(Landroid/view/View;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    .registers 8

    const/4 v0, 0x0

    if-eqz p0, :cond_2d

    if-eqz p1, :cond_2d

    :try_start_5
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    if-eqz v2, :cond_2d

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-static {p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileResourceIcon;->name(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 p0, 0x0

    if-eqz v1, :cond_20

    const-string v5, "drawable"

    invoke-virtual {v3, v1, v5, v4}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    :cond_20
    if-nez p0, :cond_26

    invoke-static {p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileResourceIcon;->resId(Ljava/lang/String;)I

    move-result p0

    :cond_26
    if-eqz p0, :cond_2d

    invoke-virtual {v2, p0}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    return-object v0
    :try_end_2d
    .catch Ljava/lang/Throwable; {:try_start_5 .. :try_end_2d} :catch_2d

    :catch_2d
    :cond_2d
    return-object v0
.end method

.method private static name(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    const/4 v0, 0x0

    if-eqz p0, :cond_1bb

    const-string v1, "internet"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_e

    const-string v0, "ic_qs_wifi_4_4"

    return-object v0

    :cond_e
    const-string v1, "wifi"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_19

    const-string v0, "ic_qs_wifi_4_4"

    return-object v0

    :cond_19
    const-string v1, "cell"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_24

    const-string v0, "ic_qs_data_switch_1"

    return-object v0

    :cond_24
    const-string v1, "mobile"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2f

    const-string v0, "ic_qs_data_switch_1"

    return-object v0

    :cond_2f
    const-string v1, "bt"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3a

    const-string v0, "qs_bluetooth_icon_off"

    return-object v0

    :cond_3a
    const-string v1, "bluetooth"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_45

    const-string v0, "qs_bluetooth_icon_off"

    return-object v0

    :cond_45
    const-string v1, "airplane"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_50

    const-string v0, "qs_airplane_icon_off"

    return-object v0

    :cond_50
    const-string v1, "rotation"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5b

    const-string v0, "qs_auto_rotate_icon_off"

    return-object v0

    :cond_5b
    const-string v1, "dnd"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_66

    const-string v0, "qs_dnd_icon_off"

    return-object v0

    :cond_66
    const-string v1, "flashlight"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_71

    const-string v0, "qs_flashlight_icon_off"

    return-object v0

    :cond_71
    const-string v1, "hotspot"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7c

    const-string v0, "qs_hotspot_icon_off"

    return-object v0

    :cond_7c
    const-string v1, "nfc"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_87

    const-string v0, "ic_qs_nfc"

    return-object v0

    :cond_87
    const-string v1, "cast"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_92

    const-string v0, "ic_cast"

    return-object v0

    :cond_92
    const-string v1, "screenrecord"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9d

    const-string v0, "qs_screen_record_icon_off"

    return-object v0

    :cond_9d
    const-string v1, "battery"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a8

    const-string v0, "qs_battery_saver_icon_off"

    return-object v0

    :cond_a8
    const-string v1, "saver"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_b3

    const-string v0, "qs_data_saver_icon_off"

    return-object v0

    :cond_b3
    const-string v1, "data_saver"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_be

    const-string v0, "qs_data_saver_icon_off"

    return-object v0

    :cond_be
    const-string v1, "dark"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_c9

    const-string v0, "qs_light_dark_theme_icon_off"

    return-object v0

    :cond_c9
    const-string v1, "night"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_d4

    const-string v0, "qs_nightlight_icon_off"

    return-object v0

    :cond_d4
    const-string v1, "location"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_df

    const-string v0, "qs_location_icon_off"

    return-object v0

    :cond_df
    const-string v1, "qr_code_scanner"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_ea

    const-string v0, "ic_qr_code_scanner"

    return-object v0

    :cond_ea
    const-string v1, "wallet"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_f5

    const-string v0, "ic_qs_wallet"

    return-object v0

    :cond_f5
    const-string v1, "controls"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_100

    const-string v0, "ic_device_unknown"

    return-object v0

    :cond_100
    const-string v1, "work"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_10b

    const-string v0, "stat_sys_managed_profile_status"

    return-object v0

    :cond_10b
    const-string v1, "mictoggle"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_116

    const-string v0, "qs_mic_access_off"

    return-object v0

    :cond_116
    const-string v1, "cameratoggle"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_121

    const-string v0, "qs_camera_access_icon_off"

    return-object v0

    :cond_121
    const-string v1, "inversion"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_12c

    const-string v0, "qs_invert_colors_icon_off"

    return-object v0

    :cond_12c
    const-string v1, "reduce_brightness"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_137

    const-string v0, "qs_extra_dim_icon_off"

    return-object v0

    :cond_137
    const-string v1, "onehanded"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_142

    const-string v0, "ic_qs_screen_saver"

    return-object v0

    :cond_142
    const-string v1, "color_correction"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_14d

    const-string v0, "ic_qs_color_correction"

    return-object v0

    :cond_14d
    const-string v1, "dream"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_158

    const-string v0, "ic_qs_screen_saver"

    return-object v0

    :cond_158
    const-string v1, "caffeine"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_163

    const-string v0, "ic_qs_caffeine"

    return-object v0

    :cond_163
    const-string v1, "dataswitch"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_16e

    const-string v0, "ic_qs_data_switch_1"

    return-object v0

    :cond_16e
    const-string v1, "heads_up"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_179

    const-string v0, "ic_qs_heads_up"

    return-object v0

    :cond_179
    const-string v1, "dc_dimming"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_184

    const-string v0, "ic_device_display"

    return-object v0

    :cond_184
    const-string v1, "aod"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_18f

    const-string v0, "ic_qs_aod"

    return-object v0

    :cond_18f
    const-string v1, "powershare"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_19a

    const-string v0, "ic_qs_powershare"

    return-object v0

    :cond_19a
    const-string v1, "reverse"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1a5

    const-string v0, "ic_qs_powershare"

    return-object v0

    :cond_1a5
    const-string v1, "font_scaling"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1b0

    const-string v0, "ic_qs_font_scaling"

    return-object v0

    :cond_1b0
    const-string v1, "alarm"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1bb

    const-string v0, "stat_sys_alarm"

    return-object v0

    :cond_1bb
    return-object v0
.end method

.method private static resId(Ljava/lang/String;)I
    .registers 3

    const/4 v0, 0x0

    if-eqz p0, :cond_fb

    const-string v1, "internet"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_13

    const-string v1, "wifi"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_17

    :cond_13
    const v0, 0x7f0807e6

    return v0

    :cond_17
    const-string v1, "cell"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_27

    const-string v1, "mobile"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2b

    :cond_27
    const v0, 0x7f08061b

    return v0

    :cond_2b
    const-string v1, "bt"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3b

    const-string v1, "bluetooth"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3f

    :cond_3b
    const v0, 0x7f080995

    return v0

    :cond_3f
    const-string v1, "airplane"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4b

    const v0, 0x7f08098f

    return v0

    :cond_4b
    const-string v1, "rotation"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_57

    const v0, 0x7f080990

    return v0

    :cond_57
    const-string v1, "dnd"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_63

    const v0, 0x7f0809a6

    return v0

    :cond_63
    const-string v1, "flashlight"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6f

    const v0, 0x7f0809aa

    return v0

    :cond_6f
    const-string v1, "hotspot"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7b

    const v0, 0x7f0809b0

    return v0

    :cond_7b
    const-string v1, "cast"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_87

    const v0, 0x7f08061c

    return v0

    :cond_87
    const-string v1, "screenrecord"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_93

    const v0, 0x7f0809cb

    return v0

    :cond_93
    const-string v1, "saver"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a3

    const-string v1, "battery"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a7

    :cond_a3
    const v0, 0x7f080992

    return v0

    :cond_a7
    const-string v1, "data_saver"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_b3

    const v0, 0x7f0809a0

    return v0

    :cond_b3
    const-string v1, "night"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_bf

    const v0, 0x7f0809c9

    return v0

    :cond_bf
    const-string v1, "reduce_brightness"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_cb

    const v0, 0x7f0809a8

    return v0

    :cond_cb
    const-string v1, "mictoggle"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_d7

    const v0, 0x7f0809c7

    return v0

    :cond_d7
    const-string v1, "cameratoggle"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_e3

    const v0, 0x7f080999

    return v0

    :cond_e3
    const-string v1, "work"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_ef

    const v0, 0x7f080a1d

    return v0

    :cond_ef
    const-string v1, "color_correction"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_fb

    const v0, 0x7f0807dc

    return v0

    :cond_fb
    return v0
.end method
