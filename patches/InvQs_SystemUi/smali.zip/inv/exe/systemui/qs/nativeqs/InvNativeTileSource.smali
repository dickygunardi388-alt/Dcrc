.class public final Linv/exe/systemui/qs/nativeqs/InvNativeTileSource;
.super Ljava/lang/Object;
.source "NativeTileSource.java"


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static source(Landroid/view/View;)Landroid/view/View;
    .registers 5

    if-eqz p0, :cond_23

    invoke-virtual {p0}, Landroid/view/View;->getId()I

    move-result v0

    const-string v1, "tile_circle"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    if-ne v0, v1, :cond_23

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v1, v0, Landroid/view/View;

    if-eqz v1, :cond_23

    check-cast v0, Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    instance-of v3, v2, Landroid/view/View;

    if-eqz v3, :cond_23

    check-cast v2, Landroid/view/View;

    return-object v2

    :cond_23
    return-object p0
.end method
