.class public final Linv/exe/systemui/qs/nativeqs/InvNativeTileCatalogRes;
.super Ljava/lang/Object;
.source "NativeTileCatalogRes.java"


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static icon(Landroid/view/View;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    .registers 4

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->icon(Landroid/view/View;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-eqz v0, :cond_7

    return-object v0

    :cond_7
    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileResourceIcon;->drawable(Landroid/view/View;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    return-object v0
.end method

.method public static label(Landroid/view/View;Ljava/lang/String;)Ljava/lang/CharSequence;
    .registers 6

    if-eqz p1, :cond_1d7

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->label(Landroid/view/View;Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v0

    if-eqz v0, :cond_15

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v1

    if-lez v1, :cond_15

    invoke-virtual {p1, v0}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_15

    return-object v0

    :cond_15
    const-string v0, "custom("

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1e

    return-object p1

    :cond_1e
    const-string v0, "internet"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_29

    const-string v0, "Internet"

    return-object v0

    :cond_29
    const-string v0, "wifi"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_34

    const-string v0, "Wi‑Fi"

    return-object v0

    :cond_34
    const-string v0, "cell"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3f

    const-string v0, "Mobile data"

    return-object v0

    :cond_3f
    const-string v0, "mobile"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4a

    const-string v0, "Mobile data"

    return-object v0

    :cond_4a
    const-string v0, "bt"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_55

    const-string v0, "Bluetooth"

    return-object v0

    :cond_55
    const-string v0, "bluetooth"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_60

    const-string v0, "Bluetooth"

    return-object v0

    :cond_60
    const-string v0, "airplane"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_6b

    const-string v0, "Airplane mode"

    return-object v0

    :cond_6b
    const-string v0, "rotation"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_76

    const-string v0, "Auto-rotate"

    return-object v0

    :cond_76
    const-string v0, "dnd"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_81

    const-string v0, "Do Not Disturb"

    return-object v0

    :cond_81
    const-string v0, "flashlight"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_8c

    const-string v0, "Flashlight"

    return-object v0

    :cond_8c
    const-string v0, "hotspot"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_97

    const-string v0, "Hotspot"

    return-object v0

    :cond_97
    const-string v0, "nfc"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a2

    const-string v0, "NFC"

    return-object v0

    :cond_a2
    const-string v0, "cast"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_ad

    const-string v0, "Screen Cast"

    return-object v0

    :cond_ad
    const-string v0, "screenrecord"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_b8

    const-string v0, "Screen record"

    return-object v0

    :cond_b8
    const-string v0, "battery"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_c3

    const-string v0, "Battery Saver"

    return-object v0

    :cond_c3
    const-string v0, "saver"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_ce

    const-string v0, "Data Saver"

    return-object v0

    :cond_ce
    const-string v0, "data_saver"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_d9

    const-string v0, "Data Saver"

    return-object v0

    :cond_d9
    const-string v0, "dark"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_e4

    const-string v0, "Dark theme"

    return-object v0

    :cond_e4
    const-string v0, "night"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_ef

    const-string v0, "Night Light"

    return-object v0

    :cond_ef
    const-string v0, "location"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_fa

    const-string v0, "Location"

    return-object v0

    :cond_fa
    const-string v0, "qr_code_scanner"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_105

    const-string v0, "QR code scanner"

    return-object v0

    :cond_105
    const-string v0, "wallet"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_110

    const-string v0, "Wallet"

    return-object v0

    :cond_110
    const-string v0, "controls"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_11b

    const-string v0, "Device controls"

    return-object v0

    :cond_11b
    const-string v0, "work"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_126

    const-string v0, "Work mode"

    return-object v0

    :cond_126
    const-string v0, "mictoggle"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_131

    const-string v0, "Mic access"

    return-object v0

    :cond_131
    const-string v0, "cameratoggle"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_13c

    const-string v0, "Camera access"

    return-object v0

    :cond_13c
    const-string v0, "inversion"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_147

    const-string v0, "Color inversion"

    return-object v0

    :cond_147
    const-string v0, "reduce_brightness"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_152

    const-string v0, "Extra dim"

    return-object v0

    :cond_152
    const-string v0, "onehanded"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_15d

    const-string v0, "One-handed mode"

    return-object v0

    :cond_15d
    const-string v0, "color_correction"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_168

    const-string v0, "Color correction"

    return-object v0

    :cond_168
    const-string v0, "dream"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_173

    const-string v0, "Screen saver"

    return-object v0

    :cond_173
    const-string v0, "caffeine"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_17e

    const-string v0, "Caffeine"

    return-object v0

    :cond_17e
    const-string v0, "dataswitch"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_189

    const-string v0, "Data switch"

    return-object v0

    :cond_189
    const-string v0, "heads_up"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_194

    const-string v0, "Heads up"

    return-object v0

    :cond_194
    const-string v0, "dc_dimming"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_19f

    const-string v0, "DC dimming"

    return-object v0

    :cond_19f
    const-string v0, "aod"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1aa

    const-string v0, "Always-on display"

    return-object v0

    :cond_1aa
    const-string v0, "powershare"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1b5

    const-string v0, "Power share"

    return-object v0

    :cond_1b5
    const-string v0, "reverse"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1c0

    const-string v0, "Reverse charging"

    return-object v0

    :cond_1c0
    const-string v0, "font_scaling"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1cb

    const-string v0, "Font size"

    return-object v0

    :cond_1cb
    const-string v0, "alarm"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1d6

    const-string v0, "Alarm"

    return-object v0

    :cond_1d6
    return-object p1

    :cond_1d7
    const-string v0, ""

    return-object v0
.end method
