.class public final Linv/exe/systemui/qs/nativeqs/InvNativeControlLongClickListener;
.super Ljava/lang/Object;
.source "NativeControlLongClickListener.java"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# instance fields
.field private final controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

.field private final id:Linv/exe/systemui/qs/model/InvControlId;

.field private final launchView:Landroid/view/View;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Linv/exe/systemui/qs/model/InvControlId;Landroid/view/View;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/nativeqs/InvNativeControlLongClickListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iput-object p2, p0, Linv/exe/systemui/qs/nativeqs/InvNativeControlLongClickListener;->id:Linv/exe/systemui/qs/model/InvControlId;

    iput-object p3, p0, Linv/exe/systemui/qs/nativeqs/InvNativeControlLongClickListener;->launchView:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .registers 5

    iget-object v0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeControlLongClickListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$0(Linv/exe/systemui/qs/controller/InvQsPanelController;)Z

    move-result v0

    if-eqz v0, :cond_a

    const/4 p0, 0x0

    return p0

    :cond_a
    iget-object v0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeControlLongClickListener;->id:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->INTERNET:Linv/exe/systemui/qs/model/InvControlId;

    if-ne v0, v1, :cond_13

    const-string v0, "internet"

    goto :goto_1b

    :cond_13
    iget-object v0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeControlLongClickListener;->id:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->BLUETOOTH:Linv/exe/systemui/qs/model/InvControlId;

    if-ne v0, v1, :cond_36

    const-string v0, "bt"

    :goto_1b
    iget-object v1, p0, Linv/exe/systemui/qs/nativeqs/InvNativeControlLongClickListener;->launchView:Landroid/view/View;

    if-eqz v1, :cond_20

    move-object p1, v1

    :cond_20
    invoke-static {p1, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->longClick(Landroid/view/View;Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_2f

    invoke-static {p1, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->openDetails(Landroid/view/View;Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_2f

    invoke-static {p1, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->click(Landroid/view/View;Ljava/lang/String;)Z

    :cond_2f
    iget-object p0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeControlLongClickListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$12(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    const/4 p0, 0x1

    return p0

    :cond_36
    iget-object v0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeControlLongClickListener;->id:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->DATA_USAGE:Linv/exe/systemui/qs/model/InvControlId;

    if-ne v0, v1, :cond_3f

    const-string v0, "android.settings.DATA_USAGE_SETTINGS"

    goto :goto_47

    :cond_3f
    iget-object v0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeControlLongClickListener;->id:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->BATTERY_VIEW:Linv/exe/systemui/qs/model/InvControlId;

    if-ne v0, v1, :cond_5a

    const-string v0, "android.settings.BATTERY_SETTINGS"

    :goto_47
    iget-object v1, p0, Linv/exe/systemui/qs/nativeqs/InvNativeControlLongClickListener;->launchView:Landroid/view/View;

    if-eqz v1, :cond_4c

    move-object p1, v1

    :cond_4c
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1, v0}, Linv/exe/systemui/qs/helper/InvControlIntentHelper;->openSetting(Landroid/content/Context;Ljava/lang/String;)V

    iget-object p0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeControlLongClickListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {p0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$12(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    const/4 p0, 0x1

    return p0

    :cond_5a
    const/4 p0, 0x0

    return p0
.end method
