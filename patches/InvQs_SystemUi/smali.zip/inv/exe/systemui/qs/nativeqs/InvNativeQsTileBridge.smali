.class public final Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;
.super Ljava/lang/Object;
.source "NativeQsTileBridge.java"


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static add(Landroid/view/View;Ljava/lang/String;)Z
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->add(Landroid/view/View;Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method public static allSpecs(Landroid/view/View;I)Ljava/util/ArrayList;
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->allSpecs(Landroid/view/View;I)Ljava/util/ArrayList;

    move-result-object p0

    return-object p0
.end method

.method public static click(Landroid/view/View;Ljava/lang/String;)Z
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->click(Landroid/view/View;Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method public static groupRank(Ljava/lang/String;)I
    .registers 1

    invoke-static {p0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->groupRank(Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static icon(Landroid/view/View;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->icon(Landroid/view/View;Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0
.end method

.method public static isActive(Landroid/view/View;Ljava/lang/String;)Z
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->isActive(Landroid/view/View;Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method public static isDialogLaunchSpec(Ljava/lang/String;)Z
    .registers 3

    if-eqz p0, :cond_5d

    const-string v0, "internet"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_b

    goto :goto_5b

    :cond_b
    const-string v0, "wifi"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_14

    goto :goto_5b

    :cond_14
    const-string v0, "cell"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1d

    goto :goto_5b

    :cond_1d
    const-string v0, "bt"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_26

    goto :goto_5b

    :cond_26
    const-string v0, "bluetooth"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2f

    goto :goto_5b

    :cond_2f
    const-string v0, "screenrecord"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_38

    goto :goto_5b

    :cond_38
    const-string v0, "cast"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_41

    goto :goto_5b

    :cond_41
    const-string v0, "controls"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4a

    goto :goto_5b

    :cond_4a
    const-string v0, "wallet"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_53

    goto :goto_5b

    :cond_53
    const-string v0, "qr_code_scanner"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_5d

    :goto_5b
    const/4 p0, 0x1

    return p0

    :cond_5d
    const/4 p0, 0x0

    return p0
.end method

.method public static label(Landroid/view/View;Ljava/lang/String;)Ljava/lang/CharSequence;
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->label(Landroid/view/View;Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public static listContainsSpec(Ljava/util/ArrayList;Ljava/lang/String;)Z
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->listContainsSpec(Ljava/util/ArrayList;Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method public static longClick(Landroid/view/View;Ljava/lang/String;)Z
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->longClick(Landroid/view/View;Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method public static moveAfter(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;)Z
    .registers 3

    invoke-static {p0, p1, p2}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->moveAfter(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method public static moveBefore(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;)Z
    .registers 3

    invoke-static {p0, p1, p2}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->moveBefore(Landroid/view/View;Ljava/lang/String;Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method public static openDetails(Landroid/view/View;Ljava/lang/String;)Z
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->openDetails(Landroid/view/View;Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method public static pruneToCapacity(Landroid/view/View;I)Z
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->pruneToCapacity(Landroid/view/View;I)Z

    move-result p0

    return p0
.end method

.method public static refresh(Landroid/view/View;Ljava/lang/String;)Z
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->refresh(Landroid/view/View;Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method public static remove(Landroid/view/View;Ljava/lang/String;)Z
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->remove(Landroid/view/View;Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method public static resetToDefault(Landroid/view/View;)Z
    .registers 1

    invoke-static {p0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->resetToDefault(Landroid/view/View;)Z

    move-result p0

    return p0
.end method

.method public static resetToDefault(Landroid/view/View;I)Z
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->resetToDefault(Landroid/view/View;I)Z

    move-result p0

    return p0
.end method

.method public static state(Landroid/view/View;Ljava/lang/String;)Lcom/android/systemui/plugins/qs/QSTile$State;
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->state(Landroid/view/View;Ljava/lang/String;)Lcom/android/systemui/plugins/qs/QSTile$State;

    move-result-object p0

    return-object p0
.end method

.method public static stateValue(Landroid/view/View;Ljava/lang/String;)I
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->stateValue(Landroid/view/View;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public static visibleSpecs(Landroid/view/View;I)Ljava/util/ArrayList;
    .registers 2

    invoke-static {p0, p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileAction;->visibleSpecs(Landroid/view/View;I)Ljava/util/ArrayList;

    move-result-object p0

    return-object p0
.end method
