.class public final Linv/exe/systemui/qs/nativeqs/InvNativeTileRemoveClickListener;
.super Ljava/lang/Object;
.source "NativeTileRemoveClickListener.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field private final controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

.field private final spec:Ljava/lang/String;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileRemoveClickListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iput-object p2, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileRemoveClickListener;->spec:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 3

    iget-object v0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileRemoveClickListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$2(Linv/exe/systemui/qs/controller/InvQsPanelController;)Linv/exe/systemui/qs/ui/InvQsPanelView;

    move-result-object p1

    iget-object p0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileRemoveClickListener;->spec:Ljava/lang/String;

    invoke-static {p1, p0}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->remove(Landroid/view/View;Ljava/lang/String;)Z

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$12(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    return-void
.end method
