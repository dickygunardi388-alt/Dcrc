.class public final Linv/exe/systemui/qs/nativeqs/InvNativeTileLongClickListener;
.super Ljava/lang/Object;
.source "NativeTileLongClickListener.java"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# instance fields
.field private final controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

.field private final spec:Ljava/lang/String;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileLongClickListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iput-object p2, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileLongClickListener;->spec:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .registers 7

    invoke-static {p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileSource;->source(Landroid/view/View;)Landroid/view/View;

    move-result-object v4

    iget-object v0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileLongClickListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$0(Linv/exe/systemui/qs/controller/InvQsPanelController;)Z

    move-result v1

    if-nez v1, :cond_1b

    iget-object p0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileLongClickListener;->spec:Ljava/lang/String;

    invoke-static {v4, p0}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->longClick(Landroid/view/View;Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_16

    const/4 p0, 0x1

    return p0

    :cond_16
    invoke-static {v4, p0}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->openDetails(Landroid/view/View;Ljava/lang/String;)Z

    move-result p0

    return p0

    :cond_1b
    invoke-static {v4}, Linv/exe/systemui/qs/drag/InvNativeDragVisual;->lift(Landroid/view/View;)V

    iget-object p0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileLongClickListener;->spec:Ljava/lang/String;

    const-string v0, "native_tile"

    invoke-static {v0, p0}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object v0

    new-instance v1, Landroid/view/View$DragShadowBuilder;

    invoke-direct {v1, v4}, Landroid/view/View$DragShadowBuilder;-><init>(Landroid/view/View;)V

    const/4 v2, 0x0

    invoke-virtual {v4, v0, v1, p0, v2}, Landroid/view/View;->startDragAndDrop(Landroid/content/ClipData;Landroid/view/View$DragShadowBuilder;Ljava/lang/Object;I)Z

    const/4 p0, 0x1

    return p0
.end method
