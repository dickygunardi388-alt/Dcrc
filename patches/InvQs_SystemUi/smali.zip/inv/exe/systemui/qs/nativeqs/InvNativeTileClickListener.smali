.class public final Linv/exe/systemui/qs/nativeqs/InvNativeTileClickListener;
.super Ljava/lang/Object;
.source "NativeTileClickListener.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field private final controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

.field private final spec:Ljava/lang/String;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvQsPanelController;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileClickListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    iput-object p2, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileClickListener;->spec:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 7

    invoke-static {p1}, Linv/exe/systemui/qs/nativeqs/InvNativeTileSource;->source(Landroid/view/View;)Landroid/view/View;

    move-result-object v4

    iget-object v0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileClickListener;->controller:Linv/exe/systemui/qs/controller/InvQsPanelController;

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$0(Linv/exe/systemui/qs/controller/InvQsPanelController;)Z

    move-result v1

    iget-object p0, p0, Linv/exe/systemui/qs/nativeqs/InvNativeTileClickListener;->spec:Ljava/lang/String;

    if-eqz v1, :cond_15

    invoke-static {v4, p0}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->remove(Landroid/view/View;Ljava/lang/String;)Z

    invoke-static {v0}, Linv/exe/systemui/qs/controller/InvQsPanelController;->access$12(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    return-void

    :cond_15
    invoke-static {v4}, Linv/exe/systemui/qs/ui/InvTileAnimation;->press(Landroid/view/View;)V

    invoke-static {v4, p0}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->click(Landroid/view/View;Ljava/lang/String;)Z

    invoke-static {v4, p0}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->refresh(Landroid/view/View;Ljava/lang/String;)Z

    invoke-static {p0}, Linv/exe/systemui/qs/nativeqs/InvNativeQsTileBridge;->isDialogLaunchSpec(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_25

    return-void

    :cond_25
    new-instance v1, Linv/exe/systemui/qs/nativeqs/InvNativeTileRebuildRunnable;

    invoke-direct {v1, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileRebuildRunnable;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    const-wide/16 v2, 0xb4

    invoke-virtual {v4, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    new-instance v1, Linv/exe/systemui/qs/nativeqs/InvNativeTileRebuildRunnable;

    invoke-direct {v1, v0}, Linv/exe/systemui/qs/nativeqs/InvNativeTileRebuildRunnable;-><init>(Linv/exe/systemui/qs/controller/InvQsPanelController;)V

    const-wide/16 v2, 0x258

    invoke-virtual {v4, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
