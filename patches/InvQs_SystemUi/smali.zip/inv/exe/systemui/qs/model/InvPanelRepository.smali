.class public Linv/exe/systemui/qs/model/InvPanelRepository;
.super Ljava/lang/Object;
.source "PanelRepository.java"


# static fields
.field private static final CONTROLS:Ljava/lang/String; = "controls"

.field private static final CTRL_COLS:Ljava/lang/String; = "ctrl_cols"

.field private static final CTRL_ROWS:Ljava/lang/String; = "ctrl_rows"

.field private static final CUSTOM_IMAGE_SIZE:Ljava/lang/String; = "custom_image_size"

.field private static final LABELS:Ljava/lang/String; = "show_labels"

.field private static final LEGACY_HORIZONTAL_DEFAULT_CONTROLS:Ljava/lang/String; = "INTERNET,BLUETOOTH,MEDIA,BRIGHTNESS_H,VOLUME_H"

.field private static final MEDIA_SIZE:Ljava/lang/String; = "media_size"

.field private static final MEDIA_SIZE_NAMES:[Ljava/lang/String;

.field private static final MEDIA_SPAN_H:[I

.field private static final MEDIA_SPAN_W:[I

.field private static final PREFS:Ljava/lang/String; = "invmod_panel"

.field private static final TILES:Ljava/lang/String; = "tiles"

.field private static final TILE_COLS:Ljava/lang/String; = "tile_cols"

.field private static final TILE_ROWS:Ljava/lang/String; = "tile_rows"

.field private static final VERTICAL_DEFAULT_CONTROLS:Ljava/lang/String; = "INTERNET,BLUETOOTH,MEDIA,BRIGHTNESS_V,VOLUME_V"


# instance fields
.field private final prefs:Landroid/content/SharedPreferences;


# direct methods
.method static constructor <clinit>()V
    .registers 7

    const/4 v0, 0x6

    .line 28
    new-array v1, v0, [I

    fill-array-data v1, :array_22

    sput-object v1, Linv/exe/systemui/qs/model/InvPanelRepository;->MEDIA_SPAN_H:[I

    .line 29
    new-array v0, v0, [I

    fill-array-data v0, :array_32

    sput-object v0, Linv/exe/systemui/qs/model/InvPanelRepository;->MEDIA_SPAN_W:[I

    .line 31
    const-string v5, "1×3"

    const-string v6, "1×4"

    const-string v1, "1×2"

    const-string v2, "2×2"

    const-string v3, "2×3"

    const-string v4, "2×4"

    filled-new-array/range {v1 .. v6}, [Ljava/lang/String;

    move-result-object v0

    .line 30
    sput-object v0, Linv/exe/systemui/qs/model/InvPanelRepository;->MEDIA_SIZE_NAMES:[Ljava/lang/String;

    return-void

    :array_22
    .array-data 4
        0x1
        0x2
        0x2
        0x2
        0x1
        0x1
    .end array-data

    :array_32
    .array-data 4
        0x2
        0x2
        0x3
        0x4
        0x3
        0x4
    .end array-data
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 4

    .line 36
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 37
    const-string v0, "invmod_panel"

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p1

    iput-object p1, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    .line 38
    invoke-direct {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->migrateLegacyHorizontalSliderDefaults()V

    return-void
.end method

.method private canLayout(Ljava/util/List;II)Z
    .registers 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Linv/exe/systemui/qs/model/InvControlId;",
            ">;II)Z"
        }
    .end annotation

    const/4 v0, 0x2

    .line 330
    new-array v0, v0, [I

    const/4 v1, 0x1

    aput p2, v0, v1

    const/4 v2, 0x0

    aput p3, v0, v2

    sget-object v3, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    invoke-static {v3, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Z

    .line 331
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_15
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-nez v3, :cond_1c

    return v1

    :cond_1c
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Linv/exe/systemui/qs/model/InvControlId;

    .line 332
    invoke-virtual {p0, v3}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlSpanW(Linv/exe/systemui/qs/model/InvControlId;)I

    move-result v4

    invoke-static {p2, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    .line 333
    invoke-virtual {p0, v3}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlSpanH(Linv/exe/systemui/qs/model/InvControlId;)I

    move-result v3

    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    move v5, v2

    :goto_37
    sub-int v6, p3, v3

    if-le v5, v6, :cond_3c

    return v2

    :cond_3c
    move v6, v2

    :goto_3d
    sub-int v7, p2, v4

    if-le v6, v7, :cond_44

    add-int/lit8 v5, v5, 0x1

    goto :goto_37

    .line 338
    :cond_44
    invoke-static {v0, v5, v6, v4, v3}, Linv/exe/systemui/qs/model/InvPanelRepository;->free([[ZIIII)Z

    move-result v7

    if-eqz v7, :cond_4e

    .line 339
    invoke-static {v0, v5, v6, v4, v3}, Linv/exe/systemui/qs/model/InvPanelRepository;->mark([[ZIIII)V

    goto :goto_15

    :cond_4e
    add-int/lit8 v6, v6, 0x1

    goto :goto_3d
.end method

.method private fitControls(Ljava/util/List;)Ljava/util/ArrayList;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Linv/exe/systemui/qs/model/InvControlId;",
            ">;)",
            "Ljava/util/ArrayList<",
            "Linv/exe/systemui/qs/model/InvControlId;",
            ">;"
        }
    .end annotation

    .line 304
    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlColumns()I

    move-result v0

    .line 305
    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlRows()I

    move-result v1

    .line 306
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 307
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_11
    :goto_11
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-nez v3, :cond_18

    return-object v2

    :cond_18
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Linv/exe/systemui/qs/model/InvControlId;

    .line 308
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 309
    invoke-direct {p0, v2, v0, v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->canLayout(Ljava/util/List;II)Z

    move-result v4

    if-eqz v4, :cond_28

    goto :goto_11

    .line 311
    :cond_28
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v4

    add-int/lit8 v4, v4, -0x1

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 312
    sget-object v4, Linv/exe/systemui/qs/model/InvControlId;->MEDIA:Linv/exe/systemui/qs/model/InvControlId;

    if-eq v3, v4, :cond_36

    goto :goto_11

    .line 316
    :cond_36
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 317
    :goto_39
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_11

    invoke-direct {p0, v2, v0, v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->canLayout(Ljava/util/List;II)Z

    move-result v3

    if-eqz v3, :cond_46

    goto :goto_11

    .line 318
    :cond_46
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    add-int/lit8 v3, v3, -0x2

    if-gez v3, :cond_58

    .line 320
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    add-int/lit8 v3, v3, -0x1

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    goto :goto_11

    .line 323
    :cond_58
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    goto :goto_39
.end method

.method private static free([[ZIIII)Z
    .registers 8

    move v0, p1

    :goto_1
    add-int v1, p1, p4

    if-lt v0, v1, :cond_7

    const/4 p0, 0x1

    return p0

    :cond_7
    move v1, p2

    :goto_8
    add-int v2, p2, p3

    if-lt v1, v2, :cond_f

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 352
    :cond_f
    aget-object v2, p0, v0

    aget-boolean v2, v2, v1

    if-eqz v2, :cond_17

    const/4 p0, 0x0

    return p0

    :cond_17
    add-int/lit8 v1, v1, 0x1

    goto :goto_8
.end method

.method private static limit(III)I
    .registers 3

    .line 49
    invoke-static {p2, p0}, Ljava/lang/Math;->min(II)I

    move-result p0

    invoke-static {p1, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    return p0
.end method

.method private static mark([[ZIIII)V
    .registers 9

    move v0, p1

    :goto_1
    add-int v1, p1, p4

    if-lt v0, v1, :cond_6

    return-void

    :cond_6
    move v1, p2

    :goto_7
    add-int v2, p2, p3

    if-lt v1, v2, :cond_e

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 359
    :cond_e
    aget-object v2, p0, v0

    const/4 v3, 0x1

    aput-boolean v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_7
.end method

.method private migrateLegacyHorizontalSliderDefaults()V
    .registers 4

    .line 42
    iget-object v0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    const/4 v1, 0x0

    const-string v2, "controls"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 43
    const-string v1, "INTERNET,BLUETOOTH,MEDIA,BRIGHTNESS_H,VOLUME_H"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_20

    .line 44
    iget-object p0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "INTERNET,BLUETOOTH,MEDIA,BRIGHTNESS_V,VOLUME_V"

    invoke-interface {p0, v2, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_20
    return-void
.end method

.method private normalizeMediaSizeForGrid()V
    .registers 7

    .line 139
    iget-object v0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "media_size"

    const/4 v2, 0x1

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    sget-object v3, Linv/exe/systemui/qs/model/InvPanelRepository;->MEDIA_SPAN_W:[I

    array-length v3, v3

    sub-int/2addr v3, v2

    const/4 v2, 0x0

    invoke-static {v0, v2, v3}, Linv/exe/systemui/qs/model/InvPanelRepository;->limit(III)I

    move-result v0

    .line 141
    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlColumns()I

    move-result v2

    .line 142
    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlRows()I

    move-result v3

    move v4, v0

    :goto_1b
    if-lez v4, :cond_2d

    .line 143
    sget-object v5, Linv/exe/systemui/qs/model/InvPanelRepository;->MEDIA_SPAN_W:[I

    aget v5, v5, v4

    if-gt v5, v2, :cond_2a

    sget-object v5, Linv/exe/systemui/qs/model/InvPanelRepository;->MEDIA_SPAN_H:[I

    aget v5, v5, v4

    if-gt v5, v3, :cond_2a

    goto :goto_2d

    :cond_2a
    add-int/lit8 v4, v4, -0x1

    goto :goto_1b

    :cond_2d
    :goto_2d
    if-eq v4, v0, :cond_3c

    .line 144
    iget-object p0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0, v1, v4}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_3c
    return-void
.end method

.method private parse(Ljava/lang/String;Z)Ljava/util/ArrayList;
    .registers 6

    new-instance p0, Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    if-eqz p2, :cond_30

    if-eqz p1, :cond_30

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_30

    const-string v0, ","

    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    array-length v0, p1

    const/4 v1, 0x0

    :goto_1b
    if-lt v1, v0, :cond_1e

    goto :goto_30

    :cond_1e
    aget-object v2, p1, v1

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Linv/exe/systemui/qs/model/InvControlId;->fromKey(Ljava/lang/String;)Linv/exe/systemui/qs/model/InvControlId;

    move-result-object v2

    if-eqz v2, :cond_2d

    invoke-virtual {p0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2d
    add-int/lit8 v1, v1, 0x1

    goto :goto_1b

    :cond_30
    :goto_30
    return-object p0
.end method

.method private save(Ljava/lang/String;Ljava/util/List;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "*>;)V"
        }
    .end annotation

    .line 190
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 191
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_9
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-nez v1, :cond_21

    .line 195
    iget-object p0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void

    .line 191
    :cond_21
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    .line 192
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v2

    if-lez v2, :cond_30

    const/16 v2, 0x2c

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 193
    :cond_30
    check-cast v1, Ljava/lang/Enum;

    invoke-virtual {v1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_9
.end method

.method private trimControlsToCapacity()V
    .registers 5

    .line 297
    iget-object v0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    const/4 v1, 0x0

    const-string v2, "controls"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->parse(Ljava/lang/String;Z)Ljava/util/ArrayList;

    move-result-object v0

    .line 298
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1d

    new-instance v0, Ljava/util/ArrayList;

    invoke-static {}, Linv/exe/systemui/qs/model/InvControlId;->defaultOrder()Ljava/util/List;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 299
    :cond_1d
    invoke-direct {p0, v0}, Linv/exe/systemui/qs/model/InvPanelRepository;->fitControls(Ljava/util/List;)Ljava/util/ArrayList;

    move-result-object v1

    .line 300
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-eq v3, v0, :cond_2e

    invoke-direct {p0, v2, v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->save(Ljava/lang/String;Ljava/util/List;)V

    :cond_2e
    return-void
.end method


# virtual methods
.method public addControl(Linv/exe/systemui/qs/model/InvControlId;)Ljava/lang/String;
    .registers 8

    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControls()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_d

    const-string p0, "exists"

    return-object p0

    :cond_d
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    move v2, v1

    sget-object v3, Linv/exe/systemui/qs/model/InvControlId;->MEDIA:Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v3

    sget-object v4, Linv/exe/systemui/qs/model/InvControlId;->BRIGHTNESS_H:Linv/exe/systemui/qs/model/InvControlId;

    if-eq p1, v4, :cond_28

    sget-object v4, Linv/exe/systemui/qs/model/InvControlId;->VOLUME_H:Linv/exe/systemui/qs/model/InvControlId;

    if-eq p1, v4, :cond_28

    sget-object v4, Linv/exe/systemui/qs/model/InvControlId;->BRIGHTNESS_V:Linv/exe/systemui/qs/model/InvControlId;

    if-eq p1, v4, :cond_28

    sget-object v4, Linv/exe/systemui/qs/model/InvControlId;->VOLUME_V:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p1, v4, :cond_2e

    :cond_28
    if-gez v3, :cond_2c

    move v2, v1

    goto :goto_2e

    :cond_2c
    add-int/lit8 v2, v3, 0x1

    :cond_2e
    :goto_2e
    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlColumns()I

    move-result v3

    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlRows()I

    move-result v4

    invoke-virtual {v0, v2, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    invoke-direct {p0, v0, v3, v4}, Linv/exe/systemui/qs/model/InvPanelRepository;->canLayout(Ljava/util/List;II)Z

    move-result v5

    if-eqz v5, :cond_44

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/model/InvPanelRepository;->setControls(Ljava/util/List;)V

    const/4 p0, 0x0

    return-object p0

    :cond_44
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move v5, v1

    :goto_48
    if-ltz v5, :cond_60

    if-eq v5, v2, :cond_5d

    invoke-virtual {v0, v5, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    invoke-direct {p0, v0, v3, v4}, Linv/exe/systemui/qs/model/InvPanelRepository;->canLayout(Ljava/util/List;II)Z

    move-result v1

    if-eqz v1, :cond_5a

    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/model/InvPanelRepository;->setControls(Ljava/util/List;)V

    const/4 p0, 0x0

    return-object p0

    :cond_5a
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_5d
    add-int/lit8 v5, v5, -0x1

    goto :goto_48

    :cond_60
    const-string p0, "control_full"

    return-object p0
.end method

.method public getControlColumns()I
    .registers 4

    iget-object p0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    const-string v0, "ctrl_cols"

    const-string v1, "inv_panel_settings_control_grid_columns_default"

    const/4 v2, 0x4

    invoke-static {v1, v2}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v1

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    const-string v0, "inv_panel_settings_control_grid_columns_min"

    const/4 v1, 0x2

    invoke-static {v0, v1}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v0

    const-string v1, "inv_panel_settings_control_grid_columns_max"

    const/4 v2, 0x4

    invoke-static {v1, v2}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v1

    invoke-static {p0, v0, v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->limit(III)I

    move-result p0

    return p0
.end method

.method public getControlRows()I
    .registers 4

    iget-object p0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    const-string v0, "ctrl_rows"

    const-string v1, "inv_panel_settings_control_grid_rows_default"

    const/4 v2, 0x3

    invoke-static {v1, v2}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v1

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    const-string v0, "inv_panel_settings_control_grid_rows_min"

    const/4 v1, 0x1

    invoke-static {v0, v1}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v0

    const-string v1, "inv_panel_settings_control_grid_rows_max"

    const/4 v2, 0x3

    invoke-static {v1, v2}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v1

    invoke-static {p0, v0, v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->limit(III)I

    move-result p0

    return p0
.end method

.method public getControlSpanH(Linv/exe/systemui/qs/model/InvControlId;)I
    .registers 3

    .line 134
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->MEDIA:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p1, v0, :cond_9

    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getMediaSpanH()I

    move-result p0

    return p0

    :cond_9
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->CUSTOM_IMAGE:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p1, v0, :cond_12

    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getCustomImageSpanH()I

    move-result p0

    return p0

    .line 135
    :cond_12
    iget p0, p1, Linv/exe/systemui/qs/model/InvControlId;->spanH:I

    return p0
.end method

.method public getControlSpanW(Linv/exe/systemui/qs/model/InvControlId;)I
    .registers 3

    .line 129
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->MEDIA:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p1, v0, :cond_9

    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getMediaSpanW()I

    move-result p0

    return p0

    :cond_9
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->CUSTOM_IMAGE:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p1, v0, :cond_12

    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getCustomImageSpanW()I

    move-result p0

    return p0

    .line 130
    :cond_12
    iget p0, p1, Linv/exe/systemui/qs/model/InvControlId;->spanW:I

    return p0
.end method

.method public getControls()Ljava/util/ArrayList;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Linv/exe/systemui/qs/model/InvControlId;",
            ">;"
        }
    .end annotation

    .line 160
    iget-object v0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "controls"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->parse(Ljava/lang/String;Z)Ljava/util/ArrayList;

    move-result-object v0

    .line 161
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1d

    new-instance v0, Ljava/util/ArrayList;

    invoke-static {}, Linv/exe/systemui/qs/model/InvControlId;->defaultOrder()Ljava/util/List;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 162
    :cond_1d
    invoke-direct {p0, v0}, Linv/exe/systemui/qs/model/InvPanelRepository;->fitControls(Ljava/util/List;)Ljava/util/ArrayList;

    move-result-object v1

    .line 163
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-eq v2, v0, :cond_2e

    invoke-virtual {p0, v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->setControls(Ljava/util/List;)V

    :cond_2e
    return-object v1
.end method

.method public getCustomImageSizeIndex()I
    .registers 4

    iget-object v0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "custom_image_size"

    const/4 v2, 0x1

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    if-nez v0, :cond_d

    const/4 v0, 0x1

    goto :goto_16

    :cond_d
    const/4 v1, 0x4

    if-ne v0, v1, :cond_12

    const/4 v0, 0x2

    goto :goto_16

    :cond_12
    const/4 v1, 0x5

    if-ne v0, v1, :cond_16

    const/4 v0, 0x3

    :cond_16
    :goto_16
    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {v0, v1, v2}, Linv/exe/systemui/qs/model/InvPanelRepository;->limit(III)I

    move-result v0

    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlColumns()I

    move-result v1

    :goto_20
    const/4 v2, 0x1

    if-le v0, v2, :cond_2d

    sget-object v2, Linv/exe/systemui/qs/model/InvPanelRepository;->MEDIA_SPAN_W:[I

    aget v2, v2, v0

    if-gt v2, v1, :cond_2a

    goto :goto_2d

    :cond_2a
    add-int/lit8 v0, v0, -0x1

    goto :goto_20

    :cond_2d
    :goto_2d
    return v0
.end method

.method public getCustomImageSpanH()I
    .registers 2

    sget-object v0, Linv/exe/systemui/qs/model/InvPanelRepository;->MEDIA_SPAN_H:[I

    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getCustomImageSizeIndex()I

    move-result p0

    aget p0, v0, p0

    return p0
.end method

.method public getCustomImageSpanW()I
    .registers 2

    sget-object v0, Linv/exe/systemui/qs/model/InvPanelRepository;->MEDIA_SPAN_W:[I

    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getCustomImageSizeIndex()I

    move-result p0

    aget p0, v0, p0

    return p0
.end method

.method public getMediaSizeIndex()I
    .registers 4

    .line 100
    iget-object v0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "media_size"

    const/4 v2, 0x1

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    sget-object v1, Linv/exe/systemui/qs/model/InvPanelRepository;->MEDIA_SPAN_W:[I

    array-length v1, v1

    sub-int/2addr v1, v2

    const/4 v2, 0x0

    invoke-static {v0, v2, v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->limit(III)I

    move-result v0

    .line 101
    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlColumns()I

    move-result v1

    .line 102
    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlRows()I

    move-result p0

    :goto_1a
    if-lez v0, :cond_2c

    .line 103
    sget-object v2, Linv/exe/systemui/qs/model/InvPanelRepository;->MEDIA_SPAN_W:[I

    aget v2, v2, v0

    if-gt v2, v1, :cond_29

    sget-object v2, Linv/exe/systemui/qs/model/InvPanelRepository;->MEDIA_SPAN_H:[I

    aget v2, v2, v0

    if-gt v2, p0, :cond_29

    goto :goto_2c

    :cond_29
    add-int/lit8 v0, v0, -0x1

    goto :goto_1a

    :cond_2c
    :goto_2c
    return v0
.end method

.method public getMediaSizeName()Ljava/lang/String;
    .registers 2

    .line 117
    sget-object v0, Linv/exe/systemui/qs/model/InvPanelRepository;->MEDIA_SIZE_NAMES:[Ljava/lang/String;

    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getMediaSizeIndex()I

    move-result p0

    aget-object p0, v0, p0

    return-object p0
.end method

.method public getMediaSpanH()I
    .registers 2

    .line 125
    sget-object v0, Linv/exe/systemui/qs/model/InvPanelRepository;->MEDIA_SPAN_H:[I

    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getMediaSizeIndex()I

    move-result p0

    aget p0, v0, p0

    return p0
.end method

.method public getMediaSpanW()I
    .registers 2

    .line 121
    sget-object v0, Linv/exe/systemui/qs/model/InvPanelRepository;->MEDIA_SPAN_W:[I

    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getMediaSizeIndex()I

    move-result p0

    aget p0, v0, p0

    return p0
.end method

.method public getShowTileLabels()Z
    .registers 3

    .line 53
    iget-object p0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    const-string v0, "show_labels"

    const/4 v1, 0x0

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p0

    return p0
.end method

.method public getTileColumns()I
    .registers 4

    iget-object p0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    const-string v0, "tile_cols"

    const-string v1, "inv_panel_settings_tile_grid_columns_default"

    const/4 v2, 0x4

    invoke-static {v1, v2}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v1

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    const-string v0, "inv_panel_settings_tile_grid_columns_min"

    const/4 v1, 0x2

    invoke-static {v0, v1}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v0

    const-string v1, "inv_panel_settings_tile_grid_columns_max"

    const/4 v2, 0x4

    invoke-static {v1, v2}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v1

    invoke-static {p0, v0, v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->limit(III)I

    move-result p0

    return p0
.end method

.method public getTileRows()I
    .registers 4

    iget-object p0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    const-string v0, "tile_rows"

    const-string v1, "inv_panel_settings_tile_grid_rows_default"

    const/4 v2, 0x3

    invoke-static {v1, v2}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v1

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    const-string v0, "inv_panel_settings_tile_grid_rows_min"

    const/4 v1, 0x1

    invoke-static {v0, v1}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v0

    const-string v1, "inv_panel_settings_tile_grid_rows_max"

    const/4 v2, 0x5

    invoke-static {v1, v2}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v1

    invoke-static {p0, v0, v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->limit(III)I

    move-result p0

    return p0
.end method

.method public getTiles()Ljava/util/ArrayList;
    .registers 1

    new-instance p0, Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    return-object p0
.end method

.method public maxVisibleTiles()I
    .registers 2

    .line 233
    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getTileColumns()I

    move-result v0

    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getTileRows()I

    move-result p0

    mul-int/2addr v0, p0

    return v0
.end method

.method public moveControl(II)V
    .registers 5

    .line 285
    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControls()Ljava/util/ArrayList;

    move-result-object v0

    if-ltz p1, :cond_21

    .line 286
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p1, v1, :cond_21

    if-ltz p2, :cond_21

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-lt p2, v1, :cond_15

    goto :goto_21

    .line 287
    :cond_15
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {v0, p2, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 288
    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/model/InvPanelRepository;->setControls(Ljava/util/List;)V

    :cond_21
    :goto_21
    return-void
.end method

.method public moveControlToIndex(Linv/exe/systemui/qs/model/InvControlId;I)V
    .registers 5

    .line 219
    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControls()Ljava/util/ArrayList;

    move-result-object v0

    .line 220
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b

    return-void

    .line 221
    :cond_b
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    invoke-static {p2, v1}, Ljava/lang/Math;->min(II)I

    move-result p2

    const/4 v1, 0x0

    invoke-static {v1, p2}, Ljava/lang/Math;->max(II)I

    move-result p2

    invoke-virtual {v0, p2, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 222
    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/model/InvPanelRepository;->setControls(Ljava/util/List;)V

    return-void
.end method

.method public removeControl(Linv/exe/systemui/qs/model/InvControlId;)V
    .registers 4

    .line 257
    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControls()Ljava/util/ArrayList;

    move-result-object v0

    .line 258
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 259
    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/model/InvPanelRepository;->setControls(Ljava/util/List;)V

    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->MEDIA:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p1, v0, :cond_11

    const-string v0, "media_size"

    goto :goto_17

    :cond_11
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->CUSTOM_IMAGE:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p1, v0, :cond_25

    const-string v0, "custom_image_size"

    :goto_17
    iget-object v1, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/4 p1, 0x1

    invoke-interface {v1, v0, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_25
    return-void
.end method

.method public resetDefaults()V
    .registers 1

    .line 364
    iget-object p0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public setControlColumns(I)V
    .registers 6

    iget-object v0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "inv_panel_settings_control_grid_columns_min"

    const/4 v2, 0x2

    invoke-static {v1, v2}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v1

    const-string v2, "inv_panel_settings_control_grid_columns_max"

    const/4 v3, 0x4

    invoke-static {v2, v3}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v2

    invoke-static {p1, v1, v2}, Linv/exe/systemui/qs/model/InvPanelRepository;->limit(III)I

    move-result p1

    const-string v1, "ctrl_cols"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-direct {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->normalizeMediaSizeForGrid()V

    invoke-direct {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->trimControlsToCapacity()V

    return-void
.end method

.method public setControlRows(I)V
    .registers 6

    iget-object v0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "inv_panel_settings_control_grid_rows_min"

    const/4 v2, 0x1

    invoke-static {v1, v2}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v1

    const-string v2, "inv_panel_settings_control_grid_rows_max"

    const/4 v3, 0x3

    invoke-static {v2, v3}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v2

    invoke-static {p1, v1, v2}, Linv/exe/systemui/qs/model/InvPanelRepository;->limit(III)I

    move-result p1

    const-string v1, "ctrl_rows"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-direct {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->normalizeMediaSizeForGrid()V

    invoke-direct {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->trimControlsToCapacity()V

    return-void
.end method

.method public setControls(Ljava/util/List;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Linv/exe/systemui/qs/model/InvControlId;",
            ">;)V"
        }
    .end annotation

    .line 172
    const-string v0, "controls"

    invoke-direct {p0, p1}, Linv/exe/systemui/qs/model/InvPanelRepository;->fitControls(Ljava/util/List;)Ljava/util/ArrayList;

    move-result-object p1

    invoke-direct {p0, v0, p1}, Linv/exe/systemui/qs/model/InvPanelRepository;->save(Ljava/lang/String;Ljava/util/List;)V

    return-void
.end method

.method public setCustomImageSizeIndex(I)V
    .registers 5

    if-nez p1, :cond_4

    const/4 p1, 0x1

    goto :goto_d

    :cond_4
    const/4 v0, 0x4

    if-ne p1, v0, :cond_9

    const/4 p1, 0x2

    goto :goto_d

    :cond_9
    const/4 v0, 0x5

    if-ne p1, v0, :cond_d

    const/4 p1, 0x3

    :cond_d
    :goto_d
    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p1, v0, v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->limit(III)I

    move-result p1

    iget-object v1, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "custom_image_size"

    invoke-interface {v1, v2, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlColumns()I

    move-result v2

    sget-object v0, Linv/exe/systemui/qs/model/InvPanelRepository;->MEDIA_SPAN_W:[I

    aget v0, v0, p1

    if-ge v2, v0, :cond_2e

    const-string v2, "ctrl_cols"

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    :cond_2e
    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlRows()I

    move-result v0

    const/4 v2, 0x2

    if-ge v0, v2, :cond_3a

    const-string v0, "ctrl_rows"

    invoke-interface {v1, v0, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    :cond_3a
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-direct {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->trimControlsToCapacity()V

    return-void
.end method

.method public setMediaSizeIndex(I)V
    .registers 5

    .line 108
    sget-object v0, Linv/exe/systemui/qs/model/InvPanelRepository;->MEDIA_SPAN_W:[I

    array-length v1, v0

    add-int/lit8 v1, v1, -0x1

    const/4 v2, 0x0

    invoke-static {p1, v2, v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->limit(III)I

    move-result p1

    .line 109
    iget-object v1, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "media_size"

    invoke-interface {v1, v2, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    .line 110
    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlColumns()I

    move-result v2

    aget v0, v0, p1

    if-ge v2, v0, :cond_23

    const-string v2, "ctrl_cols"

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 111
    :cond_23
    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlRows()I

    move-result v0

    sget-object v2, Linv/exe/systemui/qs/model/InvPanelRepository;->MEDIA_SPAN_H:[I

    aget p1, v2, p1

    if-ge v0, p1, :cond_32

    const-string v0, "ctrl_rows"

    invoke-interface {v1, v0, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 112
    :cond_32
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 113
    invoke-direct {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->trimControlsToCapacity()V

    return-void
.end method

.method public setShowTileLabels(Z)V
    .registers 3

    .line 57
    iget-object p0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string v0, "show_labels"

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public setTileColumns(I)V
    .registers 6

    iget-object v0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "inv_panel_settings_tile_grid_columns_min"

    const/4 v2, 0x2

    invoke-static {v1, v2}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v1

    const-string v2, "inv_panel_settings_tile_grid_columns_max"

    const/4 v3, 0x4

    invoke-static {v2, v3}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v2

    invoke-static {p1, v1, v2}, Linv/exe/systemui/qs/model/InvPanelRepository;->limit(III)I

    move-result p1

    const-string v1, "tile_cols"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public setTileRows(I)V
    .registers 6

    iget-object v0, p0, Linv/exe/systemui/qs/model/InvPanelRepository;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "inv_panel_settings_tile_grid_rows_min"

    const/4 v2, 0x1

    invoke-static {v1, v2}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v1

    const-string v2, "inv_panel_settings_tile_grid_rows_max"

    const/4 v3, 0x5

    invoke-static {v2, v3}, Linv/exe/systemui/qs/core/InvRes;->integerValue(Ljava/lang/String;I)I

    move-result v2

    invoke-static {p1, v1, v2}, Linv/exe/systemui/qs/model/InvPanelRepository;->limit(III)I

    move-result p1

    const-string v1, "tile_rows"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public swapControlIds(Linv/exe/systemui/qs/model/InvControlId;Linv/exe/systemui/qs/model/InvControlId;)Z
    .registers 6

    .line 199
    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControls()Ljava/util/ArrayList;

    move-result-object v0

    .line 200
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v1

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v2

    if-ltz v1, :cond_1e

    if-ltz v2, :cond_1e

    if-ne v1, v2, :cond_13

    goto :goto_1e

    .line 202
    :cond_13
    invoke-virtual {v0, v1, p2}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 203
    invoke-virtual {v0, v2, p1}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 204
    invoke-virtual {p0, v0}, Linv/exe/systemui/qs/model/InvPanelRepository;->setControls(Ljava/util/List;)V

    const/4 p0, 0x1

    return p0

    :cond_1e
    :goto_1e
    const/4 p0, 0x0

    return p0
.end method

.method public visibleControls()Ljava/util/List;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Linv/exe/systemui/qs/model/InvControlId;",
            ">;"
        }
    .end annotation

    .line 168
    invoke-virtual {p0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControls()Ljava/util/ArrayList;

    move-result-object p0

    return-object p0
.end method

.method public visibleTiles()Ljava/util/List;
    .registers 1

    new-instance p0, Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    return-object p0
.end method
