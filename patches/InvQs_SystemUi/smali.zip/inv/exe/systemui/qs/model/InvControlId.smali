.class public final enum Linv/exe/systemui/qs/model/InvControlId;
.super Ljava/lang/Enum;
.source "ControlId.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Linv/exe/systemui/qs/model/InvControlId;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum AUTO_BRIGHTNESS:Linv/exe/systemui/qs/model/InvControlId;

.field public static final enum BATTERY_VIEW:Linv/exe/systemui/qs/model/InvControlId;

.field public static final enum BLUETOOTH:Linv/exe/systemui/qs/model/InvControlId;

.field public static final enum BRIGHTNESS_H:Linv/exe/systemui/qs/model/InvControlId;

.field public static final enum BRIGHTNESS_V:Linv/exe/systemui/qs/model/InvControlId;

.field public static final enum CUSTOM_IMAGE:Linv/exe/systemui/qs/model/InvControlId;

.field public static final enum CUSTOM_NAME:Linv/exe/systemui/qs/model/InvControlId;

.field public static final enum DATA_USAGE:Linv/exe/systemui/qs/model/InvControlId;

.field private static final synthetic ENUM$VALUES:[Linv/exe/systemui/qs/model/InvControlId;

.field public static final enum FPS_INFO:Linv/exe/systemui/qs/model/InvControlId;

.field public static final enum INTERNET:Linv/exe/systemui/qs/model/InvControlId;

.field public static final enum MEDIA:Linv/exe/systemui/qs/model/InvControlId;

.field public static final enum MUTE:Linv/exe/systemui/qs/model/InvControlId;

.field public static final enum RINGER:Linv/exe/systemui/qs/model/InvControlId;

.field public static final enum VOLUME_H:Linv/exe/systemui/qs/model/InvControlId;

.field public static final enum VOLUME_V:Linv/exe/systemui/qs/model/InvControlId;


# instance fields
.field public final defaultEnabled:Z

.field public final iconRes:I

.field public final labelRes:I

.field public final spanH:I

.field public final spanW:I


# direct methods
.method static constructor <clinit>()V
    .registers 21

    .line 3
    new-instance v0, Linv/exe/systemui/qs/model/InvControlId;

    const/4 v3, 0x0

    const-string v1, "inv_ic_internet"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v4

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string v1, "INTERNET"

    const/4 v2, 0x0

    const/4 v5, 0x2

    invoke-direct/range {v0 .. v7}, Linv/exe/systemui/qs/model/InvControlId;-><init>(Ljava/lang/String;IIIIIZ)V

    sput-object v0, Linv/exe/systemui/qs/model/InvControlId;->INTERNET:Linv/exe/systemui/qs/model/InvControlId;

    new-instance v1, Linv/exe/systemui/qs/model/InvControlId;

    const/4 v4, 0x0

    const-string v2, "inv_ic_bluetooth"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v5

    const/4 v8, 0x1

    const-string v2, "BLUETOOTH"

    const/4 v3, 0x1

    const/4 v6, 0x2

    invoke-direct/range {v1 .. v8}, Linv/exe/systemui/qs/model/InvControlId;-><init>(Ljava/lang/String;IIIIIZ)V

    sput-object v1, Linv/exe/systemui/qs/model/InvControlId;->BLUETOOTH:Linv/exe/systemui/qs/model/InvControlId;

    new-instance v2, Linv/exe/systemui/qs/model/InvControlId;

    const/4 v5, 0x0

    const-string v3, "inv_ic_music"

    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v6

    const/4 v8, 0x2

    const/4 v9, 0x1

    const-string v3, "MEDIA"

    const/4 v4, 0x2

    const/4 v7, 0x2

    invoke-direct/range {v2 .. v9}, Linv/exe/systemui/qs/model/InvControlId;-><init>(Ljava/lang/String;IIIIIZ)V

    sput-object v2, Linv/exe/systemui/qs/model/InvControlId;->MEDIA:Linv/exe/systemui/qs/model/InvControlId;

    new-instance v3, Linv/exe/systemui/qs/model/InvControlId;

    const/4 v6, 0x0

    const-string v11, "inv_ic_brightness"

    invoke-static {v11}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v7

    const/4 v10, 0x0

    const-string v4, "BRIGHTNESS_H"

    const/4 v5, 0x3

    invoke-direct/range {v3 .. v10}, Linv/exe/systemui/qs/model/InvControlId;-><init>(Ljava/lang/String;IIIIIZ)V

    sput-object v3, Linv/exe/systemui/qs/model/InvControlId;->BRIGHTNESS_H:Linv/exe/systemui/qs/model/InvControlId;

    new-instance v4, Linv/exe/systemui/qs/model/InvControlId;

    const/4 v15, 0x0

    const-string v5, "inv_ic_volume"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v16

    const/16 v18, 0x1

    const/16 v19, 0x0

    const-string v13, "VOLUME_H"

    const/4 v14, 0x4

    const/16 v17, 0x2

    move-object v12, v4

    invoke-direct/range {v12 .. v19}, Linv/exe/systemui/qs/model/InvControlId;-><init>(Ljava/lang/String;IIIIIZ)V

    sput-object v4, Linv/exe/systemui/qs/model/InvControlId;->VOLUME_H:Linv/exe/systemui/qs/model/InvControlId;

    new-instance v12, Linv/exe/systemui/qs/model/InvControlId;

    const/4 v15, 0x0

    invoke-static {v11}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v16

    const/16 v18, 0x2

    const/16 v19, 0x1

    const-string v13, "BRIGHTNESS_V"

    const/4 v14, 0x5

    const/16 v17, 0x1

    invoke-direct/range {v12 .. v19}, Linv/exe/systemui/qs/model/InvControlId;-><init>(Ljava/lang/String;IIIIIZ)V

    sput-object v12, Linv/exe/systemui/qs/model/InvControlId;->BRIGHTNESS_V:Linv/exe/systemui/qs/model/InvControlId;

    new-instance v6, Linv/exe/systemui/qs/model/InvControlId;

    const/16 v16, 0x0

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v17

    const/16 v19, 0x2

    const/16 v20, 0x1

    const-string v14, "VOLUME_V"

    const/4 v15, 0x6

    const/16 v18, 0x1

    move-object v13, v6

    invoke-direct/range {v13 .. v20}, Linv/exe/systemui/qs/model/InvControlId;-><init>(Ljava/lang/String;IIIIIZ)V

    sput-object v6, Linv/exe/systemui/qs/model/InvControlId;->VOLUME_V:Linv/exe/systemui/qs/model/InvControlId;

    new-instance v7, Linv/exe/systemui/qs/model/InvControlId;

    const/16 v16, 0x0

    const-string v5, "inv_ic_auto_brightness"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v17

    const/16 v19, 0x1

    const/16 v20, 0x0

    const-string v14, "AUTO_BRIGHTNESS"

    const/4 v15, 0x7

    move-object v13, v7

    invoke-direct/range {v13 .. v20}, Linv/exe/systemui/qs/model/InvControlId;-><init>(Ljava/lang/String;IIIIIZ)V

    sput-object v7, Linv/exe/systemui/qs/model/InvControlId;->AUTO_BRIGHTNESS:Linv/exe/systemui/qs/model/InvControlId;

    new-instance v8, Linv/exe/systemui/qs/model/InvControlId;

    const/16 v16, 0x0

    const-string v5, "inv_ic_volume_off"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v17

    const-string v14, "MUTE"

    const/16 v15, 0x8

    move-object v13, v8

    invoke-direct/range {v13 .. v20}, Linv/exe/systemui/qs/model/InvControlId;-><init>(Ljava/lang/String;IIIIIZ)V

    sput-object v8, Linv/exe/systemui/qs/model/InvControlId;->MUTE:Linv/exe/systemui/qs/model/InvControlId;

    new-instance v9, Linv/exe/systemui/qs/model/InvControlId;

    const/16 v16, 0x0

    const-string v5, "inv_ic_notifications"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v17

    const-string v14, "RINGER"

    const/16 v15, 0x9

    const/16 v18, 0x2

    move-object v13, v9

    invoke-direct/range {v13 .. v20}, Linv/exe/systemui/qs/model/InvControlId;-><init>(Ljava/lang/String;IIIIIZ)V

    sput-object v9, Linv/exe/systemui/qs/model/InvControlId;->RINGER:Linv/exe/systemui/qs/model/InvControlId;

    new-instance v10, Linv/exe/systemui/qs/model/InvControlId;

    const/16 v16, 0x0

    const-string v5, "inv_ic_data_usage"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v17

    const-string v14, "DATA_USAGE"

    const/16 v15, 0xa

    const/16 v18, 0x2

    const/16 v19, 0x1

    const/16 v20, 0x0

    move-object v13, v10

    invoke-direct/range {v13 .. v20}, Linv/exe/systemui/qs/model/InvControlId;-><init>(Ljava/lang/String;IIIIIZ)V

    sput-object v10, Linv/exe/systemui/qs/model/InvControlId;->DATA_USAGE:Linv/exe/systemui/qs/model/InvControlId;

    new-instance v11, Linv/exe/systemui/qs/model/InvControlId;

    const/16 v16, 0x0

    const-string v5, "inv_ic_battery_view"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v17

    const-string v14, "BATTERY_VIEW"

    const/16 v15, 0xb

    const/16 v18, 0x2

    const/16 v19, 0x1

    const/16 v20, 0x0

    move-object v13, v11

    invoke-direct/range {v13 .. v20}, Linv/exe/systemui/qs/model/InvControlId;-><init>(Ljava/lang/String;IIIIIZ)V

    sput-object v11, Linv/exe/systemui/qs/model/InvControlId;->BATTERY_VIEW:Linv/exe/systemui/qs/model/InvControlId;

    new-instance v12, Linv/exe/systemui/qs/model/InvControlId;

    const-string v13, "FPS_INFO"

    const/16 v14, 0xc

    const/4 v15, 0x0

    const-string v16, "inv_ic_fps"

    invoke-static/range {v16 .. v16}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v16

    const/16 v17, 0x2

    const/16 v18, 0x1

    const/16 v19, 0x0

    invoke-direct/range {v12 .. v19}, Linv/exe/systemui/qs/model/InvControlId;-><init>(Ljava/lang/String;IIIIIZ)V

    sput-object v12, Linv/exe/systemui/qs/model/InvControlId;->FPS_INFO:Linv/exe/systemui/qs/model/InvControlId;

    new-instance v12, Linv/exe/systemui/qs/model/InvControlId;

    const-string v13, "CUSTOM_NAME"

    const/16 v14, 0xd

    const/4 v15, 0x0

    const-string v16, "inv_ic_person"

    invoke-static/range {v16 .. v16}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v16

    const/16 v17, 0x2

    const/16 v18, 0x1

    const/16 v19, 0x0

    invoke-direct/range {v12 .. v19}, Linv/exe/systemui/qs/model/InvControlId;-><init>(Ljava/lang/String;IIIIIZ)V

    sput-object v12, Linv/exe/systemui/qs/model/InvControlId;->CUSTOM_NAME:Linv/exe/systemui/qs/model/InvControlId;

    new-instance v12, Linv/exe/systemui/qs/model/InvControlId;

    const-string v13, "CUSTOM_IMAGE"

    const/16 v14, 0xe

    const/4 v15, 0x0

    const-string v16, "inv_ic_image"

    invoke-static/range {v16 .. v16}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v16

    const/16 v17, 0x2

    const/16 v18, 0x1

    const/16 v19, 0x0

    invoke-direct/range {v12 .. v19}, Linv/exe/systemui/qs/model/InvControlId;-><init>(Ljava/lang/String;IIIIIZ)V

    sput-object v12, Linv/exe/systemui/qs/model/InvControlId;->CUSTOM_IMAGE:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->INTERNET:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v1, Linv/exe/systemui/qs/model/InvControlId;->BLUETOOTH:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v2, Linv/exe/systemui/qs/model/InvControlId;->MEDIA:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v3, Linv/exe/systemui/qs/model/InvControlId;->BRIGHTNESS_H:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v4, Linv/exe/systemui/qs/model/InvControlId;->VOLUME_H:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v5, Linv/exe/systemui/qs/model/InvControlId;->BRIGHTNESS_V:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v6, Linv/exe/systemui/qs/model/InvControlId;->VOLUME_V:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v7, Linv/exe/systemui/qs/model/InvControlId;->AUTO_BRIGHTNESS:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v8, Linv/exe/systemui/qs/model/InvControlId;->MUTE:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v9, Linv/exe/systemui/qs/model/InvControlId;->RINGER:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v10, Linv/exe/systemui/qs/model/InvControlId;->DATA_USAGE:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v11, Linv/exe/systemui/qs/model/InvControlId;->BATTERY_VIEW:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v12, Linv/exe/systemui/qs/model/InvControlId;->FPS_INFO:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v13, Linv/exe/systemui/qs/model/InvControlId;->CUSTOM_NAME:Linv/exe/systemui/qs/model/InvControlId;

    sget-object v14, Linv/exe/systemui/qs/model/InvControlId;->CUSTOM_IMAGE:Linv/exe/systemui/qs/model/InvControlId;

    filled-new-array/range {v0 .. v14}, [Linv/exe/systemui/qs/model/InvControlId;

    move-result-object v0

    sput-object v0, Linv/exe/systemui/qs/model/InvControlId;->ENUM$VALUES:[Linv/exe/systemui/qs/model/InvControlId;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;IIIIIZ)V
    .registers 8

    .line 3
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput p3, p0, Linv/exe/systemui/qs/model/InvControlId;->labelRes:I

    iput p4, p0, Linv/exe/systemui/qs/model/InvControlId;->iconRes:I

    iput p5, p0, Linv/exe/systemui/qs/model/InvControlId;->spanW:I

    iput p6, p0, Linv/exe/systemui/qs/model/InvControlId;->spanH:I

    iput-boolean p7, p0, Linv/exe/systemui/qs/model/InvControlId;->defaultEnabled:Z

    return-void
.end method

.method public static all()Ljava/util/List;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Linv/exe/systemui/qs/model/InvControlId;",
            ">;"
        }
    .end annotation

    .line 3
    invoke-static {}, Linv/exe/systemui/qs/model/InvControlId;->values()[Linv/exe/systemui/qs/model/InvControlId;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public static defaultOrder()Ljava/util/List;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Linv/exe/systemui/qs/model/InvControlId;",
            ">;"
        }
    .end annotation

    .line 3
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-static {}, Linv/exe/systemui/qs/model/InvControlId;->values()[Linv/exe/systemui/qs/model/InvControlId;

    move-result-object v1

    array-length v2, v1

    const/4 v3, 0x0

    :goto_b
    if-lt v3, v2, :cond_e

    return-object v0

    :cond_e
    aget-object v4, v1, v3

    iget-boolean v5, v4, Linv/exe/systemui/qs/model/InvControlId;->defaultEnabled:Z

    if-eqz v5, :cond_17

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_17
    add-int/lit8 v3, v3, 0x1

    goto :goto_b
.end method

.method public static fromKey(Ljava/lang/String;)Linv/exe/systemui/qs/model/InvControlId;
    .registers 1

    .line 3
    :try_start_0
    invoke-static {p0}, Linv/exe/systemui/qs/model/InvControlId;->valueOf(Ljava/lang/String;)Linv/exe/systemui/qs/model/InvControlId;

    move-result-object p0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_4} :catch_5

    return-object p0

    :catch_5
    const/4 p0, 0x0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Linv/exe/systemui/qs/model/InvControlId;
    .registers 2

    .line 1
    const-class v0, Linv/exe/systemui/qs/model/InvControlId;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Linv/exe/systemui/qs/model/InvControlId;

    return-object p0
.end method

.method public static values()[Linv/exe/systemui/qs/model/InvControlId;
    .registers 4

    .line 1
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->ENUM$VALUES:[Linv/exe/systemui/qs/model/InvControlId;

    array-length v1, v0

    new-array v2, v1, [Linv/exe/systemui/qs/model/InvControlId;

    const/4 v3, 0x0

    invoke-static {v0, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v2
.end method


# virtual methods
.method public labelText()Ljava/lang/String;
    .registers 2

    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->INTERNET:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_7

    const-string v0, "Internet"

    return-object v0

    :cond_7
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->BLUETOOTH:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_e

    const-string v0, "Bluetooth"

    return-object v0

    :cond_e
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->MEDIA:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_15

    const-string v0, "Media player"

    return-object v0

    :cond_15
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->BRIGHTNESS_H:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_1c

    const-string v0, "Horizontal brightness"

    return-object v0

    :cond_1c
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->VOLUME_H:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_23

    const-string v0, "Horizontal volume"

    return-object v0

    :cond_23
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->BRIGHTNESS_V:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_2a

    const-string v0, "Vertical brightness"

    return-object v0

    :cond_2a
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->VOLUME_V:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_31

    const-string v0, "Vertical volume"

    return-object v0

    :cond_31
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->AUTO_BRIGHTNESS:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_38

    const-string v0, "Auto brightness"

    return-object v0

    :cond_38
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->MUTE:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_3f

    const-string v0, "Mute volume"

    return-object v0

    :cond_3f
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->RINGER:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_46

    const-string v0, "Ringer mode"

    return-object v0

    :cond_46
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->DATA_USAGE:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_4d

    const-string v0, "Data usage"

    return-object v0

    :cond_4d
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->BATTERY_VIEW:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_54

    const-string v0, "Battery"

    return-object v0

    :cond_54
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->FPS_INFO:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_5b

    const-string v0, "FPS info"

    return-object v0

    :cond_5b
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->CUSTOM_NAME:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_62

    const-string v0, "Custom name"

    return-object v0

    :cond_62
    sget-object v0, Linv/exe/systemui/qs/model/InvControlId;->CUSTOM_IMAGE:Linv/exe/systemui/qs/model/InvControlId;

    if-ne p0, v0, :cond_69

    const-string v0, "Custom image"

    return-object v0

    :cond_69
    const-string v0, "Control"

    return-object v0
.end method
