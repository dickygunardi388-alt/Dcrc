.class public final Linv/exe/systemui/qs/drag/InvDragSupport;
.super Ljava/lang/Object;
.source "DragSupport.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;,
        Linv/exe/systemui/qs/drag/InvDragSupport$Session;
    }
.end annotation


# static fields
.field private static final SESSIONS:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Linv/exe/systemui/qs/ui/InvQsPanelView;",
            "Linv/exe/systemui/qs/drag/InvDragSupport$Session;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 26
    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    sput-object v0, Linv/exe/systemui/qs/drag/InvDragSupport;->SESSIONS:Ljava/util/Map;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    .line 36
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static changed(Linv/exe/systemui/qs/ui/InvQsPanelView;)V
    .registers 2

    .line 122
    invoke-static {p0}, Linv/exe/systemui/qs/drag/InvDragSupport;->session(Linv/exe/systemui/qs/ui/InvQsPanelView;)Linv/exe/systemui/qs/drag/InvDragSupport$Session;

    move-result-object p0

    const/4 v0, 0x1

    iput-boolean v0, p0, Linv/exe/systemui/qs/drag/InvDragSupport$Session;->changed:Z

    return-void
.end method

.method public static control(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)V
    .registers 6

    .line 311
    invoke-virtual {p2, p3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 312
    new-instance v0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda3;

    invoke-direct {v0, p2, p3, p0}, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda3;-><init>(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;Linv/exe/systemui/qs/ui/InvQsPanelView;)V

    .line 320
    new-instance v1, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda4;

    invoke-direct {v1, p2, p3, p1, p0}, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda4;-><init>(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;Linv/exe/systemui/qs/model/InvPanelRepository;Linv/exe/systemui/qs/ui/InvQsPanelView;)V

    .line 347
    invoke-static {p2, v0, v1}, Linv/exe/systemui/qs/drag/InvDragSupport;->wire(Landroid/view/View;Landroid/view/View$OnLongClickListener;Landroid/view/View$OnDragListener;)V

    return-void
.end method

.method private static controlId(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)Linv/exe/systemui/qs/model/InvControlId;
    .registers 3

    if-nez p0, :cond_4

    const/4 p0, 0x0

    goto :goto_8

    .line 301
    :cond_4
    invoke-virtual {p0}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object p0

    .line 302
    :goto_8
    instance-of v0, p0, Linv/exe/systemui/qs/model/InvControlId;

    if-eqz v0, :cond_f

    check-cast p0, Linv/exe/systemui/qs/model/InvControlId;

    return-object p0

    :cond_f
    return-object p1
.end method

.method private static emptyControl(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/widget/FrameLayout;IIIIII)V
    .registers 11

    .line 480
    new-instance v0, Landroid/widget/FrameLayout;

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 481
    const-string v1, "inv_bg_grid_empty"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/FrameLayout;->setBackgroundResource(I)V

    mul-int/2addr p8, p3

    add-int/2addr p8, p4

    .line 483
    new-instance v1, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda2;

    invoke-direct {v1, v0, p1, p8, p0}, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda2;-><init>(Landroid/widget/FrameLayout;Linv/exe/systemui/qs/model/InvPanelRepository;ILinv/exe/systemui/qs/ui/InvQsPanelView;)V

    invoke-virtual {v0, v1}, Landroid/widget/FrameLayout;->setOnDragListener(Landroid/view/View$OnDragListener;)V

    .line 509
    new-instance p0, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {p0, p5, p5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    add-int/2addr p6, p5

    mul-int/2addr p4, p6

    .line 510
    iput p4, p0, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    add-int/2addr p5, p7

    mul-int/2addr p3, p5

    .line 511
    iput p3, p0, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    .line 512
    invoke-virtual {p2, v0, p0}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 513
    invoke-static {v0}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->appear(Landroid/view/View;)V

    return-void
.end method

.method private static emptyControls(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/widget/FrameLayout;)V
    .registers 18

    .line 433
    :goto_0
    invoke-virtual/range {p2 .. p2}, Landroid/widget/FrameLayout;->getChildCount()I

    move-result v0

    const/4 v1, 0x1

    if-gt v0, v1, :cond_f4

    .line 434
    invoke-virtual/range {p2 .. p2}, Landroid/widget/FrameLayout;->getWidth()I

    move-result v0

    if-gtz v0, :cond_1f

    .line 435
    invoke-virtual/range {p2 .. p2}, Landroid/widget/FrameLayout;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    instance-of v2, v2, Landroid/view/View;

    if-eqz v2, :cond_1f

    invoke-virtual/range {p2 .. p2}, Landroid/widget/FrameLayout;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v0

    :cond_1f
    const/4 v2, 0x4

    .line 436
    invoke-virtual/range {p1 .. p1}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlColumns()I

    move-result v3

    invoke-static {v2, v3}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/4 v3, 0x2

    invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I

    move-result v8

    const/4 v2, 0x3

    .line 437
    invoke-virtual/range {p1 .. p1}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlRows()I

    move-result v4

    invoke-static {v2, v4}, Ljava/lang/Math;->min(II)I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v9

    .line 438
    const-string v2, "inv_qs_control_grid_item_spacing"

    const-string v4, "inv_qs_control_grid_cell_size"

    if-gtz v0, :cond_5d

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-static {v4}, Linv/exe/systemui/qs/core/InvRes;->dimen(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v0, v5}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v0

    mul-int/2addr v0, v8

    add-int/lit8 v5, v8, -0x1

    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->dimen(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v6, v7}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v6

    mul-int/2addr v5, v6

    add-int/2addr v0, v5

    .line 439
    :cond_5d
    invoke-virtual {p0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->dimen(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v4, v2}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v7

    const/4 v10, 0x0

    if-le v8, v1, :cond_7c

    add-int/lit8 v2, v8, -0x1

    mul-int/2addr v2, v7

    sub-int/2addr v0, v2

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    div-int v5, v0, v8

    invoke-static {v1, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    move v6, v7

    goto :goto_81

    :cond_7c
    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v5

    move v6, v10

    .line 442
    :goto_81
    new-array v0, v3, [I

    aput v8, v0, v1

    aput v9, v0, v10

    sget-object v2, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    invoke-static {v2, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    move-object v11, v0

    check-cast v11, [[Z

    .line 443
    invoke-virtual/range {p1 .. p1}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControls()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_98
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-nez v2, :cond_bd

    move v3, v10

    :goto_9f
    if-lt v3, v9, :cond_a2

    return-void

    :cond_a2
    move v4, v10

    :goto_a3
    if-lt v4, v8, :cond_a8

    add-int/lit8 v3, v3, 0x1

    goto :goto_9f

    .line 460
    :cond_a8
    aget-object v0, v11, v3

    aget-boolean v0, v0, v4

    if-nez v0, :cond_b8

    move-object v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    invoke-static/range {v0 .. v8}, Linv/exe/systemui/qs/drag/InvDragSupport;->emptyControl(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/widget/FrameLayout;IIIIII)V

    move-object v2, v1

    goto :goto_ba

    :cond_b8
    move-object/from16 v2, p1

    :goto_ba
    add-int/lit8 v4, v4, 0x1

    goto :goto_a3

    :cond_bd
    move-object/from16 v2, p1

    .line 443
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Linv/exe/systemui/qs/model/InvControlId;

    .line 444
    invoke-virtual {v2, v3}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlSpanW(Linv/exe/systemui/qs/model/InvControlId;)I

    move-result v4

    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    invoke-static {v8, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    .line 445
    invoke-virtual {v2, v3}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlSpanH(Linv/exe/systemui/qs/model/InvControlId;)I

    move-result v3

    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    move v12, v10

    :goto_da
    sub-int v13, v9, v3

    if-le v12, v13, :cond_df

    goto :goto_98

    :cond_df
    move v13, v10

    :goto_e0
    sub-int v14, v8, v4

    if-le v13, v14, :cond_e7

    add-int/lit8 v12, v12, 0x1

    goto :goto_da

    .line 450
    :cond_e7
    invoke-static {v11, v12, v13, v4, v3}, Linv/exe/systemui/qs/drag/InvDragSupport;->free([[ZIIII)Z

    move-result v14

    if-eqz v14, :cond_f1

    .line 451
    invoke-static {v11, v12, v13, v4, v3}, Linv/exe/systemui/qs/drag/InvDragSupport;->mark([[ZIIII)V

    goto :goto_98

    :cond_f1
    add-int/lit8 v13, v13, 0x1

    goto :goto_e0

    :cond_f4
    move-object/from16 v2, p1

    move-object/from16 v13, p2

    .line 433
    invoke-virtual {v13, v1}, Landroid/widget/FrameLayout;->removeViewAt(I)V

    goto/16 :goto_0
.end method

.method private static findGrid(Landroid/widget/FrameLayout;)Landroid/widget/GridLayout;
    .registers 3

    const/4 v0, 0x0

    .line 74
    :goto_1
    invoke-virtual {p0}, Landroid/widget/FrameLayout;->getChildCount()I

    move-result v1

    if-lt v0, v1, :cond_9

    const/4 p0, 0x0

    return-object p0

    .line 75
    :cond_9
    invoke-virtual {p0, v0}, Landroid/widget/FrameLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    instance-of v1, v1, Landroid/widget/GridLayout;

    if-eqz v1, :cond_18

    invoke-virtual {p0, v0}, Landroid/widget/FrameLayout;->getChildAt(I)Landroid/view/View;

    move-result-object p0

    check-cast p0, Landroid/widget/GridLayout;

    return-object p0

    :cond_18
    add-int/lit8 v0, v0, 0x1

    goto :goto_1
.end method

.method private static finish(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;)V
    .registers 10

    .line 125
    invoke-static {p0}, Linv/exe/systemui/qs/drag/InvDragSupport;->session(Linv/exe/systemui/qs/ui/InvQsPanelView;)Linv/exe/systemui/qs/drag/InvDragSupport$Session;

    move-result-object v0

    .line 126
    iget-boolean v1, v0, Linv/exe/systemui/qs/drag/InvDragSupport$Session;->active:Z

    if-nez v1, :cond_9

    goto :goto_44

    :cond_9
    const/4 v1, 0x0

    .line 127
    iput-boolean v1, v0, Linv/exe/systemui/qs/drag/InvDragSupport$Session;->active:Z

    .line 128
    iget-object v4, v0, Linv/exe/systemui/qs/drag/InvDragSupport$Session;->source:Landroid/view/View;

    .line 129
    iget-object v5, v0, Linv/exe/systemui/qs/drag/InvDragSupport$Session;->target:Landroid/view/View;

    .line 130
    iget-boolean v1, v0, Linv/exe/systemui/qs/drag/InvDragSupport$Session;->changed:Z

    .line 131
    iget-boolean v3, v0, Linv/exe/systemui/qs/drag/InvDragSupport$Session;->tile:Z

    const/4 v2, 0x0

    .line 132
    iput-object v2, v0, Linv/exe/systemui/qs/drag/InvDragSupport$Session;->source:Landroid/view/View;

    .line 133
    iput-object v2, v0, Linv/exe/systemui/qs/drag/InvDragSupport$Session;->target:Landroid/view/View;

    if-eqz v4, :cond_42

    .line 136
    invoke-virtual {v4}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->cancel()V

    .line 137
    invoke-virtual {v4}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/high16 v2, 0x3f800000  # 1.0f

    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->translationZ(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const-wide/16 v6, 0xdc

    invoke-virtual {v0, v6, v7}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    :cond_42
    if-nez v1, :cond_45

    :goto_44
    return-void

    .line 141
    :cond_45
    new-instance v2, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda1;

    move-object v6, p0

    move-object v7, p1

    invoke-direct/range {v2 .. v7}, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda1;-><init>(ZLandroid/view/View;Landroid/view/View;Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;)V

    invoke-virtual {v6, v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private static free([[ZIIII)Z
    .registers 8

    move v0, p1

    :goto_1
    add-int v1, p1, p4

    if-lt v0, v1, :cond_7

    const/4 p0, 0x1

    return p0

    :cond_7
    move v1, p2

    :goto_8
    add-int v2, p2, p3

    if-lt v1, v2, :cond_f

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 467
    :cond_f
    aget-object v2, p0, v0

    aget-boolean v2, v2, v1

    if-eqz v2, :cond_17

    const/4 p0, 0x0

    return p0

    :cond_17
    add-int/lit8 v1, v1, 0x1

    goto :goto_8
.end method

.method private static hover(Landroid/view/View;Z)V
    .registers 5

    .line 117
    invoke-static {p0}, Linv/exe/systemui/qs/drag/InvNativeDragVisual;->unclipParents(Landroid/view/View;)V

    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->cancel()V

    .line 118
    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const v0, 0x3f847ae1  # 1.035f

    const/high16 v1, 0x3f800000  # 1.0f

    if-eqz p1, :cond_17

    move v2, v0

    goto :goto_18

    :cond_17
    move v2, v1

    :goto_18
    invoke-virtual {p0, v2}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    if-eqz p1, :cond_1f

    goto :goto_20

    :cond_1f
    move v0, v1

    :goto_20
    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    if-eqz p1, :cond_28

    const/high16 v1, 0x3f800000  # 1.0f

    .line 119
    :cond_28
    invoke-virtual {p0, v1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const-wide/16 v0, 0x96

    invoke-virtual {p0, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/ViewPropertyAnimator;->start()V

    return-void
.end method

.method public static synthetic lambda$1(ZLandroid/view/View;Landroid/view/View;Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;)V
    .registers 5

    if-eqz p0, :cond_a

    if-eqz p1, :cond_a

    if-eqz p2, :cond_a

    .line 143
    invoke-static {p1, p2}, Linv/exe/systemui/qs/drag/InvDragSupport;->swapViews(Landroid/view/View;Landroid/view/View;)V

    goto :goto_19

    :cond_a
    if-nez p0, :cond_16

    .line 145
    invoke-static {p3, p4}, Linv/exe/systemui/qs/drag/InvDragSupport;->relayoutControls(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;)Z

    move-result p0

    if-nez p0, :cond_19

    invoke-virtual {p3}, Linv/exe/systemui/qs/ui/InvQsPanelView;->rebuild()V

    goto :goto_19

    .line 147
    :cond_16
    invoke-virtual {p3}, Linv/exe/systemui/qs/ui/InvQsPanelView;->rebuild()V

    .line 149
    :cond_19
    :goto_19
    return-void
.end method

.method public static synthetic lambda$2(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;Linv/exe/systemui/qs/ui/InvQsPanelView;Landroid/view/View;)Z
    .registers 5

    .line 313
    invoke-static {p0, p1}, Linv/exe/systemui/qs/drag/InvDragSupport;->controlId(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)Linv/exe/systemui/qs/model/InvControlId;

    move-result-object p1

    const/4 p3, 0x0

    if-nez p1, :cond_8

    return p3

    .line 315
    :cond_8
    invoke-static {p2, p0, p3}, Linv/exe/systemui/qs/drag/InvDragSupport;->lift(Linv/exe/systemui/qs/ui/InvQsPanelView;Landroid/view/View;Z)V

    invoke-static {p0}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->lockMediaArtClipForEditHold(Landroid/view/View;)V

    .line 316
    const-string p2, "control"

    invoke-virtual {p1}, Linv/exe/systemui/qs/model/InvControlId;->name()Ljava/lang/String;

    move-result-object v0

    invoke-static {p2, v0}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object p2

    .line 317
    new-instance v0, Landroid/view/View$DragShadowBuilder;

    invoke-direct {v0, p0}, Landroid/view/View$DragShadowBuilder;-><init>(Landroid/view/View;)V

    .line 316
    invoke-virtual {p0, p2, v0, p1, p3}, Landroid/view/View;->startDragAndDrop(Landroid/content/ClipData;Landroid/view/View$DragShadowBuilder;Ljava/lang/Object;I)Z

    const/4 p0, 0x1

    return p0
.end method

.method public static synthetic lambda$3(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;Linv/exe/systemui/qs/model/InvPanelRepository;Linv/exe/systemui/qs/ui/InvQsPanelView;Landroid/view/View;Landroid/view/DragEvent;)Z
    .registers 10

    .line 321
    invoke-virtual {p5}, Landroid/view/DragEvent;->getLocalState()Ljava/lang/Object;

    move-result-object p4

    instance-of p4, p4, Linv/exe/systemui/qs/model/InvControlId;

    const/4 v0, 0x0

    if-nez p4, :cond_a

    return v0

    .line 322
    :cond_a
    invoke-virtual {p5}, Landroid/view/DragEvent;->getLocalState()Ljava/lang/Object;

    move-result-object p4

    check-cast p4, Linv/exe/systemui/qs/model/InvControlId;

    .line 323
    invoke-static {p0, p1}, Linv/exe/systemui/qs/drag/InvDragSupport;->controlId(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;)Linv/exe/systemui/qs/model/InvControlId;

    move-result-object p1

    .line 324
    invoke-virtual {p5}, Landroid/view/DragEvent;->getAction()I

    move-result p5

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eq p5, v1, :cond_39

    const/4 v1, 0x4

    if-eq p5, v1, :cond_32

    const/4 v3, 0x5

    if-eq p5, v3, :cond_2a

    const/4 p1, 0x6

    if-eq p5, p1, :cond_26

    return v2

    .line 329
    :cond_26
    invoke-static {p0, v0}, Linv/exe/systemui/qs/drag/InvDragSupport;->hover(Landroid/view/View;Z)V

    return v2

    :cond_2a
    if-eqz p1, :cond_31

    if-eq p4, p1, :cond_31

    .line 326
    invoke-static {p0, v2}, Linv/exe/systemui/qs/drag/InvDragSupport;->hover(Landroid/view/View;Z)V

    :cond_31
    return v2

    .line 340
    :cond_32
    invoke-static {p0, v0}, Linv/exe/systemui/qs/drag/InvDragSupport;->hover(Landroid/view/View;Z)V

    .line 341
    invoke-static {p3, p2}, Linv/exe/systemui/qs/drag/InvDragSupport;->finish(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;)V

    return v2

    .line 332
    :cond_39
    invoke-static {p0, v0}, Linv/exe/systemui/qs/drag/InvDragSupport;->hover(Landroid/view/View;Z)V

    if-eqz p1, :cond_4f

    if-eq p4, p1, :cond_4f

    invoke-virtual {p2, p4, p1}, Linv/exe/systemui/qs/model/InvPanelRepository;->swapControlIds(Linv/exe/systemui/qs/model/InvControlId;Linv/exe/systemui/qs/model/InvControlId;)Z

    move-result v1

    if-eqz v1, :cond_4f

    invoke-static {p3}, Linv/exe/systemui/qs/drag/InvDragSupport;->session(Linv/exe/systemui/qs/ui/InvQsPanelView;)Linv/exe/systemui/qs/drag/InvDragSupport$Session;

    move-result-object v3

    iput-object p0, v3, Linv/exe/systemui/qs/drag/InvDragSupport$Session;->target:Landroid/view/View;

    invoke-static {p3}, Linv/exe/systemui/qs/drag/InvDragSupport;->changed(Linv/exe/systemui/qs/ui/InvQsPanelView;)V

    :cond_4f
    return v2
.end method

.method public static synthetic lambda$4(Landroid/widget/FrameLayout;Linv/exe/systemui/qs/model/InvPanelRepository;ILinv/exe/systemui/qs/ui/InvQsPanelView;Landroid/view/View;Landroid/view/DragEvent;)Z
    .registers 12

    .line 484
    invoke-virtual {p5}, Landroid/view/DragEvent;->getLocalState()Ljava/lang/Object;

    move-result-object v0

    instance-of v5, v0, Linv/exe/systemui/qs/model/InvControlId;

    const/4 v1, 0x0

    if-nez v5, :cond_a

    return v1

    :cond_a
    invoke-virtual {p5}, Landroid/view/DragEvent;->getAction()I

    move-result v0

    const-string v3, "inv_bg_grid_empty"

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eq v0, v5, :cond_53

    const/4 v5, 0x4

    if-eq v0, v5, :cond_45

    const/4 v5, 0x5

    if-eq v0, v5, :cond_29

    const/4 v5, 0x6

    if-eq v0, v5, :cond_1e

    return v4

    :cond_1e
    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {p0, v5}, Landroid/widget/FrameLayout;->setBackgroundResource(I)V

    invoke-static {p4, v1}, Linv/exe/systemui/qs/drag/InvDragSupport;->hover(Landroid/view/View;Z)V

    return v4

    :cond_29
    const-string v5, "inv_bg_grid_empty_active"

    invoke-static {v5}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {p0, v5}, Landroid/widget/FrameLayout;->setBackgroundResource(I)V

    invoke-static {p4, v4}, Linv/exe/systemui/qs/drag/InvDragSupport;->hover(Landroid/view/View;Z)V

    invoke-virtual {p5}, Landroid/view/DragEvent;->getLocalState()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Linv/exe/systemui/qs/model/InvControlId;

    invoke-virtual {p1, v5, p2}, Linv/exe/systemui/qs/model/InvPanelRepository;->moveControlToIndex(Linv/exe/systemui/qs/model/InvControlId;I)V

    invoke-static {p3, p1}, Linv/exe/systemui/qs/drag/InvDragSupport;->relayoutControls(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;)Z

    invoke-static {p3}, Linv/exe/systemui/qs/drag/InvDragSupport;->changed(Linv/exe/systemui/qs/ui/InvQsPanelView;)V

    return v4

    :cond_45
    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {p0, v5}, Landroid/widget/FrameLayout;->setBackgroundResource(I)V

    invoke-static {p4, v1}, Linv/exe/systemui/qs/drag/InvDragSupport;->hover(Landroid/view/View;Z)V

    invoke-static {p3, p1}, Linv/exe/systemui/qs/drag/InvDragSupport;->finish(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;)V

    return v4

    :cond_53
    invoke-static {v3}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {p0, v5}, Landroid/widget/FrameLayout;->setBackgroundResource(I)V

    invoke-static {p4, v1}, Linv/exe/systemui/qs/drag/InvDragSupport;->hover(Landroid/view/View;Z)V

    invoke-static {p3}, Linv/exe/systemui/qs/drag/InvDragSupport;->changed(Linv/exe/systemui/qs/ui/InvQsPanelView;)V

    return v4
.end method

.method private static lift(Linv/exe/systemui/qs/ui/InvQsPanelView;Landroid/view/View;Z)V
    .registers 4

    .line 99
    invoke-static {p0}, Linv/exe/systemui/qs/drag/InvDragSupport;->session(Linv/exe/systemui/qs/ui/InvQsPanelView;)Linv/exe/systemui/qs/drag/InvDragSupport$Session;

    move-result-object p0

    const/4 v0, 0x1

    .line 100
    iput-boolean v0, p0, Linv/exe/systemui/qs/drag/InvDragSupport$Session;->active:Z

    const/4 v0, 0x0

    .line 101
    iput-boolean v0, p0, Linv/exe/systemui/qs/drag/InvDragSupport$Session;->changed:Z

    .line 102
    iput-boolean p2, p0, Linv/exe/systemui/qs/drag/InvDragSupport$Session;->tile:Z

    .line 103
    iput-object p1, p0, Linv/exe/systemui/qs/drag/InvDragSupport$Session;->source:Landroid/view/View;

    const/4 p2, 0x0

    .line 104
    iput-object p2, p0, Linv/exe/systemui/qs/drag/InvDragSupport$Session;->target:Landroid/view/View;

    invoke-static {p1}, Linv/exe/systemui/qs/drag/InvNativeDragVisual;->unclipParents(Landroid/view/View;)V

    invoke-static {p1}, Linv/exe/systemui/qs/ui/InvMediaViewRenderer;->lockMediaArtClipForEditHold(Landroid/view/View;)V

    .line 105
    invoke-virtual {p1, v0}, Landroid/view/View;->performHapticFeedback(I)Z

    .line 106
    invoke-virtual {p1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/ViewPropertyAnimator;->cancel()V

    .line 107
    invoke-virtual {p1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const p1, 0x3f851eb8  # 1.04f

    .line 108
    invoke-virtual {p0, p1}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    .line 109
    invoke-virtual {p0, p1}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const/high16 p1, 0x3f800000  # 1.0f

    .line 110
    invoke-virtual {p0, p1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const/4 p1, 0x0

    .line 111
    invoke-virtual {p0, p1}, Landroid/view/ViewPropertyAnimator;->translationZ(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const-wide/16 p1, 0x78

    .line 112
    invoke-virtual {p0, p1, p2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    .line 113
    invoke-virtual {p0}, Landroid/view/ViewPropertyAnimator;->start()V

    return-void
.end method

.method private static mark([[ZIIII)V
    .registers 9

    move v0, p1

    :goto_1
    add-int v1, p1, p4

    if-lt v0, v1, :cond_6

    return-void

    :cond_6
    move v1, p2

    :goto_7
    add-int v2, p2, p3

    if-lt v1, v2, :cond_e

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 474
    :cond_e
    aget-object v2, p0, v0

    const/4 v3, 0x1

    aput-boolean v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_7
.end method

.method private static relayoutControls(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;)Z
    .registers 30

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 154
    const-string v2, "controls_host"

    invoke-static {v2}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Linv/exe/systemui/qs/ui/InvQsPanelView;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout;

    .line 155
    invoke-virtual {v2}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_23d

    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    instance-of v3, v3, Landroid/widget/FrameLayout;

    if-nez v3, :cond_21

    goto/16 :goto_23d

    .line 156
    :cond_21
    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/FrameLayout;

    .line 157
    invoke-static {v3}, Linv/exe/systemui/qs/drag/InvDragSupport;->findGrid(Landroid/widget/FrameLayout;)Landroid/widget/GridLayout;

    move-result-object v5

    if-nez v5, :cond_2e

    return v4

    .line 160
    :cond_2e
    new-instance v6, Ljava/util/HashMap;

    invoke-direct {v6}, Ljava/util/HashMap;-><init>()V

    move v7, v4

    .line 161
    :goto_34
    invoke-virtual {v5}, Landroid/widget/GridLayout;->getChildCount()I

    move-result v8

    if-lt v7, v8, :cond_21e

    .line 167
    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControls()Ljava/util/ArrayList;

    move-result-object v8

    .line 168
    invoke-interface {v6}, Ljava/util/Map;->size()I

    move-result v7

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v9

    if-ge v7, v9, :cond_49

    return v4

    .line 169
    :cond_49
    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_4d
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-nez v7, :cond_205

    .line 171
    invoke-virtual {v2}, Landroid/widget/LinearLayout;->getWidth()I

    move-result v2

    const/4 v7, 0x4

    .line 172
    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlColumns()I

    move-result v9

    invoke-static {v7, v9}, Ljava/lang/Math;->min(II)I

    move-result v7

    const/4 v9, 0x2

    invoke-static {v9, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    const/4 v10, 0x3

    .line 173
    invoke-virtual {v1}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlRows()I

    move-result v11

    invoke-static {v10, v11}, Ljava/lang/Math;->min(II)I

    move-result v10

    const/4 v11, 0x1

    invoke-static {v11, v10}, Ljava/lang/Math;->max(II)I

    move-result v10

    .line 174
    invoke-virtual {v0}, Linv/exe/systemui/qs/ui/InvQsPanelView;->getResources()Landroid/content/res/Resources;

    move-result-object v13

    const-string v14, "inv_qs_control_grid_item_spacing"

    invoke-static {v14}, Linv/exe/systemui/qs/core/InvRes;->dimen(Ljava/lang/String;)I

    move-result v14

    invoke-virtual {v13, v14}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v13

    if-le v7, v11, :cond_93

    add-int/lit8 v14, v7, -0x1

    mul-int/2addr v14, v13

    sub-int/2addr v2, v14

    invoke-static {v11, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    div-int v12, v2, v7

    invoke-static {v11, v12}, Ljava/lang/Math;->max(II)I

    move-result v12

    move v14, v13

    goto :goto_98

    :cond_93
    invoke-static {v11, v2}, Ljava/lang/Math;->max(II)I

    move-result v12

    move v14, v4

    .line 177
    :goto_98
    new-array v2, v9, [I

    aput v7, v2, v11

    aput v10, v2, v4

    sget-object v9, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    invoke-static {v9, v2}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v2

    move-object v15, v2

    check-cast v15, [[Z

    .line 178
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 180
    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :goto_b0
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-nez v8, :cond_198

    .line 199
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_ba
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-nez v9, :cond_179

    .line 200
    new-array v8, v11, [Landroid/view/ViewGroup;

    aput-object v5, v8, v4

    invoke-static {v8}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->capture([Landroid/view/ViewGroup;)Ljava/util/Map;

    move-result-object v9

    invoke-static {v5}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->beginSmoothBounds(Landroid/view/ViewGroup;)Z

    .line 201
    invoke-virtual {v5}, Landroid/widget/GridLayout;->removeAllViews()V

    .line 202
    invoke-virtual {v5, v7}, Landroid/widget/GridLayout;->setColumnCount(I)V

    .line 203
    invoke-virtual {v5, v10}, Landroid/widget/GridLayout;->setRowCount(I)V

    .line 205
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_d8
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-nez v2, :cond_eb

    .line 225
    invoke-static {v0, v1, v3}, Linv/exe/systemui/qs/drag/InvDragSupport;->emptyControls(Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;Landroid/widget/FrameLayout;)V

    .line 226
    invoke-virtual {v5}, Landroid/widget/GridLayout;->requestLayout()V

    invoke-virtual {v3}, Landroid/widget/FrameLayout;->requestLayout()V

    invoke-static {v5, v9}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->play(Landroid/view/View;Ljava/util/Map;)V

    return v11

    .line 205
    :cond_eb
    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;

    .line 206
    iget-object v8, v2, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->id:Linv/exe/systemui/qs/model/InvControlId;

    invoke-interface {v6, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/view/View;

    move/from16 v17, v4

    .line 207
    iget v4, v2, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->w:I

    mul-int/2addr v4, v12

    move/from16 v18, v11

    iget v11, v2, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->w:I

    add-int/lit8 v11, v11, -0x1

    mul-int/2addr v11, v14

    add-int/2addr v4, v11

    .line 208
    iget v11, v2, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->h:I

    mul-int/2addr v11, v12

    iget v0, v2, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->h:I

    add-int/lit8 v0, v0, -0x1

    mul-int/2addr v0, v13

    add-int/2addr v11, v0

    .line 209
    new-instance v0, Landroid/widget/GridLayout$LayoutParams;

    move-object/from16 v19, v3

    .line 210
    iget v3, v2, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->r:I

    move-object/from16 v16, v9

    iget v9, v2, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->h:I

    move/from16 v20, v12

    sget-object v12, Landroid/widget/GridLayout;->FILL:Landroid/widget/GridLayout$Alignment;

    invoke-static {v3, v9, v12}, Landroid/widget/GridLayout;->spec(IILandroid/widget/GridLayout$Alignment;)Landroid/widget/GridLayout$Spec;

    move-result-object v3

    .line 211
    iget v9, v2, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->c:I

    iget v12, v2, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->w:I

    move/from16 v21, v13

    sget-object v13, Landroid/widget/GridLayout;->FILL:Landroid/widget/GridLayout$Alignment;

    invoke-static {v9, v12, v13}, Landroid/widget/GridLayout;->spec(IILandroid/widget/GridLayout$Alignment;)Landroid/widget/GridLayout$Spec;

    move-result-object v9

    .line 209
    invoke-direct {v0, v3, v9}, Landroid/widget/GridLayout$LayoutParams;-><init>(Landroid/widget/GridLayout$Spec;Landroid/widget/GridLayout$Spec;)V

    .line 212
    iput v4, v0, Landroid/widget/GridLayout$LayoutParams;->width:I

    .line 213
    iput v11, v0, Landroid/widget/GridLayout$LayoutParams;->height:I

    .line 214
    iget v3, v2, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->c:I

    iget v4, v2, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->w:I

    add-int/2addr v3, v4

    if-ge v3, v7, :cond_13d

    move v3, v14

    goto :goto_13f

    :cond_13d
    move/from16 v3, v17

    :goto_13f
    iput v3, v0, Landroid/widget/GridLayout$LayoutParams;->rightMargin:I

    .line 215
    iget v3, v2, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->r:I

    iget v2, v2, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->h:I

    add-int/2addr v3, v2

    if-ge v3, v10, :cond_14b

    move/from16 v2, v21

    goto :goto_14d

    :cond_14b
    move/from16 v2, v17

    :goto_14d
    iput v2, v0, Landroid/widget/GridLayout$LayoutParams;->bottomMargin:I

    const/16 v2, 0x77

    .line 216
    invoke-virtual {v0, v2}, Landroid/widget/GridLayout$LayoutParams;->setGravity(I)V

    .line 217
    invoke-virtual {v8, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/high16 v0, 0x3f800000  # 1.0f

    .line 218
    invoke-virtual {v8, v0}, Landroid/view/View;->setAlpha(F)V

    .line 219
    invoke-virtual {v8, v0}, Landroid/view/View;->setScaleX(F)V

    .line 220
    invoke-virtual {v8, v0}, Landroid/view/View;->setScaleY(F)V

    const/4 v0, 0x0

    .line 221
    invoke-virtual {v8, v0}, Landroid/view/View;->setTranslationZ(F)V

    .line 222
    invoke-virtual {v5, v8}, Landroid/widget/GridLayout;->addView(Landroid/view/View;)V

    move-object/from16 v0, p0

    move-object/from16 v9, v16

    move/from16 v4, v17

    move/from16 v11, v18

    move-object/from16 v3, v19

    move/from16 v12, v20

    move/from16 v13, v21

    goto/16 :goto_d8

    :cond_179
    move-object/from16 v19, v3

    move/from16 v17, v4

    move/from16 v18, v11

    move/from16 v20, v12

    move/from16 v21, v13

    .line 199
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;

    iget v3, v0, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->r:I

    iget v0, v0, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->h:I

    add-int/2addr v3, v0

    invoke-static {v10, v3}, Ljava/lang/Math;->max(II)I

    move-result v10

    move-object/from16 v0, p0

    move-object/from16 v3, v19

    goto/16 :goto_ba

    :cond_198
    move-object/from16 v19, v3

    move/from16 v17, v4

    move/from16 v18, v11

    move/from16 v20, v12

    move/from16 v21, v13

    .line 180
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Linv/exe/systemui/qs/model/InvControlId;

    .line 181
    invoke-virtual {v1, v0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlSpanW(Linv/exe/systemui/qs/model/InvControlId;)I

    move-result v3

    invoke-static {v7, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    move/from16 v4, v18

    invoke-static {v4, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    .line 182
    invoke-virtual {v1, v0}, Linv/exe/systemui/qs/model/InvPanelRepository;->getControlSpanH(Linv/exe/systemui/qs/model/InvControlId;)I

    move-result v8

    invoke-static {v4, v8}, Ljava/lang/Math;->max(II)I

    move-result v8

    move/from16 v9, v17

    :goto_1c0
    sub-int v11, v10, v8

    if-le v9, v11, :cond_1c5

    return v17

    :cond_1c5
    move/from16 v11, v17

    :goto_1c7
    sub-int v12, v7, v3

    if-le v11, v12, :cond_1ce

    add-int/lit8 v9, v9, 0x1

    goto :goto_1c0

    .line 187
    :cond_1ce
    invoke-static {v15, v9, v11, v3, v8}, Linv/exe/systemui/qs/drag/InvDragSupport;->free([[ZIIII)Z

    move-result v12

    if-eqz v12, :cond_1f8

    .line 188
    invoke-static {v15, v9, v11, v3, v8}, Linv/exe/systemui/qs/drag/InvDragSupport;->mark([[ZIIII)V

    .line 189
    new-instance v22, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;

    move-object/from16 v23, v0

    move/from16 v26, v3

    move/from16 v27, v8

    move/from16 v24, v9

    move/from16 v25, v11

    invoke-direct/range {v22 .. v27}, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;-><init>(Linv/exe/systemui/qs/model/InvControlId;IIII)V

    move-object/from16 v0, v22

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object/from16 v0, p0

    move v11, v4

    move/from16 v4, v17

    move-object/from16 v3, v19

    move/from16 v12, v20

    move/from16 v13, v21

    goto/16 :goto_b0

    :cond_1f8
    move-object/from16 v23, v0

    move/from16 v26, v3

    move/from16 v27, v8

    move/from16 v24, v9

    move/from16 v25, v11

    add-int/lit8 v11, v25, 0x1

    goto :goto_1c7

    :cond_205
    move-object/from16 v19, v3

    move/from16 v17, v4

    .line 169
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Linv/exe/systemui/qs/model/InvControlId;

    invoke-interface {v6, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_216

    return v17

    :cond_216
    move-object/from16 v0, p0

    move/from16 v4, v17

    move-object/from16 v3, v19

    goto/16 :goto_4d

    :cond_21e
    move-object/from16 v19, v3

    move/from16 v17, v4

    .line 162
    invoke-virtual {v5, v7}, Landroid/widget/GridLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    .line 163
    invoke-virtual {v0}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v3

    .line 164
    instance-of v4, v3, Linv/exe/systemui/qs/model/InvControlId;

    if-eqz v4, :cond_233

    check-cast v3, Linv/exe/systemui/qs/model/InvControlId;

    invoke-interface {v6, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_233
    add-int/lit8 v7, v7, 0x1

    move-object/from16 v0, p0

    move/from16 v4, v17

    move-object/from16 v3, v19

    goto/16 :goto_34

    :cond_23d
    :goto_23d
    move/from16 v17, v4

    return v17
.end method

.method private static resetDragVisual(Landroid/view/View;)V
    .registers 2

    if-nez p0, :cond_3

    return-void

    .line 291
    :cond_3
    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->cancel()V

    const/high16 v0, 0x3f800000  # 1.0f

    .line 292
    invoke-virtual {p0, v0}, Landroid/view/View;->setAlpha(F)V

    .line 293
    invoke-virtual {p0, v0}, Landroid/view/View;->setScaleX(F)V

    .line 294
    invoke-virtual {p0, v0}, Landroid/view/View;->setScaleY(F)V

    const/4 v0, 0x0

    .line 295
    invoke-virtual {p0, v0}, Landroid/view/View;->setTranslationX(F)V

    .line 296
    invoke-virtual {p0, v0}, Landroid/view/View;->setTranslationY(F)V

    .line 297
    invoke-virtual {p0, v0}, Landroid/view/View;->setTranslationZ(F)V

    return-void
.end method

.method private static session(Linv/exe/systemui/qs/ui/InvQsPanelView;)Linv/exe/systemui/qs/drag/InvDragSupport$Session;
    .registers 4

    .line 90
    sget-object v0, Linv/exe/systemui/qs/drag/InvDragSupport;->SESSIONS:Ljava/util/Map;

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Linv/exe/systemui/qs/drag/InvDragSupport$Session;

    if-nez v1, :cond_13

    .line 92
    new-instance v1, Linv/exe/systemui/qs/drag/InvDragSupport$Session;

    const/4 v2, 0x0

    invoke-direct {v1, v2}, Linv/exe/systemui/qs/drag/InvDragSupport$Session;-><init>(Linv/exe/systemui/qs/drag/InvDragSupport$Session;)V

    .line 93
    invoke-interface {v0, p0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_13
    return-object v1
.end method

.method public static swapViews(Landroid/view/View;Landroid/view/View;)V
    .registers 14

    if-eqz p0, :cond_b3

    if-eqz p1, :cond_b3

    if-ne p0, p1, :cond_8

    goto/16 :goto_b3

    .line 244
    :cond_8
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v0, v0, Landroid/view/ViewGroup;

    const/4 v1, 0x0

    if-eqz v0, :cond_18

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    goto :goto_19

    :cond_18
    move-object v0, v1

    .line 245
    :goto_19
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    instance-of v2, v2, Landroid/view/ViewGroup;

    if-eqz v2, :cond_27

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    :cond_27
    if-eqz v0, :cond_b3

    if-nez v1, :cond_2d

    goto/16 :goto_b3

    .line 248
    :cond_2d
    invoke-virtual {v0, p0}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v2

    .line 249
    invoke-virtual {v1, p1}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v3

    if-ltz v2, :cond_b3

    if-gez v3, :cond_3a

    goto :goto_b3

    .line 252
    :cond_3a
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    .line 253
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    .line 254
    invoke-virtual {p0}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v6

    .line 255
    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v7

    .line 257
    invoke-static {p0}, Linv/exe/systemui/qs/drag/InvDragSupport;->resetDragVisual(Landroid/view/View;)V

    .line 258
    invoke-static {p1}, Linv/exe/systemui/qs/drag/InvDragSupport;->resetDragVisual(Landroid/view/View;)V

    const/4 v8, 0x0

    .line 259
    invoke-virtual {v0, v8}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    .line 260
    invoke-virtual {v0, v8}, Landroid/view/ViewGroup;->setClipToPadding(Z)V

    .line 261
    invoke-virtual {v1, v8}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    .line 262
    invoke-virtual {v1, v8}, Landroid/view/ViewGroup;->setClipToPadding(Z)V

    const/4 v10, 0x2

    new-array v10, v10, [Landroid/view/ViewGroup;

    aput-object v0, v10, v8

    const/4 v11, 0x1

    aput-object v1, v10, v11

    invoke-static {v10}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->capture([Landroid/view/ViewGroup;)Ljava/util/Map;

    move-result-object v9

    if-ne v0, v1, :cond_89

    .line 267
    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    move-result v10

    invoke-virtual {v0, v10}, Landroid/view/ViewGroup;->removeViewAt(I)V

    .line 268
    invoke-static {v2, v3}, Ljava/lang/Math;->min(II)I

    move-result v10

    invoke-virtual {v0, v10}, Landroid/view/ViewGroup;->removeViewAt(I)V

    if-ge v2, v3, :cond_82

    .line 270
    invoke-virtual {v0, p1, v2, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 271
    invoke-virtual {v0, p0, v3, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    goto :goto_95

    .line 273
    :cond_82
    invoke-virtual {v0, p0, v3, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 274
    invoke-virtual {v0, p1, v2, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    goto :goto_95

    .line 277
    :cond_89
    invoke-virtual {v0, p0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 278
    invoke-virtual {v1, p1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 279
    invoke-virtual {v0, p1, v2, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 280
    invoke-virtual {v1, p0, v3, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 283
    :goto_95
    invoke-virtual {p0, v6}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 284
    invoke-virtual {p1, v7}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 285
    invoke-static {p0}, Linv/exe/systemui/qs/drag/InvDragSupport;->resetDragVisual(Landroid/view/View;)V

    .line 286
    invoke-static {p1}, Linv/exe/systemui/qs/drag/InvDragSupport;->resetDragVisual(Landroid/view/View;)V

    invoke-virtual {v0}, Landroid/view/ViewGroup;->requestLayout()V

    if-ne v0, v1, :cond_a7

    goto :goto_aa

    :cond_a7
    invoke-virtual {v1}, Landroid/view/ViewGroup;->requestLayout()V

    :goto_aa
    invoke-static {v0, v9}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->play(Landroid/view/View;Ljava/util/Map;)V

    if-ne v0, v1, :cond_b0

    goto :goto_b3

    :cond_b0
    invoke-static {v1, v9}, Linv/exe/systemui/qs/ui/InvSmoothLayout;->play(Landroid/view/View;Ljava/util/Map;)V

    :cond_b3
    :goto_b3
    return-void
.end method

.method private static unclip(Landroid/view/View;)V
    .registers 3

    .line 81
    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_1e

    .line 82
    check-cast p0, Landroid/view/ViewGroup;

    const/4 v0, 0x0

    .line 83
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    .line 84
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->setClipToPadding(Z)V

    .line 85
    :goto_d
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-lt v0, v1, :cond_14

    goto :goto_1e

    :cond_14
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-static {v1}, Linv/exe/systemui/qs/drag/InvDragSupport;->unclip(Landroid/view/View;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_d

    :cond_1e
    :goto_1e
    return-void
.end method

.method private static wire(Landroid/view/View;Landroid/view/View$OnLongClickListener;Landroid/view/View$OnDragListener;)V
    .registers 6

    .line 418
    invoke-virtual {p0}, Landroid/view/View;->getId()I

    move-result v0

    const-string v1, "media_resize_handle"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    const/4 v2, 0x0

    if-ne v0, v1, :cond_18

    const/4 p1, 0x0

    .line 419
    invoke-virtual {p0, p1}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 420
    invoke-virtual {p0, p1}, Landroid/view/View;->setOnDragListener(Landroid/view/View$OnDragListener;)V

    .line 421
    invoke-virtual {p0, v2}, Landroid/view/View;->setLongClickable(Z)V

    return-void

    .line 424
    :cond_18
    invoke-virtual {p0, p1}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 425
    invoke-virtual {p0, p2}, Landroid/view/View;->setOnDragListener(Landroid/view/View$OnDragListener;)V

    .line 426
    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_35

    .line 427
    check-cast p0, Landroid/view/ViewGroup;

    .line 428
    :goto_24
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-lt v2, v0, :cond_2b

    goto :goto_35

    :cond_2b
    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0, p1, p2}, Linv/exe/systemui/qs/drag/InvDragSupport;->wire(Landroid/view/View;Landroid/view/View$OnLongClickListener;Landroid/view/View$OnDragListener;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_24

    :cond_35
    :goto_35
    return-void
.end method
