.class public final Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;
.super Ljava/lang/Object;
.source "DragSupport.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Linv/exe/systemui/qs/drag/InvDragSupport;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "ControlPlace"
.end annotation


# instance fields
.field public final c:I

.field public final h:I

.field public final id:Linv/exe/systemui/qs/model/InvControlId;

.field public final r:I

.field public final w:I


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/model/InvControlId;IIII)V
    .registers 7

    .line 233
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    invoke-static {v0, p2}, Ljava/lang/Math;->max(II)I

    move-result p2

    const/16 v0, 0x1f

    invoke-static {v0, p2}, Ljava/lang/Math;->min(II)I

    move-result p2

    const/4 v0, 0x0

    invoke-static {v0, p3}, Ljava/lang/Math;->max(II)I

    move-result p3

    const/4 v0, 0x3

    invoke-static {v0, p3}, Ljava/lang/Math;->min(II)I

    move-result p3

    const/4 v0, 0x1

    invoke-static {v0, p4}, Ljava/lang/Math;->max(II)I

    move-result p4

    const/4 v0, 0x4

    invoke-static {v0, p4}, Ljava/lang/Math;->min(II)I

    move-result p4

    rsub-int/lit8 v0, p3, 0x4

    invoke-static {v0, p4}, Ljava/lang/Math;->min(II)I

    move-result p4

    const/4 v0, 0x1

    invoke-static {v0, p4}, Ljava/lang/Math;->max(II)I

    move-result p4

    const/4 v0, 0x1

    invoke-static {v0, p5}, Ljava/lang/Math;->max(II)I

    move-result p5

    const/4 v0, 0x3

    invoke-static {v0, p5}, Ljava/lang/Math;->min(II)I

    move-result p5

    iput-object p1, p0, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->id:Linv/exe/systemui/qs/model/InvControlId;

    iput p2, p0, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->r:I

    iput p3, p0, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->c:I

    iput p4, p0, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->w:I

    iput p5, p0, Linv/exe/systemui/qs/drag/InvDragSupport$ControlPlace;->h:I

    return-void
.end method
