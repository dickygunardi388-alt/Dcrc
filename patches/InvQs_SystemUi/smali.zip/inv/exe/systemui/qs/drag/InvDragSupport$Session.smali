.class public final Linv/exe/systemui/qs/drag/InvDragSupport$Session;
.super Ljava/lang/Object;
.source "DragSupport.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Linv/exe/systemui/qs/drag/InvDragSupport;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Session"
.end annotation


# instance fields
.field public active:Z

.field public changed:Z

.field public source:Landroid/view/View;

.field public target:Landroid/view/View;

.field public tile:Z


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 28
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Linv/exe/systemui/qs/drag/InvDragSupport$Session;)V
    .registers 2

    .line 28
    invoke-direct {p0}, Linv/exe/systemui/qs/drag/InvDragSupport$Session;-><init>()V

    return-void
.end method
