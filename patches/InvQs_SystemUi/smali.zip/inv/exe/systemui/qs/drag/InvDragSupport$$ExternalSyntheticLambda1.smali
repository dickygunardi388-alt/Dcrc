.class public final synthetic Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "b849e8a9f6cceff267251a73644faacc801ad726cc8f22a9c323c56a203f5446"
.end annotation


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:Landroid/view/View;

.field public final synthetic f$2:Landroid/view/View;

.field public final synthetic f$3:Linv/exe/systemui/qs/ui/InvQsPanelView;

.field public final synthetic f$4:Linv/exe/systemui/qs/model/InvPanelRepository;


# direct methods
.method public synthetic constructor <init>(ZLandroid/view/View;Landroid/view/View;Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;)V
    .registers 6

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda1;->f$0:Z

    iput-object p2, p0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda1;->f$1:Landroid/view/View;

    iput-object p3, p0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda1;->f$2:Landroid/view/View;

    iput-object p4, p0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda1;->f$3:Linv/exe/systemui/qs/ui/InvQsPanelView;

    iput-object p5, p0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda1;->f$4:Linv/exe/systemui/qs/model/InvPanelRepository;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    .line 0
    iget-boolean v0, p0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda1;->f$0:Z

    iget-object v1, p0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda1;->f$1:Landroid/view/View;

    iget-object v2, p0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda1;->f$2:Landroid/view/View;

    iget-object v3, p0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda1;->f$3:Linv/exe/systemui/qs/ui/InvQsPanelView;

    iget-object p0, p0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda1;->f$4:Linv/exe/systemui/qs/model/InvPanelRepository;

    invoke-static {v0, v1, v2, v3, p0}, Linv/exe/systemui/qs/drag/InvDragSupport;->lambda$1(ZLandroid/view/View;Landroid/view/View;Linv/exe/systemui/qs/ui/InvQsPanelView;Linv/exe/systemui/qs/model/InvPanelRepository;)V

    return-void
.end method
