.class public final synthetic Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnDragListener;


# annotations
.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "b849e8a9f6cceff267251a73644faacc801ad726cc8f22a9c323c56a203f5446"
.end annotation


# instance fields
.field public final synthetic f$0:Landroid/view/View;

.field public final synthetic f$1:Linv/exe/systemui/qs/model/InvControlId;

.field public final synthetic f$2:Linv/exe/systemui/qs/model/InvPanelRepository;

.field public final synthetic f$3:Linv/exe/systemui/qs/ui/InvQsPanelView;


# direct methods
.method public synthetic constructor <init>(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;Linv/exe/systemui/qs/model/InvPanelRepository;Linv/exe/systemui/qs/ui/InvQsPanelView;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda4;->f$0:Landroid/view/View;

    iput-object p2, p0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda4;->f$1:Linv/exe/systemui/qs/model/InvControlId;

    iput-object p3, p0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda4;->f$2:Linv/exe/systemui/qs/model/InvPanelRepository;

    iput-object p4, p0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda4;->f$3:Linv/exe/systemui/qs/ui/InvQsPanelView;

    return-void
.end method


# virtual methods
.method public final onDrag(Landroid/view/View;Landroid/view/DragEvent;)Z
    .registers 9

    .line 0
    iget-object v0, p0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda4;->f$0:Landroid/view/View;

    iget-object v1, p0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda4;->f$1:Linv/exe/systemui/qs/model/InvControlId;

    iget-object v2, p0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda4;->f$2:Linv/exe/systemui/qs/model/InvPanelRepository;

    iget-object v3, p0, Linv/exe/systemui/qs/drag/InvDragSupport$$ExternalSyntheticLambda4;->f$3:Linv/exe/systemui/qs/ui/InvQsPanelView;

    move-object v4, p1

    move-object v5, p2

    invoke-static/range {v0 .. v5}, Linv/exe/systemui/qs/drag/InvDragSupport;->lambda$3(Landroid/view/View;Linv/exe/systemui/qs/model/InvControlId;Linv/exe/systemui/qs/model/InvPanelRepository;Linv/exe/systemui/qs/ui/InvQsPanelView;Landroid/view/View;Landroid/view/DragEvent;)Z

    move-result p0

    return p0
.end method
