.class public final Linv/exe/systemui/qs/helper/InvActivityLaunchHelper;
.super Ljava/lang/Object;
.source "ActivityLaunchHelper.java"


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static collapsePanels(Landroid/content/Context;)V
    .registers 3

    if-nez p0, :cond_3

    return-void

    :cond_3
    :try_start_3
    const-string v0, "statusbar"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    instance-of v1, v0, Landroid/app/StatusBarManager;

    if-eqz v1, :cond_14

    check-cast v0, Landroid/app/StatusBarManager;

    invoke-virtual {v0}, Landroid/app/StatusBarManager;->collapsePanels()V
    :try_end_12
    .catchall {:try_start_3 .. :try_end_12} :catchall_13

    goto :goto_14

    :catchall_13
    move-exception v0

    :cond_14
    :goto_14
    return-void
.end method

.method public static openInvosSettings(Landroid/view/View;)V
    .registers 2

    const-string v0, "android.settings.SETTINGS"

    invoke-static {p0, v0}, Linv/exe/systemui/qs/helper/InvActivityLaunchHelper;->tryStartAction(Landroid/view/View;Ljava/lang/String;)Z

    return-void
.end method

.method public static openMediaSessionActivity(Landroid/view/View;Landroid/app/PendingIntent;Ljava/lang/String;)V
    .registers 3

    if-eqz p1, :cond_5

    invoke-static {p0, p1}, Linv/exe/systemui/qs/helper/InvActivityLaunchHelper;->startPendingIntent(Landroid/view/View;Landroid/app/PendingIntent;)Z

    :cond_5
    return-void
.end method

.method public static openPackage(Landroid/view/View;Ljava/lang/String;)V
    .registers 2

    if-eqz p1, :cond_5

    invoke-static {p0, p1}, Linv/exe/systemui/qs/helper/InvActivityLaunchHelper;->tryStartPackage(Landroid/view/View;Ljava/lang/String;)Z

    :cond_5
    return-void
.end method

.method private static startActivity(Landroid/view/View;Landroid/content/Intent;)Z
    .registers 7

    const/4 v0, 0x0

    if-eqz p0, :cond_31

    if-eqz p1, :cond_31

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    if-eqz v1, :cond_31

    const v2, 0x34000000

    invoke-virtual {p1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    :try_start_11
    const-class v2, Lcom/android/systemui/plugins/ActivityStarter;

    invoke-static {v2}, Lcom/android/systemui/Dependency;->get(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/systemui/plugins/ActivityStarter;

    if-eqz v2, :cond_31

    new-instance v3, Lcom/android/systemui/animation/Expandable$Companion$fromView$1;

    invoke-direct {v3, p0}, Lcom/android/systemui/animation/Expandable$Companion$fromView$1;-><init>(Landroid/view/View;)V

    const/16 v4, 0x21

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v3, v4}, Lcom/android/systemui/animation/Expandable;->activityLaunchController(Ljava/lang/Integer;)Lcom/android/systemui/animation/GhostedViewLaunchAnimatorController;

    move-result-object v3

    const/4 v4, 0x1

    invoke-interface {v2, p1, v4, v3}, Lcom/android/systemui/plugins/ActivityStarter;->startActivity(Landroid/content/Intent;ZLcom/android/systemui/animation/ActivityLaunchAnimator$Controller;)V
    :try_end_2e
    .catchall {:try_start_11 .. :try_end_2e} :catchall_30

    const/4 v0, 0x1

    return v0

    :catchall_30
    move-exception v1

    :cond_31
    return v0
.end method

.method private static startPendingIntent(Landroid/view/View;Landroid/app/PendingIntent;)Z
    .registers 7

    const/4 v0, 0x0

    if-eqz p0, :cond_2a

    if-eqz p1, :cond_2a

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    if-eqz v1, :cond_2a

    :try_start_b
    const-class v2, Lcom/android/systemui/plugins/ActivityStarter;

    invoke-static {v2}, Lcom/android/systemui/Dependency;->get(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/android/systemui/plugins/ActivityStarter;

    if-eqz v2, :cond_2a

    new-instance v3, Lcom/android/systemui/animation/Expandable$Companion$fromView$1;

    invoke-direct {v3, p0}, Lcom/android/systemui/animation/Expandable$Companion$fromView$1;-><init>(Landroid/view/View;)V

    const/16 v4, 0x1f

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v3, v4}, Lcom/android/systemui/animation/Expandable;->activityLaunchController(Ljava/lang/Integer;)Lcom/android/systemui/animation/GhostedViewLaunchAnimatorController;

    move-result-object v3

    invoke-interface {v2, p1, v3}, Lcom/android/systemui/plugins/ActivityStarter;->postStartActivityDismissingKeyguard(Landroid/app/PendingIntent;Lcom/android/systemui/animation/ActivityLaunchAnimator$Controller;)V
    :try_end_27
    .catchall {:try_start_b .. :try_end_27} :catchall_29

    const/4 v0, 0x1

    return v0

    :catchall_29
    move-exception v1

    :cond_2a
    return v0
.end method

.method private static tryStartAction(Landroid/view/View;Ljava/lang/String;)Z
    .registers 3

    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-static {p0, v0}, Linv/exe/systemui/qs/helper/InvActivityLaunchHelper;->startActivity(Landroid/view/View;Landroid/content/Intent;)Z

    move-result p0

    return p0
.end method

.method private static tryStartPackage(Landroid/view/View;Ljava/lang/String;)Z
    .registers 5

    const/4 v0, 0x0

    if-eqz p0, :cond_1a

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    if-eqz v1, :cond_1a

    :try_start_9
    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {v1, p1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1
    :try_end_11
    .catchall {:try_start_9 .. :try_end_11} :catchall_19

    if-nez p1, :cond_14

    return v0

    :cond_14
    invoke-static {p0, p1}, Linv/exe/systemui/qs/helper/InvActivityLaunchHelper;->startActivity(Landroid/view/View;Landroid/content/Intent;)Z

    move-result p0

    return p0

    :catchall_19
    move-exception v1

    :cond_1a
    return v0
.end method
