.class public final Linv/exe/systemui/qs/helper/InvControlIntentHelper;
.super Ljava/lang/Object;
.source "ControlIntentHelper.java"


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static openSetting(Landroid/content/Context;Ljava/lang/String;)V
    .registers 4

    if-eqz p0, :cond_12

    if-eqz p1, :cond_12

    :try_start_4
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/high16 p1, 0x10000000

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_11
    .catch Ljava/lang/Throwable; {:try_start_4 .. :try_end_11} :catch_12

    return-void

    :catch_12
    :cond_12
    return-void
.end method
