.class public final Linv/exe/systemui/qs/helper/InvSettingsButtonClickListener;
.super Ljava/lang/Object;
.source "SettingsButtonClickListener.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 3

    invoke-static {p1}, Linv/exe/systemui/qs/helper/InvActivityLaunchHelper;->openInvosSettings(Landroid/view/View;)V

    return-void
.end method
