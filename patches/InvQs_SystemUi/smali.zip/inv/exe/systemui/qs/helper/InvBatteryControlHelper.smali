.class public final Linv/exe/systemui/qs/helper/InvBatteryControlHelper;
.super Ljava/lang/Object;
.source "BatteryControlHelper.java"


# static fields
.field private static sChargeLastMs:J

.field private static sChargePercent:I

.field private static sChargeText:Ljava/lang/String;


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static baseLabel(I)Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Battery\n"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, "%"

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static isCharging(Landroid/content/Context;)Z
    .registers 6

    const/4 v0, 0x0

    new-instance v1, Landroid/content/IntentFilter;

    const-string v2, "android.intent.action.BATTERY_CHANGED"

    invoke-direct {v1, v2}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    invoke-virtual {p0, v2, v1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object p0

    if-eqz p0, :cond_1c

    const-string v1, "status"

    const/4 v2, -0x1

    invoke-virtual {p0, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p0

    const/4 v1, 0x2

    if-eq p0, v1, :cond_1d

    const/4 v1, 0x5

    if-eq p0, v1, :cond_1d

    :cond_1c
    return v0

    :cond_1d
    const/4 v0, 0x1

    return v0
.end method

.method public static label(Landroid/content/Context;)Ljava/lang/String;
    .registers 22

    move-object/from16 v0, p0

    const/4 v1, 0x0

    const/4 v2, -0x1

    :try_start_4
    new-instance v3, Landroid/content/IntentFilter;

    const-string v4, "android.intent.action.BATTERY_CHANGED"

    invoke-direct {v3, v4}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1, v3}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object v3

    if-eqz v3, :cond_135

    const-string v4, "level"

    invoke-virtual {v3, v4, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v4

    const-string v5, "scale"

    const/16 v6, 0x64

    invoke-virtual {v3, v5, v6}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v5

    if-gtz v5, :cond_23

    const/16 v5, 0x64

    :cond_23
    mul-int/lit8 v4, v4, 0x64

    div-int/2addr v4, v5

    const/4 v5, 0x0

    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    const/16 v6, 0x64

    invoke-static {v6, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    const-string v6, "status"

    invoke-virtual {v3, v6, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v6

    const-string v7, "voltage"

    invoke-virtual {v3, v7, v5}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v7

    const-string v8, "batterymanager"

    invoke-virtual {v0, v8}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    instance-of v9, v8, Landroid/os/BatteryManager;

    if-eqz v9, :cond_54

    check-cast v8, Landroid/os/BatteryManager;

    const/4 v9, 0x2

    invoke-virtual {v8, v9}, Landroid/os/BatteryManager;->getIntProperty(I)I

    move-result v9

    const/4 v10, 0x1

    invoke-virtual {v8, v10}, Landroid/os/BatteryManager;->getIntProperty(I)I

    move-result v8

    goto :goto_5a

    :cond_54
    const v9, -0x80000000

    const v8, -0x80000000

    :goto_5a
    const/4 v10, 0x2

    if-eq v6, v10, :cond_62

    const/4 v10, 0x5

    if-eq v6, v10, :cond_62

    goto/16 :goto_eb

    :cond_62
    sget-object v10, Linv/exe/systemui/qs/helper/InvBatteryControlHelper;->sChargeText:Ljava/lang/String;

    if-eqz v10, :cond_79

    sget v11, Linv/exe/systemui/qs/helper/InvBatteryControlHelper;->sChargePercent:I

    if-ne v11, v4, :cond_79

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    sget-wide v13, Linv/exe/systemui/qs/helper/InvBatteryControlHelper;->sChargeLastMs:J

    sub-long/2addr v11, v13

    const-wide/16 v13, 0x3a98

    cmp-long v12, v11, v13

    if-ltz v12, :cond_78

    goto :goto_79

    :cond_78
    return-object v10

    :cond_79
    :goto_79
    invoke-static {v4}, Linv/exe/systemui/qs/helper/InvBatteryControlHelper;->baseLabel(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v9}, Ljava/lang/Math;->abs(I)I

    move-result v1

    if-lez v1, :cond_d1

    if-lez v7, :cond_d1

    div-int/lit16 v2, v1, 0x3e8

    add-int/lit8 v2, v2, 0x32

    div-int/lit8 v2, v2, 0x64

    mul-int/lit8 v2, v2, 0x64

    int-to-long v5, v2

    int-to-long v11, v7

    mul-long/2addr v5, v11

    const-wide/32 v11, 0xf4240

    div-long/2addr v5, v11

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v0, " · "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "mA "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "W"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-wide/16 v1, 0xa

    cmp-long v3, v5, v1

    if-ltz v3, :cond_bc

    const-string v1, " fast"

    goto :goto_be

    :cond_bc
    const-string v1, " charging"

    :goto_be
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Linv/exe/systemui/qs/helper/InvBatteryControlHelper;->sChargeText:Ljava/lang/String;

    sput v4, Linv/exe/systemui/qs/helper/InvBatteryControlHelper;->sChargePercent:I

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    sput-wide v11, Linv/exe/systemui/qs/helper/InvBatteryControlHelper;->sChargeLastMs:J

    return-object v0

    :cond_d1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v0, " · charging"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Linv/exe/systemui/qs/helper/InvBatteryControlHelper;->sChargeText:Ljava/lang/String;

    sput v4, Linv/exe/systemui/qs/helper/InvBatteryControlHelper;->sChargePercent:I

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    sput-wide v11, Linv/exe/systemui/qs/helper/InvBatteryControlHelper;->sChargeLastMs:J

    return-object v0

    :goto_eb
    invoke-static {v4}, Linv/exe/systemui/qs/helper/InvBatteryControlHelper;->baseLabel(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v9}, Ljava/lang/Math;->abs(I)I

    move-result v1

    if-lez v1, :cond_134

    if-lez v8, :cond_134

    int-to-long v5, v8

    const-wide/16 v11, 0x3c

    mul-long/2addr v5, v11

    int-to-long v11, v1

    div-long/2addr v5, v11

    const-wide/16 v11, 0x0

    cmp-long v1, v5, v11

    if-lez v1, :cond_134

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    const-wide/32 v13, 0xea60

    mul-long/2addr v13, v5

    add-long/2addr v11, v13

    new-instance v1, Ljava/text/SimpleDateFormat;

    const-string v2, "HH:mm"

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v2, Ljava/util/Date;

    invoke-direct {v2, v11, v12}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v1, v2}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v0, " · until "

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_134
    return-object v0

    :cond_135
    const-string v0, "Battery\nUnavailable"
    :try_end_137
    .catch Ljava/lang/Throwable; {:try_start_4 .. :try_end_137} :catch_138

    return-object v0

    :catch_138
    const-string v0, "Battery\nUnavailable"

    return-object v0
.end method
