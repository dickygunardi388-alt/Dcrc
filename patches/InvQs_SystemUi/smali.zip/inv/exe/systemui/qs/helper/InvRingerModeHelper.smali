.class public final Linv/exe/systemui/qs/helper/InvRingerModeHelper;
.super Ljava/lang/Object;
.source "RingerModeHelper.java"


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static audio(Landroid/content/Context;)Landroid/media/AudioManager;
    .registers 2

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    :cond_4
    :try_start_4
    const-string v0, "audio"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/media/AudioManager;
    :try_end_c
    .catchall {:try_start_4 .. :try_end_c} :catchall_d

    return-object p0

    :catchall_d
    const/4 p0, 0x0

    return-object p0
.end method

.method public static cycle(Landroid/content/Context;)V
    .registers 4

    invoke-static {p0}, Linv/exe/systemui/qs/helper/InvRingerModeHelper;->audio(Landroid/content/Context;)Landroid/media/AudioManager;

    move-result-object p0

    if-nez p0, :cond_7

    return-void

    :cond_7
    :try_start_7
    invoke-virtual {p0}, Landroid/media/AudioManager;->getRingerMode()I

    move-result v0

    const/4 v1, 0x2

    if-ne v0, v1, :cond_10

    const/4 v0, 0x1

    goto :goto_16

    :cond_10
    const/4 v1, 0x1

    if-ne v0, v1, :cond_15

    const/4 v0, 0x0

    goto :goto_16

    :cond_15
    const/4 v0, 0x2

    :goto_16
    invoke-virtual {p0, v0}, Landroid/media/AudioManager;->setRingerMode(I)V
    :try_end_19
    .catchall {:try_start_7 .. :try_end_19} :catchall_19

    :catchall_19
    return-void
.end method

.method private static mode(Landroid/content/Context;)I
    .registers 2

    const/4 v0, 0x2

    invoke-static {p0}, Linv/exe/systemui/qs/helper/InvRingerModeHelper;->audio(Landroid/content/Context;)Landroid/media/AudioManager;

    move-result-object p0

    if-nez p0, :cond_8

    return v0

    :cond_8
    :try_start_8
    invoke-virtual {p0}, Landroid/media/AudioManager;->getRingerMode()I

    move-result p0
    :try_end_c
    .catchall {:try_start_8 .. :try_end_c} :catchall_d

    return p0

    :catchall_d
    return v0
.end method

.method public static render(Landroid/view/View;Landroid/widget/TextView;)V
    .registers 9

    if-nez p0, :cond_3

    return-void

    :cond_3
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Linv/exe/systemui/qs/helper/InvRingerModeHelper;->mode(Landroid/content/Context;)I

    move-result v1

    if-nez v1, :cond_16

    const-string v2, "Silent"

    const-string v3, "inv_bg_pill"

    const-string v4, "inv_text_primary"

    const-string v6, "inv_ic_volume_off"

    goto :goto_2a

    :cond_16
    const/4 v2, 0x1

    if-ne v1, v2, :cond_22

    const-string v2, "Vibrate"

    const-string v3, "inv_bg_pill_on"

    const-string v4, "inv_icon_on_accent"

    const-string v6, "inv_ic_vibrate"

    goto :goto_2a

    :cond_22
    const-string v2, "Ringer"

    const-string v3, "inv_bg_pill_on"

    const-string v4, "inv_icon_on_accent"

    const-string v6, "inv_ic_notifications"

    :goto_2a
    if-eqz p1, :cond_3a

    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v4}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v0, v5}, Landroid/content/Context;->getColor(I)I

    move-result v5

    invoke-virtual {p1, v5}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_3a
    const/4 p1, 0x0

    if-nez v1, :cond_3e

    goto :goto_3f

    :cond_3e
    const/4 p1, 0x1

    :goto_3f
    invoke-static {p0, p1}, Linv/exe/systemui/qs/ui/InvTileAnimation;->pillBackground(Landroid/view/View;Z)V

    invoke-static {v4}, Linv/exe/systemui/qs/core/InvRes;->color(Ljava/lang/String;)I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/content/Context;->getColor(I)I

    move-result p1

    const-string v1, "pill_icon"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    instance-of v2, v1, Landroid/widget/ImageView;

    if-eqz v2, :cond_68

    check-cast v1, Landroid/widget/ImageView;

    invoke-static {v6}, Linv/exe/systemui/qs/core/InvRes;->drawable(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    :cond_68
    const-string v1, "pill_divider"

    invoke-static {v1}, Linv/exe/systemui/qs/core/InvRes;->id(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p0

    if-eqz p0, :cond_77

    invoke-virtual {p0, p1}, Landroid/view/View;->setBackgroundColor(I)V

    :cond_77
    return-void
.end method
