.class public final Linv/exe/systemui/qs/helper/InvMediaAppClickListener;
.super Ljava/lang/Object;
.source "MediaAppClickListener.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field private final launchSource:Landroid/view/View;

.field private final media:Linv/exe/systemui/qs/controller/InvMediaSessionController;


# direct methods
.method public constructor <init>(Linv/exe/systemui/qs/controller/InvMediaSessionController;)V
    .registers 3

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Linv/exe/systemui/qs/helper/InvMediaAppClickListener;-><init>(Linv/exe/systemui/qs/controller/InvMediaSessionController;Landroid/view/View;)V

    return-void
.end method

.method public constructor <init>(Linv/exe/systemui/qs/controller/InvMediaSessionController;Landroid/view/View;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/systemui/qs/helper/InvMediaAppClickListener;->media:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    iput-object p2, p0, Linv/exe/systemui/qs/helper/InvMediaAppClickListener;->launchSource:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 5

    iget-object v0, p0, Linv/exe/systemui/qs/helper/InvMediaAppClickListener;->media:Linv/exe/systemui/qs/controller/InvMediaSessionController;

    if-eqz v0, :cond_14

    iget-object v1, p0, Linv/exe/systemui/qs/helper/InvMediaAppClickListener;->launchSource:Landroid/view/View;

    if-eqz v1, :cond_9

    move-object p1, v1

    :cond_9
    invoke-virtual {v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->getSessionActivityPendingIntent()Landroid/app/PendingIntent;

    move-result-object v1

    invoke-virtual {v0}, Linv/exe/systemui/qs/controller/InvMediaSessionController;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-static {p1, v1, v2}, Linv/exe/systemui/qs/helper/InvActivityLaunchHelper;->openMediaSessionActivity(Landroid/view/View;Landroid/app/PendingIntent;Ljava/lang/String;)V

    :cond_14
    return-void
.end method
