.class public final Linv/exe/systemui/qs/helper/InvDataUsageControlHelper;
.super Ljava/lang/Object;
.source "DataUsageControlHelper.java"


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static activeTransport(Landroid/content/Context;)I
    .registers 4

    :try_start_0
    const-string v0, "connectivity"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/net/ConnectivityManager;

    if-eqz p0, :cond_22

    invoke-virtual {p0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object p0

    if-eqz p0, :cond_22

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->isConnected()Z

    move-result v0

    if-eqz v0, :cond_22

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getType()I

    move-result p0

    const/4 v0, 0x1

    if-ne p0, v0, :cond_1e
    :try_end_1d
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_1d} :catch_24

    return v0

    :cond_1e
    const/4 v0, 0x0

    if-ne p0, v0, :cond_22

    return v0

    :cond_22
    const/4 v0, -0x1

    return v0

    :catch_24
    const/4 v0, -0x1

    return v0
.end method

.method private static formatBytes(J)Ljava/lang/String;
    .registers 7

    const-wide/16 v0, 0x0

    cmp-long v2, p0, v0

    if-gez v2, :cond_8

    const-wide/16 p0, 0x0

    :cond_8
    const-wide/32 v0, 0x40000000

    cmp-long v2, p0, v0

    if-ltz v2, :cond_25

    div-long/2addr p0, v0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string p1, " GB"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    move-object v1, p0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_25
    const-wide/32 v0, 0x100000

    cmp-long v2, p0, v0

    if-ltz v2, :cond_42

    div-long/2addr p0, v0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string p1, " MB"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    move-object v1, p0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_42
    const-wide/16 v0, 0x400

    div-long/2addr p0, v0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string p1, " KB"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    move-object v1, p0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static isConnected(Landroid/content/Context;)Z
    .registers 2

    invoke-static {p0}, Linv/exe/systemui/qs/helper/InvDataUsageControlHelper;->activeTransport(Landroid/content/Context;)I

    move-result p0

    if-gez p0, :cond_8

    const/4 p0, 0x0

    return p0

    :cond_8
    const/4 p0, 0x1

    return p0
.end method

.method public static label(Landroid/content/Context;)Ljava/lang/String;
    .registers 16

    :try_start_0
    invoke-static {}, Landroid/net/TrafficStats;->getTotalRxBytes()J

    move-result-wide v0

    invoke-static {}, Landroid/net/TrafficStats;->getTotalTxBytes()J

    move-result-wide v2

    add-long/2addr v0, v2

    const-wide/16 v2, 0x0

    cmp-long v6, v0, v2

    if-gez v6, :cond_11

    goto/16 :goto_ca

    :cond_11
    invoke-static {}, Landroid/net/TrafficStats;->getMobileRxBytes()J

    move-result-wide v4

    invoke-static {}, Landroid/net/TrafficStats;->getMobileTxBytes()J

    move-result-wide v6

    add-long/2addr v4, v6

    cmp-long v6, v4, v2

    if-ltz v6, :cond_1f

    goto :goto_21

    :cond_1f
    const-wide/16 v4, 0x0

    :goto_21
    cmp-long v6, v4, v0

    if-lez v6, :cond_26

    move-wide v4, v0

    :cond_26
    invoke-static {}, Linv/exe/systemui/qs/helper/InvDataUsageControlHelper;->todayId()Ljava/lang/String;

    move-result-object v8

    const-string v9, "inv_data_usage_daily_v2"

    const/4 v10, 0x0

    invoke-virtual {p0, v9, v10}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v9

    const-string v10, "day"

    const-string v11, ""

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v11, "base_total"

    invoke-interface {v9, v11, v0, v1}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v11

    const-string v13, "base_mobile"

    invoke-interface {v9, v13, v4, v5}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v13

    invoke-virtual {v10}, Ljava/lang/String;->length()I

    move-result v6

    if-nez v6, :cond_4d

    const/4 v7, 0x1

    goto :goto_4e

    :cond_4d
    const/4 v7, 0x0

    :goto_4e
    invoke-virtual {v8, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_5d

    cmp-long v10, v11, v0

    if-lez v10, :cond_59

    goto :goto_5d

    :cond_59
    cmp-long v10, v13, v4

    if-lez v10, :cond_7f

    :cond_5d
    :goto_5d
    if-eqz v7, :cond_64

    const-wide/16 v11, 0x0

    const-wide/16 v13, 0x0

    goto :goto_66

    :cond_64
    move-wide v11, v0

    move-wide v13, v4

    :goto_66
    invoke-interface {v9}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    const-string v9, "day"

    invoke-interface {v10, v9, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    const-string v9, "base_total"

    invoke-interface {v10, v9, v11, v12}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    const-string v9, "base_mobile"

    invoke-interface {v10, v9, v13, v14}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    invoke-interface {v10}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_7f
    sub-long/2addr v0, v11

    sub-long/2addr v4, v13

    cmp-long v6, v0, v2

    if-ltz v6, :cond_86

    goto :goto_88

    :cond_86
    const-wide/16 v0, 0x0

    :goto_88
    cmp-long v6, v4, v2

    if-ltz v6, :cond_8d

    goto :goto_8f

    :cond_8d
    const-wide/16 v4, 0x0

    :goto_8f
    move-wide v11, v0

    sub-long/2addr v11, v4

    cmp-long v6, v11, v2

    if-ltz v6, :cond_96

    goto :goto_98

    :cond_96
    const-wide/16 v11, 0x0

    :goto_98
    invoke-static {p0}, Linv/exe/systemui/qs/helper/InvDataUsageControlHelper;->activeTransport(Landroid/content/Context;)I

    move-result v6

    const/4 v7, 0x1

    if-ne v6, v7, :cond_a3

    move-wide v0, v11

    const-string v2, "Wi-Fi · "

    goto :goto_ac

    :cond_a3
    if-nez v6, :cond_a9

    move-wide v0, v4

    const-string v2, "Mobile · "

    goto :goto_ac

    :cond_a9
    const-string v0, "Data usage\nNo connection"

    goto :goto_cc

    :goto_ac
    invoke-static {v0, v1}, Linv/exe/systemui/qs/helper/InvDataUsageControlHelper;->formatBytes(J)Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "Data usage\n"

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " today"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_cc

    :goto_ca
    const-string v0, "Data usage\nUnavailable"
    :try_end_cc
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_cc} :catch_cd

    :goto_cc
    return-object v0

    :catch_cd
    const-string v0, "Data usage\nUnavailable"

    return-object v0
.end method

.method private static todayId()Ljava/lang/String;
    .registers 5

    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "yyyyMMdd"

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v1, Ljava/util/Date;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    invoke-direct {v1, v2, v3}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v0, v1}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
