# classes2.dex

.class public Linv/systemui/dynamic/InvEqualizerView;
.super Landroid/view/View;
.source "InvEqualizerView.java"

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field private static sGlobalPhase:F


# instance fields
.field private mBarBottomColor:I

.field private mBarGlowColor:I

.field private mBarPaint:Landroid/graphics/Paint;

.field private mBarTopColor:I

.field private mBgPaint:Landroid/graphics/Paint;

.field private mPhase:F

.field private mRect:Landroid/graphics/RectF;

.field private mRunning:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    invoke-direct {p0}, Linv/systemui/dynamic/InvEqualizerView;->init()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    invoke-direct {p0}, Linv/systemui/dynamic/InvEqualizerView;->init()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4

    invoke-direct {p0, p1, p2, p3}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    invoke-direct {p0}, Linv/systemui/dynamic/InvEqualizerView;->init()V

    return-void
.end method

.method private drawOneBar(Landroid/graphics/Canvas;IF)V
    .registers 16

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v1

    int-to-float v1, v1

    const/high16 v2, 0x40800000  # 4.0f

    cmpg-float v2, v0, v2

    if-gtz v2, :cond_11

    return-void

    :cond_11
    const v2, 0x3dcccccd  # 0.1f

    mul-float/2addr v2, v0

    const v3, 0x3d4ccccd  # 0.05f

    mul-float/2addr v3, v0

    const/high16 v4, 0x40000000  # 2.0f

    mul-float v5, v2, v4

    sub-float v5, v0, v5

    const/high16 v6, 0x40a00000  # 5.0f

    mul-float/2addr v6, v3

    sub-float/2addr v5, v6

    const/high16 v6, 0x40c00000  # 6.0f

    div-float/2addr v5, v6

    const v11, 0x3f666666  # 0.9f

    if-eqz p2, :cond_35

    const/4 v6, 0x5

    if-eq p2, v6, :cond_35

    const/4 v6, 0x1

    if-eq p2, v6, :cond_39

    const/4 v6, 0x4

    if-eq p2, v6, :cond_39

    goto :goto_3c

    :cond_35
    const v11, 0x3f19999a  # 0.6f

    goto :goto_3c

    :cond_39
    const v11, 0x3f4ccccd  # 0.8f

    :goto_3c
    iget-boolean v6, p0, Linv/systemui/dynamic/InvEqualizerView;->mRunning:Z

    if-nez v6, :cond_45

    const v8, 0x3dcccccd  # 0.1f

    mul-float/2addr v8, v1

    goto :goto_6c

    :cond_45
    iget v7, p0, Linv/systemui/dynamic/InvEqualizerView;->mPhase:F

    const v8, 0x3f19999a  # 0.6f

    mul-float/2addr v8, p3

    add-float/2addr v7, v8

    int-to-float v8, p2

    const v6, 0x3f4ccccd  # 0.8f

    mul-float/2addr v8, v6

    add-float/2addr v7, v8

    float-to-double v7, v7

    invoke-static {v7, v8}, Ljava/lang/Math;->sin(D)D

    move-result-wide v7

    const-wide/high16 v9, 0x3ff0000000000000L  # 1.0

    add-double/2addr v7, v9

    const-wide/high16 v9, 0x3fe0000000000000L  # 0.5

    mul-double/2addr v7, v9

    double-to-float v7, v7

    const v8, 0x3f333333  # 0.7f

    mul-float/2addr v7, v8

    const v8, 0x3ecccccd  # 0.4f

    add-float/2addr v7, v8

    mul-float/2addr v7, v11

    const v8, 0x3f333333  # 0.7f

    mul-float/2addr v8, v1

    mul-float/2addr v8, v7

    :goto_6c
    div-float v7, v1, v4

    div-float v9, v8, v4

    sub-float/2addr v7, v9

    div-float/2addr v1, v4

    div-float/2addr v8, v4

    add-float v10, v1, v8

    int-to-float v6, p2

    add-float v11, v5, v3

    mul-float/2addr v6, v11

    add-float/2addr v6, v2

    add-float v11, v6, v5

    const v8, 0x3f19999a  # 0.6f

    mul-float/2addr v8, v5

    iget-object v3, p0, Linv/systemui/dynamic/InvEqualizerView;->mRect:Landroid/graphics/RectF;

    invoke-virtual {v3, v6, v7, v11, v10}, Landroid/graphics/RectF;->set(FFFF)V

    new-instance v0, Landroid/graphics/LinearGradient;

    const/4 v1, 0x0

    int-to-float v1, v1

    move v2, v7

    const/4 v3, 0x0

    int-to-float v3, v3

    move v4, v10

    iget v5, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarTopColor:I

    iget v6, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarBottomColor:I

    sget-object v7, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v0 .. v7}, Landroid/graphics/LinearGradient;-><init>(FFFFIILandroid/graphics/Shader$TileMode;)V

    iget-object v1, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarPaint:Landroid/graphics/Paint;

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    if-eqz p2, :cond_a9

    const/4 v0, 0x5

    if-eq p2, v0, :cond_a9

    const/4 v0, 0x1

    if-eq p2, v0, :cond_ac

    const/4 v0, 0x4

    if-eq p2, v0, :cond_ac

    const/16 v0, 0xff

    goto :goto_ae

    :cond_a9
    const/16 v0, 0xde

    goto :goto_ae

    :cond_ac
    const/16 v0, 0xee

    :goto_ae
    iget-object v1, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarPaint:Landroid/graphics/Paint;

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setAlpha(I)V

    const v0, 0x3ee66666  # 0.45f

    mul-float/2addr v0, v8

    const/4 v2, 0x0

    int-to-float v2, v2

    iget v3, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarGlowColor:I

    invoke-virtual {v1, v0, v2, v2, v3}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    iget-object v3, p0, Linv/systemui/dynamic/InvEqualizerView;->mRect:Landroid/graphics/RectF;

    iget-object v4, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v3, v8, v8, v4}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method private init()V
    .registers 4

    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Linv/systemui/dynamic/InvEqualizerView;->mBgPaint:Landroid/graphics/Paint;

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v0, p0, Linv/systemui/dynamic/InvEqualizerView;->mBgPaint:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarPaint:Landroid/graphics/Paint;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    iput v1, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarTopColor:I

    const v2, -0x222223

    iput v2, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarBottomColor:I

    const v2, 0x66ffffff

    iput v2, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarGlowColor:I

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, v1, v2}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    iget-object v0, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarPaint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Linv/systemui/dynamic/InvEqualizerView;->mRect:Landroid/graphics/RectF;

    sget v0, Linv/systemui/dynamic/InvEqualizerView;->sGlobalPhase:F

    iput v0, p0, Linv/systemui/dynamic/InvEqualizerView;->mPhase:F

    return-void
.end method

.method private static makeIosBottomColor(I)I
    .registers 5

    invoke-static {p0}, Landroid/graphics/Color;->red(I)I

    move-result v0

    invoke-static {p0}, Landroid/graphics/Color;->green(I)I

    move-result v1

    invoke-static {p0}, Landroid/graphics/Color;->blue(I)I

    move-result v2

    mul-int/lit8 v0, v0, 0x58

    div-int/lit8 v0, v0, 0x64

    mul-int/lit8 v1, v1, 0x58

    div-int/lit8 v1, v1, 0x64

    mul-int/lit8 v2, v2, 0x58

    div-int/lit8 v2, v2, 0x64

    invoke-static {v0, v1, v2}, Landroid/graphics/Color;->rgb(III)I

    move-result v0

    return v0
.end method

.method private static makeIosGlowColor(I)I
    .registers 5

    invoke-static {p0}, Landroid/graphics/Color;->red(I)I

    move-result v0

    invoke-static {p0}, Landroid/graphics/Color;->green(I)I

    move-result v1

    invoke-static {p0}, Landroid/graphics/Color;->blue(I)I

    move-result v2

    const/16 v3, 0x66

    invoke-static {v3, v0, v1, v2}, Landroid/graphics/Color;->argb(IIII)I

    move-result v0

    return v0
.end method

.method private static makeLightVibrant(I)I
    .registers 8

    invoke-static {p0}, Landroid/graphics/Color;->red(I)I

    move-result v0

    invoke-static {p0}, Landroid/graphics/Color;->green(I)I

    move-result v1

    invoke-static {p0}, Landroid/graphics/Color;->blue(I)I

    move-result v2

    add-int v3, v0, v1

    add-int/2addr v3, v2

    div-int/lit8 v3, v3, 0x3

    sub-int v4, v0, v3

    mul-int/lit8 v4, v4, 0x7d

    div-int/lit8 v4, v4, 0x64

    add-int v0, v3, v4

    sub-int v4, v1, v3

    mul-int/lit8 v4, v4, 0x7d

    div-int/lit8 v4, v4, 0x64

    add-int v1, v3, v4

    sub-int v4, v2, v3

    mul-int/lit8 v4, v4, 0x7d

    div-int/lit8 v4, v4, 0x64

    add-int v2, v3, v4

    const/4 v5, 0x0

    const/16 v6, 0xff

    if-ge v0, v5, :cond_2f

    move v0, v5

    :cond_2f
    if-le v0, v6, :cond_32

    move v0, v6

    :cond_32
    if-ge v1, v5, :cond_35

    move v1, v5

    :cond_35
    if-le v1, v6, :cond_38

    move v1, v6

    :cond_38
    if-ge v2, v5, :cond_3b

    move v2, v5

    :cond_3b
    if-le v2, v6, :cond_3e

    move v2, v6

    :cond_3e
    sub-int v4, v6, v0

    mul-int/lit8 v4, v4, 0x12

    div-int/lit8 v4, v4, 0x64

    add-int/2addr v0, v4

    sub-int v4, v6, v1

    mul-int/lit8 v4, v4, 0x12

    div-int/lit8 v4, v4, 0x64

    add-int/2addr v1, v4

    sub-int v4, v6, v2

    mul-int/lit8 v4, v4, 0x12

    div-int/lit8 v4, v4, 0x64

    add-int/2addr v2, v4

    invoke-static {v0, v1, v2}, Landroid/graphics/Color;->rgb(III)I

    move-result v0

    return v0
.end method

.method private static scoreLightVibrant(I)I
    .registers 8

    invoke-static {p0}, Landroid/graphics/Color;->red(I)I

    move-result v0

    invoke-static {p0}, Landroid/graphics/Color;->green(I)I

    move-result v1

    invoke-static {p0}, Landroid/graphics/Color;->blue(I)I

    move-result v2

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v3

    invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I

    move-result v3

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v4

    invoke-static {v4, v2}, Ljava/lang/Math;->min(II)I

    move-result v4

    sub-int v5, v3, v4

    const/16 v6, 0x28

    if-lt v3, v6, :cond_26

    mul-int/lit8 v6, v5, 0x2

    add-int/2addr v6, v3

    return v6

    :cond_26
    const/4 v6, 0x0

    return v6
.end method


# virtual methods
.method protected onAttachedToWindow()V
    .registers 1

    invoke-super {p0}, Landroid/view/View;->onAttachedToWindow()V

    invoke-virtual {p0}, Linv/systemui/dynamic/InvEqualizerView;->start()V

    return-void
.end method

.method protected onDetachedFromWindow()V
    .registers 1

    invoke-virtual {p0}, Linv/systemui/dynamic/InvEqualizerView;->stop()V

    invoke-super {p0}, Landroid/view/View;->onDetachedFromWindow()V

    return-void
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 10

    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v1

    if-lez v0, :cond_4f

    if-lez v1, :cond_4f

    int-to-float v2, v0

    int-to-float v3, v1

    iget-object v4, p0, Linv/systemui/dynamic/InvEqualizerView;->mRect:Landroid/graphics/RectF;

    const/4 v5, 0x0

    invoke-virtual {v4, v5, v5, v2, v3}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    int-to-float v0, v0

    const v1, 0x3e8f5c29  # 0.28f

    mul-float/2addr v0, v1

    iget-object v1, p0, Linv/systemui/dynamic/InvEqualizerView;->mRect:Landroid/graphics/RectF;

    iget-object v2, p0, Linv/systemui/dynamic/InvEqualizerView;->mBgPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v1, v0, v0, v2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0, p1, v1, v2}, Linv/systemui/dynamic/InvEqualizerView;->drawOneBar(Landroid/graphics/Canvas;IF)V

    const/4 v1, 0x1

    const v2, 0x3fa66666  # 1.3f

    invoke-direct {p0, p1, v1, v2}, Linv/systemui/dynamic/InvEqualizerView;->drawOneBar(Landroid/graphics/Canvas;IF)V

    const/4 v1, 0x2

    const v2, 0x4019999a  # 2.4f

    invoke-direct {p0, p1, v1, v2}, Linv/systemui/dynamic/InvEqualizerView;->drawOneBar(Landroid/graphics/Canvas;IF)V

    const/4 v1, 0x3

    const v2, 0x40666666  # 3.6f

    invoke-direct {p0, p1, v1, v2}, Linv/systemui/dynamic/InvEqualizerView;->drawOneBar(Landroid/graphics/Canvas;IF)V

    const/4 v1, 0x4

    const v2, 0x4099999a  # 4.8f

    invoke-direct {p0, p1, v1, v2}, Linv/systemui/dynamic/InvEqualizerView;->drawOneBar(Landroid/graphics/Canvas;IF)V

    const/4 v1, 0x5

    const v2, 0x40c33333  # 6.1f

    invoke-direct {p0, p1, v1, v2}, Linv/systemui/dynamic/InvEqualizerView;->drawOneBar(Landroid/graphics/Canvas;IF)V

    :cond_4f
    return-void
.end method

.method public run()V
    .registers 5

    iget-boolean v0, p0, Linv/systemui/dynamic/InvEqualizerView;->mRunning:Z

    if-eqz v0, :cond_24

    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_1f

    iget v0, p0, Linv/systemui/dynamic/InvEqualizerView;->mPhase:F

    const v1, 0x3e3851ec  # 0.18f

    add-float/2addr v0, v1

    const v1, 0x40c90fdb

    cmpl-float v2, v0, v1

    if-lez v2, :cond_18

    sub-float/2addr v0, v1

    :cond_18
    iput v0, p0, Linv/systemui/dynamic/InvEqualizerView;->mPhase:F

    sput v0, Linv/systemui/dynamic/InvEqualizerView;->sGlobalPhase:F

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    :cond_1f
    const-wide/16 v0, 0x26

    invoke-virtual {p0, p0, v0, v1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_24
    return-void
.end method

.method public setAlbumArtColor(Landroid/graphics/Bitmap;)V
    .registers 13

    if-eqz p1, :cond_89

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v0

    if-nez v0, :cond_89

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v0

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v1

    if-lez v0, :cond_89

    if-lez v1, :cond_89

    const/4 v2, -0x1

    const/4 v3, -0x1

    div-int/lit8 v4, v0, 0x2

    div-int/lit8 v5, v1, 0x2

    invoke-virtual {p1, v4, v5}, Landroid/graphics/Bitmap;->getPixel(II)I

    move-result v6

    invoke-static {v6}, Linv/systemui/dynamic/InvEqualizerView;->scoreLightVibrant(I)I

    move-result v7

    if-le v7, v3, :cond_26

    move v3, v7

    move v2, v6

    :cond_26
    div-int/lit8 v4, v0, 0x4

    div-int/lit8 v5, v1, 0x4

    invoke-virtual {p1, v4, v5}, Landroid/graphics/Bitmap;->getPixel(II)I

    move-result v6

    invoke-static {v6}, Linv/systemui/dynamic/InvEqualizerView;->scoreLightVibrant(I)I

    move-result v7

    if-le v7, v3, :cond_36

    move v3, v7

    move v2, v6

    :cond_36
    mul-int/lit8 v4, v0, 0x3

    div-int/lit8 v4, v4, 0x4

    div-int/lit8 v5, v1, 0x4

    invoke-virtual {p1, v4, v5}, Landroid/graphics/Bitmap;->getPixel(II)I

    move-result v6

    invoke-static {v6}, Linv/systemui/dynamic/InvEqualizerView;->scoreLightVibrant(I)I

    move-result v7

    if-le v7, v3, :cond_48

    move v3, v7

    move v2, v6

    :cond_48
    div-int/lit8 v4, v0, 0x4

    mul-int/lit8 v5, v1, 0x3

    div-int/lit8 v5, v5, 0x4

    invoke-virtual {p1, v4, v5}, Landroid/graphics/Bitmap;->getPixel(II)I

    move-result v6

    invoke-static {v6}, Linv/systemui/dynamic/InvEqualizerView;->scoreLightVibrant(I)I

    move-result v7

    if-le v7, v3, :cond_5a

    move v3, v7

    move v2, v6

    :cond_5a
    mul-int/lit8 v4, v0, 0x3

    div-int/lit8 v4, v4, 0x4

    mul-int/lit8 v5, v1, 0x3

    div-int/lit8 v5, v5, 0x4

    invoke-virtual {p1, v4, v5}, Landroid/graphics/Bitmap;->getPixel(II)I

    move-result v6

    invoke-static {v6}, Linv/systemui/dynamic/InvEqualizerView;->scoreLightVibrant(I)I

    move-result v7

    if-le v7, v3, :cond_6d

    move v2, v6

    :cond_6d
    invoke-static {v2}, Linv/systemui/dynamic/InvEqualizerView;->makeLightVibrant(I)I

    move-result v0

    iput v0, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarTopColor:I

    invoke-static {v2}, Linv/systemui/dynamic/InvEqualizerView;->makeIosBottomColor(I)I

    move-result v0

    iput v0, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarBottomColor:I

    invoke-static {v2}, Linv/systemui/dynamic/InvEqualizerView;->makeIosGlowColor(I)I

    move-result v0

    iput v0, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarGlowColor:I

    const/4 v0, 0x0

    iget-object v1, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarPaint:Landroid/graphics/Paint;

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void

    :cond_89
    const/4 v0, -0x1

    iput v0, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarTopColor:I

    const v0, -0x222223

    iput v0, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarBottomColor:I

    const v0, 0x66ffffff

    iput v0, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarGlowColor:I

    const/4 v0, 0x0

    iget-object v1, p0, Linv/systemui/dynamic/InvEqualizerView;->mBarPaint:Landroid/graphics/Paint;

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public start()V
    .registers 3

    iget-boolean v0, p0, Linv/systemui/dynamic/InvEqualizerView;->mRunning:Z

    if-nez v0, :cond_11

    sget v1, Linv/systemui/dynamic/InvEqualizerView;->sGlobalPhase:F

    iput v1, p0, Linv/systemui/dynamic/InvEqualizerView;->mPhase:F

    const/4 v0, 0x1

    iput-boolean v0, p0, Linv/systemui/dynamic/InvEqualizerView;->mRunning:Z

    invoke-virtual {p0, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    invoke-virtual {p0, p0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_11
    return-void
.end method

.method public stop()V
    .registers 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/systemui/dynamic/InvEqualizerView;->mRunning:Z

    invoke-virtual {p0, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method
