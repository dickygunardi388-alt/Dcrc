# classes2.dex

.class final Linv/systemui/dynamic/InvDynamicIslandView$HideViewRunnable;
.super Ljava/lang/Object;
.source "InvDynamicIslandView.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final mTarget:Landroid/view/View;


# direct methods
.method constructor <init>(Landroid/view/View;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/systemui/dynamic/InvDynamicIslandView$HideViewRunnable;->mTarget:Landroid/view/View;

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView$HideViewRunnable;->mTarget:Landroid/view/View;

    if-eqz v0, :cond_19

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/high16 v1, 0x3f800000  # 1.0f

    invoke-virtual {v0, v1}, Landroid/view/View;->setAlpha(F)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationX(F)V

    const/high16 v1, 0x3f800000  # 1.0f

    invoke-virtual {v0, v1}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setScaleY(F)V

    :cond_19
    return-void
.end method
