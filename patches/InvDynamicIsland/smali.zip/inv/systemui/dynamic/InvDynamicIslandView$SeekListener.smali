# classes2.dex

.class Linv/systemui/dynamic/InvDynamicIslandView$SeekListener;
.super Ljava/lang/Object;
.source "InvDynamicIslandView.java"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# instance fields
.field private final mView:Linv/systemui/dynamic/InvDynamicIslandView;


# direct methods
.method public constructor <init>(Linv/systemui/dynamic/InvDynamicIslandView;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/systemui/dynamic/InvDynamicIslandView$SeekListener;->mView:Linv/systemui/dynamic/InvDynamicIslandView;

    return-void
.end method


# virtual methods
.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .registers 5

    if-eqz p3, :cond_9

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView$SeekListener;->mView:Linv/systemui/dynamic/InvDynamicIslandView;

    if-eqz v0, :cond_9

    invoke-virtual {v0, p2}, Linv/systemui/dynamic/InvDynamicIslandView;->seekToProgress(I)V

    :cond_9
    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 2

    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 2

    return-void
.end method
