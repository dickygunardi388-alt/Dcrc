# classes2.dex

.class public Linv/systemui/dynamic/InvDynamicIslandView$ProgressRunnable;
.super Ljava/lang/Object;
.source "InvDynamicIslandView.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final mView:Linv/systemui/dynamic/InvDynamicIslandView;


# direct methods
.method public constructor <init>(Linv/systemui/dynamic/InvDynamicIslandView;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/systemui/dynamic/InvDynamicIslandView$ProgressRunnable;->mView:Linv/systemui/dynamic/InvDynamicIslandView;

    return-void
.end method


# virtual methods
.method public run()V
    .registers 2

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView$ProgressRunnable;->mView:Linv/systemui/dynamic/InvDynamicIslandView;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Linv/systemui/dynamic/InvDynamicIslandView;->runMediaProgressTick()V

    :cond_7
    return-void
.end method
