# classes2.dex

.class public Linv/systemui/dynamic/InvDynamicIslandView;
.super Landroid/widget/FrameLayout;
.source "InvDynamicIslandView.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# static fields
.field private static final EXPANDED_MEDIA:I = 0x1

.field private static final EXPANDED_NONE:I = 0x0

.field private static final EXPANDED_RECORD:I = 0x2

.field private static final STATE_IDLE:I = 0x0

.field private static final STATE_MEDIA_COLLAPSED:I = 0x1

.field private static final STATE_MEDIA_EXPANDED:I = 0x2

.field private static sViews:Ljava/util/ArrayList;


# instance fields
.field private mAlbumArt:Landroid/graphics/Bitmap;

.field private mArtist:Ljava/lang/String;

.field private mBatteryReceiver:Landroid/content/BroadcastReceiver;

.field private mBtnNext:Landroid/widget/ImageView;

.field private mBtnPlayPause:Landroid/widget/ImageView;

.field private mBtnPrev:Landroid/widget/ImageView;

.field private mChargingActive:Z

.field private mChargingPercent:I

.field private mChargingPlugged:Z

.field private mChargingRunnable:Ljava/lang/Runnable;

.field private mCollapsedRoot:Landroid/view/View;

.field private mCurrentState:I

.field private mDuration:J

.field private mExpandedMode:I

.field private mExpandedRoot:Landroid/view/View;

.field private mHandler:Landroid/os/Handler;

.field private mHideAfterCollapse:Z

.field private mHost:Linv/systemui/dynamic/InvDynamicIslandView;

.field private mIsExpandedWindow:Z

.field private mKeepSharedMediaCollapse:Z

.field private mLowBatteryAlertShown:Z

.field private mMediaActive:Z

.field private mMediaManager:Lcom/android/systemui/statusbar/NotificationMediaManager;

.field private mPauseHiddenUntilPlay:Z

.field private mPauseTicks:I

.field private mPowerRestoreMode:I

.field private mProgressRunnable:Ljava/lang/Runnable;

.field private mRecordActive:Z

.field private mRecordExpandedFromBubble:Z

.field private mRecordPauseBase:J

.field private mRecordPaused:Z

.field private mRecordPausedTotal:J

.field private mRecordRunnable:Ljava/lang/Runnable;

.field private mRecordStart:J

.field private mTitle:Ljava/lang/String;

.field private mWindowManager:Landroid/view/WindowManager;

.field private mWindowParams:Landroid/view/WindowManager$LayoutParams;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    sput-object v0, Linv/systemui/dynamic/InvDynamicIslandView;->sViews:Ljava/util/ArrayList;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Linv/systemui/dynamic/InvDynamicIslandView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4

    invoke-direct {p0, p1, p2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mIsExpandedWindow:Z

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mCurrentState:I

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseTicks:I

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHandler:Landroid/os/Handler;

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->initCollapsed()V

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;Z)V
    .registers 4

    invoke-direct {p0, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-boolean p2, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mIsExpandedWindow:Z

    const/4 v0, 0x2

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mCurrentState:I

    const/4 v0, 0x1

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHideAfterCollapse:Z

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHandler:Landroid/os/Handler;

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->initExpanded()V

    return-void
.end method

.method private applyAutoSharedBubbleLayout()V
    .registers 12

    const-string v0, "inv_island_panel"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    const-string v1, "inv_second_bubble"

    invoke-direct {p0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v1

    if-eqz v0, :cond_6c

    if-eqz v1, :cond_6c

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    const/16 v4, 0x96

    invoke-direct {p0, v4}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v4

    if-eqz v2, :cond_25

    iget v5, v2, Landroid/view/ViewGroup$LayoutParams;->width:I

    if-lez v5, :cond_25

    move v4, v5

    :cond_25
    const/16 v5, 0x26

    invoke-direct {p0, v5}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v5

    if-eqz v3, :cond_32

    iget v6, v3, Landroid/view/ViewGroup$LayoutParams;->width:I

    if-lez v6, :cond_32

    move v5, v6

    :cond_32
    const/4 v6, 0x4

    invoke-direct {p0, v6}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v6

    add-int v7, v4, v5

    add-int/2addr v7, v6

    const/16 v8, 0x26

    invoke-direct {p0, v8}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v8

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v9

    if-eqz v9, :cond_4d

    iput v7, v9, Landroid/view/ViewGroup$LayoutParams;->width:I

    iput v8, v9, Landroid/view/ViewGroup$LayoutParams;->height:I

    invoke-virtual {p0, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_4d
    add-int v9, v5, v6

    div-int/lit8 v9, v9, 0x2

    neg-int v9, v9

    int-to-float v9, v9

    invoke-virtual {v0, v9}, Landroid/view/View;->setTranslationX(F)V

    add-int v10, v4, v6

    div-int/lit8 v10, v10, 0x2

    int-to-float v10, v10

    invoke-virtual {v1, v10}, Landroid/view/View;->setTranslationX(F)V

    const/4 v10, 0x0

    int-to-float v10, v10

    invoke-virtual {v1, v10}, Landroid/view/View;->setTranslationY(F)V

    invoke-virtual {v1}, Landroid/view/View;->bringToFront()V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    :cond_6c
    return-void
.end method

.method private applyChargingFullWidth()V
    .registers 7

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v1, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    const/16 v2, 0x20

    invoke-direct {p0, v2}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v2

    const/4 v3, 0x2

    mul-int/2addr v2, v3

    sub-int/2addr v1, v2

    const/16 v2, 0x30

    invoke-direct {p0, v2}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v2

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->beginTransition()V

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    if-eqz v3, :cond_29

    iput v1, v3, Landroid/view/ViewGroup$LayoutParams;->width:I

    iput v2, v3, Landroid/view/ViewGroup$LayoutParams;->height:I

    invoke-virtual {p0, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_29
    invoke-direct {p0, v1, v2}, Linv/systemui/dynamic/InvDynamicIslandView;->applyPanelSizePx(II)V

    const/4 v3, 0x0

    invoke-direct {p0, v3}, Linv/systemui/dynamic/InvDynamicIslandView;->setPanelTranslationDp(I)V

    return-void
.end method

.method private applyChargingNotification(ZI)V
    .registers 3

    iput p2, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPercent:I

    if-eqz p1, :cond_8

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showChargingCollapsed()V

    return-void

    :cond_8
    iget-boolean p1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingActive:Z

    if-eqz p1, :cond_f

    invoke-virtual {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->runChargingHide()V

    :cond_f
    return-void
.end method

.method private applyMedia(Landroid/media/MediaMetadata;I)V
    .registers 5

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mIsExpandedWindow:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    if-eqz p1, :cond_69

    const/4 v0, 0x1

    if-ne p2, v0, :cond_b

    goto :goto_69

    :cond_b
    const-string v0, "android.media.metadata.TITLE"

    invoke-virtual {p1, v0}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mTitle:Ljava/lang/String;

    const-string v0, "android.media.metadata.ARTIST"

    invoke-virtual {p1, v0}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mArtist:Ljava/lang/String;

    const-string v0, "android.media.metadata.ART"

    invoke-virtual {p1, v0}, Landroid/media/MediaMetadata;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    if-eqz v0, :cond_24

    goto :goto_2a

    :cond_24
    const-string v0, "android.media.metadata.ALBUM_ART"

    invoke-virtual {p1, v0}, Landroid/media/MediaMetadata;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    :goto_2a
    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mAlbumArt:Landroid/graphics/Bitmap;

    const-string v0, "android.media.metadata.DURATION"

    invoke-virtual {p1, v0}, Landroid/media/MediaMetadata;->getLong(Ljava/lang/String;)J

    move-result-wide v0

    iput-wide v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mDuration:J

    const/4 v0, 0x3

    if-ne p2, v0, :cond_42

    const/4 v0, 0x1

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    const/4 v0, 0x0

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseTicks:I

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHideAfterCollapse:Z

    goto :goto_4a

    :cond_42
    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-eqz v0, :cond_4a

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showIdleCollapsed()V

    return-void

    :cond_4a
    :goto_4a
    const/4 v0, 0x2

    if-ne p2, v0, :cond_50

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->schedulePauseHideDelayed()V

    :cond_50
    iget v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mCurrentState:I

    if-eqz v0, :cond_5b

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->bindCollapsedContent()V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->updateExpandedWindowContent()V

    return-void

    :cond_5b
    const/4 v0, 0x3

    if-ne p2, v0, :cond_68

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showMediaCollapsed()V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->bindCollapsedContent()V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->updateExpandedWindowContent()V

    return-void

    :cond_68
    return-void

    :cond_69
    :goto_69
    const/4 v0, 0x0

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mTitle:Ljava/lang/String;

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mArtist:Ljava/lang/String;

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mAlbumArt:Landroid/graphics/Bitmap;

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mDuration:J

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    invoke-virtual {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->hideExpandedWindow()V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showIdleCollapsed()V

    return-void
.end method

.method private applyOwnSize(II)V
    .registers 5

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->beginTransition()V

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    if-eqz v0, :cond_1e

    invoke-direct {p0, p1}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v1

    iput v1, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    invoke-direct {p0, p2}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v1

    iput v1, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    invoke-virtual {p0, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    :cond_1e
    return-void
.end method

.method private applyPanelRadius(F)V
    .registers 9

    const-string v0, "inv_island_panel"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_27

    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    instance-of v2, v1, Landroid/graphics/drawable/GradientDrawable;

    if-eqz v2, :cond_27

    check-cast v1, Landroid/graphics/drawable/GradientDrawable;

    const/16 v2, 0x15

    invoke-direct {p0, v2}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v2

    const/16 v3, 0x26

    invoke-direct {p0, v3}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v3

    sub-int v4, v3, v2

    int-to-float v4, v4

    mul-float/2addr v4, p1

    int-to-float v5, v2

    add-float/2addr v5, v4

    invoke-virtual {v1, v5}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    :cond_27
    return-void
.end method

.method private applyPanelSizeDp(II)V
    .registers 5

    invoke-direct {p0, p1}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v0

    invoke-direct {p0, p2}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v1

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyPanelSizePx(II)V

    return-void
.end method

.method private applyPanelSizePx(II)V
    .registers 5

    const-string v0, "inv_island_panel"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_1b

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    if-eqz v1, :cond_1b

    iput p1, v1, Landroid/view/ViewGroup$LayoutParams;->width:I

    iput p2, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0}, Landroid/view/View;->requestLayout()V

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_1b
    return-void
.end method

.method private applyPowerNoticeMorphProgress(F)V
    .registers 14

    invoke-direct {p0, p1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyPanelRadius(F)V

    iget v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPowerRestoreMode:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_b

    const/16 v0, 0x8c

    goto :goto_20

    :cond_b
    const/4 v1, 0x1

    if-ne v0, v1, :cond_18

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v1, :cond_15

    const/16 v0, 0xd2

    goto :goto_20

    :cond_15
    const/16 v0, 0x96

    goto :goto_20

    :cond_18
    const/4 v1, 0x3

    if-ne v0, v1, :cond_1e

    const/16 v0, 0xd2

    goto :goto_20

    :cond_1e
    const/16 v0, 0x64

    :goto_20
    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v0

    const/16 v1, 0x26

    invoke-direct {p0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v1

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->widthPixels:I

    const/16 v3, 0x20

    invoke-direct {p0, v3}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v3

    mul-int/lit8 v3, v3, 0x2

    sub-int/2addr v2, v3

    const/16 v3, 0x30

    invoke-direct {p0, v3}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v3

    sub-int v4, v2, v0

    int-to-float v4, v4

    mul-float/2addr v4, p1

    int-to-float v5, v0

    add-float/2addr v5, v4

    float-to-int v5, v5

    sub-int v6, v3, v1

    int-to-float v6, v6

    mul-float/2addr v6, p1

    int-to-float v7, v1

    add-float/2addr v7, v6

    float-to-int v7, v7

    invoke-direct {p0, v5, v7}, Linv/systemui/dynamic/InvDynamicIslandView;->applyPanelSizePx(II)V

    const-string v8, "inv_island_panel"

    invoke-direct {p0, v8}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v9

    if-eqz v9, :cond_74

    const/4 v10, 0x0

    int-to-float v10, v10

    invoke-virtual {v9, v10}, Landroid/view/View;->setTranslationX(F)V

    const/16 v10, 0x8

    invoke-direct {p0, v10}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v10

    int-to-float v10, v10

    mul-float/2addr v10, p1

    invoke-virtual {v9, v10}, Landroid/view/View;->setTranslationY(F)V

    const/high16 v11, 0x3f800000  # 1.0f

    invoke-virtual {v9, v11}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v9, v11}, Landroid/view/View;->setScaleY(F)V

    :cond_74
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showChargingPowerContent()V

    const/high16 v10, 0x3f800000  # 1.0f

    sub-float/2addr v10, p1

    const-string v8, "inv_collapsed_content"

    invoke-direct {p0, v8}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v9

    if-eqz v9, :cond_8e

    invoke-virtual {v9, v10}, Landroid/view/View;->setAlpha(F)V

    cmpl-float v11, p1, v10

    if-lez v11, :cond_8e

    const/16 v11, 0x8

    invoke-virtual {v9, v11}, Landroid/view/View;->setVisibility(I)V

    :cond_8e
    const-string v8, "inv_second_bubble"

    invoke-direct {p0, v8}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v9

    if-eqz v9, :cond_a7

    iget v11, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPowerRestoreMode:I

    const/4 v7, 0x3

    if-ne v11, v7, :cond_a2

    invoke-virtual {v9, v10}, Landroid/view/View;->setAlpha(F)V

    cmpl-float v11, p1, v10

    if-lez v11, :cond_a7

    :cond_a2
    const/16 v11, 0x8

    invoke-virtual {v9, v11}, Landroid/view/View;->setVisibility(I)V

    :cond_a7
    const-string v8, "inv_power_notice_content"

    invoke-direct {p0, v8}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v9

    if-eqz v9, :cond_b2

    invoke-virtual {v9, p1}, Landroid/view/View;->setAlpha(F)V

    :cond_b2
    return-void
.end method

.method private applyRecordMorphProgress(F)V
    .registers 14

    invoke-direct {p0, p1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyPanelRadius(F)V

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordExpandedFromBubble:Z

    if-eqz v0, :cond_1a

    const/16 v0, 0x26

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v0

    const/16 v1, 0x26

    invoke-direct {p0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v1

    const/16 v2, 0x4d

    invoke-direct {p0, v2}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v2

    goto :goto_27

    :cond_1a
    const/16 v0, 0x8c

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v0

    const/16 v1, 0x26

    invoke-direct {p0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v1

    const/4 v2, 0x0

    :goto_27
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->getExpandedWidth()I

    move-result v3

    const/16 v4, 0x50

    invoke-direct {p0, v4}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v4

    sub-int v5, v3, v0

    int-to-float v5, v5

    mul-float/2addr v5, p1

    int-to-float v6, v0

    add-float/2addr v6, v5

    float-to-int v6, v6

    sub-int v5, v4, v1

    int-to-float v5, v5

    mul-float/2addr v5, p1

    int-to-float v7, v1

    add-float/2addr v7, v5

    float-to-int v7, v7

    invoke-direct {p0, v6, v7}, Linv/systemui/dynamic/InvDynamicIslandView;->applyPanelSizePx(II)V

    const-string v8, "inv_island_panel"

    invoke-direct {p0, v8}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v8

    if-eqz v8, :cond_66

    int-to-float v9, v2

    const/high16 v10, 0x3f800000  # 1.0f

    sub-float v10, v10, p1

    mul-float/2addr v9, v10

    invoke-virtual {v8, v9}, Landroid/view/View;->setTranslationX(F)V

    const/16 v9, 0x8

    invoke-direct {p0, v9}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v9

    int-to-float v9, v9

    mul-float/2addr v9, p1

    invoke-virtual {v8, v9}, Landroid/view/View;->setTranslationY(F)V

    const/high16 v9, 0x3f800000  # 1.0f

    invoke-virtual {v8, v9}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v8, v9}, Landroid/view/View;->setScaleY(F)V

    :cond_66
    const-string v0, "inv_collapsed_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_87

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/high16 v1, 0x3f800000  # 1.0f

    sub-float/2addr v1, p1

    invoke-virtual {v0, v1}, Landroid/view/View;->setAlpha(F)V

    const/high16 v1, 0x3f800000  # 1.0f

    invoke-virtual {v0, v1}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setScaleY(F)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationX(F)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationY(F)V

    :cond_87
    const-string v0, "inv_record_dot"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_98

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    goto :goto_95

    const/4 v1, 0x0

    :goto_95
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_98
    const-string v0, "inv_record_time_collapsed"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_ab

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordExpandedFromBubble:Z

    if-eqz v1, :cond_a7

    const/16 v1, 0x8

    goto :goto_a8

    :cond_a7
    const/4 v1, 0x0

    :goto_a8
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_ab
    const-string v0, "inv_expanded_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_b8

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_b8
    const-string v0, "inv_second_bubble"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_c5

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_c5
    const-string v0, "inv_second_bubble_icon"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_d8

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordExpandedFromBubble:Z

    if-eqz v1, :cond_d3

    const/4 v1, 0x0

    goto :goto_d5

    :cond_d3
    const/16 v1, 0x8

    :goto_d5
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_d8
    const-string v0, "inv_album_collapsed"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_e5

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_e5
    const-string v0, "inv_equalizer_icon"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_f2

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_f2
    const-string v0, "inv_record_expanded_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_123

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v0, p1}, Landroid/view/View;->setAlpha(F)V

    const v2, 0x3f7ae148  # 0.98f

    const v3, 0x3ca3d70a  # 0.02f

    mul-float/2addr v3, p1

    add-float/2addr v2, v3

    invoke-virtual {v0, v2}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setScaleY(F)V

    const/4 v3, 0x0

    invoke-virtual {v0, v3}, Landroid/view/View;->setTranslationX(F)V

    const/4 v2, 0x3

    invoke-direct {p0, v2}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v2

    int-to-float v2, v2

    const/high16 v3, 0x3f800000  # 1.0f

    sub-float/2addr v3, p1

    mul-float/2addr v2, v3

    invoke-virtual {v0, v2}, Landroid/view/View;->setTranslationY(F)V

    invoke-virtual {v0}, Landroid/view/View;->bringToFront()V

    :cond_123
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->updateRecordTimeViews()V

    return-void
.end method

.method private applyScreenRecord(Z)V
    .registers 7

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mIsExpandedWindow:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    iput-boolean p1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz p1, :cond_27

    iget-wide v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordStart:J

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    if-nez v4, :cond_17

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordStart:J

    :cond_17
    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    if-eqz v0, :cond_1f

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-eqz v0, :cond_23

    :cond_1f
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showRecordCollapsedPill()V

    return-void

    :cond_23
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showMediaCollapsed()V

    return-void

    :cond_27
    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mKeepSharedMediaCollapse:Z

    if-eqz v0, :cond_32

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->stopRecordTimerLoop()V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showMediaCollapsed()V

    return-void

    :cond_32
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordStart:J

    iput-wide v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPauseBase:J

    iput-wide v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPausedTotal:J

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPaused:Z

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->stopRecordTimerLoop()V

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    if-eqz v1, :cond_4f

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-eqz v1, :cond_4b

    goto :goto_4f

    :cond_4b
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showMediaCollapsed()V

    return-void

    :cond_4f
    :goto_4f
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showIdleCollapsed()V

    return-void
.end method

.method private applyScreenRecordPaused(Z)V
    .registers 4

    return-void
.end method

.method private applySharedMediaMorphAnchor(FI)V
    .registers 14

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v0, :cond_72

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-nez v0, :cond_72

    const-string v0, "inv_island_panel"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_72

    const-string v1, "inv_second_bubble"

    invoke-direct {p0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v1

    const/16 v2, 0x4

    invoke-direct {p0, v2}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v2

    const/16 v3, 0x26

    invoke-direct {p0, v3}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v3

    if-eqz v1, :cond_2f

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    if-eqz v4, :cond_2f

    iget v5, v4, Landroid/view/ViewGroup$LayoutParams;->width:I

    if-lez v5, :cond_2f

    move v3, v5

    :cond_2f
    add-int v8, p2, v3

    add-int/2addr v8, v2

    const/16 v9, 0x26

    invoke-direct {p0, v9}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v9

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v10

    if-eqz v10, :cond_45

    iput v8, v10, Landroid/view/ViewGroup$LayoutParams;->width:I

    iput v9, v10, Landroid/view/ViewGroup$LayoutParams;->height:I

    invoke-virtual {p0, v10}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_45
    add-int v5, v3, v2

    div-int/lit8 v5, v5, 0x2

    int-to-float v5, v5

    neg-float v5, v5

    const/high16 v6, 0x3f800000  # 1.0f

    sub-float/2addr v6, p1

    mul-float/2addr v5, v6

    invoke-virtual {v0, v5}, Landroid/view/View;->setTranslationX(F)V

    if-eqz v1, :cond_72

    add-int v7, p2, v2

    div-int/lit8 v7, v7, 0x2

    int-to-float v7, v7

    add-int v8, v3, v2

    div-int/lit8 v8, v8, 0x2

    int-to-float v8, v8

    mul-float/2addr v8, p1

    add-float/2addr v7, v8

    invoke-virtual {v1, v7}, Landroid/view/View;->setTranslationX(F)V

    const/4 v7, 0x0

    int-to-float v7, v7

    invoke-virtual {v1, v7}, Landroid/view/View;->setTranslationY(F)V

    const v7, 0x3d23d70a  # 0.04f

    cmpg-float v7, p1, v7

    if-gez v7, :cond_72

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->applyAutoSharedBubbleLayout()V

    :cond_72
    return-void
.end method

.method private beginTransition()V
    .registers 1

    return-void
.end method

.method private bindCollapsedContent()V
    .registers 4

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mAlbumArt:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_1d

    const-string v1, "inv_album_collapsed"

    invoke-direct {p0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v1

    instance-of v2, v1, Landroid/widget/ImageView;

    if-eqz v2, :cond_1d

    check-cast v1, Landroid/widget/ImageView;

    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/view/View;->setClipToOutline(Z)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {v1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_1d
    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mAlbumArt:Landroid/graphics/Bitmap;

    const-string v1, "inv_equalizer_icon"

    invoke-direct {p0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v1

    instance-of v2, v1, Linv/systemui/dynamic/InvEqualizerView;

    if-eqz v2, :cond_2e

    check-cast v1, Linv/systemui/dynamic/InvEqualizerView;

    invoke-virtual {v1, v0}, Linv/systemui/dynamic/InvEqualizerView;->setAlbumArtColor(Landroid/graphics/Bitmap;)V

    :cond_2e
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->bindRecordCollapsedContent()V

    return-void
.end method

.method private bindExpandedContent()V
    .registers 5

    iget v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_9

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->bindRecordExpandedContent()V

    return-void

    :cond_9
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->hideRecordExpandedContent()V

    const-string v0, "inv_media_top_row"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_18

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_18
    const-string v0, "inv_media_progress_row"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_24

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_24
    const-string v0, "inv_media_controls"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_30

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_30
    const-string v0, "inv_media_title"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    instance-of v1, v0, Landroid/widget/TextView;

    if-eqz v1, :cond_56

    iget-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mTitle:Ljava/lang/String;

    if-eqz v1, :cond_56

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setSingleLine(Z)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setHorizontallyScrolling(Z)V

    sget-object v2, Landroid/text/TextUtils$TruncateAt;->MARQUEE:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setSelected(Z)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationX(F)V

    :cond_56
    const-string v0, "inv_media_artist"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    instance-of v1, v0, Landroid/widget/TextView;

    if-eqz v1, :cond_7c

    iget-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mArtist:Ljava/lang/String;

    if-eqz v1, :cond_7c

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setSingleLine(Z)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setHorizontallyScrolling(Z)V

    sget-object v2, Landroid/text/TextUtils$TruncateAt;->MARQUEE:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setSelected(Z)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationX(F)V

    :cond_7c
    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mAlbumArt:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_93

    const-string v1, "inv_album_collapsed"

    invoke-direct {p0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v1

    instance-of v2, v1, Landroid/widget/ImageView;

    if-eqz v2, :cond_93

    check-cast v1, Landroid/widget/ImageView;

    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/view/View;->setClipToOutline(Z)V

    :cond_93
    const-string v0, "inv_album_collapsed"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_ab

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/high16 v1, 0x3f800000  # 1.0f

    invoke-virtual {v0, v1}, Landroid/view/View;->setAlpha(F)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_ab
    const-string v0, "inv_equalizer_icon"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_c5

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/high16 v1, 0x3f800000  # 1.0f

    invoke-virtual {v0, v1}, Landroid/view/View;->setAlpha(F)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setScaleY(F)V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->startEqualizerNow()V

    :cond_c5
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->initMediaSession()V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->bindMediaButtons()V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->updateTimeViews()V

    return-void
.end method

.method private bindMediaButtons()V
    .registers 4

    const-string v0, "inv_media_prev"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    instance-of v1, v0, Landroid/widget/ImageView;

    if-eqz v1, :cond_15

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mBtnPrev:Landroid/widget/ImageView;

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_15
    const-string v0, "inv_media_play_pause"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    instance-of v1, v0, Landroid/widget/ImageView;

    if-eqz v1, :cond_2a

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mBtnPlayPause:Landroid/widget/ImageView;

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_2a
    const-string v0, "inv_media_next"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    instance-of v1, v0, Landroid/widget/ImageView;

    if-eqz v1, :cond_3f

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mBtnNext:Landroid/widget/ImageView;

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_3f
    const-string v0, "inv_media_seekbar"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    instance-of v1, v0, Landroid/widget/SeekBar;

    if-eqz v1, :cond_64

    check-cast v0, Landroid/widget/SeekBar;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setThumb(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setThumbOffset(I)V

    invoke-virtual {v0, v1}, Landroid/widget/AbsSeekBar;->setSplitTrack(Z)V

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Landroid/widget/SeekBar;->setEnabled(Z)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setClickable(Z)V

    new-instance v1, Linv/systemui/dynamic/InvDynamicIslandView$SeekListener;

    invoke-direct {v1, p0}, Linv/systemui/dynamic/InvDynamicIslandView$SeekListener;-><init>(Linv/systemui/dynamic/InvDynamicIslandView;)V

    invoke-virtual {v0, v1}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    :cond_64
    return-void
.end method

.method private bindRecordCollapsedContent()V
    .registers 6

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-nez v0, :cond_6

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mKeepSharedMediaCollapse:Z

    :cond_6
    const-string v1, "inv_record_dot"

    invoke-direct {p0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v1

    const-string v2, "inv_record_time_collapsed"

    invoke-direct {p0, v2}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v2

    const-string v3, "inv_second_bubble"

    invoke-direct {p0, v3}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v3

    iget-boolean v4, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mIsExpandedWindow:Z

    if-eqz v4, :cond_32

    if-eqz v1, :cond_23

    const/16 v4, 0x8

    invoke-virtual {v1, v4}, Landroid/view/View;->setVisibility(I)V

    :cond_23
    if-eqz v2, :cond_2a

    const/16 v4, 0x8

    invoke-virtual {v2, v4}, Landroid/view/View;->setVisibility(I)V

    :cond_2a
    if-eqz v3, :cond_31

    const/16 v4, 0x8

    invoke-virtual {v3, v4}, Landroid/view/View;->setVisibility(I)V

    :cond_31
    return-void

    :cond_32
    if-eqz v0, :cond_8d

    iget v4, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    const/4 v0, 0x1

    if-ne v4, v0, :cond_68

    iget-boolean v4, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    if-eqz v4, :cond_68

    iget-boolean v4, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-eqz v4, :cond_42

    goto :goto_68

    :cond_42
    iget-object v4, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mTitle:Ljava/lang/String;

    if-eqz v4, :cond_68

    if-eqz v3, :cond_59

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Landroid/view/View;->setVisibility(I)V

    const/4 v4, 0x1

    invoke-virtual {v3, v4}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {v3, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->applyAutoSharedBubbleLayout()V

    invoke-virtual {v3}, Landroid/view/View;->bringToFront()V

    :cond_59
    if-eqz v1, :cond_60

    const/16 v4, 0x8

    invoke-virtual {v1, v4}, Landroid/view/View;->setVisibility(I)V

    :cond_60
    if-eqz v2, :cond_a2

    const/16 v4, 0x8

    invoke-virtual {v2, v4}, Landroid/view/View;->setVisibility(I)V

    goto :goto_a2

    :cond_68
    :goto_68
    if-eqz v3, :cond_6f

    const/16 v4, 0x8

    invoke-virtual {v3, v4}, Landroid/view/View;->setVisibility(I)V

    :cond_6f
    if-eqz v1, :cond_7c

    const/4 v4, 0x0

    invoke-virtual {v1, v4}, Landroid/view/View;->setVisibility(I)V

    const/4 v4, 0x1

    invoke-virtual {v1, v4}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {v1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_7c
    if-eqz v2, :cond_89

    const/4 v4, 0x0

    invoke-virtual {v2, v4}, Landroid/view/View;->setVisibility(I)V

    const/4 v4, 0x1

    invoke-virtual {v2, v4}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {v2, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_89
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->updateRecordTimeViews()V

    goto :goto_a2

    :cond_8d
    if-eqz v1, :cond_94

    const/16 v4, 0x8

    invoke-virtual {v1, v4}, Landroid/view/View;->setVisibility(I)V

    :cond_94
    if-eqz v2, :cond_9b

    const/16 v4, 0x8

    invoke-virtual {v2, v4}, Landroid/view/View;->setVisibility(I)V

    :cond_9b
    if-eqz v3, :cond_a2

    const/16 v4, 0x8

    invoke-virtual {v3, v4}, Landroid/view/View;->setVisibility(I)V

    :cond_a2
    :goto_a2
    return-void
.end method

.method private bindRecordExpandedContent()V
    .registers 4

    const-string v0, "inv_collapsed_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_d

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_d
    const-string v0, "inv_expanded_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_1a

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_1a
    const-string v0, "inv_second_bubble"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_27

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_27
    const-string v0, "inv_album_collapsed"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_34

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_34
    const-string v0, "inv_equalizer_icon"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_68

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const-string v0, "inv_media_progress_row"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_4e

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_4e
    const-string v0, "inv_media_controls"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_5b

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_5b
    const-string v0, "inv_media_top_row"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_68

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_68
    const-string v0, "inv_record_expanded_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_84

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setAlpha(F)V

    const v1, 0x3f7ae148  # 0.98f

    invoke-virtual {v0, v1}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setScaleY(F)V

    invoke-virtual {v0}, Landroid/view/View;->bringToFront()V

    :cond_84
    const-string v0, "inv_record_stop"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_93

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_93
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->updateRecordTimeViews()V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->startRecordTimerLoop()V

    return-void
.end method

.method private capturePowerRestoreState()V
    .registers 3

    const/4 v0, 0x0

    iget v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mCurrentState:I

    if-eqz v1, :cond_4b

    iget v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    const/4 v0, 0x2

    if-ne v1, v0, :cond_f

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v1, :cond_4a

    goto :goto_4b

    :cond_f
    const/4 v0, 0x1

    if-ne v1, v0, :cond_20

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-eqz v1, :cond_17

    goto :goto_4a

    :cond_17
    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    if-eqz v1, :cond_4a

    iget-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mTitle:Ljava/lang/String;

    if-eqz v1, :cond_4a

    goto :goto_4b

    :cond_20
    const/4 v0, 0x3

    if-ne v1, v0, :cond_35

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-eqz v1, :cond_28

    goto :goto_4a

    :cond_28
    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v1, :cond_4a

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    if-eqz v1, :cond_4a

    iget-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mTitle:Ljava/lang/String;

    if-eqz v1, :cond_4a

    goto :goto_4b

    :cond_35
    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v1, :cond_3b

    const/4 v0, 0x2

    goto :goto_4b

    :cond_3b
    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-eqz v1, :cond_40

    goto :goto_4a

    :cond_40
    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    if-eqz v1, :cond_4a

    iget-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mTitle:Ljava/lang/String;

    if-eqz v1, :cond_4a

    const/4 v0, 0x1

    goto :goto_4b

    :cond_4a
    :goto_4a
    const/4 v0, 0x0

    :cond_4b
    :goto_4b
    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPowerRestoreMode:I

    return-void
.end method

.method private computeCurrentPosition(Landroid/media/session/PlaybackState;)J
    .registers 10

    invoke-virtual {p1}, Landroid/media/session/PlaybackState;->getPosition()J

    move-result-wide v0

    invoke-virtual {p1}, Landroid/media/session/PlaybackState;->getState()I

    move-result v2

    const/4 v3, 0x3

    if-ne v2, v3, :cond_21

    invoke-virtual {p1}, Landroid/media/session/PlaybackState;->getLastPositionUpdateTime()J

    move-result-wide v3

    const-wide/16 v5, 0x0

    cmp-long v7, v3, v5

    if-lez v7, :cond_21

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v5

    sub-long/2addr v5, v3

    const-wide/16 v3, 0x0

    cmp-long v7, v5, v3

    if-lez v7, :cond_21

    add-long/2addr v0, v5

    :cond_21
    return-wide v0
.end method

.method public static dispatchCharging(ZI)V
    .registers 5

    sget-object v0, Linv/systemui/dynamic/InvDynamicIslandView;->sViews:Ljava/util/ArrayList;

    if-eqz v0, :cond_1c

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_8
    :goto_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1c

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    instance-of v2, v1, Linv/systemui/dynamic/InvDynamicIslandView;

    if-eqz v2, :cond_8

    check-cast v1, Linv/systemui/dynamic/InvDynamicIslandView;

    invoke-direct {v1, p0, p1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyChargingNotification(ZI)V

    goto :goto_8

    :cond_1c
    return-void
.end method

.method public static dispatchMedia(Landroid/media/MediaMetadata;I)V
    .registers 7

    sget-object v0, Linv/systemui/dynamic/InvDynamicIslandView;->sViews:Ljava/util/ArrayList;

    if-eqz v0, :cond_19

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_9
    if-ge v2, v1, :cond_19

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Linv/systemui/dynamic/InvDynamicIslandView;

    if-eqz v3, :cond_16

    invoke-direct {v3, p0, p1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyMedia(Landroid/media/MediaMetadata;I)V

    :cond_16
    add-int/lit8 v2, v2, 0x1

    goto :goto_9

    :cond_19
    return-void
.end method

.method private dispatchMediaKeyFallback(I)V
    .registers 2

    return-void
.end method

.method public static dispatchScreenRecord(Z)V
    .registers 4

    sget-object v0, Linv/systemui/dynamic/InvDynamicIslandView;->sViews:Ljava/util/ArrayList;

    if-eqz v0, :cond_1c

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_8
    :goto_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1c

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    instance-of v2, v1, Linv/systemui/dynamic/InvDynamicIslandView;

    if-eqz v2, :cond_8

    check-cast v1, Linv/systemui/dynamic/InvDynamicIslandView;

    invoke-direct {v1, p0}, Linv/systemui/dynamic/InvDynamicIslandView;->applyScreenRecord(Z)V

    goto :goto_8

    :cond_1c
    return-void
.end method

.method public static dispatchScreenRecordPaused(Z)V
    .registers 1

    return-void
.end method

.method private dp(I)I
    .registers 4

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    int-to-float p1, p1

    iget v1, v0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, v1

    const/high16 v1, 0x3f000000  # 0.5f

    add-float/2addr p1, v1

    float-to-int p1, p1

    return p1
.end method

.method private find(Ljava/lang/String;)Landroid/view/View;
    .registers 4

    const-string v0, "id"

    invoke-direct {p0, v0, p1}, Linv/systemui/dynamic/InvDynamicIslandView;->getRes(Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    if-eqz p1, :cond_d

    invoke-virtual {p0, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    return-object p1

    :cond_d
    const/4 p1, 0x0

    return-object p1
.end method

.method private formatMs(J)Ljava/lang/String;
    .registers 5

    const-wide/16 v0, 0x3e8

    div-long/2addr p1, v0

    invoke-static {p1, p2}, Landroid/text/format/DateUtils;->formatElapsedTime(J)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private getExpandedWidth()I
    .registers 4

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    if-lez v0, :cond_14

    const/16 v1, 0x18

    invoke-direct {p0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v1

    sub-int/2addr v0, v1

    return v0

    :cond_14
    const/16 v0, 0x154

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v0

    return v0
.end method

.method private getRes(Ljava/lang/String;Ljava/lang/String;)I
    .registers 6

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, p2, p1, v0}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    return p1
.end method

.method private handlePlaybackRunning(Z)V
    .registers 3

    if-eqz p1, :cond_d

    const/4 v0, 0x0

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseTicks:I

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHideAfterCollapse:Z

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->startEqualizerNow()V

    return-void

    :cond_d
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->stopEqualizerNow()V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->schedulePauseHideDelayed()V

    return-void
.end method

.method private hideRecordExpandedContent()V
    .registers 3

    const-string v0, "inv_record_expanded_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_d

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_d
    return-void
.end method

.method private initBase()V
    .registers 2

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->setClipToPadding(Z)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setFocusable(Z)V

    invoke-virtual {p0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method private initCollapsed()V
    .registers 5

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->initBase()V

    const-string v0, "layout"

    const-string v1, "inv_dynamic_island"

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->getRes(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_34

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v1, v0, p0, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    const-string v0, "inv_touch_outside_root"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mCollapsedRoot:Landroid/view/View;

    if-eqz v0, :cond_26

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_26
    const-string v0, "inv_island_panel"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_34

    invoke-virtual {v0, v2}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_34
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showIdleCollapsed()V

    return-void
.end method

.method private initExpanded()V
    .registers 5

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->initBase()V

    const-string v0, "layout"

    const-string v1, "inv_dynamic_island"

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->getRes(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_34

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v1, v0, p0, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    const-string v0, "inv_touch_outside_root"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mCollapsedRoot:Landroid/view/View;

    if-eqz v0, :cond_26

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_26
    const-string v0, "inv_island_panel"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_34

    invoke-virtual {v0, v2}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_34
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showIdleCollapsed()V

    return-void
.end method

.method private initMediaSession()V
    .registers 3

    :try_start_0
    const-class v0, Lcom/android/systemui/statusbar/NotificationMediaManager;

    invoke-static {v0}, Lcom/android/systemui/Dependency;->get(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/android/systemui/statusbar/NotificationMediaManager;

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaManager:Lcom/android/systemui/statusbar/NotificationMediaManager;

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->readMediaControllerMetadata()V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->startProgressLoop()V
    :try_end_10
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_10} :catch_11

    return-void

    :catch_11
    return-void
.end method

.method private isPlaybackCurrentlyPlaying()Z
    .registers 4

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaManager:Lcom/android/systemui/statusbar/NotificationMediaManager;

    if-eqz v0, :cond_13

    invoke-virtual {v0}, Lcom/android/systemui/statusbar/NotificationMediaManager;->getCurrentPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v1

    if-eqz v1, :cond_13

    invoke-virtual {v1}, Landroid/media/session/PlaybackState;->getState()I

    move-result v1

    const/4 v2, 0x3

    if-ne v1, v2, :cond_13

    const/4 v0, 0x1

    return v0

    :cond_13
    const/4 v0, 0x0

    return v0
.end method

.method private makePercentString(I)Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string p0, "%"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private makeWindowParams()Landroid/view/WindowManager$LayoutParams;
    .registers 6

    new-instance v0, Landroid/view/WindowManager$LayoutParams;

    invoke-direct {v0}, Landroid/view/WindowManager$LayoutParams;-><init>()V

    const/4 v1, -0x1

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->width:I

    const/4 v1, -0x1

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->height:I

    const/16 v1, 0x7d9

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->type:I

    const v1, 0x1000328

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    const/4 v1, -0x3

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->format:I

    const/16 v1, 0x31

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->gravity:I

    const/4 v1, 0x0

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->x:I

    :try_start_1e
    const/4 v2, 0x2

    new-array v2, v2, [I

    invoke-virtual {p0, v2}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v3, 0x1

    aget v4, v2, v3

    iput v4, v0, Landroid/view/WindowManager$LayoutParams;->y:I
    :try_end_29
    .catch Ljava/lang/Throwable; {:try_start_1e .. :try_end_29} :catch_2a

    goto :goto_2d

    :catch_2a
    const/4 v1, 0x0

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    :goto_2d
    const-string v1, "InvDynamicIslandExpanded"

    invoke-virtual {v0, v1}, Landroid/view/WindowManager$LayoutParams;->setTitle(Ljava/lang/CharSequence;)V

    iget v1, v0, Landroid/view/WindowManager$LayoutParams;->privateFlags:I

    or-int/lit8 v1, v1, 0x50

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->privateFlags:I

    return-object v0
.end method

.method private openCurrentMediaApp()V
    .registers 8

    :try_start_0
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_42

    const-string v1, "media_session"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/media/session/MediaSessionManager;

    if-eqz v1, :cond_42

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/media/session/MediaSessionManager;->getActiveSessions(Landroid/content/ComponentName;)Ljava/util/List;

    move-result-object v1

    if-eqz v1, :cond_42

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_1b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_42

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/media/session/MediaController;

    if-eqz v2, :cond_1b

    invoke-virtual {v2}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_1b

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v4

    invoke-virtual {v4, v3}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v4

    if-eqz v4, :cond_1b

    const/high16 v5, 0x10000000

    invoke-virtual {v4, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v0, v4}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void
    :try_end_42
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_42} :catch_42

    :catch_42
    :cond_42
    return-void
.end method

.method private openMediaExpanded()V
    .registers 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordExpandedFromBubble:Z

    const/4 v0, 0x1

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showExpandedWindow()V

    return-void
.end method

.method private openRecordExpanded()V
    .registers 2

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v0, :cond_a

    const/4 v0, 0x2

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showExpandedWindow()V

    :cond_a
    return-void
.end method

.method private openRecordExpandedFromBubble()V
    .registers 2

    const/4 v0, 0x1

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordExpandedFromBubble:Z

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->openRecordExpanded()V

    return-void
.end method

.method private openRecordExpandedFromPill()V
    .registers 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordExpandedFromBubble:Z

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->openRecordExpanded()V

    return-void
.end method

.method private playMorphShow()V
    .registers 1

    return-void
.end method

.method private playPop()V
    .registers 1

    return-void
.end method

.method private readMediaControllerMetadata()V
    .registers 7

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaManager:Lcom/android/systemui/statusbar/NotificationMediaManager;

    if-eqz v0, :cond_5a

    invoke-virtual {v0}, Lcom/android/systemui/statusbar/NotificationMediaManager;->getMediaMetadata()Landroid/media/MediaMetadata;

    move-result-object v1

    if-eqz v1, :cond_5a

    const-string v2, "android.media.metadata.TITLE"

    invoke-virtual {v1, v2}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_19

    iput-object v2, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mTitle:Ljava/lang/String;

    const-string v3, "inv_media_title"

    invoke-direct {p0, v3, v2}, Linv/systemui/dynamic/InvDynamicIslandView;->setTextById(Ljava/lang/String;Ljava/lang/String;)V

    :cond_19
    const-string v2, "android.media.metadata.ARTIST"

    invoke-virtual {v1, v2}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_28

    iput-object v2, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mArtist:Ljava/lang/String;

    const-string v3, "inv_media_artist"

    invoke-direct {p0, v3, v2}, Linv/systemui/dynamic/InvDynamicIslandView;->setTextById(Ljava/lang/String;Ljava/lang/String;)V

    :cond_28
    const-string v2, "android.media.metadata.ALBUM_ART"

    invoke-virtual {v1, v2}, Landroid/media/MediaMetadata;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    if-eqz v2, :cond_33

    iput-object v2, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mAlbumArt:Landroid/graphics/Bitmap;

    goto :goto_3d

    :cond_33
    const-string v2, "android.media.metadata.ART"

    invoke-virtual {v1, v2}, Landroid/media/MediaMetadata;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    if-eqz v2, :cond_4c

    iput-object v2, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mAlbumArt:Landroid/graphics/Bitmap;

    :goto_3d
    const-string v3, "inv_album_collapsed"

    invoke-direct {p0, v3}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v3

    instance-of v4, v3, Landroid/widget/ImageView;

    if-eqz v4, :cond_4c

    check-cast v3, Landroid/widget/ImageView;

    invoke-virtual {v3, v2}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    :cond_4c
    const-string v2, "android.media.metadata.DURATION"

    invoke-virtual {v1, v2}, Landroid/media/MediaMetadata;->getLong(Ljava/lang/String;)J

    move-result-wide v2

    const-wide/16 v4, 0x0

    cmp-long v4, v2, v4

    if-lez v4, :cond_5a

    iput-wide v2, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mDuration:J

    :cond_5a
    return-void
.end method

.method private registerBatteryReceiver()V
    .registers 5

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mIsExpandedWindow:Z

    if-nez v0, :cond_24

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mBatteryReceiver:Landroid/content/BroadcastReceiver;

    if-eqz v0, :cond_9

    return-void

    :cond_9
    new-instance v0, Linv/systemui/dynamic/InvDynamicIslandView$BatteryReceiver;

    invoke-direct {v0, p0}, Linv/systemui/dynamic/InvDynamicIslandView$BatteryReceiver;-><init>(Linv/systemui/dynamic/InvDynamicIslandView;)V

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mBatteryReceiver:Landroid/content/BroadcastReceiver;

    new-instance v1, Landroid/content/IntentFilter;

    const-string v2, "android.intent.action.BATTERY_CHANGED"

    invoke-direct {v1, v2}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2, v0, v1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object v3

    if-eqz v3, :cond_24

    invoke-virtual {p0, v3}, Linv/systemui/dynamic/InvDynamicIslandView;->handleBatteryChanged(Landroid/content/Intent;)V

    :cond_24
    return-void
.end method

.method private restorePowerNoticeState()V
    .registers 3

    iget v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPowerRestoreMode:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_16

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v0, :cond_35

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    if-eqz v0, :cond_35

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mTitle:Ljava/lang/String;

    if-eqz v0, :cond_35

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-eqz v0, :cond_31

    goto :goto_35

    :cond_16
    const/4 v1, 0x1

    if-ne v0, v1, :cond_26

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    if-eqz v0, :cond_35

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mTitle:Ljava/lang/String;

    if-eqz v0, :cond_35

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-eqz v0, :cond_31

    goto :goto_35

    :cond_26
    const/4 v1, 0x2

    if-ne v0, v1, :cond_35

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v0, :cond_35

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showRecordCollapsedPill()V

    goto :goto_38

    :cond_31
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showMediaCollapsed()V

    goto :goto_38

    :cond_35
    :goto_35
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showIdleCollapsed()V

    :goto_38
    const/4 v0, 0x0

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPowerRestoreMode:I

    return-void
.end method

.method private scheduleChargingHideOnHost()V
    .registers 5

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingRunnable:Ljava/lang/Runnable;

    if-eqz v0, :cond_7

    invoke-virtual {p0, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    :cond_7
    new-instance v0, Linv/systemui/dynamic/InvDynamicIslandView$ChargingHideRunnable;

    invoke-direct {v0, p0}, Linv/systemui/dynamic/InvDynamicIslandView$ChargingHideRunnable;-><init>(Linv/systemui/dynamic/InvDynamicIslandView;)V

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingRunnable:Ljava/lang/Runnable;

    const-wide/16 v1, 0x1388

    invoke-virtual {p0, v0, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method private schedulePauseHideDelayed()V
    .registers 5

    iget v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mCurrentState:I

    if-eqz v0, :cond_1e

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-eqz v0, :cond_9

    return-void

    :cond_9
    iget v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseTicks:I

    if-lez v0, :cond_e

    return-void

    :cond_e
    const/4 v0, 0x1

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseTicks:I

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->stopEqualizerNow()V

    new-instance v0, Linv/systemui/dynamic/InvDynamicIslandView$PauseHideRunnable;

    invoke-direct {v0, p0}, Linv/systemui/dynamic/InvDynamicIslandView$PauseHideRunnable;-><init>(Linv/systemui/dynamic/InvDynamicIslandView;)V

    const-wide/16 v1, 0xbb8

    invoke-virtual {p0, v0, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_1e
    return-void
.end method

.method private sendMediaKey(I)V
    .registers 4

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaManager:Lcom/android/systemui/statusbar/NotificationMediaManager;

    if-eqz v0, :cond_1b

    const/16 v1, 0x58

    if-ne p1, v1, :cond_c

    invoke-virtual {v0}, Lcom/android/systemui/statusbar/NotificationMediaManager;->skipTrackPrevious()V

    return-void

    :cond_c
    const/16 v1, 0x55

    if-ne p1, v1, :cond_14

    invoke-virtual {v0}, Lcom/android/systemui/statusbar/NotificationMediaManager;->playPauseTrack()V

    return-void

    :cond_14
    const/16 v1, 0x57

    if-ne p1, v1, :cond_1b

    invoke-virtual {v0}, Lcom/android/systemui/statusbar/NotificationMediaManager;->skipTrackNext()V

    :cond_1b
    return-void
.end method

.method private setPanelTranslationDp(I)V
    .registers 4

    const-string v0, "inv_island_panel"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_15

    invoke-direct {p0, p1}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationX(F)V

    const/4 v1, 0x0

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationY(F)V

    :cond_15
    return-void
.end method

.method private setStatusBarIconsHiddenForIsland(Z)V
    .registers 4

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mIsExpandedWindow:Z

    if-eqz v0, :cond_c

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHost:Linv/systemui/dynamic/InvDynamicIslandView;

    if-eqz v0, :cond_27

    invoke-direct {v0, p1}, Linv/systemui/dynamic/InvDynamicIslandView;->setStatusBarIconsHiddenForIsland(Z)V

    return-void

    :cond_c
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    :goto_10
    if-eqz v0, :cond_27

    instance-of v1, v0, Lcom/android/systemui/statusbar/phone/PhoneStatusBarView;

    if-eqz v1, :cond_1c

    check-cast v0, Lcom/android/systemui/statusbar/phone/PhoneStatusBarView;

    invoke-virtual {v0, p1}, Lcom/android/systemui/statusbar/phone/PhoneStatusBarView;->setInvDynamicIslandExpanded(Z)V

    return-void

    :cond_1c
    instance-of v1, v0, Landroid/view/View;

    if-eqz v1, :cond_27

    check-cast v0, Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    goto :goto_10

    :cond_27
    return-void
.end method

.method private setTextById(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0, p1}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object p1

    instance-of v0, p1, Landroid/widget/TextView;

    if-eqz v0, :cond_d

    check-cast p1, Landroid/widget/TextView;

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_d
    return-void
.end method

.method private setTextColorById(Ljava/lang/String;I)V
    .registers 3

    invoke-direct {p0, p1}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object p1

    instance-of p0, p1, Landroid/widget/TextView;

    if-eqz p0, :cond_d

    check-cast p1, Landroid/widget/TextView;

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_d
    return-void
.end method

.method private showChargingCollapsed()V
    .registers 4

    const/4 v0, 0x1

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingActive:Z

    if-nez v1, :cond_8

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->capturePowerRestoreState()V

    :cond_8
    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingActive:Z

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPlugged:Z

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mCurrentState:I

    const/4 v0, 0x0

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    iget v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPercent:I

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->updatePowerNoticeText(ZI)V

    const/16 v0, 0x96

    const/16 v1, 0x26

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyOwnSize(II)V

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyPanelSizeDp(II)V

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->setPanelTranslationDp(I)V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showChargingPowerContent()V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->scheduleChargingHideOnHost()V

    return-void
.end method

.method private showChargingPowerContent()V
    .registers 4

    const-string v0, "inv_collapsed_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_d

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_d
    const-string v0, "inv_expanded_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_1a

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_1a
    const-string v0, "inv_record_expanded_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_27

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_27
    const-string v0, "inv_second_bubble"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_34

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_34
    const-string v0, "inv_power_notice_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_59

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/high16 v2, 0x3f800000  # 1.0f

    invoke-virtual {v0, v2}, Landroid/view/View;->setAlpha(F)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setScaleY(F)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationX(F)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationY(F)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setFocusable(Z)V

    :cond_59
    return-void
.end method

.method private showCollapsedContentOnly()V
    .registers 4

    const-string v0, "inv_record_expanded_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_d

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_d
    const-string v0, "inv_collapsed_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_2b

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/high16 v2, 0x3f800000  # 1.0f

    invoke-virtual {v0, v2}, Landroid/view/View;->setAlpha(F)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setScaleY(F)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationX(F)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationY(F)V

    :cond_2b
    const-string v0, "inv_expanded_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_38

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_38
    const-string v0, "inv_power_notice_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_45

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_45
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->bindRecordCollapsedContent()V

    return-void
.end method

.method private showExpandedWindow()V
    .registers 7

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->setStatusBarIconsHiddenForIsland(Z)V

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedRoot:Landroid/view/View;

    if-eqz v0, :cond_c

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->updateExpandedWindowContent()V

    return-void

    :cond_c
    :try_start_c
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "window"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/WindowManager;

    iput-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mWindowManager:Landroid/view/WindowManager;

    new-instance v2, Linv/systemui/dynamic/InvDynamicIslandView;

    const/4 v3, 0x1

    invoke-direct {v2, v0, v3}, Linv/systemui/dynamic/InvDynamicIslandView;-><init>(Landroid/content/Context;Z)V

    iput-object v2, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedRoot:Landroid/view/View;

    iput-object p0, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mHost:Linv/systemui/dynamic/InvDynamicIslandView;

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mTitle:Ljava/lang/String;

    iput-object v0, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mTitle:Ljava/lang/String;

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mArtist:Ljava/lang/String;

    iput-object v0, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mArtist:Ljava/lang/String;

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mAlbumArt:Landroid/graphics/Bitmap;

    iput-object v0, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mAlbumArt:Landroid/graphics/Bitmap;

    iget-wide v3, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mDuration:J

    iput-wide v3, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mDuration:J

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    iput-boolean v0, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mKeepSharedMediaCollapse:Z

    iput-boolean v0, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mKeepSharedMediaCollapse:Z

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    iput-boolean v0, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    iget-wide v3, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordStart:J

    iput-wide v3, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordStart:J

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPaused:Z

    iput-boolean v0, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPaused:Z

    iget-wide v3, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPauseBase:J

    iput-wide v3, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPauseBase:J

    iget-wide v3, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPausedTotal:J

    iput-wide v3, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPausedTotal:J

    iget v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    iput v0, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    iget v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPowerRestoreMode:I

    iput v0, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mPowerRestoreMode:I

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingActive:Z

    iput-boolean v0, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingActive:Z

    iget v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPercent:I

    iput v0, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPercent:I

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPlugged:Z

    iput-boolean v0, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPlugged:Z

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordExpandedFromBubble:Z

    iput-boolean v0, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordExpandedFromBubble:Z

    invoke-direct {v2}, Linv/systemui/dynamic/InvDynamicIslandView;->bindCollapsedContent()V

    invoke-direct {v2}, Linv/systemui/dynamic/InvDynamicIslandView;->bindExpandedContent()V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->makeWindowParams()Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    iput-object v0, v2, Linv/systemui/dynamic/InvDynamicIslandView;->mWindowParams:Landroid/view/WindowManager$LayoutParams;

    invoke-interface {v1, v2, v0}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->setAlpha(F)V

    new-instance v0, Linv/systemui/dynamic/InvDynamicIslandView$ExpandRunnable;

    invoke-direct {v0, v2}, Linv/systemui/dynamic/InvDynamicIslandView$ExpandRunnable;-><init>(Linv/systemui/dynamic/InvDynamicIslandView;)V

    const-wide/16 v3, 0x20

    invoke-virtual {v2, v0, v3, v4}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v0, 0x2

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mCurrentState:I
    :try_end_88
    .catch Ljava/lang/Throwable; {:try_start_c .. :try_end_88} :catch_89

    return-void

    :catch_89
    const/high16 v0, 0x3f800000  # 1.0f

    invoke-virtual {p0, v0}, Landroid/view/View;->setAlpha(F)V

    return-void
.end method

.method private showIdleCollapsed()V
    .registers 3

    const/4 v0, 0x0

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mCurrentState:I

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    const/16 v0, 0x64

    const/16 v1, 0x26

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyOwnSize(II)V

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyPanelSizeDp(II)V

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->setPanelTranslationDp(I)V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showCollapsedContentOnly()V

    const-string v0, "inv_album_collapsed"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_23

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_23
    const-string v0, "inv_equalizer_icon"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_33

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->stopEqualizerNow()V

    :cond_33
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->bindRecordCollapsedContent()V

    return-void
.end method

.method private showLowBatteryCollapsed()V
    .registers 4

    const/4 v0, 0x1

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingActive:Z

    if-nez v1, :cond_8

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->capturePowerRestoreState()V

    :cond_8
    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingActive:Z

    const/4 v1, 0x0

    iput-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPlugged:Z

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mCurrentState:I

    iput v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    iget v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPercent:I

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->updatePowerNoticeText(ZI)V

    const/16 v0, 0x96

    const/16 v1, 0x26

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyOwnSize(II)V

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyPanelSizeDp(II)V

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->setPanelTranslationDp(I)V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showChargingPowerContent()V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->scheduleChargingHideOnHost()V

    return-void
.end method

.method private showMediaCollapsed()V
    .registers 4

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingActive:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-eqz v0, :cond_a

    goto :goto_13

    :cond_a
    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    if-eqz v0, :cond_13

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mTitle:Ljava/lang/String;

    if-eqz v0, :cond_13

    goto :goto_1f

    :cond_13
    :goto_13
    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v0, :cond_1b

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showRecordCollapsedPill()V

    return-void

    :cond_1b
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showIdleCollapsed()V

    return-void

    :goto_1f
    const/4 v0, 0x1

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mCurrentState:I

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-nez v0, :cond_2a

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mKeepSharedMediaCollapse:Z

    :cond_2a
    if-eqz v0, :cond_3c

    const/16 v0, 0xd2

    const/16 v1, 0x26

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyOwnSize(II)V

    const/16 v0, 0x96

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyPanelSizeDp(II)V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->applyAutoSharedBubbleLayout()V

    goto :goto_4a

    :cond_3c
    const/16 v0, 0x96

    const/16 v1, 0x26

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyOwnSize(II)V

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyPanelSizeDp(II)V

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->setPanelTranslationDp(I)V

    :goto_4a
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showCollapsedContentOnly()V

    const-string v0, "inv_album_collapsed"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_58

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->softShowView(Landroid/view/View;)V

    :cond_58
    const-string v0, "inv_equalizer_icon"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_66

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->softShowView(Landroid/view/View;)V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->startEqualizerNow()V

    :cond_66
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->bindCollapsedContent()V

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-nez v0, :cond_6f

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mKeepSharedMediaCollapse:Z

    :cond_6f
    if-eqz v0, :cond_74

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->applyAutoSharedBubbleLayout()V

    :cond_74
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->startRecordTimerLoop()V

    return-void
.end method

.method private showRecordCollapsedPill()V
    .registers 4

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingActive:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    const/4 v0, 0x1

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mCurrentState:I

    const/4 v0, 0x2

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    const/16 v0, 0x8c

    const/16 v1, 0x26

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyOwnSize(II)V

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyPanelSizeDp(II)V

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->setPanelTranslationDp(I)V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showCollapsedContentOnly()V

    const-string v0, "inv_album_collapsed"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_29

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_29
    const-string v0, "inv_equalizer_icon"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_39

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->stopEqualizerNow()V

    :cond_39
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->bindRecordCollapsedContent()V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->startRecordTimerLoop()V

    const/16 v0, 0x8c

    const/16 v1, 0x26

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyOwnSize(II)V

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyPanelSizeDp(II)V

    return-void
.end method

.method private softShowView(Landroid/view/View;)V
    .registers 3

    if-eqz p1, :cond_15

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    const/high16 v0, 0x3f800000  # 1.0f

    invoke-virtual {p1, v0}, Landroid/view/View;->setAlpha(F)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setScaleY(F)V

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->setTranslationX(F)V

    :cond_15
    return-void
.end method

.method private startEqualizerNow()V
    .registers 3

    const-string v0, "inv_equalizer_icon"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_11

    instance-of v1, v0, Linv/systemui/dynamic/InvEqualizerView;

    if-eqz v1, :cond_11

    check-cast v0, Linv/systemui/dynamic/InvEqualizerView;

    invoke-virtual {v0}, Linv/systemui/dynamic/InvEqualizerView;->start()V

    :cond_11
    return-void
.end method

.method private startProgressLoop()V
    .registers 5

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHandler:Landroid/os/Handler;

    if-eqz v0, :cond_1a

    iget-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mProgressRunnable:Ljava/lang/Runnable;

    if-eqz v1, :cond_c

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    goto :goto_13

    :cond_c
    new-instance v1, Linv/systemui/dynamic/InvDynamicIslandView$ProgressRunnable;

    invoke-direct {v1, p0}, Linv/systemui/dynamic/InvDynamicIslandView$ProgressRunnable;-><init>(Linv/systemui/dynamic/InvDynamicIslandView;)V

    iput-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mProgressRunnable:Ljava/lang/Runnable;

    :goto_13
    iget-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mProgressRunnable:Ljava/lang/Runnable;

    const-wide/16 v2, 0x20

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_1a
    return-void
.end method

.method private startRecordTimerLoop()V
    .registers 5

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v0, :cond_23

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPaused:Z

    if-eqz v0, :cond_9

    goto :goto_23

    :cond_9
    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHandler:Landroid/os/Handler;

    if-eqz v0, :cond_23

    iget-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordRunnable:Ljava/lang/Runnable;

    if-eqz v1, :cond_15

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    goto :goto_1c

    :cond_15
    new-instance v1, Linv/systemui/dynamic/InvDynamicIslandView$RecordTimerRunnable;

    invoke-direct {v1, p0}, Linv/systemui/dynamic/InvDynamicIslandView$RecordTimerRunnable;-><init>(Linv/systemui/dynamic/InvDynamicIslandView;)V

    iput-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordRunnable:Ljava/lang/Runnable;

    :goto_1c
    iget-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordRunnable:Ljava/lang/Runnable;

    const-wide/16 v2, 0x3e8

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_23
    :goto_23
    return-void
.end method

.method private startSpringMorph(Z)V
    .registers 10

    const/4 v0, 0x2

    new-array v0, v0, [F

    if-eqz p1, :cond_f

    const/4 v1, 0x0

    const/4 v2, 0x0

    aput v1, v0, v2

    const/high16 v1, 0x3f800000  # 1.0f

    const/4 v2, 0x1

    aput v1, v0, v2

    goto :goto_18

    :cond_f
    const/high16 v1, 0x3f800000  # 1.0f

    const/4 v2, 0x0

    aput v1, v0, v2

    const/4 v1, 0x0

    const/4 v2, 0x1

    aput v1, v0, v2

    :goto_18
    invoke-static {v0}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object v0

    new-instance v1, Linv/systemui/dynamic/InvDynamicIslandView$MorphUpdateListener;

    invoke-direct {v1, p0}, Linv/systemui/dynamic/InvDynamicIslandView$MorphUpdateListener;-><init>(Linv/systemui/dynamic/InvDynamicIslandView;)V

    invoke-virtual {v0, v1}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    const-wide/16 v1, 0x1c2

    invoke-virtual {v0, v1, v2}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    if-eqz p1, :cond_37

    new-instance v1, Landroid/view/animation/OvershootInterpolator;

    const v2, 0x3f266666  # 0.65f

    invoke-direct {v1, v2}, Landroid/view/animation/OvershootInterpolator;-><init>(F)V

    invoke-virtual {v0, v1}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    goto :goto_41

    :cond_37
    new-instance v1, Landroid/view/animation/DecelerateInterpolator;

    const/high16 v2, 0x40200000  # 2.5f

    invoke-direct {v1, v2}, Landroid/view/animation/DecelerateInterpolator;-><init>(F)V

    invoke-virtual {v0, v1}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    :goto_41
    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->start()V

    return-void
.end method

.method private stopEqualizerNow()V
    .registers 3

    const-string v0, "inv_equalizer_icon"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_14

    instance-of v1, v0, Linv/systemui/dynamic/InvEqualizerView;

    if-eqz v1, :cond_14

    check-cast v0, Linv/systemui/dynamic/InvEqualizerView;

    invoke-virtual {v0}, Linv/systemui/dynamic/InvEqualizerView;->stop()V

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_14
    return-void
.end method

.method private stopRecordTimerLoop()V
    .registers 3

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHandler:Landroid/os/Handler;

    if-eqz v0, :cond_b

    iget-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordRunnable:Ljava/lang/Runnable;

    if-eqz v1, :cond_b

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_b
    return-void
.end method

.method private stopScreenRecordingFromIsland()V
    .registers 4

    :try_start_0
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz v0, :cond_13

    const-string v1, "media_projection"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/projection/MediaProjectionManager;

    if-eqz v0, :cond_13

    invoke-virtual {v0}, Landroid/media/projection/MediaProjectionManager;->stopActiveProjection()V

    :cond_13
    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHost:Linv/systemui/dynamic/InvDynamicIslandView;

    if-eqz v0, :cond_1f

    iget-boolean v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    if-eqz v1, :cond_26

    const/4 v1, 0x1

    iput-boolean v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mKeepSharedMediaCollapse:Z

    goto :goto_26

    :cond_1f
    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    if-eqz v1, :cond_26

    const/4 v1, 0x1

    iput-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mKeepSharedMediaCollapse:Z

    :cond_26
    :goto_26
    const/4 v0, 0x0

    invoke-static {v0}, Linv/systemui/dynamic/InvDynamicIslandView;->dispatchScreenRecord(Z)V

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHost:Linv/systemui/dynamic/InvDynamicIslandView;

    if-eqz v0, :cond_3f

    iget-boolean v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    if-eqz v1, :cond_38

    iget-boolean v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-nez v1, :cond_38

    const/4 v1, 0x0

    goto :goto_39

    :cond_38
    const/4 v1, 0x1

    :goto_39
    iput-boolean v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mHideAfterCollapse:Z

    invoke-virtual {v0}, Linv/systemui/dynamic/InvDynamicIslandView;->hideExpandedWindow()V

    goto :goto_4f

    :cond_3f
    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    if-eqz v1, :cond_49

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-nez v1, :cond_49

    const/4 v1, 0x0

    goto :goto_4a

    :cond_49
    const/4 v1, 0x1

    :goto_4a
    iput-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHideAfterCollapse:Z

    invoke-virtual {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->hideExpandedWindow()V
    :try_end_4f
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_4f} :catch_50

    :goto_4f
    return-void

    :catch_50
    move-exception v0

    const-string v1, "InvDynamicIsland"

    const-string v2, "stop screen recording failed"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return-void
.end method

.method private unregisterBatteryReceiver()V
    .registers 3

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mBatteryReceiver:Landroid/content/BroadcastReceiver;

    if-eqz v0, :cond_e

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    const/4 v0, 0x0

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mBatteryReceiver:Landroid/content/BroadcastReceiver;

    :cond_e
    return-void
.end method

.method private updateExpandedWindowContent()V
    .registers 5

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedRoot:Landroid/view/View;

    instance-of v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;

    if-eqz v1, :cond_4e

    check-cast v0, Linv/systemui/dynamic/InvDynamicIslandView;

    iget-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mTitle:Ljava/lang/String;

    iput-object v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mTitle:Ljava/lang/String;

    iget-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mArtist:Ljava/lang/String;

    iput-object v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mArtist:Ljava/lang/String;

    iget-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mAlbumArt:Landroid/graphics/Bitmap;

    iput-object v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mAlbumArt:Landroid/graphics/Bitmap;

    iget-wide v2, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mDuration:J

    iput-wide v2, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mDuration:J

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    iput-boolean v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mKeepSharedMediaCollapse:Z

    iput-boolean v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mKeepSharedMediaCollapse:Z

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    iput-boolean v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    iget-wide v2, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordStart:J

    iput-wide v2, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordStart:J

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPaused:Z

    iput-boolean v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPaused:Z

    iget-wide v2, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPauseBase:J

    iput-wide v2, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPauseBase:J

    iget-wide v2, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPausedTotal:J

    iput-wide v2, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPausedTotal:J

    iget v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    iput v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    iget v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPowerRestoreMode:I

    iput v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mPowerRestoreMode:I

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingActive:Z

    iput-boolean v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingActive:Z

    iget v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPercent:I

    iput v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPercent:I

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPlugged:Z

    iput-boolean v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPlugged:Z

    invoke-direct {v0}, Linv/systemui/dynamic/InvDynamicIslandView;->bindCollapsedContent()V

    invoke-direct {v0}, Linv/systemui/dynamic/InvDynamicIslandView;->bindExpandedContent()V

    :cond_4e
    return-void
.end method

.method private updatePlayPauseIcon(Z)V
    .registers 7

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mBtnPlayPause:Landroid/widget/ImageView;

    if-eqz v0, :cond_22

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "drawable"

    if-eqz p1, :cond_f

    const-string v3, "inv_ic_pause"

    goto :goto_11

    :cond_f
    const-string v3, "inv_ic_play"

    :goto_11
    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v3, v2, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    if-eqz v1, :cond_22

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    :cond_22
    return-void
.end method

.method private updatePowerNoticeText(ZI)V
    .registers 5

    invoke-direct {p0, p2}, Linv/systemui/dynamic/InvDynamicIslandView;->makePercentString(I)Ljava/lang/String;

    move-result-object p2

    if-eqz p1, :cond_1b

    const-string v0, "inv_charging_title"

    const-string v1, "Low Battery"

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->setTextById(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "inv_charging_subtitle"

    invoke-direct {p0, v0, p2}, Linv/systemui/dynamic/InvDynamicIslandView;->setTextById(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "inv_charging_subtitle"

    const v1, -0x4c4c5

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->setTextColorById(Ljava/lang/String;I)V

    return-void

    :cond_1b
    const-string v0, "inv_charging_title"

    const-string v1, "Charging"

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->setTextById(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "inv_charging_subtitle"

    invoke-direct {p0, v0, p2}, Linv/systemui/dynamic/InvDynamicIslandView;->setTextById(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "inv_charging_subtitle"

    const v1, -0xcf2ea8

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->setTextColorById(Ljava/lang/String;I)V

    return-void
.end method

.method private updateRecordTimeViews()V
    .registers 9

    iget-wide v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordStart:J

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    if-nez v4, :cond_b

    const-string v0, "00:00"

    goto :goto_27

    :cond_b
    iget-boolean v4, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPaused:Z

    if-eqz v4, :cond_12

    iget-wide v2, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPauseBase:J

    goto :goto_16

    :cond_12
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    :goto_16
    sub-long/2addr v2, v0

    iget-wide v4, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPausedTotal:J

    sub-long/2addr v2, v4

    const-wide/16 v4, 0x0

    cmp-long v6, v2, v4

    if-ltz v6, :cond_21

    goto :goto_23

    :cond_21
    const-wide/16 v2, 0x0

    :goto_23
    invoke-direct {p0, v2, v3}, Linv/systemui/dynamic/InvDynamicIslandView;->formatMs(J)Ljava/lang/String;

    move-result-object v0

    :goto_27
    const-string v1, "inv_record_time_collapsed"

    invoke-direct {p0, v1, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->setTextById(Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "inv_record_time_expanded"

    invoke-direct {p0, v1, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->setTextById(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private updateTimeViews()V
    .registers 16

    :try_start_0
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->readMediaControllerMetadata()V

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaManager:Lcom/android/systemui/statusbar/NotificationMediaManager;

    if-eqz v0, :cond_86

    invoke-virtual {v0}, Lcom/android/systemui/statusbar/NotificationMediaManager;->getCurrentPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v1

    if-eqz v1, :cond_86

    invoke-direct {p0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->computeCurrentPosition(Landroid/media/session/PlaybackState;)J

    move-result-wide v2

    invoke-virtual {v1}, Landroid/media/session/PlaybackState;->getState()I

    move-result v4

    const/4 v5, 0x3

    if-ne v4, v5, :cond_20

    const/4 v4, 0x1

    invoke-direct {p0, v4}, Linv/systemui/dynamic/InvDynamicIslandView;->updatePlayPauseIcon(Z)V

    invoke-direct {p0, v4}, Linv/systemui/dynamic/InvDynamicIslandView;->handlePlaybackRunning(Z)V

    goto :goto_2b

    :cond_20
    const/4 v5, 0x0

    invoke-direct {p0, v5}, Linv/systemui/dynamic/InvDynamicIslandView;->updatePlayPauseIcon(Z)V

    const/4 v5, 0x2

    if-ne v4, v5, :cond_2b

    const/4 v5, 0x0

    invoke-direct {p0, v5}, Linv/systemui/dynamic/InvDynamicIslandView;->handlePlaybackRunning(Z)V

    :cond_2b
    :goto_2b
    iget-wide v4, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mDuration:J

    const-wide/16 v6, 0x0

    cmp-long v8, v4, v6

    if-lez v8, :cond_7c

    cmp-long v8, v2, v4

    if-lez v8, :cond_38

    move-wide v2, v4

    :cond_38
    invoke-direct {p0, v2, v3}, Linv/systemui/dynamic/InvDynamicIslandView;->formatMs(J)Ljava/lang/String;

    move-result-object v6

    const-string v7, "inv_media_time_start"

    invoke-direct {p0, v7, v6}, Linv/systemui/dynamic/InvDynamicIslandView;->setTextById(Ljava/lang/String;Ljava/lang/String;)V

    sub-long v6, v4, v2

    const-wide/16 v8, 0x0

    cmp-long v8, v6, v8

    if-ltz v8, :cond_4a

    goto :goto_4c

    :cond_4a
    const-wide/16 v6, 0x0

    :goto_4c
    invoke-direct {p0, v6, v7}, Linv/systemui/dynamic/InvDynamicIslandView;->formatMs(J)Ljava/lang/String;

    move-result-object v6

    const-string v7, "-"

    invoke-virtual {v7, v6}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "inv_media_time_end"

    invoke-direct {p0, v7, v6}, Linv/systemui/dynamic/InvDynamicIslandView;->setTextById(Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "inv_media_seekbar"

    invoke-direct {p0, v6}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    instance-of v7, v6, Landroid/widget/SeekBar;

    if-eqz v7, :cond_94

    check-cast v6, Landroid/widget/SeekBar;

    long-to-int v7, v4

    if-lez v7, :cond_77

    invoke-virtual {v6, v7}, Landroid/widget/SeekBar;->setMax(I)V

    long-to-int v7, v2

    const/4 v8, 0x0

    if-lt v7, v8, :cond_72

    goto :goto_73

    :cond_72
    const/4 v7, 0x0

    :goto_73
    invoke-virtual {v6, v7}, Landroid/widget/SeekBar;->setProgress(I)V

    goto :goto_94

    :cond_77
    const/4 v7, 0x0

    invoke-virtual {v6, v7}, Landroid/widget/SeekBar;->setProgress(I)V

    goto :goto_94

    :cond_7c
    invoke-direct {p0, v2, v3}, Linv/systemui/dynamic/InvDynamicIslandView;->formatMs(J)Ljava/lang/String;

    move-result-object v2

    const-string v3, "inv_media_time_start"

    invoke-direct {p0, v3, v2}, Linv/systemui/dynamic/InvDynamicIslandView;->setTextById(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_94

    :cond_86
    const-string v0, "inv_media_time_start"

    const-string v1, "0:00"

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->setTextById(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "inv_media_time_end"

    const-string v1, "-0:00"

    invoke-direct {p0, v0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->setTextById(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_94
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_94} :catch_95

    :cond_94
    :goto_94
    return-void

    :catch_95
    return-void
.end method


# virtual methods
.method public applyMorphProgress(F)V
    .registers 16

    const/4 v0, 0x0

    cmpg-float v1, p1, v0

    if-ltz v1, :cond_6

    goto :goto_7

    :cond_6
    const/4 p1, 0x0

    :goto_7
    const/high16 v0, 0x3f800000  # 1.0f

    cmpl-float v1, p1, v0

    if-gtz v1, :cond_e

    goto :goto_10

    :cond_e
    const/high16 p1, 0x3f800000  # 1.0f

    :goto_10
    iget v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_19

    invoke-direct {p0, p1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyPowerNoticeMorphProgress(F)V

    return-void

    :cond_19
    const/4 v1, 0x2

    if-ne v0, v1, :cond_20

    invoke-direct {p0, p1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyRecordMorphProgress(F)V

    return-void

    :cond_20
    invoke-direct {p0, p1}, Linv/systemui/dynamic/InvDynamicIslandView;->applyPanelRadius(F)V

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v1, :cond_2b

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-eqz v1, :cond_2e

    :cond_2b
    const/16 v1, 0x96

    goto :goto_30

    :cond_2e
    const/16 v1, 0x96

    :goto_30
    invoke-direct {p0, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v1

    const/16 v2, 0x26

    invoke-direct {p0, v2}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v2

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->getExpandedWidth()I

    move-result v3

    const/16 v4, 0xb2

    invoke-direct {p0, v4}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v4

    sub-int v5, v3, v1

    int-to-float v5, v5

    mul-float/2addr v5, p1

    int-to-float v6, v1

    add-float/2addr v6, v5

    float-to-int v6, v6

    sub-int v5, v4, v2

    int-to-float v5, v5

    mul-float/2addr v5, p1

    int-to-float v7, v2

    add-float/2addr v7, v5

    float-to-int v7, v7

    invoke-direct {p0, v6, v7}, Linv/systemui/dynamic/InvDynamicIslandView;->applyPanelSizePx(II)V

    const-string v8, "inv_island_panel"

    invoke-direct {p0, v8}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v8

    if-eqz v8, :cond_6c

    const/4 v12, 0x0

    invoke-virtual {v8, v12}, Landroid/view/View;->setTranslationX(F)V

    const/16 v12, 0x8

    invoke-direct {p0, v12}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v12

    int-to-float v12, v12

    mul-float/2addr v12, p1

    invoke-virtual {v8, v12}, Landroid/view/View;->setTranslationY(F)V

    :cond_6c
    invoke-direct {p0, p1, v6}, Linv/systemui/dynamic/InvDynamicIslandView;->applySharedMediaMorphAnchor(FI)V

    const/high16 v9, 0x3f800000  # 1.0f

    sub-float v10, v9, p1

    mul-float v11, p1, v10

    const/high16 v12, 0x40800000  # 4.0f

    mul-float/2addr v11, v12

    if-eqz v8, :cond_8c

    const v12, 0x3d4ccccd  # 0.05f

    mul-float/2addr v12, v11

    sub-float v13, v9, v12

    invoke-virtual {v8, v13}, Landroid/view/View;->setScaleY(F)V

    const v12, 0x3c23d70a  # 0.01f

    mul-float/2addr v12, v11

    add-float v13, v9, v12

    invoke-virtual {v8, v13}, Landroid/view/View;->setScaleX(F)V

    :cond_8c
    const-string v8, "inv_unused_collapsed_content"

    invoke-direct {p0, v8}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v8

    if-eqz v8, :cond_d1

    const/4 v12, 0x0

    invoke-virtual {v8, v12}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v8, v9}, Landroid/view/View;->setAlpha(F)V

    invoke-virtual {v8, v9}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v8, v9}, Landroid/view/View;->setScaleY(F)V

    const/4 v12, 0x0

    invoke-virtual {v8, v12}, Landroid/view/View;->setTranslationX(F)V

    const/4 v12, 0x0

    invoke-virtual {v8, v12}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v8, v9}, Landroid/view/View;->setAlpha(F)V

    const v12, 0x3f733333  # 0.95f

    mul-float/2addr v12, p1

    sub-float v12, v9, v12

    const v13, 0x3d4ccccd  # 0.05f

    cmpg-float v0, v12, v13

    if-ltz v0, :cond_ba

    goto :goto_bb

    :cond_ba
    move v12, v13

    :goto_bb
    invoke-virtual {v8, v12}, Landroid/view/View;->setScaleX(F)V

    const v13, 0x3e800000  # 0.25f

    mul-float/2addr v13, p1

    sub-float v13, v9, v13

    invoke-virtual {v8, v13}, Landroid/view/View;->setScaleY(F)V

    const/high16 v13, -0x3c6a0000  # -300.0f

    mul-float/2addr v13, p1

    const/high16 v0, -0x3f000000  # -8.0f

    mul-float/2addr v0, v11

    add-float/2addr v13, v0

    invoke-virtual {v8, v13}, Landroid/view/View;->setTranslationX(F)V

    :cond_d1
    const-string v8, "inv_expanded_content"

    invoke-direct {p0, v8}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v8

    if-eqz v8, :cond_10f

    const/4 v12, 0x0

    invoke-virtual {v8, v12}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v8, v9}, Landroid/view/View;->setAlpha(F)V

    const v12, 0x3e23d70a  # 0.16f

    sub-float v12, p1, v12

    const v13, 0x3f570a3d  # 0.84f

    div-float/2addr v12, v13

    const/4 v13, 0x0

    cmpg-float v0, v12, v13

    if-ltz v0, :cond_ef

    goto :goto_f0

    :cond_ef
    const/4 v12, 0x0

    :goto_f0
    cmpl-float v0, v12, v9

    if-gtz v0, :cond_f5

    goto :goto_f7

    :cond_f5
    const/high16 v12, 0x3f800000  # 1.0f

    :goto_f7
    invoke-virtual {v8, v12}, Landroid/view/View;->setAlpha(F)V

    const v13, 0x3f7ae148  # 0.98f

    const v0, 0x3ca3d70a  # 0.02f

    mul-float/2addr v0, v12

    add-float/2addr v13, v0

    invoke-virtual {v8, v13}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v8, v13}, Landroid/view/View;->setScaleY(F)V

    const/4 v13, 0x0

    invoke-virtual {v8, v13}, Landroid/view/View;->setTranslationX(F)V

    invoke-virtual {v8, v13}, Landroid/view/View;->setTranslationY(F)V

    :cond_10f
    const-string v8, "inv_album_collapsed"

    invoke-direct {p0, v8}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v8

    if-eqz v8, :cond_15a

    const/4 v13, 0x0

    invoke-virtual {v8, v13}, Landroid/view/View;->setVisibility(I)V

    const v12, 0x3d4ccccd  # 0.05f

    sub-float v12, p1, v12

    const v13, 0x3f733333  # 0.95f

    div-float/2addr v12, v13

    const/4 v13, 0x0

    cmpg-float v0, v12, v13

    if-ltz v0, :cond_12a

    goto :goto_12b

    :cond_12a
    const/4 v12, 0x0

    :goto_12b
    cmpl-float v0, v12, v9

    if-gtz v0, :cond_130

    goto :goto_132

    :cond_130
    const/high16 v12, 0x3f800000  # 1.0f

    :goto_132
    const v13, 0x3f800000  # 1.0f

    const/high16 v0, 0x3fa00000  # 1.25f

    mul-float/2addr v0, v12

    add-float/2addr v13, v0

    invoke-virtual {v8, v13}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v8, v13}, Landroid/view/View;->setScaleY(F)V

    const/16 v0, 0x12

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v0

    int-to-float v0, v0

    mul-float/2addr v0, v12

    invoke-virtual {v8, v0}, Landroid/view/View;->setTranslationX(F)V

    const/16 v0, -0x24

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v0

    int-to-float v0, v0

    mul-float/2addr v0, v12

    invoke-virtual {v8, v0}, Landroid/view/View;->setTranslationY(F)V

    const/high16 v13, 0x3f800000  # 1.0f

    invoke-virtual {v8, v13}, Landroid/view/View;->setAlpha(F)V

    :cond_15a
    const-string v8, "inv_media_text_box"

    invoke-direct {p0, v8}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v8

    if-eqz v8, :cond_1b4

    const v12, 0x3f0ccccd  # 0.55f

    sub-float v12, p1, v12

    const v13, 0x3ee66666  # 0.45f

    div-float/2addr v12, v13

    const/4 v13, 0x0

    cmpg-float v0, v12, v13

    if-ltz v0, :cond_171

    goto :goto_172

    :cond_171
    const/4 v12, 0x0

    :goto_172
    cmpl-float v0, v12, v9

    if-gtz v0, :cond_177

    goto :goto_179

    :cond_177
    const/high16 v12, 0x3f800000  # 1.0f

    :goto_179
    const/4 v13, 0x0

    invoke-virtual {v8, v13}, Landroid/view/View;->setTranslationX(F)V

    const/4 v13, 0x0

    invoke-virtual {v8, v13}, Landroid/view/View;->setTranslationY(F)V

    invoke-virtual {v8, v9}, Landroid/view/View;->setAlpha(F)V

    const/high16 v0, 0x3f800000  # 1.0f

    invoke-virtual {v8, v0}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v8, v0}, Landroid/view/View;->setScaleY(F)V

    const-string v8, "inv_media_title"

    invoke-direct {p0, v8}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v8

    if-eqz v8, :cond_1a0

    const/4 v13, 0x0

    invoke-virtual {v8, v13}, Landroid/view/View;->setTranslationX(F)V

    invoke-virtual {v8, v13}, Landroid/view/View;->setTranslationY(F)V

    const/high16 v13, 0x3f800000  # 1.0f

    invoke-virtual {v8, v13}, Landroid/view/View;->setAlpha(F)V

    :cond_1a0
    const-string v8, "inv_media_artist"

    invoke-direct {p0, v8}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v8

    if-eqz v8, :cond_1b4

    const/4 v13, 0x0

    invoke-virtual {v8, v13}, Landroid/view/View;->setTranslationX(F)V

    invoke-virtual {v8, v13}, Landroid/view/View;->setTranslationY(F)V

    const/high16 v13, 0x3f800000  # 1.0f

    invoke-virtual {v8, v13}, Landroid/view/View;->setAlpha(F)V

    :cond_1b4
    const-string v8, "inv_equalizer_icon"

    invoke-direct {p0, v8}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v8

    if-eqz v8, :cond_1de

    const/4 v12, 0x0

    invoke-virtual {v8, v12}, Landroid/view/View;->setTranslationX(F)V

    const/16 v12, -0x34

    invoke-direct {p0, v12}, Linv/systemui/dynamic/InvDynamicIslandView;->dp(I)I

    move-result v12

    int-to-float v12, v12

    mul-float/2addr v12, p1

    invoke-virtual {v8, v12}, Landroid/view/View;->setTranslationY(F)V

    const v12, 0x3f75c28f  # 0.96f

    const v13, 0x3d23d70a  # 0.04f

    mul-float/2addr v13, p1

    add-float/2addr v12, v13

    invoke-virtual {v8, v12}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v8, v12}, Landroid/view/View;->setScaleY(F)V

    const/high16 v13, 0x3f800000  # 1.0f

    invoke-virtual {v8, v13}, Landroid/view/View;->setAlpha(F)V

    :cond_1de
    return-void
.end method

.method public clearMedia()V
    .registers 3

    const/4 v0, 0x0

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mTitle:Ljava/lang/String;

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mArtist:Ljava/lang/String;

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mAlbumArt:Landroid/graphics/Bitmap;

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mDuration:J

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    invoke-virtual {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->hideExpandedWindow()V

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v0, :cond_19

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showRecordCollapsedPill()V

    return-void

    :cond_19
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showIdleCollapsed()V

    return-void
.end method

.method public forceRemoveExpandedWindow()V
    .registers 4

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedRoot:Landroid/view/View;

    if-eqz v0, :cond_12

    :try_start_4
    iget-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mWindowManager:Landroid/view/WindowManager;

    if-eqz v1, :cond_b

    invoke-interface {v1, v0}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V

    :cond_b
    const/4 v0, 0x0

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedRoot:Landroid/view/View;
    :try_end_e
    .catch Ljava/lang/Throwable; {:try_start_4 .. :try_end_e} :catch_f

    goto :goto_12

    :catch_f
    const/4 v0, 0x0

    iput-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedRoot:Landroid/view/View;

    :cond_12
    :goto_12
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->setStatusBarIconsHiddenForIsland(Z)V

    const/high16 v0, 0x3f800000  # 1.0f

    invoke-virtual {p0, v0}, Landroid/view/View;->setAlpha(F)V

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mKeepSharedMediaCollapse:Z

    if-eqz v0, :cond_34

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mKeepSharedMediaCollapse:Z

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordStart:J

    iput-wide v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPauseBase:J

    iput-wide v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPausedTotal:J

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPaused:Z

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->stopRecordTimerLoop()V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showMediaCollapsed()V

    return-void

    :cond_34
    iget v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mCurrentState:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_47

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHideAfterCollapse:Z

    if-eqz v0, :cond_44

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHideAfterCollapse:Z

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showIdleCollapsed()V

    goto :goto_47

    :cond_44
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showMediaCollapsed()V

    :cond_47
    :goto_47
    return-void
.end method

.method public handleBatteryChanged(Landroid/content/Intent;)V
    .registers 8

    if-eqz p1, :cond_5b

    const-string v0, "status"

    const/4 v1, -0x1

    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const/4 v2, 0x2

    if-eq v0, v2, :cond_11

    const/4 v2, 0x5

    if-eq v0, v2, :cond_11

    const/4 v2, 0x0

    goto :goto_12

    :cond_11
    const/4 v2, 0x1

    :goto_12
    const-string v0, "level"

    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const-string v3, "scale"

    const/16 v4, 0x64

    invoke-virtual {p1, v3, v4}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v3

    if-ltz v0, :cond_28

    if-lez v3, :cond_28

    mul-int/lit8 v0, v0, 0x64

    div-int/2addr v0, v3

    goto :goto_2a

    :cond_28
    iget v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPercent:I

    :goto_2a
    if-eqz v2, :cond_3d

    const/4 v3, 0x0

    iput-boolean v3, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mLowBatteryAlertShown:Z

    iget-boolean v3, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPlugged:Z

    if-nez v3, :cond_3a

    const/4 v3, 0x1

    iput-boolean v3, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPlugged:Z

    invoke-direct {p0, v3, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->applyChargingNotification(ZI)V

    return-void

    :cond_3a
    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPercent:I

    goto :goto_5b

    :cond_3d
    const/16 v4, 0x15

    if-ge v0, v4, :cond_4e

    iget-boolean v5, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mLowBatteryAlertShown:Z

    if-nez v5, :cond_51

    const/4 v5, 0x1

    iput-boolean v5, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mLowBatteryAlertShown:Z

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPercent:I

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showLowBatteryCollapsed()V

    goto :goto_51

    :cond_4e
    const/4 v5, 0x0

    iput-boolean v5, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mLowBatteryAlertShown:Z

    :cond_51
    :goto_51
    iget-boolean v3, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPlugged:Z

    if-eqz v3, :cond_5b

    const/4 v3, 0x0

    iput-boolean v3, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPlugged:Z

    invoke-direct {p0, v3, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->applyChargingNotification(ZI)V

    :cond_5b
    :goto_5b
    return-void
.end method

.method public hideExpandedWindow()V
    .registers 5

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->setStatusBarIconsHiddenForIsland(Z)V

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedRoot:Landroid/view/View;

    if-eqz v0, :cond_52

    instance-of v1, v0, Linv/systemui/dynamic/InvDynamicIslandView;

    if-eqz v1, :cond_4e

    check-cast v0, Linv/systemui/dynamic/InvDynamicIslandView;

    iget v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    const/4 v2, 0x3

    if-ne v1, v2, :cond_17

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->restorePowerNoticeState()V

    goto :goto_40

    :cond_17
    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHideAfterCollapse:Z

    if-eqz v1, :cond_28

    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/ViewPropertyAnimator;->cancel()V

    const/high16 v1, 0x3f800000  # 1.0f

    invoke-virtual {v0, v1}, Landroid/view/View;->setAlpha(F)V

    goto :goto_40

    :cond_28
    const/high16 v1, 0x3f800000  # 1.0f

    invoke-virtual {p0, v1}, Landroid/view/View;->setAlpha(F)V

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v1, :cond_3d

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    if-eqz v1, :cond_39

    iget-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-eqz v1, :cond_3d

    :cond_39
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showRecordCollapsedPill()V

    goto :goto_40

    :cond_3d
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showMediaCollapsed()V

    :goto_40
    invoke-virtual {v0}, Linv/systemui/dynamic/InvDynamicIslandView;->morphToCollapsed()V

    new-instance v1, Linv/systemui/dynamic/InvDynamicIslandView$CollapseRemoveRunnable;

    invoke-direct {v1, p0}, Linv/systemui/dynamic/InvDynamicIslandView$CollapseRemoveRunnable;-><init>(Linv/systemui/dynamic/InvDynamicIslandView;)V

    const-wide/16 v2, 0x2d0

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_4e
    invoke-virtual {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->forceRemoveExpandedWindow()V

    return-void

    :cond_52
    const/high16 v0, 0x3f800000  # 1.0f

    invoke-virtual {p0, v0}, Landroid/view/View;->setAlpha(F)V

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHideAfterCollapse:Z

    if-eqz v0, :cond_62

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHideAfterCollapse:Z

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showIdleCollapsed()V

    goto :goto_7e

    :cond_62
    iget v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_6b

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->restorePowerNoticeState()V

    goto :goto_7e

    :cond_6b
    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v0, :cond_7b

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    if-eqz v0, :cond_77

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-eqz v0, :cond_7b

    :cond_77
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showRecordCollapsedPill()V

    goto :goto_7e

    :cond_7b
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showMediaCollapsed()V

    :goto_7e
    return-void
.end method

.method public hideExpandedWindowSmart()V
    .registers 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHideAfterCollapse:Z

    invoke-virtual {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->hideExpandedWindow()V

    return-void
.end method

.method public morphToCollapsed()V
    .registers 4

    const/4 v0, 0x1

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mCurrentState:I

    iget v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_16

    const-string v0, "inv_power_notice_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_15

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_15
    goto :goto_55

    :cond_16
    const/4 v1, 0x2

    if-ne v0, v1, :cond_55

    const-string v0, "inv_expanded_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_26

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_26
    const-string v0, "inv_collapsed_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_33

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_33
    const-string v0, "inv_record_expanded_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_47

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/high16 v2, 0x3f800000  # 1.0f

    invoke-virtual {v0, v2}, Landroid/view/View;->setAlpha(F)V

    invoke-virtual {v0}, Landroid/view/View;->bringToFront()V

    :cond_47
    const-string v0, "inv_second_bubble"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_77

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    goto :goto_77

    :cond_55
    :goto_55
    const-string v0, "inv_collapsed_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_66

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/high16 v2, 0x3f800000  # 1.0f

    invoke-virtual {v0, v2}, Landroid/view/View;->setAlpha(F)V

    :cond_66
    const-string v0, "inv_expanded_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_77

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/high16 v2, 0x3f800000  # 1.0f

    invoke-virtual {v0, v2}, Landroid/view/View;->setAlpha(F)V

    :cond_77
    :goto_77
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->startSpringMorph(Z)V

    return-void
.end method

.method public morphToExpanded()V
    .registers 5

    const/4 v0, 0x2

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mCurrentState:I

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->bindExpandedContent()V

    iget v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mExpandedMode:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_1f

    iget v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPercent:I

    iget-boolean v2, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingPlugged:Z

    if-eqz v2, :cond_13

    const/4 v2, 0x0

    goto :goto_14

    :cond_13
    const/4 v2, 0x1

    :goto_14
    invoke-direct {p0, v2, v1}, Linv/systemui/dynamic/InvDynamicIslandView;->updatePowerNoticeText(ZI)V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showChargingPowerContent()V

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->startSpringMorph(Z)V

    return-void

    :cond_1f
    const/4 v1, 0x2

    if-ne v0, v1, :cond_74

    const-string v0, "inv_collapsed_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_2f

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_2f
    const-string v0, "inv_expanded_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_3c

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_3c
    const-string v0, "inv_record_expanded_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_99

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setAlpha(F)V

    const v2, 0x3f7ae148  # 0.98f

    invoke-virtual {v0, v2}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setScaleY(F)V

    invoke-virtual {v0}, Landroid/view/View;->bringToFront()V

    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v3

    const/high16 v2, 0x3f800000  # 1.0f

    invoke-virtual {v3, v2}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v3

    invoke-virtual {v3, v2}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v3

    invoke-virtual {v3, v2}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v3

    const-wide/16 v1, 0xb4

    invoke-virtual {v3, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/ViewPropertyAnimator;->start()V

    goto :goto_99

    :cond_74
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->hideRecordExpandedContent()V

    const-string v0, "inv_collapsed_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_88

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/high16 v2, 0x3f800000  # 1.0f

    invoke-virtual {v0, v2}, Landroid/view/View;->setAlpha(F)V

    :cond_88
    const-string v0, "inv_expanded_content"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_99

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/high16 v1, 0x3f800000  # 1.0f

    invoke-virtual {v0, v1}, Landroid/view/View;->setAlpha(F)V

    :cond_99
    :goto_99
    const/4 v0, 0x1

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->startSpringMorph(Z)V

    return-void
.end method

.method protected onAttachedToWindow()V
    .registers 2

    invoke-super {p0}, Landroid/widget/FrameLayout;->onAttachedToWindow()V

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mIsExpandedWindow:Z

    if-nez v0, :cond_e

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Linv/systemui/dynamic/InvProjectionRecordDetector;->init(Landroid/content/Context;)V

    :cond_e
    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mIsExpandedWindow:Z

    if-nez v0, :cond_21

    sget-object v0, Linv/systemui/dynamic/InvDynamicIslandView;->sViews:Ljava/util/ArrayList;

    if-eqz v0, :cond_21

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_21

    sget-object v0, Linv/systemui/dynamic/InvDynamicIslandView;->sViews:Ljava/util/ArrayList;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_21
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->registerBatteryReceiver()V

    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .registers 6

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingActive:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    const-string v0, "inv_record_stop"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_13

    if-ne p1, v0, :cond_13

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->stopScreenRecordingFromIsland()V

    return-void

    :cond_13
    const-string v0, "inv_album_collapsed"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_2c

    if-ne p1, v0, :cond_2c

    iget-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHost:Linv/systemui/dynamic/InvDynamicIslandView;

    if-eqz v1, :cond_25

    invoke-virtual {v1}, Linv/systemui/dynamic/InvDynamicIslandView;->hideExpandedWindowSmart()V

    goto :goto_28

    :cond_25
    invoke-virtual {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->hideExpandedWindowSmart()V

    :goto_28
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->openCurrentMediaApp()V

    return-void

    :cond_2c
    const-string v0, "inv_media_prev"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_3c

    if-ne p1, v0, :cond_3c

    const/16 v0, 0x58

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->sendMediaKey(I)V

    return-void

    :cond_3c
    const-string v0, "inv_media_play_pause"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_4c

    if-ne p1, v0, :cond_4c

    const/16 v0, 0x55

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->sendMediaKey(I)V

    return-void

    :cond_4c
    const-string v0, "inv_media_next"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_5c

    if-ne p1, v0, :cond_5c

    const/16 v0, 0x57

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->sendMediaKey(I)V

    return-void

    :cond_5c
    const-string v0, "inv_second_bubble"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_6a

    if-ne p1, v0, :cond_6a

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->openRecordExpandedFromBubble()V

    return-void

    :cond_6a
    const-string v0, "inv_record_dot"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_78

    if-ne p1, v0, :cond_78

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->openRecordExpandedFromPill()V

    return-void

    :cond_78
    const-string v0, "inv_record_time_collapsed"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_86

    if-ne p1, v0, :cond_86

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->openRecordExpandedFromPill()V

    return-void

    :cond_86
    const-string v0, "inv_island_panel"

    invoke-direct {p0, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->find(Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    const/4 v1, 0x1

    if-eqz v0, :cond_aa

    if-ne p1, v0, :cond_aa

    iget-boolean v2, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mIsExpandedWindow:Z

    if-eqz v2, :cond_96

    return-void

    :cond_96
    iget-boolean v2, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    if-eqz v2, :cond_9e

    iget-boolean v2, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-eqz v2, :cond_a6

    :cond_9e
    iget-boolean v2, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v2, :cond_c9

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->openRecordExpandedFromPill()V

    return-void

    :cond_a6
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->openMediaExpanded()V

    return-void

    :cond_aa
    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mIsExpandedWindow:Z

    if-eqz v0, :cond_b6

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHost:Linv/systemui/dynamic/InvDynamicIslandView;

    if-eqz v0, :cond_c9

    invoke-virtual {v0}, Linv/systemui/dynamic/InvDynamicIslandView;->hideExpandedWindowSmart()V

    return-void

    :cond_b6
    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    if-eqz v0, :cond_be

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-eqz v0, :cond_c6

    :cond_be
    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v0, :cond_c9

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->openRecordExpandedFromPill()V

    return-void

    :cond_c6
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->openMediaExpanded()V

    :cond_c9
    return-void
.end method

.method protected onDetachedFromWindow()V
    .registers 2

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->unregisterBatteryReceiver()V

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mIsExpandedWindow:Z

    if-nez v0, :cond_11

    invoke-virtual {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->hideExpandedWindow()V

    sget-object v0, Linv/systemui/dynamic/InvDynamicIslandView;->sViews:Ljava/util/ArrayList;

    if-eqz v0, :cond_11

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :cond_11
    invoke-super {p0}, Landroid/widget/FrameLayout;->onDetachedFromWindow()V

    return-void
.end method

.method public performPauseHideIfStillPaused()V
    .registers 3

    iget v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseTicks:I

    if-lez v0, :cond_5

    goto :goto_6

    :cond_5
    return-void

    :goto_6
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->isPlaybackCurrentlyPlaying()Z

    move-result v0

    if-eqz v0, :cond_17

    const/4 v0, 0x0

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseTicks:I

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHideAfterCollapse:Z

    const/4 v0, 0x1

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    return-void

    :cond_17
    const/4 v0, 0x0

    iput v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseTicks:I

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->stopEqualizerNow()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    iget v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mCurrentState:I

    if-eqz v0, :cond_3c

    const/4 v1, 0x1

    iput-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    iput-boolean v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHideAfterCollapse:Z

    const/4 v1, 0x2

    if-ne v0, v1, :cond_30

    invoke-virtual {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->hideExpandedWindow()V

    return-void

    :cond_30
    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v0, :cond_38

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showRecordCollapsedPill()V

    return-void

    :cond_38
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showIdleCollapsed()V

    return-void

    :cond_3c
    const/4 v0, 0x1

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    return-void
.end method

.method public runChargingHide()V
    .registers 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mChargingActive:Z

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->restorePowerNoticeState()V

    return-void
.end method

.method public runMediaProgressTick()V
    .registers 5

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->updateTimeViews()V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->updateRecordTimeViews()V

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mHandler:Landroid/os/Handler;

    if-eqz v0, :cond_13

    iget-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mProgressRunnable:Ljava/lang/Runnable;

    if-eqz v1, :cond_13

    const-wide/16 v2, 0x20

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_13
    return-void
.end method

.method public runRecordTimerTick()V
    .registers 2

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->updateRecordTimeViews()V

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v0, :cond_f

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordPaused:Z

    if-eqz v0, :cond_c

    goto :goto_f

    :cond_c
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->startRecordTimerLoop()V

    :cond_f
    :goto_f
    return-void
.end method

.method public seekToProgress(I)V
    .registers 5

    :try_start_0
    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaManager:Lcom/android/systemui/statusbar/NotificationMediaManager;

    if-eqz v0, :cond_b

    int-to-long v1, p1

    invoke-virtual {v0, v1, v2}, Lcom/android/systemui/statusbar/NotificationMediaManager;->seekToPosition(J)V

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->updateTimeViews()V
    :try_end_b
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_b} :catch_c

    :cond_b
    return-void

    :catch_c
    return-void
.end method

.method public showMedia()V
    .registers 2

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mMediaActive:Z

    if-eqz v0, :cond_8

    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mPauseHiddenUntilPlay:Z

    if-eqz v0, :cond_14

    :cond_8
    iget-boolean v0, p0, Linv/systemui/dynamic/InvDynamicIslandView;->mRecordActive:Z

    if-eqz v0, :cond_10

    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showRecordCollapsedPill()V

    return-void

    :cond_10
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showIdleCollapsed()V

    return-void

    :cond_14
    invoke-direct {p0}, Linv/systemui/dynamic/InvDynamicIslandView;->showMediaCollapsed()V

    return-void
.end method
