# classes2.dex

.class public Linv/systemui/dynamic/InvDynamicIslandView$MorphUpdateListener;
.super Ljava/lang/Object;
.source "InvDynamicIslandView.java"

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# instance fields
.field private mView:Linv/systemui/dynamic/InvDynamicIslandView;


# direct methods
.method public constructor <init>(Linv/systemui/dynamic/InvDynamicIslandView;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/systemui/dynamic/InvDynamicIslandView$MorphUpdateListener;->mView:Linv/systemui/dynamic/InvDynamicIslandView;

    return-void
.end method


# virtual methods
.method public onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .registers 4

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object p1

    instance-of v0, p1, Ljava/lang/Float;

    if-eqz v0, :cond_15

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result v0

    iget-object v1, p0, Linv/systemui/dynamic/InvDynamicIslandView$MorphUpdateListener;->mView:Linv/systemui/dynamic/InvDynamicIslandView;

    if-eqz v1, :cond_15

    invoke-virtual {v1, v0}, Linv/systemui/dynamic/InvDynamicIslandView;->applyMorphProgress(F)V

    :cond_15
    return-void
.end method
