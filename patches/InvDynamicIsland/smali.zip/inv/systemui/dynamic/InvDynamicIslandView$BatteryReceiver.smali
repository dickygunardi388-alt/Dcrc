# classes2.dex

.class final Linv/systemui/dynamic/InvDynamicIslandView$BatteryReceiver;
.super Landroid/content/BroadcastReceiver;
.source "InvDynamicIslandView.java"


# instance fields
.field private final mHost:Linv/systemui/dynamic/InvDynamicIslandView;


# direct methods
.method constructor <init>(Linv/systemui/dynamic/InvDynamicIslandView;)V
    .registers 2

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    iput-object p1, p0, Linv/systemui/dynamic/InvDynamicIslandView$BatteryReceiver;->mHost:Linv/systemui/dynamic/InvDynamicIslandView;

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 3

    iget-object p1, p0, Linv/systemui/dynamic/InvDynamicIslandView$BatteryReceiver;->mHost:Linv/systemui/dynamic/InvDynamicIslandView;

    if-eqz p1, :cond_7

    invoke-virtual {p1, p2}, Linv/systemui/dynamic/InvDynamicIslandView;->handleBatteryChanged(Landroid/content/Intent;)V

    :cond_7
    return-void
.end method
