# classes2.dex

.class public Linv/systemui/dynamic/InvProjectionRecordDetector;
.super Landroid/media/projection/MediaProjectionManager$Callback;
.source "InvProjectionRecordDetector.java"


# static fields
.field private static sCallback:Linv/systemui/dynamic/InvProjectionRecordDetector;

.field private static sManager:Landroid/media/projection/MediaProjectionManager;

.field private static sRegistered:Z


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/media/projection/MediaProjectionManager$Callback;-><init>()V

    return-void
.end method

.method public static init(Landroid/content/Context;)V
    .registers 6

    sget-boolean v0, Linv/systemui/dynamic/InvProjectionRecordDetector;->sRegistered:Z

    if-nez v0, :cond_38

    if-eqz p0, :cond_38

    :try_start_6
    const-string v0, "media_projection"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/projection/MediaProjectionManager;

    if-eqz v0, :cond_38

    sput-object v0, Linv/systemui/dynamic/InvProjectionRecordDetector;->sManager:Landroid/media/projection/MediaProjectionManager;

    new-instance v1, Linv/systemui/dynamic/InvProjectionRecordDetector;

    invoke-direct {v1}, Linv/systemui/dynamic/InvProjectionRecordDetector;-><init>()V

    sput-object v1, Linv/systemui/dynamic/InvProjectionRecordDetector;->sCallback:Linv/systemui/dynamic/InvProjectionRecordDetector;

    new-instance v2, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    invoke-virtual {v0, v1, v2}, Landroid/media/projection/MediaProjectionManager;->addCallback(Landroid/media/projection/MediaProjectionManager$Callback;Landroid/os/Handler;)V

    const/4 v0, 0x1

    sput-boolean v0, Linv/systemui/dynamic/InvProjectionRecordDetector;->sRegistered:Z

    const-string v0, "InvProjectionRecord"

    const-string v1, "MediaProjection callback registered"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_2f
    .catch Ljava/lang/Throwable; {:try_start_6 .. :try_end_2f} :catch_30

    goto :goto_38

    :catch_30
    move-exception v0

    const-string v1, "InvProjectionRecord"

    const-string v2, "register failed"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_38
    :goto_38
    return-void
.end method


# virtual methods
.method public onStart(Landroid/media/projection/MediaProjectionInfo;)V
    .registers 4

    const-string v0, "InvProjectionRecord"

    const-string v1, "projection start"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x1

    invoke-static {v0}, Linv/systemui/dynamic/InvDynamicIslandView;->dispatchScreenRecord(Z)V

    return-void
.end method

.method public onStop(Landroid/media/projection/MediaProjectionInfo;)V
    .registers 4

    const-string v0, "InvProjectionRecord"

    const-string v1, "projection stop"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v0, 0x0

    invoke-static {v0}, Linv/systemui/dynamic/InvDynamicIslandView;->dispatchScreenRecord(Z)V

    return-void
.end method
