# classes2.dex

.class final Linv/systemui/dynamic/InvDynamicIslandView$RecordTimerRunnable;
.super Ljava/lang/Object;
.source "InvDynamicIslandView.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic this$0:Linv/systemui/dynamic/InvDynamicIslandView;


# direct methods
.method constructor <init>(Linv/systemui/dynamic/InvDynamicIslandView;)V
    .registers 2

    iput-object p1, p0, Linv/systemui/dynamic/InvDynamicIslandView$RecordTimerRunnable;->this$0:Linv/systemui/dynamic/InvDynamicIslandView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 2

    iget-object v0, p0, Linv/systemui/dynamic/InvDynamicIslandView$RecordTimerRunnable;->this$0:Linv/systemui/dynamic/InvDynamicIslandView;

    invoke-virtual {v0}, Linv/systemui/dynamic/InvDynamicIslandView;->runRecordTimerTick()V

    return-void
.end method
