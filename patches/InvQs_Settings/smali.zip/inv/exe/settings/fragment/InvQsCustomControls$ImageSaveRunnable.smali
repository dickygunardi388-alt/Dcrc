# classes2.dex

.class public Linv/exe/settings/fragment/InvQsCustomControls$ImageSaveRunnable;
.super Ljava/lang/Object;
.source "InvQsCustomControls.java"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final mContext:Landroid/content/Context;

.field private final mUri:Landroid/net/Uri;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/net/Uri;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Linv/exe/settings/fragment/InvQsCustomControls$ImageSaveRunnable;->mContext:Landroid/content/Context;

    iput-object p2, p0, Linv/exe/settings/fragment/InvQsCustomControls$ImageSaveRunnable;->mUri:Landroid/net/Uri;

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    iget-object v0, p0, Linv/exe/settings/fragment/InvQsCustomControls$ImageSaveRunnable;->mContext:Landroid/content/Context;

    iget-object v1, p0, Linv/exe/settings/fragment/InvQsCustomControls$ImageSaveRunnable;->mUri:Landroid/net/Uri;

    invoke-static {v0, v1}, Linv/exe/settings/fragment/InvQsCustomControls;->setImage(Landroid/content/Context;Landroid/net/Uri;)Z

    return-void
.end method
